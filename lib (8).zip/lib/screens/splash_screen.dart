// ignore_for_file: use_build_context_synchronously

import 'dart:async';
import 'dart:math';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:doctor_car_app/screens/login_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  final Random random = Random();

  late AnimationController glowCtrl;
  late AnimationController flashCtrl;
  late AnimationController shakeCtrl;
  late AnimationController glitchCtrl;
  late AnimationController zoomCtrl;
  late AnimationController sparkCtrl;
  late AnimationController shockwaveCtrl;

  @override
  void initState() {
    super.initState();

    // ----------------------------------------------------
    // 🔥 Better Animation Durations + Stability
    // ----------------------------------------------------
    glowCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat(reverse: true);

    flashCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..forward();

    shakeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    )..repeat(reverse: true);

    glitchCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 280),
    )..repeat();

    zoomCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
      upperBound: 1.08,
      lowerBound: 0.92,
    )..forward();

    sparkCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    )..repeat();

    shockwaveCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..forward();

    // ----------------------------------------------------
    // ⚡ Navigation FIX + Clean + Safe
    // ----------------------------------------------------
    Future.delayed(const Duration(seconds: 4), () {
      if (!mounted) return;

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const LoginScreen()),
      );
    });
  }

  @override
  void dispose() {
    glowCtrl.dispose();
    flashCtrl.dispose();
    shakeCtrl.dispose();
    glitchCtrl.dispose();
    zoomCtrl.dispose();
    sparkCtrl.dispose();
    shockwaveCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final animations = [
      glowCtrl,
      flashCtrl,
      shakeCtrl,
      glitchCtrl,
      zoomCtrl,
      sparkCtrl,
      shockwaveCtrl
    ];

    return Scaffold(
      backgroundColor: Colors.black,
      body: AnimatedBuilder(
        animation: Listenable.merge(animations),
        builder: (_, __) {
          final shakeX = (shakeCtrl.value - 0.5) * 8;
          final glitchOffset = (glitchCtrl.value - 0.5) * 10;

          return Stack(
            alignment: Alignment.center,
            children: [
              _buildBackground(),
              _buildShockwave(),
              _buildFog(),
              _buildScanlines(),
              _buildParticles(),
              _buildSparks(),
              _buildFlash(),

              // ----------------------------------------------------
              // LOGO + Glow + Shake + Glitch + Zoom
              // ----------------------------------------------------
              Transform.translate(
                offset: Offset(shakeX + glitchOffset, 0),
                child: ScaleTransition(
                  scale: zoomCtrl,
                  child: CustomPaint(
                    painter: _LogoGlowPainter(glowCtrl.value),
                    child: Image.asset(
                      "assets/images/logo_doctorcar.png",
                      width: 280,
                    ),
                  ),
                ),
              ),

              _buildElectricFrame(),

              // ----------------------------------------------------
              // TITLE
              // ----------------------------------------------------
              Positioned(
                bottom: 110,
                child: Text(
                  "Doctor Car",
                  style: TextStyle(
                    fontSize: 36,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    shadows: [
                      Shadow(
                        color: Colors.blueAccent.withOpacity(0.8),
                        blurRadius: 22,
                      ),
                      Shadow(
                        color: Colors.orangeAccent.withOpacity(0.6),
                        blurRadius: 35,
                      ),
                    ],
                  ),
                ),
              ),

              const Positioned(
                bottom: 35,
                child: CircularProgressIndicator(
                  color: Colors.orangeAccent,
                  strokeWidth: 4,
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  // --------------------------------------------------------
  // EFFECT WIDGETS
  // --------------------------------------------------------

  Widget _buildBackground() {
    return Container(
      decoration: BoxDecoration(
        gradient: RadialGradient(
          radius: 1.3,
          colors: [
            Colors.black,
            Colors.blue.shade900.withOpacity(.25),
            Colors.orange.shade600.withOpacity(.12),
          ],
        ),
      ),
    );
  }

  Widget _buildFog() {
    return BackdropFilter(
      filter: ImageFilter.blur(sigmaX: 18, sigmaY: 12),
      child: Container(color: Colors.transparent),
    );
  }

  Widget _buildScanlines() {
    return CustomPaint(
      painter: _ScanlinePainter(),
    );
  }

  Widget _buildFlash() {
    return Opacity(
      opacity: (1 - flashCtrl.value).clamp(0.0, 1.0),
      child: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            colors: [Colors.white, Colors.transparent],
          ),
        ),
      ),
    );
  }

  Widget _buildShockwave() {
    return CustomPaint(
      painter: _ShockwavePainter(shockwaveCtrl.value),
    );
  }

  Widget _buildElectricFrame() {
    return CustomPaint(
      painter: _ElectricFramePainter(glitchCtrl.value),
    );
  }

  Widget _buildParticles() {
    return CustomPaint(
      painter: _ParticlePainter(random, glowCtrl.value),
    );
  }

  Widget _buildSparks() {
    return CustomPaint(
      painter: _ElectricSparksPainter(sparkCtrl.value, random),
    );
  }
}

// -------------------------------------------------------------
// PAINTERS
// -------------------------------------------------------------

class _LogoGlowPainter extends CustomPainter {
  final double value;
  _LogoGlowPainter(this.value);

  @override
  void paint(Canvas canvas, Size size) {
    final glowPaint = Paint()
      ..color = Colors.blueAccent.withOpacity(.8)
      ..maskFilter = const MaskFilter.blur(BlurStyle.outer, 45);

    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Offset.zero & size,
        const Radius.circular(200),
      ),
      glowPaint,
    );
  }

  @override
  bool shouldRepaint(_) => true;
}

class _ScanlinePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = Colors.white.withOpacity(.03)
      ..strokeWidth = 1;

    for (double y = 0; y < size.height; y += 4) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
    }
  }

  @override
  bool shouldRepaint(_) => false;
}

class _ShockwavePainter extends CustomPainter {
  final double t;
  _ShockwavePainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final radius = t * 600;

    final paint = Paint()
      ..color = Colors.blueAccent.withOpacity(1 - t)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 6 * (1 - t);

    canvas.drawCircle(
      Offset(size.width / 2, size.height / 2 + 40),
      radius,
      paint,
    );
  }

  @override
  bool shouldRepaint(_) => true;
}

class _ElectricFramePainter extends CustomPainter {
  final double noise;
  _ElectricFramePainter(this.noise);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.cyanAccent.withOpacity(.5)
      ..strokeWidth = 3
      ..style = PaintingStyle.stroke;

    final rect = Rect.fromLTWH(40, 80, size.width - 80, size.height - 200);

    canvas.drawRRect(
      RRect.fromRectAndRadius(rect, const Radius.circular(30)),
      paint,
    );
  }

  @override
  bool shouldRepaint(_) => true;
}

class _ParticlePainter extends CustomPainter {
  final Random random;
  final double pulse;
  _ParticlePainter(this.random, this.pulse);

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = Colors.orangeAccent.withOpacity(.7)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5);

    for (int i = 0; i < 70; i++) {
      final x = random.nextDouble() * size.width;
      final y = random.nextDouble() * size.height;
      final r = random.nextDouble() * 3;
      canvas.drawCircle(Offset(x, y), r, p);
    }
  }

  @override
  bool shouldRepaint(_) => true;
}

class _ElectricSparksPainter extends CustomPainter {
  final double t;
  final Random random;

  _ElectricSparksPainter(this.t, this.random);

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = Colors.blueAccent.withOpacity(.8)
      ..strokeWidth = 2;

    for (int i = 0; i < 10; i++) {
      final x1 = random.nextDouble() * size.width;
      final y1 = size.height * 0.65 + random.nextDouble() * 60;

      final x2 = x1 + random.nextDouble() * 30 - 15;
      final y2 = y1 + random.nextDouble() * 30 - 15;

      canvas.drawLine(Offset(x1, y1), Offset(x2, y2), p);
    }
  }

  @override
  bool shouldRepaint(_) => true;
}
