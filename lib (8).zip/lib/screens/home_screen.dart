// ignore_for_file: depend_on_referenced_packages, use_build_context_synchronously

import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;

// WIDGETS
// ignore: unused_import
import '../widgets/siri_button.dart';

// SCREENS
import 'chat_screen.dart';
import 'about_screen.dart';
import 'contact_screen.dart';
import 'road_services_screen.dart';
import 'settings_screen.dart';
import 'account_settings_screen.dart';
import 'smart_accident_screen.dart';
import 'previous_services_screen.dart';
import 'supplementary_services_screen.dart';
import 'searching_technician_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  // ======================================================
  // AI SYSTEM
  // ======================================================

  final TextEditingController _searchController = TextEditingController();

  final String openAIApiKey =
      "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";

  Future<String?> aiDiagnose(String problem) async {
    try {
      final res = await http.post(
        Uri.parse("https://api.openai.com/v1/chat/completions"),
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer $openAIApiKey",
        },
        body: jsonEncode({
          "model": "gpt-3.5-turbo",
          "messages": [
            {
              "role": "system",
              "content": "You are a professional automotive AI assistant."
            },
            {"role": "user", "content": problem}
          ]
        }),
      );

      if (res.statusCode != 200) return null;

      return jsonDecode(res.body)["choices"][0]["message"]["content"];
    } catch (_) {
      return null;
    }
  }

  // تشغيل الذكاء الاصطناعي
  void runSearchAI() async {
    final query = _searchController.text.trim();
    if (query.isEmpty) {
      toast("❗ اكتب مشكلتك أولاً");
      return;
    }

    FocusScope.of(context).unfocus();
    showLoading();

    final result = await aiDiagnose(query);

    Navigator.pop(context);

    if (result == null) {
      showResult("⚠ خطأ في الاتصال بالذكاء الاصطناعي");
      return;
    }

    showResult(result);

    Future.delayed(const Duration(seconds: 2), () {
      openTracking(result);
    });
  }

  void toast(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      duration: const Duration(seconds: 2),
    ));
  }

  void showLoading() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => Center(
        child: Container(
          padding: const EdgeInsets.all(25),
          decoration: BoxDecoration(
            color: Colors.black87,
            borderRadius: BorderRadius.circular(15),
          ),
          child: const Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(color: Colors.blueAccent),
              SizedBox(height: 18),
              Text("جاري التحليل...", style: TextStyle(color: Colors.white))
            ],
          ),
        ),
      ),
    );
  }

  void showResult(String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xff0D1A33),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: Text("نتيجة التحليل",
            style: GoogleFonts.cairo(color: Colors.white)),
        content: Text(msg,
            style: GoogleFonts.cairo(
                color: const Color.fromARGB(179, 120, 139, 208), height: 1.4)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("متابعة",
                style: GoogleFonts.cairo(color: Colors.blueAccent)),
          )
        ],
      ),
    );
  }

  void openTracking(String type) {
    final id = "ORDER_${DateTime.now().millisecondsSinceEpoch}";
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => SearchingTechnicianScreen(
          userId: "USER01",
          serviceType: type,
          lat: 31.4175,
          lng: 31.8153,
          orderId: id,
        ),
      ),
    );
  }

  // ======================================================
  // THEME
  // ======================================================
  bool drawerOpen = false;
  bool isArabic = true;

  Color get accent => const Color(0xff3D8BFF);
  Color get accentLight => const Color(0xff64A8FF);
  Color get primaryBg => const Color(0xff0A1124);

  late AnimationController waveCtrl;
  late AnimationController pulseCtrl;

  String t(String ar, String en) => isArabic ? ar : en;

  @override
  void initState() {
    super.initState();

    waveCtrl =
        AnimationController(vsync: this, duration: const Duration(seconds: 3))
          ..repeat(reverse: true);

    pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
      lowerBound: .9,
      upperBound: 1.10,
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    waveCtrl.dispose();
    pulseCtrl.dispose();
    super.dispose();
  }

  // ======================================================
  // UI SECTIONS
  // ======================================================

  Widget topHeader() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        GestureDetector(
            onTap: () => setState(() => drawerOpen = !drawerOpen),
            child: const Icon(Icons.menu, color: Colors.white, size: 30)),

        // Logo
        Row(
          children: [
            const Icon(Icons.directions_car,
                color: Color.fromARGB(255, 13, 105, 210), size: 30),
            const SizedBox(width: 6),
            Text("Doctor Car",
                style: GoogleFonts.cairo(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.white)),
          ],
        ),

        // Language + Theme
        Row(
          children: [
            IconButton(
              onPressed: () => setState(() => isArabic = !isArabic),
              icon: const Icon(Icons.language, color: Colors.white),
            ),
          ],
        ),
      ],
    );
  }

  // ----------------------
  // SEARCH BAR + CHAT + SIRI
  // ----------------------
  Widget searchWithButtons(double w) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: w * .06),
      child: Row(
        children: [
          // Siri
          GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const ChatScreen()),
              );
            },
            child: Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient:
                    const LinearGradient(colors: [Colors.blue, Colors.cyan]),
                boxShadow: [
                  BoxShadow(
                      color: Colors.blue.withOpacity(.4),
                      blurRadius: 14,
                      spreadRadius: 2)
                ],
              ),
              child: const Icon(Icons.mic, color: Colors.white),
            ),
          ),

          const SizedBox(width: 12),

          // Search Bar
          Expanded(
            child: Container(
              height: 55,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                border:
                    Border.all(color: accentLight.withOpacity(.7), width: 2),
                color: Colors.white.withOpacity(.06),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _searchController,
                      style: GoogleFonts.cairo(color: Colors.white),
                      decoration: InputDecoration(
                        hintText:
                            t("سجّل أو اكتب مشكلتك…", "Describe your issue…"),
                        hintStyle: GoogleFonts.cairo(color: Colors.white60),
                        border: InputBorder.none,
                      ),
                      onSubmitted: (_) => runSearchAI(),
                    ),
                  ),
                  GestureDetector(
                    onTap: runSearchAI,
                    child: Icon(Icons.search, color: accentLight, size: 30),
                  )
                ],
              ),
            ),
          ),

          const SizedBox(width: 12),

          // ChatGPT Button
          GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const ChatScreen()),
              );
            },
            child: Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white.withOpacity(.1),
                border: Border.all(
                    color: Colors.blueAccent.withOpacity(.7), width: 2),
              ),
              child: const Icon(Icons.chat, color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  // ----------------------
  // Frosted Button
  // ----------------------
  Widget frostedButton(String title, IconData icon, VoidCallback onTap) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(22),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
        child: GestureDetector(
          onTap: onTap,
          child: Container(
            height: 135,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22),
              color: Colors.white.withOpacity(.05),
              border: Border.all(color: accentLight.withOpacity(.6), width: 2),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, color: accentLight, size: 45),
                const SizedBox(height: 10),
                Text(title,
                    style: GoogleFonts.cairo(
                        fontSize: 21,
                        color: Colors.white,
                        fontWeight: FontWeight.bold)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ----------------------
  // Quick Button
  // ----------------------
  Widget quickBtn(IconData icon, String text, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            width: 75,
            height: 75,
            decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(colors: [accent, accentLight]),
                boxShadow: [
                  BoxShadow(
                      color: accent.withOpacity(.4),
                      blurRadius: 16,
                      spreadRadius: 3)
                ]),
            child: Icon(icon, color: Colors.white, size: 32),
          ),
          const SizedBox(height: 8),
          Text(text,
              style: GoogleFonts.cairo(color: Colors.white, fontSize: 20)),
        ],
      ),
    );
  }

  // ----------------------
  // Drawer Item
  // ----------------------
  Widget drawerItem(IconData icon, String text, VoidCallback onTap) {
    return InkWell(
      onTap: () {
        Navigator.pop(context);
        onTap();
      },
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 16),
        child: Row(
          children: [
            Icon(icon, size: 26, color: accentLight),
            const SizedBox(width: 10),
            Text(text,
                style: GoogleFonts.cairo(fontSize: 18, color: Colors.white)),
          ],
        ),
      ),
    );
  }

  // Drawer UI
  Widget drawer(double w) {
    return Container(
      width: w * .60,
      color: const Color(0xff0D1A33),
      padding: const EdgeInsets.only(top: 90, left: 22),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.directions_car, color: accentLight, size: 55),
          const SizedBox(height: 20),
          drawerItem(Icons.info, t("من نحن", "About"),
              () => goto(const AboutScreen())),
          drawerItem(Icons.phone, t("تواصل معنا", "Contact"),
              () => goto(const ContactScreen())),
          drawerItem(Icons.settings, t("الإعدادات", "Settings"),
              () => goto(const SettingsScreen())),
          drawerItem(Icons.history, t("السجل", "History"),
              () => goto(const PreviousServicesScreen())),
        ],
      ),
    );
  }

  void goto(Widget page) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }

  // ======================================================
  // PAGE CONTENT
  // ======================================================

  Widget buildContent(double w, double h) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.only(bottom: 200),
          child: Column(
            children: [
              const SizedBox(height: 10),

              topHeader(),

              const SizedBox(height: 20),

              Text(
                t("مساعدك الذكي للسيارة", "Your Smart Auto Assistant"),
                style: GoogleFonts.cairo(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.white),
              ),

              const SizedBox(height: 25),

              searchWithButtons(w),

              const SizedBox(height: 40),

              // أدوات رئيسية
              Padding(
                padding: EdgeInsets.symmetric(horizontal: w * .06),
                child: Row(
                  children: [
                    Expanded(
                      child: frostedButton(
                        t("خدمات الطريق", "Road Services"),
                        Icons.alt_route,
                        () => goto(const RoadServicesScreen()),
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: frostedButton(
                        t("الطوارئ", "Emergency"),
                        Icons.emergency,
                        () => openTracking("Emergency"),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 40),

              Text(
                t("المساعدة والتشخيص المتقدمة",
                    "Advanced assistance and diagnostics"),
                style: GoogleFonts.cairo(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: Colors.white),
              ),

              const SizedBox(height: 20),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  quickBtn(Icons.history, t("السجل", "History"),
                      () => goto(const PreviousServicesScreen())),
                  quickBtn(Icons.handyman, t("الدعم", "Support"), () {}),
                  quickBtn(Icons.more_horiz, t("المزيد", "More"), () async {
                    final res = await Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => const SupplementaryServicesScreen()),
                    );
                    if (res != null) {
                      openTracking(res["type"]);
                    }
                  }),
                  quickBtn(Icons.car_crash, t("حادث", "Accident"),
                      () => goto(const SmartAccidentScreen())),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ======================================================
  // BUILD MAIN LAYOUT
  // ======================================================

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;

    return Directionality(
      textDirection: isArabic ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        backgroundColor: primaryBg,
        body: Stack(
          children: [
            Positioned.fill(child: CustomPaint(painter: BackgroundPainter())),

            // Drawer
            AnimatedPositioned(
              duration: const Duration(milliseconds: 260),
              left: drawerOpen ? 0 : -w * .60,
              top: 0,
              bottom: 0,
              child: drawer(w),
            ),

            // Main Content
            AnimatedScale(
              scale: drawerOpen ? 0.88 : 1,
              duration: const Duration(milliseconds: 300),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                transform: Matrix4.translationValues(
                  drawerOpen ? w * .45 : 0,
                  drawerOpen ? h * .02 : 0,
                  0,
                ),
                child: buildContent(w, h),
              ),
            ),
          ],
        ),

        // -------------------------------
        // BOTTOM BAR
        // -------------------------------
        bottomNavigationBar: SizedBox(
          height: 170,
          child: Stack(
            alignment: Alignment.center,
            children: [
              Positioned.fill(
                  child: CustomPaint(painter: BottomWave(waveCtrl.value))),

              // زر الاتصال السريع
              Positioned(
                top: 18,
                child: ScaleTransition(
                  scale: pulseCtrl,
                  child: Container(
                    width: 95,
                    height: 95,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(colors: [accent, accentLight]),
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                            color: accent.withOpacity(.4),
                            blurRadius: 34,
                            spreadRadius: 10),
                      ],
                    ),
                    child:
                        const Icon(Icons.call, color: Colors.white, size: 40),
                  ),
                ),
              ),

              Positioned(
                top: 120,
                child: Text(
                  t("اتصال سريع", "Quick Call"),
                  style: GoogleFonts.cairo(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold),
                ),
              ),

              Positioned(
                bottom: 25,
                left: 40,
                child: bottomIcon(Icons.person, t("حسابي", "Account"),
                    () => goto(const AccountSettingsScreen())),
              ),
              Positioned(
                bottom: 25,
                right: 40,
                child: bottomIcon(Icons.home, t("الرئيسية", "Home"), () {}),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // -----------------------------------------
  // Bottom Icon
  // -----------------------------------------
  Widget bottomIcon(IconData icon, String title, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white.withOpacity(.7), width: 2),
              color: Colors.white.withOpacity(.12),
            ),
            child: Icon(icon, color: Colors.white, size: 26),
          ),
          const SizedBox(height: 5),
          Text(title,
              style: GoogleFonts.cairo(color: Colors.white, fontSize: 20)),
        ],
      ),
    );
  }
}

// ======================================================
// Custom Painters
// ======================================================

class BackgroundPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..shader = const LinearGradient(
        colors: [
          Color(0xff0A1124),
          Color(0xff0D1A33),
          Color(0xff0A1124),
        ],
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
      ).createShader(
        Rect.fromLTWH(0, 0, size.width, size.height),
      );

    canvas.drawRect(
      Rect.fromLTWH(0, 0, size.width, size.height),
      paint,
    );
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}

class BottomWave extends CustomPainter {
  final double value;
  BottomWave(this.value);

  @override
  void paint(Canvas canvas, Size size) {
    double shift = 30 * value;

    final path = Path();
    path.moveTo(0, 50 + shift);
    path.quadraticBezierTo(
        size.width * .25, 0 + shift, size.width * .50, 40 + shift);
    path.quadraticBezierTo(
        size.width * .85, 100 + shift, size.width, 50 + shift);
    path.lineTo(size.width, size.height);
    path.lineTo(0, size.height);
    path.close();

    final paint = Paint()..color = Colors.white.withOpacity(.1);

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => true;
}
