// lib/screens/marketplace/marketplace_screen.dart

import 'package:flutter/material.dart';
import '../../pages/brands/brands_page.dart';
import '../../pages/categories/categories_page.dart';
import '../../pages/products/product_list_page.dart';
import '../../core/widgets/custom_appbar.dart';

class MarketplaceScreen extends StatefulWidget {
  const MarketplaceScreen({super.key});

  @override
  State<MarketplaceScreen> createState() => _MarketplaceScreenState();
}

class _MarketplaceScreenState extends State<MarketplaceScreen> {
  final TextEditingController searchController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(title: "Marketplace"),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // -------------------------------
            // SEARCH BAR
            // -------------------------------
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              decoration: BoxDecoration(
                color: Colors.grey.shade200,
                borderRadius: BorderRadius.circular(14),
              ),
              child: TextField(
                controller: searchController,
                decoration: const InputDecoration(
                  hintText: "Search parts, brands, models...",
                  border: InputBorder.none,
                  icon: Icon(Icons.search),
                ),
                onChanged: (value) {
                  if (value.trim().isNotEmpty) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const ProductListPage(),
                      ),
                    );
                  }
                },
              ),
            ),

            const SizedBox(height: 25),

            // -------------------------------
            // CATEGORIES
            // -------------------------------
            const Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Categories",
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                Icon(Icons.arrow_forward_ios_rounded, size: 18),
              ],
            ),
            const SizedBox(height: 12),

            GridView(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 4,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
              ),
              children: [
                categoryItem("Engine", Icons.settings, () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const CategoriesPage(),
                    ),
                  );
                }),
                categoryItem("Brakes", Icons.safety_check, () {}),
                categoryItem("Filters", Icons.filter_alt, () {}),
                categoryItem("Electrical", Icons.bolt, () {}),
              ],
            ),

            const SizedBox(height: 30),

            // -------------------------------
            // BRANDS SECTION
            // -------------------------------
            const Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Brands",
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                Icon(Icons.arrow_forward_ios_rounded, size: 18),
              ],
            ),

            const SizedBox(height: 12),

            SizedBox(
              height: 120,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  brandItem("Toyota", "https://i.imgur.com/YZ9hGf4.png", () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const BrandsPage(),
                      ),
                    );
                  }),
                  brandItem("BMW", "https://i.imgur.com/MOq8Ilt.png", () {}),
                  brandItem(
                      "Mercedes", "https://i.imgur.com/Z1QpT3V.png", () {}),
                  brandItem("Audi", "https://i.imgur.com/6xRZbq2.png", () {}),
                ],
              ),
            ),

            const SizedBox(height: 25),

            // -------------------------------
            // POPULAR ITEMS
            // -------------------------------
            const Text(
              "Popular Parts",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),

            const SizedBox(height: 10),

            SizedBox(
              height: 250,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  productCard(
                      "Oil Filter", "https://i.imgur.com/4WldqLy.jpg", 150),
                  productCard(
                      "Spark Plug", "https://i.imgur.com/0HHhRk4.jpg", 90),
                  productCard(
                      "Brake Pads", "https://i.imgur.com/jU9nKHz.jpg", 320),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // -------------------------------
  // CATEGORY ITEM WIDGET
  // -------------------------------
  Widget categoryItem(String title, IconData icon, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(.08),
              blurRadius: 6,
            ),
          ],
        ),
        child: Column(
          children: [
            Icon(icon, size: 32, color: Colors.blue),
            const SizedBox(height: 6),
            Text(title,
                style:
                    const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }

  // -------------------------------
  // BRAND ITEM WIDGET
  // -------------------------------
  Widget brandItem(String name, String img, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 100,
        margin: const EdgeInsets.only(right: 12),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(.1),
              blurRadius: 8,
            ),
          ],
        ),
        child: Column(
          children: [
            Expanded(child: Image.network(img, fit: BoxFit.contain)),
            const SizedBox(height: 4),
            Text(name,
                style:
                    const TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }

  // -------------------------------
  // PRODUCT CARD WIDGET
  // -------------------------------
  Widget productCard(String name, String img, double price) {
    return Container(
      width: 160,
      margin: const EdgeInsets.only(right: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(.08),
            blurRadius: 6,
          ),
        ],
      ),
      child: Column(
        children: [
          Expanded(child: Image.network(img, fit: BoxFit.cover)),
          const SizedBox(height: 8),
          Text(
            name,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontWeight: FontWeight.w600),
          ),
          Text(
            "\$$price",
            style: const TextStyle(
                fontSize: 16, fontWeight: FontWeight.bold, color: Colors.blue),
          ),
        ],
      ),
    );
  }
}
