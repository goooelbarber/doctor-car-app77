// lib/pages/brands/models_page.dart

import 'package:flutter/material.dart';
import '../../core/widgets/custom_appbar.dart';
import '../../data/cars/car_models_data.dart';
import '../products/product_list_page.dart';

class ModelsPage extends StatelessWidget {
  final int brandId;
  final String brandName;

  const ModelsPage({super.key, required this.brandId, required this.brandName});

  @override
  Widget build(BuildContext context) {
    final models = carModels.where((m) => m.brandId == brandId).toList();

    return Scaffold(
      appBar: CustomAppBar(title: "$brandName Models"),
      body: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: models.length,
        itemBuilder: (context, index) {
          final m = models[index];
          return Card(
            child: ListTile(
              title: Text(m.modelName),
              subtitle: Text("Years: ${m.years.first} - ${m.years.last}"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ProductListPage(modelId: m.id),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
