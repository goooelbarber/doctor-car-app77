import 'package:flutter/material.dart';
import '../../data/brands/brands_data.dart';
import '../../core/widgets/custom_appbar.dart';
import 'models_page.dart';

class BrandsPage extends StatelessWidget {
  const BrandsPage({super.key});

  @override
  Widget build(BuildContext context) {
    // حماية من null — إذا حصل Null لن يعمل كراش
    final brandList = brands;

    return Scaffold(
      appBar: const CustomAppBar(title: "Brands"),
      body: brandList.isEmpty
          ? const Center(
              child: Text(
                "No Brands Available",
                style: TextStyle(fontSize: 20),
              ),
            )
          : GridView.builder(
              padding: const EdgeInsets.all(12),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
              ),
              itemCount: brandList.length,
              itemBuilder: (context, index) {
                final brand = brandList[index];

                return GestureDetector(
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => ModelsPage(
                        brandId: brand.id,
                        brandName: brand.name,
                      ),
                    ),
                  ),
                  child: Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      color: Colors.white,
                      border: Border.all(color: Colors.grey.shade300),
                    ),
                    child: Column(
                      children: [
                        Expanded(
                          child: Image.network(
                            brand.logo,
                            fit: BoxFit.contain,
                            errorBuilder: (_, __, ___) =>
                                const Icon(Icons.error, size: 40),
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          brand.name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}
