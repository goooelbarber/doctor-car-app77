// lib/pages/cart/cart_page.dart

import 'package:flutter/material.dart';
import '../../core/widgets/custom_appbar.dart';

class CartPage extends StatelessWidget {
  const CartPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      appBar: CustomAppBar(title: "My Cart"),
      body: Center(
        child: Text(
          "Your cart is empty",
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600),
        ),
      ),
    );
  }
}
