import 'package:doctor_car_app/models/product_model.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/widgets/custom_appbar.dart';
import '../../data/brands/brands_data.dart';
import '../../data/products/products_data.dart';
import '../products/product_list_page.dart';
import '../search/search_page.dart';
import '../brands/brands_page.dart';
// ignore: unused_import
import '../categories/categories_page.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffF7F7FB),
      appBar: const CustomAppBar(title: "Marketplace"),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _heroSlider(),
            _searchBar(context),
            const SizedBox(height: 20),
            _sectionTitle("Categories", context),
            _categoriesGrid(context),
            _sectionTitle("Brands", context),
            _brandsSlider(context),
            _sectionTitle("Trending Parts", context),
            _productSlider(context, allProducts.take(6).toList()),
            _sectionTitle("Recommended For You", context),
            _productSlider(context, allProducts.reversed.take(6).toList()),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  // ----------------------------------------------------
  // HERO SLIDER
  // ----------------------------------------------------
  Widget _heroSlider() {
    final banners = [
      "https://res.cloudinary.com/dkftl1ytd/image/upload/v1735834078/banner_car_parts_1.jpg",
      "https://res.cloudinary.com/dkftl1ytd/image/upload/v1735834079/banner_car_service_2.jpg",
      "https://res.cloudinary.com/dkftl1ytd/image/upload/v1735834079/banner_engine_parts_3.jpg",
    ];

    return SizedBox(
      height: 190,
      child: PageView.builder(
        controller: PageController(viewportFraction: 0.92),
        itemCount: banners.length,
        itemBuilder: (context, i) {
          return AnimatedContainer(
            duration: const Duration(milliseconds: 400),
            margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              image: DecorationImage(
                image: NetworkImage(banners[i]),
                fit: BoxFit.cover,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(.18),
                  blurRadius: 20,
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  // ----------------------------------------------------
  // SEARCH BAR
  // ----------------------------------------------------
  Widget _searchBar(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.push(
          context, MaterialPageRoute(builder: (_) => const SearchPage())),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16),
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              blurRadius: 12,
              offset: const Offset(0, 3),
              color: Colors.black.withOpacity(0.07),
            )
          ],
        ),
        child: Row(
          children: [
            const Icon(Icons.search, size: 26, color: Colors.grey),
            const SizedBox(width: 12),
            Text("Search for parts, brands, models…",
                style: GoogleFonts.poppins(
                    fontSize: 15, color: Colors.grey.shade600)),
          ],
        ),
      ),
    );
  }

  // ----------------------------------------------------
  // SECTION TITLE
  // ----------------------------------------------------
  Widget _sectionTitle(String title, BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 25, 16, 12),
      child: Text(
        title,
        style: GoogleFonts.poppins(
          fontSize: 21,
          fontWeight: FontWeight.w700,
          color: const Color(0xff2A2A45),
        ),
      ),
    );
  }

  // ----------------------------------------------------
  // CATEGORIES GRID
  // ----------------------------------------------------
  Widget _categoriesGrid(BuildContext context) {
    final categories = <Map<String, dynamic>>[
      {"name": "Engine", "icon": Icons.speed, "id": 1},
      {"name": "Brakes", "icon": Icons.security, "id": 2},
      {"name": "Filters", "icon": Icons.filter_alt, "id": 3},
      {"name": "Electrical", "icon": Icons.bolt, "id": 4},
    ];

    return SizedBox(
      height: 140,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        scrollDirection: Axis.horizontal,
        itemCount: categories.length,
        separatorBuilder: (_, __) => const SizedBox(width: 16),
        itemBuilder: (context, i) {
          final c = categories[i];

          return GestureDetector(
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => ProductListPage(categoryId: c["id"] as int),
              ),
            ),
            child: Container(
              width: 120,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(18),
                boxShadow: [
                  BoxShadow(
                      color: Colors.black.withOpacity(.08), blurRadius: 10)
                ],
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(c["icon"] as IconData, size: 35, color: Colors.blue),
                  const SizedBox(height: 10),
                  Text(
                    c["name"],
                    style: GoogleFonts.poppins(
                        fontSize: 14, fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // ----------------------------------------------------
  // BRANDS SLIDER
  // ----------------------------------------------------
  Widget _brandsSlider(BuildContext context) {
    return SizedBox(
      height: 120,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        scrollDirection: Axis.horizontal,
        itemCount: brands.length,
        separatorBuilder: (_, __) => const SizedBox(width: 16),
        itemBuilder: (context, i) {
          final b = brands[i];

          return GestureDetector(
            onTap: () => Navigator.push(
                context, MaterialPageRoute(builder: (_) => const BrandsPage())),
            child: Container(
              width: 110,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                      color: Colors.black.withOpacity(.09), blurRadius: 12)
                ],
              ),
              child: Column(
                children: [
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Image.network(
                        b.logo,
                        fit: BoxFit.contain,
                      ),
                    ),
                  ),
                  Text(b.name,
                      style: GoogleFonts.poppins(
                          fontSize: 13, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 8),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // ----------------------------------------------------
  // PRODUCT SLIDER
  // ----------------------------------------------------
  Widget _productSlider(BuildContext context, List<ProductModel> products) {
    return SizedBox(
      height: 260,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        scrollDirection: Axis.horizontal,
        itemCount: products.length,
        separatorBuilder: (_, __) => const SizedBox(width: 18),
        itemBuilder: (context, i) {
          final p = products[i];

          return GestureDetector(
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => ProductListPage()),
            ),
            child: Container(
              width: 180,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(18),
                boxShadow: [
                  BoxShadow(
                      color: Colors.black.withOpacity(.08), blurRadius: 12)
                ],
              ),
              child: Column(
                children: [
                  Expanded(
                    child: ClipRRect(
                      borderRadius:
                          const BorderRadius.vertical(top: Radius.circular(18)),
                      child: Image.network(
                        p.imageUrl,
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8),
                    child: Column(
                      children: [
                        Text(
                          p.name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: GoogleFonts.poppins(
                              fontSize: 14, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          "\$${p.price}",
                          style: GoogleFonts.poppins(
                              color: Colors.blue,
                              fontSize: 15,
                              fontWeight: FontWeight.w700),
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
