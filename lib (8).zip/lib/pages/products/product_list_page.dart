import 'package:flutter/material.dart';

import '../../core/widgets/custom_appbar.dart';
import '../../core/widgets/product_card.dart';
import '../../data/products/products_data.dart';
import '../../models/product_model.dart';
import 'product_details_page.dart';

class ProductListPage extends StatelessWidget {
  final int? modelId;
  final int? categoryId;

  const ProductListPage({
    super.key,
    this.modelId,
    this.categoryId,
  });

  @override
  Widget build(BuildContext context) {
    // حماية من null
    List<ProductModel> products = List<ProductModel>.from(allProducts);

    // فلترة بالموديل
    if (modelId != null) {
      products = products.where((p) => p.carModelId == modelId).toList();
    }

    // فلترة بالفئة
    if (categoryId != null) {
      products = products.where((p) => p.categoryId == categoryId).toList();
    }

    return Scaffold(
      appBar: const CustomAppBar(title: "Products"),
      body: products.isEmpty
          ? const Center(
              child: Text(
                "No products found",
                style: TextStyle(fontSize: 20),
              ),
            )
          : GridView.builder(
              padding: const EdgeInsets.all(12),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: .72,
              ),
              itemCount: products.length,
              itemBuilder: (context, index) {
                final p = products[index];

                return ProductCard(
                  image: p.imageUrl,
                  name: p.name,
                  price: p.price,
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => ProductDetailsPage(product: p),
                      ),
                    );
                  },
                );
              },
            ),
    );
  }
}
