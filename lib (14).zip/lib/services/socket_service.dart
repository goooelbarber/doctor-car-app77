// ignore: library_prefixes
import 'package:socket_io_client/socket_io_client.dart' as IO;
import '../config/api_config.dart';

class SocketService {
  // ===============================
  // 🧠 Singleton
  // ===============================
  static final SocketService _instance = SocketService._internal();
  factory SocketService() => _instance;
  SocketService._internal();

  IO.Socket? _socket;

  bool get isConnected => _socket?.connected ?? false;

  // ===============================
  // 🔌 Connect (Web + Mobile SAFE)
  // ===============================
  void connect() {
    if (_socket != null) {
      if (!_socket!.connected) {
        _socket!.connect();
      }
      return;
    }

    _socket = IO.io(
      ApiConfig.socketUrl,
      IO.OptionBuilder()
          .setTransports(['polling', 'websocket']) // مهم للويب
          .disableAutoConnect() // اتصال يدوي
          .enableReconnection()
          .build(),
    );

    _socket!.onConnect((_) {
      // ignore: avoid_print
      print("🔌 Socket connected");
    });

    _socket!.onDisconnect((_) {
      // ignore: avoid_print
      print("❌ Socket disconnected");
    });

    _socket!.onConnectError((e) {
      // ignore: avoid_print
      print("❌ Socket connect error: $e");
    });

    _socket!.connect();
  }

  // ===============================
  // 🔄 Connection status listener
  // ===============================
  void onConnectionChanged(void Function(bool connected) callback) {
    callback(isConnected);

    _socket?.off("connect");
    _socket?.off("disconnect");

    _socket?.onConnect((_) => callback(true));
    _socket?.onDisconnect((_) => callback(false));
  }

  // =========================================================
  // 📦 ORDERS (Technician Tracking)
  // =========================================================

  /// الانضمام لغرفة الطلب
  void joinOrderRoom(String orderId) {
    _socket?.emit("joinOrderRoom", orderId);
  }

  /// استقبال موقع الفني
  void onTechnicianLocation(void Function(double lat, double lng) callback) {
    _socket?.off("technicianLocationUpdate");
    _socket?.on("technicianLocationUpdate", (data) {
      if (data == null || data["location"] == null) return;

      final lat = (data["location"]["lat"] as num).toDouble();
      final lng = (data["location"]["lng"] as num).toDouble();

      callback(lat, lng);
    });
  }

  /// استقبال تحديث حالة الطلب
  void onOrderStatusUpdate(void Function(String status) callback) {
    _socket?.off("orderStatusUpdated");
    _socket?.on("orderStatusUpdated", (data) {
      if (data == null) return;
      callback((data["status"] ?? "").toString());
    });
  }

  // =========================================================
  // 💬 SUPPORT CHAT
  // =========================================================

  /// الانضمام لغرفة الشات
  void joinSupportChat(String chatId) {
    _socket?.emit("joinSupportChat", {"chatId": chatId});
  }

  /// إرسال رسالة دعم
  void sendSupportMessage({
    required String chatId,
    required String text,
    String senderType = "user",
    String? clientTempId,
  }) {
    _socket?.emit("supportMessage:send", {
      "chatId": chatId,
      "text": text,
      "senderType": senderType,
      if (clientTempId != null) "clientTempId": clientTempId,
    });
  }

  /// استقبال رسالة جديدة
  void onSupportMessage(void Function(Map<String, dynamic>) callback) {
    _socket?.off("supportMessage:new");
    _socket?.on("supportMessage:new", (data) {
      if (data == null) return;
      callback(Map<String, dynamic>.from(data));
    });
  }

  /// ACK لتأكيد الإرسال
  void onSupportAck(void Function(Map<String, dynamic>) callback) {
    _socket?.off("supportMessage:ack");
    _socket?.on("supportMessage:ack", (data) {
      if (data == null) return;
      callback(Map<String, dynamic>.from(data));
    });
  }

  // ===============================
  // ✍️ Typing Indicator
  // ===============================
  void emitSupportTyping({
    required String chatId,
    required bool typing,
    required String senderType,
  }) {
    _socket?.emit("supportChat:typing", {
      "chatId": chatId,
      "typing": typing,
      "senderType": senderType,
    });
  }

  void onSupportTyping(void Function(Map<String, dynamic>) callback) {
    _socket?.off("supportChat:typing");
    _socket?.on("supportChat:typing", (data) {
      if (data == null) return;
      callback(Map<String, dynamic>.from(data));
    });
  }

  // ===============================
  // 👀 Read Receipt (Seen)
  // ===============================
  void emitSupportRead({
    required String chatId,
    required String readerType,
  }) {
    _socket?.emit("supportChat:read", {
      "chatId": chatId,
      "readerType": readerType,
    });
  }

  // ===============================
  // 🔌 Disconnect & cleanup
  // ===============================
  void disconnect() {
    if (_socket == null) return;
    _socket!.clearListeners();
    _socket!.disconnect();
    _socket = null;
  }
}
