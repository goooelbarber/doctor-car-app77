// PATH: lib/services/support_chat_service.dart
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/api_config.dart';

class SupportChatService {
  /// GET /api/support/me
  static Future<Map<String, dynamic>> getOrCreateChat() async {
    final uri = Uri.parse("${ApiConfig.support}/me");
    final res = await http.get(uri, headers: {
      "Content-Type": "application/json",
    });

    if (res.statusCode != 200) {
      throw Exception("getOrCreateChat failed: ${res.statusCode} ${res.body}");
    }

    final data = jsonDecode(res.body);
    return Map<String, dynamic>.from(data);
  }

  /// GET /api/support/:chatId/messages
  static Future<List<Map<String, dynamic>>> getMessages(String chatId) async {
    final uri = Uri.parse("${ApiConfig.support}/$chatId/messages");
    final res = await http.get(uri, headers: {
      "Content-Type": "application/json",
    });

    if (res.statusCode != 200) {
      throw Exception("getMessages failed: ${res.statusCode} ${res.body}");
    }

    final data = jsonDecode(res.body);
    if (data is! List) return [];
    return data.map((e) => Map<String, dynamic>.from(e)).toList();
  }
}
