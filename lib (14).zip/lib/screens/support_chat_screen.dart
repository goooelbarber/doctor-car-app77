// PATH: lib/screens/support_chat_screen.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../services/socket_service.dart';
import '../services/support_chat_service.dart';

class ChatMessage {
  final String localId; // client temp id
  final String? id; // server id
  final String senderType; // user | technician | system
  final String text;
  final DateTime createdAt;

  /// sending | sent | failed
  String status;

  final DateTime? readByTechnicianAt;

  ChatMessage({
    required this.localId,
    required this.senderType,
    required this.text,
    required this.createdAt,
    required this.status,
    this.id,
    this.readByTechnicianAt,
  });

  static DateTime _parse(dynamic v) {
    if (v == null) return DateTime.now();
    try {
      return DateTime.parse(v.toString()).toLocal();
    } catch (_) {
      return DateTime.now();
    }
  }

  factory ChatMessage.fromServer(Map<String, dynamic> m) {
    return ChatMessage(
      localId:
          (m["clientTempId"] ?? m["_id"] ?? UniqueKey().toString()).toString(),
      id: (m["_id"] ?? m["id"])?.toString(),
      senderType: (m["senderType"] ?? "system").toString(),
      text: (m["text"] ?? "").toString(),
      createdAt: _parse(m["createdAt"] ?? m["created_at"]),
      status: "sent",
      readByTechnicianAt: m["readByTechnicianAt"] != null
          ? _parse(m["readByTechnicianAt"])
          : null,
    );
  }
}

class SupportChatScreen extends StatefulWidget {
  const SupportChatScreen({super.key});

  @override
  State<SupportChatScreen> createState() => _SupportChatScreenState();
}

class _SupportChatScreenState extends State<SupportChatScreen> {
  final SocketService socket = SocketService();

  final TextEditingController _controller = TextEditingController();
  final ScrollController _scroll = ScrollController();

  String? chatId;
  bool loading = true;
  bool socketConnected = false;
  bool otherTyping = false;

  final List<ChatMessage> _messages = [];

  Timer? _typingTimer;
  bool _nearBottom = true;

  @override
  void initState() {
    super.initState();
    _scroll.addListener(_onScroll);
    _init();
  }

  void _onScroll() {
    if (!_scroll.hasClients) return;
    final max = _scroll.position.maxScrollExtent;
    final cur = _scroll.position.pixels;
    _nearBottom = (max - cur) < 140;
  }

  Future<void> _init() async {
    try {
      socket.connect();

      socket.onConnectionChanged((c) {
        if (!mounted) return;
        setState(() => socketConnected = c);
      });

      final chat = await SupportChatService.getOrCreateChat();
      chatId = (chat["_id"] ?? chat["id"]).toString();

      socket.joinSupportChat(chatId!);

      final old = await SupportChatService.getMessages(chatId!);
      _messages
        ..clear()
        ..addAll(old.map(ChatMessage.fromServer));

      // realtime new message
      socket.onSupportMessage((m) {
        if (!mounted) return;
        final msg = ChatMessage.fromServer(m);

        // منع التكرار
        final exists = _messages.any((x) => x.id != null && x.id == msg.id);
        if (!exists) {
          setState(() => _messages.add(msg));
          _maybeScrollDown();
        }

        // read receipt
        _emitRead();
      });

      // ACK for sending -> sent
      socket.onSupportAck((ack) {
        final tempId = (ack["clientTempId"] ?? "").toString();
        final serverId = (ack["serverId"] ?? "").toString();

        final i = _messages
            .indexWhere((m) => m.localId == tempId && m.status == "sending");
        if (i != -1) {
          setState(() {
            _messages[i].status = "sent";
          });
        }

        // لو عايز تربط serverId محليًا (اختياري)
        if (i != -1 && serverId.isNotEmpty) {
          // ignore: unused_local_variable
          final _ = serverId;
        }
      });

      // Typing from mechanic
      socket.onSupportTyping((payload) {
        final from = (payload["senderType"] ?? "").toString();
        if (from == "user") return;
        if (!mounted) return;
        setState(() => otherTyping = payload["typing"] == true);
        if (otherTyping) _maybeScrollDown();
      });

      setState(() => loading = false);

      WidgetsBinding.instance.addPostFrameCallback((_) {
        _jumpDown();
        _emitRead();
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => loading = false);
      debugPrint("❌ SupportChat init error: $e");
    }
  }

  Future<void> _refresh() async {
    if (chatId == null) return;
    final old = await SupportChatService.getMessages(chatId!);
    if (!mounted) return;
    setState(() {
      _messages
        ..clear()
        ..addAll(old.map(ChatMessage.fromServer));
    });
    WidgetsBinding.instance.addPostFrameCallback((_) => _jumpDown());
  }

  void _send() {
    if (chatId == null) return;

    final text = _controller.text.trim();
    if (text.isEmpty) return;

    // لو مش متصل، امنع الإرسال
    if (!socketConnected) {
      _snack("غير متصل بالسيرفر");
      return;
    }

    final tempId = DateTime.now().microsecondsSinceEpoch.toString();

    final local = ChatMessage(
      localId: tempId,
      id: null,
      senderType: "user",
      text: text,
      createdAt: DateTime.now(),
      status: "sending",
      readByTechnicianAt: null,
    );

    setState(() => _messages.add(local));
    _controller.clear();
    _jumpDown();

    socket.sendSupportMessage(
      chatId: chatId!,
      text: text,
      senderType: "user",
      clientTempId: tempId,
    );

    // لو ACK ماجاش خلال 7 ثواني: failed
    Future.delayed(const Duration(seconds: 7), () {
      final i = _messages.indexWhere((m) => m.localId == tempId);
      if (!mounted || i == -1) return;
      if (_messages[i].status == "sending") {
        setState(() => _messages[i].status = "failed");
      }
    });

    _emitTyping(false);
  }

  void _retry(ChatMessage m) {
    if (chatId == null) return;
    if (!socketConnected) {
      _snack("غير متصل بالسيرفر");
      return;
    }

    setState(() => m.status = "sending");

    socket.sendSupportMessage(
      chatId: chatId!,
      text: m.text,
      senderType: "user",
      clientTempId: m.localId,
    );

    Future.delayed(const Duration(seconds: 7), () {
      final i = _messages.indexWhere((x) => x.localId == m.localId);
      if (!mounted || i == -1) return;
      if (_messages[i].status == "sending") {
        setState(() => _messages[i].status = "failed");
      }
    });
  }

  void _emitTyping(bool typing) {
    if (chatId == null) return;
    socket.emitSupportTyping(
      chatId: chatId!,
      typing: typing,
      senderType: "user",
    );
  }

  void _emitRead() {
    if (chatId == null) return;
    socket.emitSupportRead(chatId: chatId!, readerType: "user");
  }

  void _onTypingChanged(String _) {
    _emitTyping(true);
    _typingTimer?.cancel();
    _typingTimer =
        Timer(const Duration(milliseconds: 600), () => _emitTyping(false));
  }

  void _maybeScrollDown() {
    if (_nearBottom) _scrollDownAnimated();
  }

  void _jumpDown() {
    if (!_scroll.hasClients) return;
    _scroll.jumpTo(_scroll.position.maxScrollExtent);
  }

  void _scrollDownAnimated() {
    Future.delayed(const Duration(milliseconds: 80), () {
      if (!_scroll.hasClients) return;
      _scroll.animateTo(
        _scroll.position.maxScrollExtent,
        duration: const Duration(milliseconds: 260),
        curve: Curves.easeOut,
      );
    });
  }

  void _snack(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(text, style: GoogleFonts.cairo())),
    );
  }

  @override
  void dispose() {
    _typingTimer?.cancel();
    _controller.dispose();
    _scroll.removeListener(_onScroll);
    _scroll.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final titleStyle =
        GoogleFonts.cairo(fontWeight: FontWeight.w700, fontSize: 18);

    return Scaffold(
      backgroundColor: const Color(0xFF070B14),
      appBar: AppBar(
        elevation: 0,
        backgroundColor: const Color(0xFF070B14),
        centerTitle: true,
        title: Text("الدعم الفني", style: titleStyle),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(34),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
            child: Row(
              children: [
                _statusDot(socketConnected),
                const SizedBox(width: 8),
                Text(
                  socketConnected
                      ? "متصل"
                      : "غير متصل — إعادة المحاولة تلقائيًا",
                  style: GoogleFonts.cairo(
                    fontSize: 12.5,
                    color:
                        socketConnected ? Colors.greenAccent : Colors.redAccent,
                  ),
                ),
                const Spacer(),
                if (otherTyping)
                  Text(
                    "الميكانيكي يكتب…",
                    style: GoogleFonts.cairo(
                        fontSize: 12.5,
                        color: const Color.fromARGB(179, 246, 169, 26)),
                  ),
              ],
            ),
          ),
        ),
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Expanded(
                  child: RefreshIndicator(
                    onRefresh: _refresh,
                    child: _messages.isEmpty
                        ? _empty()
                        : ListView.builder(
                            controller: _scroll,
                            padding: const EdgeInsets.fromLTRB(14, 10, 14, 12),
                            itemCount: _messages.length,
                            itemBuilder: (_, i) => _bubble(_messages[i]),
                          ),
                  ),
                ),
                _composer(),
              ],
            ),
    );
  }

  Widget _statusDot(bool ok) {
    return Container(
      width: 9,
      height: 9,
      decoration: BoxDecoration(
        color: ok ? Colors.greenAccent : Colors.redAccent,
        shape: BoxShape.circle,
      ),
    );
  }

  Widget _empty() {
    return Center(
      child: Text(
        "ابدأ المحادثة مع الدعم الفني",
        style: GoogleFonts.cairo(
            color: const Color.fromARGB(137, 215, 223, 107), fontSize: 16),
      ),
    );
  }

  Widget _bubble(ChatMessage m) {
    final isUser = m.senderType == "user";
    final bg = isUser ? const Color(0xFFF7C948) : const Color(0xFF111A2E);
    final fg = isUser ? Colors.black : Colors.white;

    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 6),
        padding: const EdgeInsets.fromLTRB(12, 10, 12, 8),
        constraints: const BoxConstraints(maxWidth: 340),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(16),
            topRight: const Radius.circular(16),
            bottomLeft: Radius.circular(isUser ? 16 : 6),
            bottomRight: Radius.circular(isUser ? 6 : 16),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(.22),
              blurRadius: 10,
              offset: const Offset(0, 6),
            )
          ],
        ),
        child: Column(
          crossAxisAlignment:
              isUser ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          children: [
            Text(
              m.text,
              style: GoogleFonts.cairo(color: fg, fontSize: 15, height: 1.35),
            ),
            const SizedBox(height: 6),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  _time(m.createdAt),
                  style: GoogleFonts.cairo(
                      fontSize: 11,
                      color: isUser
                          ? Colors.black54
                          : const Color.fromARGB(137, 193, 204, 111)),
                ),
                if (isUser) ...[
                  const SizedBox(width: 8),
                  _statusIcon(m),
                ]
              ],
            )
          ],
        ),
      ),
    );
  }

  Widget _statusIcon(ChatMessage m) {
    if (m.status == "sending") {
      return const SizedBox(
        width: 14,
        height: 14,
        child: CircularProgressIndicator(strokeWidth: 2),
      );
    }
    if (m.status == "failed") {
      return InkWell(
        onTap: () => _retry(m),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.error_outline, size: 16, color: Colors.red),
            const SizedBox(width: 4),
            Text("إعادة",
                style: GoogleFonts.cairo(fontSize: 11, color: Colors.red)),
          ],
        ),
      );
    }
    return const Icon(Icons.done, size: 16, color: Colors.black54);
  }

  Widget _composer() {
    final canSend = socketConnected && _controller.text.trim().isNotEmpty;

    return SafeArea(
      child: Container(
        padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
        decoration: const BoxDecoration(
          color: Color(0xFF0A1020),
          border: Border(top: BorderSide(color: Color(0x221FFFFFF), width: 1)),
        ),
        child: Row(
          children: [
            Expanded(
              child: TextField(
                controller: _controller,
                onChanged: (v) {
                  setState(() {}); // علشان زر الإرسال يتفعل
                  _onTypingChanged(v);
                },
                minLines: 1,
                maxLines: 4,
                style: GoogleFonts.cairo(color: Colors.white, fontSize: 14.5),
                decoration: InputDecoration(
                  hintText: "اكتب رسالتك…",
                  hintStyle: GoogleFonts.cairo(color: Colors.white38),
                  filled: true,
                  fillColor: const Color(0xFF111A2E),
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 10),
            AnimatedOpacity(
              opacity: canSend ? 1 : .5,
              duration: const Duration(milliseconds: 200),
              child: InkWell(
                onTap: canSend ? _send : null,
                borderRadius: BorderRadius.circular(999),
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: Color(0xFFF7C948),
                  ),
                  child: const Icon(Icons.send, color: Colors.black),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _time(DateTime dt) {
    final h = dt.hour.toString().padLeft(2, '0');
    final m = dt.minute.toString().padLeft(2, '0');
    return "$h:$m";
  }
}
