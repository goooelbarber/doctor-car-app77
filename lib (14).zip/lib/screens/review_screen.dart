import 'dart:ui';
import 'package:flutter/material.dart';

class ReviewScreen extends StatefulWidget {
  final String orderId;

  const ReviewScreen({super.key, required this.orderId});

  @override
  State<ReviewScreen> createState() => _ReviewScreenState();
}

class _ReviewScreenState extends State<ReviewScreen>
    with TickerProviderStateMixin {
  double overallRating = 0;
  double techRating = 0;
  double speedRating = 0;
  double priceRating = 0;

  bool isSending = false;

  final TextEditingController commentController = TextEditingController();

  final List<String> tags = [
    "سريع",
    "محترف",
    "سعر مناسب",
    "تواصل ممتاز",
    "تأخير",
    "غير مرضي",
  ];

  final Set<String> selectedTags = {};

  // ================= SUBMIT =================

  Future<void> submitReview() async {
    if (overallRating == 0) {
      _snack("من فضلك اختر التقييم العام");
      return;
    }

    setState(() => isSending = true);

    await Future.delayed(const Duration(seconds: 2));

    setState(() => isSending = false);

    _showSuccessDialog();
  }

  // ================= UI =================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(
              "تخطي",
              style: TextStyle(color: Colors.white70),
            ),
          )
        ],
      ),
      body: Stack(
        children: [
          _background(),
          _content(),
          if (isSending) _loading(),
        ],
      ),
    );
  }

  Widget _background() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Color(0xff050A12),
            Color(0xff0E1A2B),
            Color(0xff162C46),
          ],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
    );
  }

  Widget _content() {
    return Center(
      child: ClipRRect(
        borderRadius: BorderRadius.circular(28),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
          child: Container(
            width: MediaQuery.of(context).size.width * 0.9,
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(.08),
              borderRadius: BorderRadius.circular(28),
              border: Border.all(color: Colors.white24),
            ),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    "قيّم تجربتك",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 26,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 20),
                  _ratingSection("التقييم العام", (v) {
                    setState(() => overallRating = v);
                  }, overallRating, big: true),
                  const SizedBox(height: 20),
                  _ratingSection(
                      "احترافية الفني", (v) => techRating = v, techRating),
                  _ratingSection(
                      "سرعة الوصول", (v) => speedRating = v, speedRating),
                  _ratingSection("السعر", (v) => priceRating = v, priceRating),
                  const SizedBox(height: 20),
                  _tags(),
                  const SizedBox(height: 20),
                  _commentBox(),
                  const SizedBox(height: 26),
                  _submitButton(),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ================= COMPONENTS =================

  Widget _ratingSection(String title, Function(double) onRate, double value,
      {bool big = false}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title,
            style: const TextStyle(color: Colors.white70, fontSize: 15)),
        const SizedBox(height: 8),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(
            5,
            (i) => GestureDetector(
              onTap: () => setState(() => onRate(i + 1.0)),
              child: Icon(
                Icons.star_rounded,
                size: big ? 44 : 32,
                color: value >= i + 1 ? Colors.amber : Colors.white24,
              ),
            ),
          ),
        ),
        const SizedBox(height: 12),
      ],
    );
  }

  Widget _tags() {
    return Wrap(
      spacing: 10,
      runSpacing: 10,
      children: tags.map((t) {
        final active = selectedTags.contains(t);
        return GestureDetector(
          onTap: () {
            setState(() {
              active ? selectedTags.remove(t) : selectedTags.add(t);
            });
          },
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            decoration: BoxDecoration(
              color: active ? Colors.amber : Colors.white10,
              borderRadius: BorderRadius.circular(18),
            ),
            child: Text(
              t,
              style: TextStyle(
                color: active ? Colors.black : Colors.white70,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _commentBox() {
    return TextField(
      controller: commentController,
      maxLines: 3,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        hintText: "أضف تعليقًا (اختياري)",
        hintStyle: TextStyle(color: Colors.white.withOpacity(.4)),
        filled: true,
        fillColor: Colors.white.withOpacity(.06),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: Colors.white24),
        ),
      ),
    );
  }

  Widget _submitButton() {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: isSending ? null : submitReview,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.amber,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        ),
        child: const Text(
          "إرسال التقييم",
          style: TextStyle(
              color: Colors.black, fontSize: 20, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }

  Widget _loading() {
    return Container(
      color: Colors.black87,
      child: const Center(
        child: CircularProgressIndicator(color: Colors.amber),
      ),
    );
  }

  // ================= HELPERS =================

  void _snack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  void _showSuccessDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: Colors.black,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.check_circle, color: Colors.green, size: 60),
            SizedBox(height: 12),
            Text(
              "شكرًا لتقييمك 🙏",
              style: TextStyle(color: Colors.white, fontSize: 20),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );

    Future.delayed(const Duration(seconds: 2), () {
      // ignore: use_build_context_synchronously
      Navigator.pop(context); // dialog
      // ignore: use_build_context_synchronously
      Navigator.pop(context); // screen
    });
  }
}
