import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../services/socket_service.dart';

class TechnicianTrackingScreen extends StatefulWidget {
  final String orderId;

  const TechnicianTrackingScreen({
    super.key,
    required this.orderId,
  });

  @override
  State<TechnicianTrackingScreen> createState() =>
      _TechnicianTrackingScreenState();
}

class _TechnicianTrackingScreenState extends State<TechnicianTrackingScreen> {
  GoogleMapController? _mapController;
  final SocketService socketService = SocketService();

  LatLng techPos = const LatLng(30.05, 31.23);
  bool socketConnected = false;

  @override
  void initState() {
    super.initState();

    // 🔌 اتصال Socket (Singleton – مش هيعمل اتصال جديد لو موجود)
    socketService.connect();

    // 🔄 راقب حالة الاتصال (اختياري)
    socketService.onConnectionChanged((connected) {
      if (!mounted) return;
      setState(() => socketConnected = connected);
    });

    // 🚪 انضم لغرفة الطلب
    socketService.joinOrderRoom(widget.orderId);

    // 📡 استقبل تحديثات موقع الفني
    socketService.onTechnicianLocation((lat, lng) {
      if (!mounted) return;

      final newPos = LatLng(lat, lng);

      setState(() {
        techPos = newPos;
      });

      _mapController?.animateCamera(
        CameraUpdate.newLatLng(newPos),
      );
    });
  }

  @override
  void dispose() {
    // ❌ لا تفصل socket هنا
    // لأنه Singleton ومستخدم في الشات وغيره
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("تتبع الفني"),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: Icon(
              socketConnected ? Icons.wifi : Icons.wifi_off,
              color: socketConnected ? Colors.green : Colors.red,
            ),
          )
        ],
      ),
      body: GoogleMap(
        initialCameraPosition: CameraPosition(
          target: techPos,
          zoom: 15,
        ),
        markers: {
          Marker(
            markerId: const MarkerId("tech"),
            position: techPos,
            icon: BitmapDescriptor.defaultMarkerWithHue(
              BitmapDescriptor.hueOrange,
            ),
          ),
        },
        onMapCreated: (controller) {
          _mapController = controller;
        },
      ),
    );
  }
}
