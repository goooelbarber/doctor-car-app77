import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_fonts/google_fonts.dart';

class MapPickerScreen extends StatefulWidget {
  final String selectedService;

  const MapPickerScreen({
    super.key,
    required this.selectedService,
  });

  @override
  State<MapPickerScreen> createState() => _MapPickerScreenState();
}

class _MapPickerScreenState extends State<MapPickerScreen> {
  GoogleMapController? _map;
  LatLng? userPosition;
  LatLng? selectedPosition;

  bool loading = true;
  String errorMsg = "";

  @override
  void initState() {
    super.initState();
    _getUserLocation();
  }

  // ================== GET USER LOCATION ==================
  Future<void> _getUserLocation() async {
    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        setState(() {
          errorMsg = "الرجاء تفعيل خدمة الموقع";
          loading = false;
        });
        return;
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }

      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        setState(() {
          errorMsg = "تم رفض إذن الموقع";
          loading = false;
        });
        return;
      }

      final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );

      setState(() {
        userPosition = LatLng(pos.latitude, pos.longitude);
        selectedPosition = userPosition;
        loading = false;
      });
    } catch (e) {
      setState(() {
        errorMsg = "حدث خطأ في تحديد الموقع";
        loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    // ---------------- LOADING / ERROR ----------------
    if (loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    if (userPosition == null) {
      return Scaffold(
        appBar: AppBar(
          title: Text("خطأ", style: GoogleFonts.cairo()),
          backgroundColor: Colors.redAccent,
        ),
        body: Center(
          child: Text(
            errorMsg.isEmpty ? "تعذر تحديد الموقع" : errorMsg,
            style: GoogleFonts.cairo(fontSize: 18),
          ),
        ),
      );
    }

    // ---------------- MAIN UI ----------------
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "تحديد موقعك",
          style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.blue.shade800,
        centerTitle: true,
      ),
      body: Stack(
        children: [
          // ================== MAP ==================
          GoogleMap(
            initialCameraPosition: CameraPosition(
              target: userPosition!,
              zoom: 14.5,
            ),
            onMapCreated: (controller) => _map = controller,
            onTap: (LatLng point) {
              setState(() {
                selectedPosition = point;
              });
            },
            markers: {
              Marker(
                markerId: const MarkerId("selected"),
                position: selectedPosition!,
                icon: BitmapDescriptor.defaultMarkerWithHue(
                  BitmapDescriptor.hueRed,
                ),
              ),
            },
            myLocationEnabled: true,
            myLocationButtonEnabled: false,
            zoomControlsEnabled: false,
          ),

          // ================== CENTER PIN ==================
          Positioned.fill(
            child: IgnorePointer(
              child: Center(
                child: Icon(
                  Icons.location_on,
                  size: 52,
                  color: Colors.red.shade700,
                ),
              ),
            ),
          ),

          // ================== MY LOCATION BUTTON ==================
          Positioned(
            bottom: 140,
            right: 16,
            child: FloatingActionButton(
              backgroundColor: Colors.white,
              onPressed: () {
                if (userPosition != null) {
                  _map?.animateCamera(
                    CameraUpdate.newLatLngZoom(userPosition!, 15),
                  );
                  setState(() => selectedPosition = userPosition);
                }
              },
              child: const Icon(Icons.my_location, color: Colors.blue),
            ),
          ),

          // ================== CONFIRM BUTTON ==================
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(.95),
                boxShadow: [
                  BoxShadow(
                    blurRadius: 10,
                    color: Colors.black12.withOpacity(.15),
                    offset: const Offset(0, -4),
                  ),
                ],
              ),
              child: SizedBox(
                height: 55,
                child: ElevatedButton(
                  onPressed: () {
                    if (selectedPosition == null) return;

                    // ✅ الحل الأساسي للمشكلة
                    // نرجّع الموقع للصفحة اللي فتحت MapPicker
                    Navigator.pop(context, selectedPosition);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green.shade700,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  child: Text(
                    "تأكيد الموقع",
                    style: GoogleFonts.cairo(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
