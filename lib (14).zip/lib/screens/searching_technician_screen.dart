// ignore_for_file: depend_on_referenced_packages

import 'dart:async';
import 'dart:ui';
import 'package:doctor_car_app/screens/tracking/tracking_screen.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../config/api_config.dart';

class SearchingTechnicianScreen extends StatefulWidget {
  final String userId;
  final String serviceType;
  final double lat;
  final double lng;
  final String orderId;

  const SearchingTechnicianScreen({
    super.key,
    required this.userId,
    required this.serviceType,
    required this.lat,
    required this.lng,
    required this.orderId,
  });

  @override
  State<SearchingTechnicianScreen> createState() =>
      _SearchingTechnicianScreenState();
}

class _SearchingTechnicianScreenState extends State<SearchingTechnicianScreen>
    with TickerProviderStateMixin {
  // ignore: unused_field
  GoogleMapController? _map;
  late AnimationController _pulseCtrl;

  LatLng? userLocation;

  int _seconds = 0;
  late Timer _timer;

  @override
  void initState() {
    super.initState();

    userLocation = LatLng(widget.lat, widget.lng);

    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 950),
      lowerBound: 0.82,
      upperBound: 1.18,
    )..repeat(reverse: true);

    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      setState(() => _seconds++);
    });

    // ⏳ انتقال تلقائي بعد 5 ثواني
    Future.delayed(const Duration(seconds: 5), goToTracking);
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _timer.cancel();
    super.dispose();
  }

  // =======================
  // NAVIGATION
  // =======================
  void goToTracking() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => TrackingScreen(
          orderId: widget.orderId,
          userId: widget.userId,
          serviceType: widget.serviceType,
          baseUrl: ApiConfig.baseUrl,
        ),
      ),
    );
  }

  // =======================
  // SMART TEXT
  // =======================
  String get searchingText {
    if (_seconds < 10) return "جارٍ البحث عن أقرب فني…";
    if (_seconds < 20) return "جاري التواصل مع الفنيين القريبين…";
    return "قريبًا سيتم العثور على فني مناسب";
  }

  // =======================
  // UI
  // =======================
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
        backgroundColor: Colors.black,
        body: Stack(
          children: [
            _buildDarkMap(),
            _buildBackButton(),
            _buildSearchingPulse(),
            _buildBottomGlassSheet(),
          ],
        ),
      ),
    );
  }

  // =======================
  // MAP
  // =======================
  Widget _buildDarkMap() {
    return GoogleMap(
      initialCameraPosition: CameraPosition(
        target: userLocation!,
        zoom: 14.5,
      ),
      onMapCreated: (controller) {
        _map = controller;
        controller.setMapStyle(_uberMapStyle);
      },
      zoomControlsEnabled: false,
      myLocationButtonEnabled: false,
      markers: {
        Marker(
          markerId: const MarkerId("me"),
          position: userLocation!,
          icon: BitmapDescriptor.defaultMarkerWithHue(
            BitmapDescriptor.hueRed,
          ),
        ),
      },
    );
  }

  // =======================
  // BACK BUTTON
  // =======================
  Widget _buildBackButton() {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.only(top: 10, left: 12),
        child: GestureDetector(
          onTap: _cancelOrder,
          child: Container(
            width: 45,
            height: 45,
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(.55),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.close,
              color: Colors.white,
              size: 22,
            ),
          ),
        ),
      ),
    );
  }

  // =======================
  // SEARCH ANIMATION
  // =======================
  Widget _buildSearchingPulse() {
    return Positioned(
      top: 200,
      left: 0,
      right: 0,
      child: ScaleTransition(
        scale: _pulseCtrl,
        child: Center(
          child: Container(
            width: 150,
            height: 150,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white.withOpacity(.06),
              border: Border.all(color: Colors.white, width: 3),
            ),
            child: const Icon(
              Icons.search,
              size: 60,
              color: Colors.white,
            ),
          ),
        ),
      ),
    );
  }

  // =======================
  // BOTTOM SHEET
  // =======================
  Widget _buildBottomGlassSheet() {
    return Positioned(
      bottom: 0,
      left: 0,
      right: 0,
      child: ClipRRect(
        borderRadius: const BorderRadius.vertical(top: Radius.circular(38)),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 32, horizontal: 26),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(.85),
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(38)),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _grabber(),
                const SizedBox(height: 20),
                Text(
                  searchingText,
                  style: GoogleFonts.cairo(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  "نوع الخدمة: ${widget.serviceType}",
                  style: GoogleFonts.cairo(color: Colors.black54),
                ),
                const SizedBox(height: 10),
                Text(
                  "مدة البحث: $_seconds ثانية",
                  style: GoogleFonts.cairo(
                    fontSize: 14,
                    color: Colors.black45,
                  ),
                ),
                const SizedBox(height: 22),
                const CircularProgressIndicator(
                  strokeWidth: 3,
                  color: Colors.blueAccent,
                ),
                const SizedBox(height: 28),
                _goTrackingButton(),
                const SizedBox(height: 14),
                _cancelButton(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _grabber() {
    return Container(
      width: 52,
      height: 6,
      decoration: BoxDecoration(
        color: Colors.grey.shade400,
        borderRadius: BorderRadius.circular(12),
      ),
    );
  }

  Widget _goTrackingButton() {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: goToTracking,
        style: ElevatedButton.styleFrom(
          padding: const EdgeInsets.symmetric(vertical: 16),
          backgroundColor: Colors.blueAccent,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
        child: Text(
          "الانتقال لتتبع الفني",
          style: GoogleFonts.cairo(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  Widget _cancelButton() {
    return TextButton(
      onPressed: _cancelOrder,
      child: Text(
        "إلغاء الطلب",
        style: GoogleFonts.cairo(
          fontSize: 16,
          color: Colors.redAccent,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  void _cancelOrder() {
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("تم إلغاء الطلب")),
    );
  }

  // =======================
  // MAP STYLE
  // =======================
  final String _uberMapStyle = '''
  [
    {"elementType":"geometry","stylers":[{"color":"#1c1c1c"}]},
    {"elementType":"labels.text.fill","stylers":[{"color":"#9e9e9e"}]},
    {"elementType":"labels.text.stroke","stylers":[{"color":"#000000"}]},
    {"featureType":"poi","stylers":[{"visibility":"off"}]},
    {"featureType":"road","stylers":[{"color":"#2b2b2b"}]},
    {"featureType":"water","stylers":[{"color":"#0d1117"}]}
  ]
  ''';
}
