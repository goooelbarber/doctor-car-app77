import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'review_screen.dart';

class PaymentScreen extends StatefulWidget {
  final String orderId;

  const PaymentScreen({super.key, required this.orderId});

  @override
  State<PaymentScreen> createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> {
  String selected = "cash";
  final String walletNumber = "01275649151";
  bool _isPaying = false;

  // 💰 قيم تجريبية (تربطها لاحقًا بالـ API)
  final double servicePrice = 120;
  final double fees = 30;
  final double discount = 0;

  double get total => servicePrice + fees - discount;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromARGB(255, 1, 10, 23),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        title: const Text(
          "الدفع",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Stack(
        children: [
          _content(),
          if (_isPaying) _loadingOverlay(),
        ],
      ),
    );
  }

  // ================= CONTENT =================

  Widget _content() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(22),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 10),
          const Text(
            "اختر طريقة الدفع",
            style: TextStyle(
              fontSize: 26,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 25),
          _paymentCard(
            id: "cash",
            title: "الدفع نقدًا",
            subtitle: "الدفع بعد انتهاء الخدمة",
            icon: Icons.money_rounded,
            color: Colors.greenAccent,
          ),
          _paymentCard(
            id: "visa",
            title: "فيزا / ماستر كارد",
            subtitle: "الدفع الإلكتروني الآمن",
            icon: Icons.credit_card_rounded,
            color: Colors.blueAccent,
          ),
          _paymentCard(
            id: "wallet",
            title: "فودافون كاش",
            subtitle: "تحويل للمحفظة",
            icon: Icons.account_balance_wallet_rounded,
            color: Colors.redAccent,
          ),
          if (selected == "wallet") _walletBox(),
          const SizedBox(height: 30),
          _invoiceCard(),
          const SizedBox(height: 30),
          _payButton(),
          const SizedBox(height: 50),
        ],
      ),
    );
  }

  // ================= PAYMENT CARD =================

  Widget _paymentCard({
    required String id,
    required String title,
    required String subtitle,
    required IconData icon,
    required Color color,
  }) {
    final bool isActive = selected == id;

    return GestureDetector(
      onTap: () => setState(() => selected = id),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 280),
        margin: const EdgeInsets.only(bottom: 18),
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: isActive ? color.withOpacity(.12) : Colors.white10,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(
            color: isActive ? color : Colors.white24,
            width: isActive ? 2 : 1,
          ),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: color.withOpacity(.25),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Icon(icon, size: 32, color: color),
            ),
            const SizedBox(width: 18),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.white)),
                  const SizedBox(height: 6),
                  Text(subtitle,
                      style:
                          const TextStyle(fontSize: 14, color: Colors.white70)),
                ],
              ),
            ),
            Icon(
              isActive ? Icons.check_circle : Icons.circle_outlined,
              size: 26,
              color: isActive ? color : Colors.white38,
            ),
          ],
        ),
      ),
    );
  }

  // ================= WALLET BOX =================

  Widget _walletBox() {
    return Container(
      padding: const EdgeInsets.all(20),
      margin: const EdgeInsets.only(bottom: 20),
      decoration: BoxDecoration(
        color: Colors.black,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.redAccent),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text("رقم فودافون كاش",
              style:
                  TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: Text(
                  walletNumber,
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    letterSpacing: 1,
                  ),
                ),
              ),
              IconButton(
                icon: const Icon(Icons.copy, color: Colors.white),
                onPressed: () {
                  Clipboard.setData(ClipboardData(text: walletNumber));
                  _snack("تم نسخ رقم المحفظة");
                },
              )
            ],
          ),
          const SizedBox(height: 8),
          const Text(
            "حوّل المبلغ ثم اضغط (دفع الآن)",
            style: TextStyle(color: Colors.white70),
          ),
        ],
      ),
    );
  }

  // ================= INVOICE =================

  Widget _invoiceCard() {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: Colors.white10,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: Colors.white24),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _row("سعر الخدمة", servicePrice),
          _row("رسوم إضافية", fees),
          _row("خصم", -discount),
          const Divider(color: Colors.white24, height: 30),
          Text(
            "الإجمالي: ${total.toStringAsFixed(2)} ج.م",
            style: const TextStyle(
              fontSize: 26,
              fontWeight: FontWeight.bold,
              color: Colors.amber,
            ),
          ),
        ],
      ),
    );
  }

  Widget _row(String t, double v) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(t, style: const TextStyle(color: Colors.white70)),
          Text(
            "${v.toStringAsFixed(2)} ج.م",
            style: const TextStyle(color: Colors.white),
          ),
        ],
      ),
    );
  }

  // ================= PAY =================

  Widget _payButton() {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: _isPaying ? null : _pay,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.amber,
          padding: const EdgeInsets.symmetric(vertical: 18),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        ),
        child: const Text(
          "تأكيد الدفع",
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
      ),
    );
  }

  Future<void> _pay() async {
    setState(() => _isPaying = true);

    await Future.delayed(const Duration(seconds: 2));

    setState(() => _isPaying = false);

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => ReviewScreen(orderId: widget.orderId),
      ),
    );
  }

  // ================= LOADING =================

  Widget _loadingOverlay() {
    return Container(
      color: Colors.black87,
      child: const Center(
        child: CircularProgressIndicator(color: Colors.amber),
      ),
    );
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }
}
