// screens/services/supplementary_services_screen.dart
// ignore: unnecessary_import
import 'dart:ui';
// ignore: unused_import
import 'package:doctor_car_app/screens/map_picker_screen.dart';
// ignore: unused_import
import 'package:doctor_car_app/screens/searching_technician_screen.dart';
import 'package:doctor_car_app/screens/service_details_screen.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

// ✅ لو المسار عندك مختلف عدّليه فقط

class SupplementaryServicesScreen extends StatefulWidget {
  const SupplementaryServicesScreen({super.key});

  @override
  State<SupplementaryServicesScreen> createState() =>
      _SupplementaryServicesScreenState();
}

class _SupplementaryServicesScreenState
    extends State<SupplementaryServicesScreen> {
  static const Color _bg = Color.fromARGB(255, 1, 10, 23);
  final TextEditingController _searchCtrl = TextEditingController();
  String _category = "الكل";

  LinearGradient get _gold => const LinearGradient(
        colors: [Color(0xffE8C87A), Color(0xffB68A32)],
      );

  final List<String> categories = [
    "الكل",
    "ميكانيكا",
    "كهرباء",
    "إطارات",
    "عفشة",
    "فحص",
    "تنظيف",
    "طوارئ",
  ];

  final List<Map<String, dynamic>> services = [
    // ================= طوارئ =================
    {
      "name": "سطحة سيارات",
      "icon": Icons.local_shipping,
      "category": "طوارئ",
      "price": 350,
      "rating": 4.9,
      "time": "حسب المسافة",
      "desc": "نقل السيارة عند العطل",
    },
    {
      "name": "فتح سيارة",
      "icon": Icons.lock_open,
      "category": "طوارئ",
      "price": 120,
      "rating": 4.7,
      "time": "10 دقائق",
      "desc": "فتح السيارة بدون تلف",
    },
    {
      "name": "نفاد بنزين",
      "icon": Icons.local_gas_station,
      "category": "طوارئ",
      "price": 100,
      "rating": 4.6,
      "time": "10 دقائق",
      "desc": "توصيل وقود للطوارئ",
    },

    // ================= ميكانيكا =================
    {
      "name": "تغيير زيت",
      "icon": Icons.oil_barrel,
      "category": "ميكانيكا",
      "price": 120,
      "rating": 4.7,
      "time": "10 دقائق",
      "desc": "تغيير زيت + فحص المحرك",
    },
    {
      "name": "ميكانيكي عام",
      "icon": Icons.build,
      "category": "ميكانيكا",
      "price": 150,
      "rating": 4.8,
      "time": "20 دقيقة",
      "desc": "إصلاح أعطال ميكانيكية",
    },
    {
      "name": "تغيير فلتر هواء",
      "icon": Icons.filter_alt,
      "category": "ميكانيكا",
      "price": 60,
      "rating": 4.5,
      "time": "5 دقائق",
      "desc": "تغيير فلتر الهواء",
    },

    // ================= كهرباء =================
    {
      "name": "تغيير بطارية",
      "icon": Icons.battery_charging_full,
      "category": "كهرباء",
      "price": 180,
      "rating": 4.7,
      "time": "12 دقيقة",
      "desc": "فحص وتركيب بطارية",
    },
    {
      "name": "شحن بطارية",
      "icon": Icons.battery_full,
      "category": "كهرباء",
      "price": 90,
      "rating": 4.4,
      "time": "10 دقائق",
      "desc": "شحن البطارية",
    },
    {
      "name": "فحص كهرباء",
      "icon": Icons.bolt,
      "category": "كهرباء",
      "price": 100,
      "rating": 4.3,
      "time": "15 دقيقة",
      "desc": "تشخيص كهرباء السيارة",
    },

    // ================= إطارات =================
    {
      "name": "بنشر / كاوتش",
      "icon": Icons.tire_repair,
      "category": "إطارات",
      "price": 60,
      "rating": 4.8,
      "time": "7 دقائق",
      "desc": "إصلاح إطار",
    },
    {
      "name": "تغيير كاوتش",
      "icon": Icons.circle,
      "category": "إطارات",
      "price": 80,
      "rating": 4.6,
      "time": "10 دقائق",
      "desc": "تغيير الإطار",
    },

    // ================= عفشة =================
    {
      "name": "فحص عفشة",
      "icon": Icons.car_repair,
      "category": "عفشة",
      "price": 120,
      "rating": 4.8,
      "time": "20 دقيقة",
      "desc": "فحص كامل للعفشة",
    },
    {
      "name": "تغيير مساعد",
      "icon": Icons.settings,
      "category": "عفشة",
      "price": 300,
      "rating": 4.7,
      "time": "30 دقيقة",
      "desc": "تغيير مساعد أمامي أو خلفي",
    },
    {
      "name": "شد عفشة",
      "icon": Icons.tune,
      "category": "عفشة",
      "price": 150,
      "rating": 4.6,
      "time": "25 دقيقة",
      "desc": "شد وضبط العفشة",
    },

    // ================= فحص =================
    {
      "name": "فحص كمبيوتر",
      "icon": Icons.memory,
      "category": "فحص",
      "price": 130,
      "rating": 4.6,
      "time": "8 دقائق",
      "desc": "تشخيص أعطال ECU",
    },

    // ================= تنظيف =================
    {
      "name": "غسيل السيارة",
      "icon": Icons.local_car_wash,
      "category": "تنظيف",
      "price": 90,
      "rating": 4.2,
      "time": "20 دقيقة",
      "desc": "غسيل داخلي وخارجي",
    },
  ];

  List<Map<String, dynamic>> get filtered => services.where((s) {
        final search = _searchCtrl.text.trim().toLowerCase();
        final name = s["name"].toString().toLowerCase();
        final cat = s["category"].toString().toLowerCase();

        final matchSearch =
            search.isEmpty || name.contains(search) || cat.contains(search);
        final matchCat = _category == "الكل" || s["category"] == _category;

        return matchSearch && matchCat;
      }).toList();

  Map<String, dynamic> _safeService(Map<String, dynamic> s) => {
        ...s,
        "type": s["type"] ?? s["name"],
      };

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: _bg,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          centerTitle: true,
          title: ShaderMask(
            shaderCallback: (b) => _gold.createShader(b),
            child: Text(
              "الخدمات الإضافية",
              style: GoogleFonts.cairo(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.white),
            ),
          ),
        ),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: TextField(
                controller: _searchCtrl,
                onChanged: (_) => setState(() {}),
                style: GoogleFonts.cairo(color: Colors.white),
                decoration: InputDecoration(
                  hintText: "ابحث عن خدمة...",
                  hintStyle: GoogleFonts.cairo(color: Colors.white38),
                  prefixIcon: const Icon(Icons.search, color: Colors.white38),
                  filled: true,
                  fillColor: Colors.white.withOpacity(.06),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(18),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 42,
              child: ListView.separated(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                scrollDirection: Axis.horizontal,
                itemCount: categories.length,
                separatorBuilder: (_, __) => const SizedBox(width: 10),
                itemBuilder: (_, i) {
                  final c = categories[i];
                  final active = c == _category;
                  return GestureDetector(
                    onTap: () => setState(() => _category = c),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 20, vertical: 8),
                      decoration: BoxDecoration(
                        gradient: active ? _gold : null,
                        color: active ? null : Colors.white.withOpacity(.06),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        c,
                        style: GoogleFonts.cairo(
                          color: active ? Colors.black : Colors.white70,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
            Expanded(
              child: GridView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: filtered.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisExtent: 190,
                  crossAxisSpacing: 14,
                  mainAxisSpacing: 14,
                ),
                itemBuilder: (_, i) {
                  final s = filtered[i];
                  return GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) =>
                              ServiceDetailsScreen(service: _safeService(s)),
                        ),
                      );
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(.06),
                        borderRadius: BorderRadius.circular(22),
                        border: Border.all(color: Colors.white24),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(s["icon"], size: 46, color: Colors.amber),
                          const SizedBox(height: 8),
                          Text(
                            s["name"],
                            textAlign: TextAlign.center,
                            style: GoogleFonts.cairo(
                                color: Colors.white,
                                fontWeight: FontWeight.bold),
                          ),
                          Text(
                            "${s['price']} ج.م · ${s['time']}",
                            style: GoogleFonts.cairo(
                                color: Colors.white70, fontSize: 13),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
