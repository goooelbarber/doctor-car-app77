import 'dart:math';

double _degToRad(double deg) => deg * (pi / 180);

/// حساب المسافة KM
double calcDistanceKm(double lat1, double lon1, double lat2, double lon2) {
  const earthRadius = 6371;
  final dLat = _degToRad(lat2 - lat1);
  final dLon = _degToRad(lon2 - lon1);

  final a = sin(dLat / 2) * sin(dLat / 2) +
      cos(_degToRad(lat1)) *
          cos(_degToRad(lat2)) *
          sin(dLon / 2) *
          sin(dLon / 2);

  final c = 2 * atan2(sqrt(a), sqrt(1 - a));
  return earthRadius * c;
}

/// وقت الوصول: السرعة 40 كم/ساعة
String calcETA(double distanceKm) {
  double hours = distanceKm / 40;
  int mins = (hours * 60).round();
  return "$mins دقيقة";
}
