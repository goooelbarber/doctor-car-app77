class ApiConfig {
  ApiConfig._();

  // ======================================================
  // 🌐 BACKEND
  // ======================================================
  // ✅ خليهم هنا بس عشان تغيير الـ IP / Port يبقى في مكان واحد
  static const String baseUrl = "http://192.168.1.11:5555";
  static const String socketUrl = baseUrl;

  // ✅ Defaults
  static const Duration requestTimeout = Duration(seconds: 12);

  // ✅ Headers لو هتحتاجها في http calls
  static Map<String, String> jsonHeaders({String? token}) => {
        "Content-Type": "application/json",
        if (token != null && token.isNotEmpty) "Authorization": "Bearer $token",
      };

  // ======================================================
  // 🔐 AUTH
  // ======================================================
  static String get userLogin => "$baseUrl/api/users/login";
  static String get technicianLogin => "$baseUrl/api/technicians/login";

  // ======================================================
  // 🚕 ORDERS
  // ======================================================
  static String get orders => "$baseUrl/api/orders";
  static String get createOrder => "$baseUrl/api/orders";

  // ======================================================
  // 👨‍🔧 TECHNICIANS
  // ======================================================
  static String get technicians => "$baseUrl/api/technicians";

  // ======================================================
  // 🏪 CENTERS
  // ======================================================
  static String get centers => "$baseUrl/api/centers";

  /// ✅ GET /api/centers/nearby
  /// Query:
  /// lat,lng,limit,maxDistance (meters)
  /// + optional: governorate, city
  static String nearbyCenters({
    required double lat,
    required double lng,
    int limit = 20,
    int maxDistanceMeters = 50000, // default 50km
    String? governorate,
    String? city,
  }) {
    final l = limit.clamp(1, 50);

    // ✅ safety limits: 1km..200km
    final md = maxDistanceMeters.clamp(1000, 200000);

    final qp = <String, String>{
      "lat": lat.toString(),
      "lng": lng.toString(),
      "limit": l.toString(),
      "maxDistance": md.toString(),
    };

    if (governorate != null && governorate.trim().isNotEmpty) {
      qp["governorate"] = governorate.trim();
    }
    if (city != null && city.trim().isNotEmpty) {
      qp["city"] = city.trim();
    }

    return Uri.parse("$baseUrl/api/centers/nearby")
        .replace(queryParameters: qp)
        .toString();
  }

  /// ✅ convenience: get Damietta centers (حتى لو المستخدم بعيد)
  static String nearbyDamiettaCenters({
    int limit = 50,
    int maxDistanceMeters = 200000, // 200km
    String? city,
  }) {
    return nearbyCenters(
      lat: 31.4165,
      lng: 31.8133,
      limit: limit,
      maxDistanceMeters: maxDistanceMeters,
      governorate: "دمياط",
      city: city,
    );
  }

  // ======================================================
  // 💬 SUPPORT CHAT (REST)
  // ======================================================
  static String get support => "$baseUrl/api/support";
  static String get supportChats => "$baseUrl/api/support/chats";
  static String supportMessages(String chatId) =>
      "$baseUrl/api/support/chats/$chatId/messages";

  // ======================================================
  // 💳 PAYMENTS
  // ======================================================
  static String get payments => "$baseUrl/api/payments";

  // ======================================================
  // ⭐ FEEDBACK
  // ======================================================
  static String get feedback => "$baseUrl/api/feedback";

  // ======================================================
  // 🗺️ GOOGLE MAPS
  // ======================================================
  // ⚠️ الأفضل تحط الـ API Key في .env أو --dart-define عشان الأمان
  static const String googleMapsApiKey =
      "AIzaSyD9BGSScE-DU9nbdFgIbJV4fbNspNdPg_M";

  static String autocomplete(String text, {String lang = "ar"}) {
    final q = Uri.encodeComponent(text.trim());
    return "https://maps.googleapis.com/maps/api/place/autocomplete/json"
        "?input=$q&key=$googleMapsApiKey&language=$lang&components=country:eg";
  }

  static String placeDetails(String placeId, {String lang = "ar"}) {
    final id = Uri.encodeComponent(placeId.trim());
    return "https://maps.googleapis.com/maps/api/place/details/json"
        "?place_id=$id&key=$googleMapsApiKey&language=$lang";
  }
}
