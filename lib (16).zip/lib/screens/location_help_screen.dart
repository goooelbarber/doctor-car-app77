import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_fonts/google_fonts.dart';

// ✅ على الويب فقط
// ignore: avoid_web_libraries_in_flutter
import 'dart:html' as html;

class LocationHelpScreen extends StatefulWidget {
  final bool isArabic;
  final bool isDarkMode;

  /// لازم Future عشان نقدر نعمل await قبل ما نقفل الشاشة
  final Future<void> Function() onRefresh;

  const LocationHelpScreen({
    super.key,
    required this.isArabic,
    required this.isDarkMode,
    required this.onRefresh,
  });

  @override
  State<LocationHelpScreen> createState() => _LocationHelpScreenState();
}

class _LocationHelpScreenState extends State<LocationHelpScreen> {
  bool _loading = false;

  Color get bg =>
      widget.isDarkMode ? const Color(0xff0E1320) : const Color(0xffF5F6FA);
  Color get surface =>
      widget.isDarkMode ? const Color(0xff151A2E) : Colors.white;
  Color get textMain =>
      widget.isDarkMode ? Colors.white : const Color(0xff111827);
  Color get textSub =>
      widget.isDarkMode ? Colors.white70 : const Color(0xff6B7280);

  static const Color primary = Color(0xff1F4BA5);

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: GoogleFonts.cairo()),
        behavior: SnackBarBehavior.floating,
        backgroundColor: widget.isDarkMode
            ? const Color(0xff0B1220)
            : const Color(0xff111827),
      ),
    );
  }

  // ✅ فحص + طلب صلاحية الموقع قبل refresh
  Future<bool> _ensureLocationReady() async {
    try {
      // 1) هل خدمة الموقع شغالة؟ (على الموبايل/ديسكتوب)
      // على الويب sometimes بيرجع true دائمًا، بس نسيبه برضو
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled && !kIsWeb) {
        _snack(widget.isArabic
            ? "خدمة الموقع مقفولة.. فعّل GPS من إعدادات الجهاز ❌"
            : "Location services are OFF. Enable GPS ❌");
        return false;
      }

      // 2) صلاحيات
      LocationPermission permission = await Geolocator.checkPermission();

      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }

      if (permission == LocationPermission.denied) {
        _snack(widget.isArabic
            ? "تم رفض صلاحية الموقع. فعّلها من المتصفح/الإعدادات ❌"
            : "Location permission denied. Enable it from browser/settings ❌");
        return false;
      }

      if (permission == LocationPermission.deniedForever) {
        _snack(widget.isArabic
            ? "الصلاحية مرفوضة نهائيًا. افتح الإعدادات وفعّل الموقع ❌"
            : "Permission denied forever. Open settings and enable location ❌");
        return false;
      }

      // 3) اختبار سريع إننا نقدر نجيب موقع (لتفادي إن refresh يعلق)
      // نعمل timeout عشان لو المتصفح/الجهاز معلق ما يقفش للأبد
      await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.low,
      ).timeout(const Duration(seconds: 8));

      return true;
    } on TimeoutException {
      _snack(widget.isArabic
          ? "أخذ الموقع وقت طويل.. جرّب تاني بعد ما تفعّل Location ✅"
          : "Getting location timed out. Try again after enabling Location ✅");
      return false;
    } catch (e) {
      _snack(widget.isArabic
          ? "تعذر الحصول على الموقع: $e"
          : "Couldn't get location: $e");
      return false;
    }
  }

  Future<void> _handleRefresh() async {
    if (_loading) return;
    setState(() => _loading = true);

    try {
      final ok = await _ensureLocationReady();
      if (!ok) return;

      await widget.onRefresh();

      if (!mounted) return;
      Navigator.pop(context);
    } catch (e) {
      _snack(widget.isArabic
          ? "حصل خطأ أثناء تحديث المراكز ❌"
          : "Error while refreshing centers ❌");
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _openSettings() async {
    if (kIsWeb) {
      // ✅ محاولات فتح إعدادات الموقع في Chrome/Edge
      // ملاحظة: بعض المتصفحات تمنع فتح صفحات settings مباشرة
      try {
        // 1) فتح إعدادات الموقع الخاصة بالمتصفح (Chrome/Edge)
        // قد لا تعمل على كل الأجهزة/المتصفحات
        html.window.open('chrome://settings/content/location', '_blank');

        // 2) fallback: فتح صفحة تعليمات جوجل الرسمية/مساعدة (لو عايز)
        // لو حسيت chrome:// مش شغال، شيل السطر ده أو سيبه كـ fallback
        // html.window.open('https://support.google.com/chrome/answer/142065', '_blank');

        _snack(widget.isArabic
            ? "لو ما اتفتحتش الإعدادات: اضغط 🔒 جنب الرابط > Location > Allow ثم Refresh ✅"
            : "If settings didn't open: click 🔒 next to URL > Location > Allow then Refresh ✅");
      } catch (_) {
        _snack(widget.isArabic
            ? "افتح 🔒 جنب الرابط > Location > Allow ثم Refresh ✅"
            : "Open 🔒 next to URL > Location > Allow then Refresh ✅");
      }
      return;
    }

    try {
      await Geolocator.openLocationSettings();
    } catch (_) {
      _snack(widget.isArabic
          ? "تعذر فتح الإعدادات على هذا الجهاز"
          : "Cannot open settings on this device");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: widget.isArabic ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        backgroundColor: bg,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          title: Text(
            widget.isArabic ? "حل مشكلة الموقع" : "Fix Location Problem",
            style: GoogleFonts.cairo(
              fontWeight: FontWeight.w900,
              color: textMain,
            ),
          ),
          iconTheme: IconThemeData(color: textMain),
        ),
        body: Padding(
          padding: const EdgeInsets.all(16),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: surface,
              borderRadius: BorderRadius.circular(22),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.location_off, color: textSub, size: 40),
                const SizedBox(height: 12),
                Text(
                  widget.isArabic
                      ? "عشان نعرض المراكز القريبة لازم تفعّل الموقع ✅"
                      : "To show nearby centers, enable location ✅",
                  style: GoogleFonts.cairo(
                    fontSize: 15,
                    fontWeight: FontWeight.w900,
                    color: textMain,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  widget.isArabic
                      ? "📌 لو بتستخدم Chrome (Web):\n1) اضغط 🔒 جنب الرابط\n2) Location = Allow\n3) اعمل Refresh"
                      : "📌 If you're using Chrome (Web):\n1) Click 🔒 next to the URL\n2) Location = Allow\n3) Refresh the page",
                  style: GoogleFonts.cairo(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: textSub,
                    height: 1.5,
                  ),
                ),
                const SizedBox(height: 18),

                // ✅ زر تحديث المراكز
                SizedBox(
                  width: double.infinity,
                  height: 52,
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: primary,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                    ),
                    icon: _loading
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                              strokeWidth: 2.5,
                              color: Colors.white,
                            ),
                          )
                        : const Icon(Icons.refresh),
                    label: Text(
                      widget.isArabic ? "تحديث المراكز" : "Refresh Centers",
                      style: GoogleFonts.cairo(fontWeight: FontWeight.w900),
                    ),
                    onPressed: _handleRefresh,
                  ),
                ),

                const SizedBox(height: 12),

                // ✅ زر فتح إعدادات الموقع
                SizedBox(
                  width: double.infinity,
                  height: 52,
                  child: OutlinedButton.icon(
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: primary, width: 1.4),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                    ),
                    icon: const Icon(Icons.settings, color: primary),
                    label: Text(
                      widget.isArabic
                          ? "فتح إعدادات الموقع"
                          : "Open Location Settings",
                      style: GoogleFonts.cairo(
                        fontWeight: FontWeight.w900,
                        color: primary,
                      ),
                    ),
                    onPressed: _openSettings,
                  ),
                ),

                const Spacer(),
                Center(
                  child: Text(
                    widget.isArabic
                        ? "لو ما اشتغلش.. ابعتلي Screenshot من Console error ✅"
                        : "If it still doesn't work, send Console error screenshot ✅",
                    style: GoogleFonts.cairo(
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      color: textSub,
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
