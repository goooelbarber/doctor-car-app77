// PATH: lib/screens/home_screen.dart
// ignore_for_file: depend_on_referenced_packages

import 'dart:async';
import 'dart:convert';

import 'package:doctor_car_app/maintenance_services_screen.dart';
import 'package:doctor_car_app/pages/home/home_page.dart';
import 'package:doctor_car_app/screens/about/about_us_screen.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:http/http.dart' as http;
import 'package:geolocator/geolocator.dart';
import 'package:doctor_car_app/screens/location_help_screen.dart';
import 'package:doctor_car_app/screens/obd_report_preview_screen.dart';
import 'account_settings_screen.dart';
import 'road_services_screen.dart';
import 'package:doctor_car_app/screens/support_chat_screen.dart';
import 'package:doctor_car_app/services/support_chat_service.dart';
import 'package:doctor_car_app/config/api_config.dart';
import 'package:doctor_car_app/screens/contact_screen.dart';
import 'package:doctor_car_app/screens/smart_accident_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

// =======================
// Models
// =======================
class OfferItem {
  final String title;
  final String image;
  final String distance;
  final String until;

  const OfferItem({
    required this.title,
    required this.image,
    required this.distance,
    required this.until,
  });
}

class CenterItem {
  final String id;
  final String name;
  final double rating;
  final String image; // asset OR url
  final double? lat;
  final double? lng;

  // ✅ distance in meters (server or local)
  final double? distanceMeters;

  const CenterItem({
    required this.id,
    required this.name,
    required this.rating,
    required this.image,
    this.lat,
    this.lng,
    this.distanceMeters,
  });

  bool get hasCoords => lat != null && lng != null;

  String get distanceText {
    if (distanceMeters == null) return "";
    final km = distanceMeters! / 1000.0;
    if (km < 1) return "${distanceMeters!.round()} م";
    return "${km.toStringAsFixed(km < 10 ? 1 : 0)} كم";
  }

  CenterItem copyWith({double? distanceMeters}) {
    return CenterItem(
      id: id,
      name: name,
      rating: rating,
      image: image,
      lat: lat,
      lng: lng,
      distanceMeters: distanceMeters ?? this.distanceMeters,
    );
  }

  factory CenterItem.fromJson(Map<String, dynamic> j) {
    double _num(dynamic v, {double fallback = 0}) {
      if (v == null) return fallback;
      if (v is num) return v.toDouble();
      return double.tryParse(v.toString()) ?? fallback;
    }

    double? lat;
    double? lng;

    // API returns lat/lng
    if (j["lat"] != null && j["lng"] != null) {
      lat = _num(j["lat"]);
      lng = _num(j["lng"]);
    } else if (j["location"] is Map) {
      // fallback if returned GeoJSON
      final loc = (j["location"] as Map);
      if (loc["coordinates"] is List &&
          (loc["coordinates"] as List).length >= 2) {
        lng = _num((loc["coordinates"] as List)[0]);
        lat = _num((loc["coordinates"] as List)[1]);
      }
    }

    double? distMeters;
    if (j["distanceMeters"] != null) {
      distMeters = _num(j["distanceMeters"]);
    } else if (j["distance"] != null) {
      // sometimes server returns km
      final d = _num(j["distance"]);
      distMeters = d > 1000 ? d : (d * 1000);
    }

    return CenterItem(
      id: (j["_id"] ?? j["id"] ?? "").toString(),
      name: (j["name"] ?? j["title"] ?? "").toString(),
      rating: _num(j["rating"], fallback: 0).clamp(0, 5).toDouble(),
      image: (j["imageUrl"] ?? j["image"] ?? "").toString(),
      lat: lat,
      lng: lng,
      distanceMeters: distMeters,
    );
  }
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  // ================== SETTINGS ==================
  bool _isArabic = true;
  bool _isDarkMode = false;
  bool _prefsLoaded = false;

  // ================== LOCATION STATE ==================
  Position? _myPos;
  String? _locationError;

  // ================== RADIUS FEATURE ==================
  static const List<int> _radiusOptionsKm = [5, 10, 20, 50];
  int _selectedRadiusKm = 20; // default

  double get _maxRadiusMeters => _selectedRadiusKm * 1000.0;
  static const int _centersLimit = 50;

  // ================== CONTROLLERS ==================
  final PageController _bannerController = PageController();
  int _currentBanner = 0;
  Timer? _timer;

  // Bottom nav active index
  int _navIndex = 4;

  // ================== COLORS ==================
  static const Color _primary = Color(0xff1F4BA5);
  static const Color _gold = Color(0xffF7B500);

  // ================== DATA ==================
  final List<String> banners = const [
    "assets/banners/1.png",
    "assets/banners/2.png",
    "assets/banners/3.png",
  ];

  final List<OfferItem> offers = const [
    OfferItem(
      title: "خصم 25% على الصيانة",
      image: "assets/offers/1.png",
      distance: "12 كم",
      until: "صالح حتى 31-01-2026",
    ),
    OfferItem(
      title: "خصم 8% على الزجاج المحلي",
      image: "assets/offers/2.png",
      distance: "15 كم",
      until: "صالح حتى 15-01-2026",
    ),
    OfferItem(
      title: "خصم 20% على السطحة",
      image: "assets/offers/3.png",
      distance: "9 كم",
      until: "صالح حتى 01-02-2026",
    ),
  ];

  late Future<List<CenterItem>> _centersFuture;

  // ================== TRANSLATIONS ==================
  final Map<String, Map<String, String>> _strings = const {
    "home": {"ar": "الرئيسية", "en": "Home"},
    "account": {"ar": "حسابي", "en": "Account"},
    "vehicles": {"ar": "مركباتي", "en": "Vehicles"},
    "orders": {"ar": "الطلبات", "en": "Orders"},
    "offers": {"ar": "عروض مراكز الصيانة", "en": "Maintenance Offers"},
    "nearby": {"ar": "مراكز قريبة منك", "en": "Nearby Centers"},
    "urgent": {"ar": "خدمة الطريق", "en": "Road Service"},
    "maint": {"ar": "خدمات الصيانة", "en": "Maintenance"},
    "contact": {"ar": "تواصل معنا", "en": "Contact Us"},
    "how": {"ar": "ازاي تستخدم Doctor Car", "en": "How to use Doctor Car"},
    "why": {"ar": "ليه تختار Doctor Car؟", "en": "Why Doctor Car?"},
    "getOffer": {"ar": "احصل على العرض", "en": "Get Offer"},
    "supportChat": {
      "ar": "الدعم الفني (شات مباشر)",
      "en": "Support (Live Chat)"
    },
    "supportSub": {
      "ar": "تواصل فورًا مع الدعم أو الميكانيكي",
      "en": "Chat with support instantly"
    },
    "emergency": {"ar": "طوارئ 112", "en": "Emergency 112"},
    "emergencySub": {
      "ar": "للحوادث والمواقف الخطيرة فقط",
      "en": "For serious emergencies only"
    },
    "loginFirst": {"ar": "يجب تسجيل الدخول أولاً", "en": "Please login first"},
    "chatError": {"ar": "حدث خطأ أثناء فتح الشات", "en": "Failed to open chat"},
    "callFail": {
      "ar": "لا يمكن فتح الاتصال على هذا الجهاز",
      "en": "Cannot place a call on this device"
    },
    "loadFail": {"ar": "تعذر تحميل المراكز", "en": "Failed to load centers"},
    "retry": {"ar": "إعادة المحاولة", "en": "Retry"},
    "details": {"ar": "تفاصيل", "en": "Details"},
    "noCenters": {
      "ar": "لا يوجد مراكز قريبة الآن",
      "en": "No nearby centers right now"
    },
    "needLocation": {
      "ar": "فعّل الموقع لعرض أقرب المراكز",
      "en": "Enable location to show nearby centers"
    },
    "openSettings": {"ar": "فتح الإعدادات", "en": "Open Settings"},
    "locating": {
      "ar": "جارٍ تحديد موقعك...",
      "en": "Detecting your location..."
    },
    "yourLocation": {"ar": "موقعك", "en": "Your location"},
    "radius": {"ar": "النطاق", "en": "Radius"},
  };

  String trKey(String key) => _strings[key]?[_isArabic ? "ar" : "en"] ?? "";

  // ================== THEME TOKENS ==================
  Color get bgColor =>
      _isDarkMode ? const Color(0xff0E1320) : const Color(0xffF5F6FA);
  Color get surface => _isDarkMode ? const Color(0xff151A2E) : Colors.white;
  Color get surface2 => _isDarkMode ? const Color(0xff11182A) : Colors.white;
  Color get textMain => _isDarkMode ? Colors.white : const Color(0xff111827);
  Color get textSub => _isDarkMode ? Colors.white70 : const Color(0xff6B7280);
  Color get stroke => _isDarkMode
      ? Colors.white.withOpacity(.10)
      : Colors.black.withOpacity(.06);
  Color get shadow => Colors.black.withOpacity(_isDarkMode ? .28 : .06);

  TextStyle get titleStyle => GoogleFonts.cairo(
      fontSize: 18, fontWeight: FontWeight.w800, color: textMain);
  TextStyle smallStyle({Color? c, FontWeight w = FontWeight.w600}) =>
      GoogleFonts.cairo(fontSize: 13, color: c ?? textSub, fontWeight: w);
  TextStyle bodyStyle({Color? c, FontWeight w = FontWeight.w600}) =>
      GoogleFonts.cairo(fontSize: 14, color: c ?? textMain, fontWeight: w);

  // ================== INIT ==================
  @override
  void initState() {
    super.initState();

    _centersFuture = _fetchCentersNearMe(); // ✅ avoid late init errors
    _loadPrefs();

    _timer = Timer.periodic(const Duration(seconds: 4), (_) {
      if (!mounted) return;
      if (banners.isEmpty) return;
      _currentBanner = (_currentBanner + 1) % banners.length;
      _bannerController.animateToPage(
        _currentBanner,
        duration: const Duration(milliseconds: 550),
        curve: Curves.easeInOutCubic,
      );
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _bannerController.dispose();
    super.dispose();
  }

  // ================== Prefs ==================
  Future<void> _loadPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;

    final savedRadius = prefs.getInt("nearbyRadiusKm");
    final radius = (_radiusOptionsKm.contains(savedRadius))
        ? savedRadius!
        : _selectedRadiusKm;

    setState(() {
      _isArabic = prefs.getBool("isArabic") ?? true;
      _isDarkMode = prefs.getBool("isDarkMode") ?? false;
      _selectedRadiusKm = radius;
      _prefsLoaded = true;
    });

    // refresh with the saved radius
    _refresh();
  }

  Future<void> _toggleLanguage() async {
    HapticFeedback.selectionClick();
    setState(() => _isArabic = !_isArabic);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool("isArabic", _isArabic);
  }

  Future<void> _toggleTheme() async {
    HapticFeedback.selectionClick();
    setState(() => _isDarkMode = !_isDarkMode);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool("isDarkMode", _isDarkMode);
  }

  Future<void> _setRadiusKm(int km) async {
    if (km == _selectedRadiusKm) return;
    HapticFeedback.selectionClick();
    setState(() => _selectedRadiusKm = km);

    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt("nearbyRadiusKm", km);

    await _refresh();
  }

  void _goto(Widget page) =>
      Navigator.push(context, MaterialPageRoute(builder: (_) => page));

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: GoogleFonts.cairo()),
        behavior: SnackBarBehavior.floating,
        backgroundColor:
            _isDarkMode ? const Color(0xff0B1220) : const Color(0xff111827),
      ),
    );
  }

  // ================== LOCATION (geolocator) ==================
  Future<Position> _getAccurateLocation() async {
    // 1) Service enabled (mostly for mobile/desktop)
    final serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled && !kIsWeb) {
      throw Exception("LOCATION_SERVICE_DISABLED");
    }

    // 2) Permission
    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }

    if (permission == LocationPermission.denied) {
      throw Exception("LOCATION_PERMISSION_DENIED");
    }
    if (permission == LocationPermission.deniedForever) {
      throw Exception("LOCATION_PERMISSION_DENIED_FOREVER");
    }

    // 3) fast last known (update UI quickly)
    try {
      final last = await Geolocator.getLastKnownPosition();
      if (last != null) {
        _myPos = last;
        if (mounted) setState(() {});
      }
    } catch (_) {}

    // 4) current position with timeout (prevent hanging)
    try {
      final current = await Geolocator.getCurrentPosition(
        desiredAccuracy: kIsWeb ? LocationAccuracy.low : LocationAccuracy.high,
        timeLimit: const Duration(seconds: 12),
      );

      _myPos = current;
      if (mounted) setState(() {});
      return current;
    } on TimeoutException {
      throw Exception("LOCATION_TIMEOUT");
    } catch (e) {
      throw Exception("LOCATION_FAILED:$e");
    }
  }

  // ================== Google Maps Nearby (Fallback) ==================
  Future<void> _openGoogleMapsNearby() async {
    try {
      final pos = await _getAccurateLocation();
      final lat = pos.latitude;
      final lng = pos.longitude;

      final url = Uri.parse(
        "https://www.google.com/maps/search/?api=1&query=%D9%85%D8%B1%D9%83%D8%B2%20%D8%B5%D9%8A%D8%A7%D9%86%D8%A9&center=$lat,$lng",
      );

      if (await canLaunchUrl(url)) {
        await launchUrl(url, mode: LaunchMode.externalApplication);
      } else {
        _snack(
            _isArabic ? "تعذر فتح خرائط Google" : "Couldn't open Google Maps");
      }
    } catch (_) {
      _snack(_isArabic ? "تعذر تحديد موقعك" : "Couldn't get your location");
    }
  }

  // ================== NETWORK: Centers Nearby ==================
  Future<List<CenterItem>> _fetchCentersNearMe() async {
    _locationError = null;

    try {
      final pos = await _getAccurateLocation();

      // ✅ IMPORTANT:
      // ApiConfig.nearbyCenters must accept maxDistanceMeters and send it as maxDistance in query string.
      final uri = Uri.parse(
        ApiConfig.nearbyCenters(
          lat: pos.latitude,
          lng: pos.longitude,
          limit: _centersLimit,
          maxDistanceMeters: _maxRadiusMeters.toInt(),
        ),
      );

      final res = await http.get(uri).timeout(const Duration(seconds: 15));

      if (res.statusCode != 200) {
        _locationError = trKey("loadFail");
        return <CenterItem>[];
      }

      final decoded = jsonDecode(res.body);
      if (decoded is! List) return <CenterItem>[];

      final List<CenterItem> centers = [];

      for (final item in decoded) {
        if (item is! Map<String, dynamic>) continue;

        final center = CenterItem.fromJson(item);

        if (!center.hasCoords) {
          debugPrint("Skipping center without coords: ${center.name}");
          continue;
        }

        // ✅ best: server distanceMeters, fallback: local
        final double d =
            (center.distanceMeters != null && center.distanceMeters! > 0)
                ? center.distanceMeters!
                : Geolocator.distanceBetween(
                    pos.latitude,
                    pos.longitude,
                    center.lat!,
                    center.lng!,
                  );

        // ✅ safety filter
        if (d > _maxRadiusMeters) continue;

        centers.add(center.copyWith(distanceMeters: d));
      }

      centers.sort((a, b) {
        final da = a.distanceMeters ?? double.infinity;
        final db = b.distanceMeters ?? double.infinity;
        return da.compareTo(db);
      });

      return centers;
    } catch (e) {
      final msg = e.toString();

      if (msg.contains("LOCATION_SERVICE_DISABLED")) {
        _locationError = _isArabic
            ? "خدمة الموقع مقفولة.. فعّل GPS ثم جرّب تاني ✅"
            : "Location services are OFF. Enable GPS then try again ✅";
      } else if (msg.contains("LOCATION_PERMISSION_DENIED_FOREVER")) {
        _locationError = _isArabic
            ? "صلاحية الموقع مرفوضة نهائيًا.. فعّلها من الإعدادات ✅"
            : "Location permission denied forever. Enable it from settings ✅";
      } else if (msg.contains("LOCATION_PERMISSION_DENIED")) {
        _locationError = trKey("needLocation");
      } else if (msg.contains("LOCATION_TIMEOUT")) {
        _locationError = _isArabic
            ? "أخذ تحديد الموقع وقت طويل.. فعّل Location وحاول مرة أخرى ✅"
            : "Location timed out. Enable Location and try again ✅";
      } else if (msg.contains("LOCATION_FAILED")) {
        _locationError = trKey("needLocation");
      } else {
        _locationError = trKey("loadFail");
      }

      return <CenterItem>[];
    }
  }

  Future<void> _refresh() async {
    HapticFeedback.selectionClick();
    setState(() {
      _centersFuture = _fetchCentersNearMe();
    });
    await _centersFuture;
  }

  // ================== Image (asset or network) ==================
  Widget smartImage(
    String pathOrUrl, {
    double width = 60,
    double height = 60,
    double radius = 12,
  }) {
    final isUrl =
        pathOrUrl.startsWith("http://") || pathOrUrl.startsWith("https://");

    if (pathOrUrl.trim().isEmpty) {
      return _imgFallback(width, height, radius);
    }

    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: isUrl
          ? Image.network(
              pathOrUrl,
              width: width,
              height: height,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => _imgFallback(width, height, radius),
              loadingBuilder: (context, child, p) =>
                  p == null ? child : _imgFallback(width, height, radius),
            )
          : Image.asset(
              pathOrUrl,
              width: width,
              height: height,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => _imgFallback(width, height, radius),
            ),
    );
  }

  Widget _imgFallback(double width, double height, double radius) {
    return Container(
      width: width,
      height: height,
      decoration: BoxDecoration(
        color:
            _isDarkMode ? Colors.white.withOpacity(.06) : Colors.grey.shade200,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: stroke),
      ),
      child: Icon(Icons.image_not_supported, color: textSub),
    );
  }

  // ================== Calls ==================
  Future<void> _callEmergency() async {
    final uri = Uri.parse("tel:112");
    try {
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri);
      } else {
        _snack(trKey("callFail"));
      }
    } catch (_) {
      _snack(trKey("callFail"));
    }
  }

  Future<void> _openSupportChatFromSheet() async {
    Navigator.pop(context);
    try {
      final prefs = await SharedPreferences.getInstance();
      final userId = prefs.getString("userId");
      if (!mounted) return;

      if (userId == null || userId.isEmpty) {
        _snack(trKey("loginFirst"));
        return;
      }

      final chatData = await SupportChatService.getOrCreateChat();
      final chatId = chatData["_id"]?.toString();

      if (chatId == null || chatId.isEmpty) {
        _snack(trKey("chatError"));
        return;
      }

      if (!mounted) return;
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => SupportChatScreen(chatId: chatId, userId: userId),
        ),
      );
    } catch (_) {
      _snack(trKey("chatError"));
    }
  }

  // ================== Call sheet ==================
  void _showCallSheet() {
    HapticFeedback.selectionClick();
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black54,
      builder: (_) {
        return ClipRRect(
          borderRadius: const BorderRadius.vertical(top: Radius.circular(26)),
          child: Container(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 18),
            color: surface,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 60,
                  height: 6,
                  margin: const EdgeInsets.only(bottom: 16),
                  decoration: BoxDecoration(
                    color: _isDarkMode
                        ? Colors.white.withOpacity(.18)
                        : Colors.grey.shade300,
                    borderRadius: BorderRadius.circular(6),
                  ),
                ),
                _sheetCard(
                  icon: Icons.support_agent,
                  title: trKey("supportChat"),
                  subtitle: trKey("supportSub"),
                  bg: _isDarkMode
                      ? Colors.white.withOpacity(.06)
                      : const Color(0xffE8F0FF),
                  iconColor: _primary,
                  onTap: _openSupportChatFromSheet,
                ),
                const SizedBox(height: 12),
                _sheetCard(
                  icon: Icons.emergency,
                  title: trKey("emergency"),
                  subtitle: trKey("emergencySub"),
                  bg: _isDarkMode
                      ? Colors.white.withOpacity(.06)
                      : const Color(0xffFFE5E5),
                  iconColor: Colors.red,
                  onTap: () {
                    Navigator.pop(context);
                    _callEmergency();
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _sheetCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color bg,
    required Color iconColor,
    required VoidCallback onTap,
  }) {
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: stroke),
        ),
        child: Row(
          children: [
            Container(
              width: 52,
              height: 52,
              decoration: BoxDecoration(
                color: surface2,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: stroke),
              ),
              child: Icon(icon, color: iconColor, size: 28),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: bodyStyle(w: FontWeight.w800)),
                  const SizedBox(height: 3),
                  Text(subtitle, style: smallStyle()),
                ],
              ),
            ),
            Icon(
              _isArabic ? Icons.arrow_back_ios_new : Icons.arrow_forward_ios,
              size: 16,
              color: textSub,
            ),
          ],
        ),
      ),
    );
  }

  // ================== My location card ==================
  Widget _myLocationCard() {
    if (_myPos == null) return const SizedBox.shrink();
    final lat = _myPos!.latitude.toStringAsFixed(5);
    final lng = _myPos!.longitude.toStringAsFixed(5);

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: stroke),
      ),
      child: Row(
        children: [
          const Icon(Icons.my_location, color: _primary),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              "${trKey("yourLocation")}: $lat , $lng",
              style: GoogleFonts.cairo(
                color: textMain,
                fontWeight: FontWeight.w800,
                fontSize: 13,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ================== Radius selector ==================
  Widget _radiusSelector() {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: stroke),
      ),
      child: Row(
        children: [
          Icon(Icons.radar, color: _primary.withOpacity(.95)),
          const SizedBox(width: 10),
          Text(
            "${trKey("radius")}:",
            style: GoogleFonts.cairo(
              color: textMain,
              fontWeight: FontWeight.w900,
              fontSize: 13,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: _radiusOptionsKm.map((km) {
                  final selected = km == _selectedRadiusKm;
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    child: ChoiceChip(
                      selected: selected,
                      label: Text(
                        "$km km",
                        style: GoogleFonts.cairo(
                          fontWeight: FontWeight.w900,
                          color: selected ? Colors.white : textMain,
                        ),
                      ),
                      onSelected: (_) => _setRadiusKm(km),
                      selectedColor: _primary,
                      backgroundColor: _isDarkMode
                          ? Colors.white.withOpacity(.06)
                          : Colors.grey.shade100,
                      side: BorderSide(color: selected ? _primary : stroke),
                    ),
                  );
                }).toList(),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ===================== Smart Hub (NEW) =====================
  // ✅ شريط واحد احترافي يجمع (أدوات ذكية + Scan & Rescue)
  Widget _smartHubBarPro() {
    return InkWell(
      onTap: () {
        HapticFeedback.selectionClick();
        _openSmartHubSheet();
      },
      borderRadius: BorderRadius.circular(26),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(26),
          border: Border.all(color: stroke),
          boxShadow: [
            BoxShadow(
              color: shadow,
              blurRadius: 26,
              offset: const Offset(0, 16),
            ),
          ],
          gradient: LinearGradient(
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
            colors: _isDarkMode
                ? [
                    const Color(0xff0F172A),
                    const Color(0xff151A2E),
                  ]
                : [
                    const Color(0xffF6F9FF),
                    Colors.white,
                  ],
          ),
        ),
        child: Row(
          children: [
            // ✅ Left "open" chevron (better than back arrow)
            Icon(
              _isArabic
                  ? Icons.chevron_left_rounded
                  : Icons.chevron_right_rounded,
              size: 26,
              color: textSub,
            ),
            const SizedBox(width: 8),

            // ✅ Main content
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Title + Badge
                  Row(
                    children: [
                      Text(
                        "Smart Hub",
                        style: GoogleFonts.cairo(
                          fontSize: 16,
                          fontWeight: FontWeight.w900,
                          color: textMain,
                        ),
                      ),
                      const SizedBox(width: 8),
                      _hubBadgePro(_isArabic ? "مميز" : "PRO"),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    _isArabic
                        ? "أدوات ذكية + فحص OBD بتجربة واحدة"
                        : "Smart tools + OBD scan in one experience",
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: GoogleFonts.cairo(
                      fontSize: 12.7,
                      fontWeight: FontWeight.w700,
                      color: textSub,
                    ),
                  ),
                  const SizedBox(height: 14),

                  // ✅ Two equal premium tiles
                  Row(
                    children: [
                      Expanded(
                        child: _hubTilePro(
                          title: _isArabic ? "أدوات ذكية" : "Smart Tools",
                          subtitle:
                              _isArabic ? "صور / صوت / سريع" : "Photo / Sound",
                          icon: Icons.bolt_rounded,
                          onTap: () {
                            HapticFeedback.selectionClick();
                            _openSmartHubSheet(); // أو لو عندك شيت خاص للأدوات
                          },
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _hubTilePro(
                          title: "Scan & Rescue",
                          subtitle:
                              _isArabic ? "فحص OBD كامل" : "Full OBD scan",
                          icon: Icons.qr_code_scanner_rounded,
                          emphasize: true,
                          onTap: () {
                            HapticFeedback.selectionClick();
                            _openScanRescueSheet();
                          },
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(width: 10),

            // ✅ Right big icon (brand)
            Container(
              width: 56,
              height: 56,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                gradient: LinearGradient(
                  begin: Alignment.topRight,
                  end: Alignment.bottomLeft,
                  colors: [
                    _primary,
                    _primary.withOpacity(.65),
                  ],
                ),
                boxShadow: [
                  BoxShadow(
                    color: _primary.withOpacity(.25),
                    blurRadius: 18,
                    offset: const Offset(0, 10),
                  ),
                ],
              ),
              child:
                  const Icon(Icons.auto_awesome, color: Colors.white, size: 28),
            ),
          ],
        ),
      ),
    );
  }

  Widget _hubBadgePro(String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: _gold.withOpacity(_isDarkMode ? .18 : .16),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: _gold.withOpacity(.28)),
      ),
      child: Text(
        text,
        style: GoogleFonts.cairo(
          fontSize: 11.5,
          fontWeight: FontWeight.w900,
          color: _isDarkMode ? Colors.white : const Color(0xff7A5400),
        ),
      ),
    );
  }

  Widget _hubTilePro({
    required String title,
    required String subtitle,
    required IconData icon,
    required VoidCallback onTap,
    bool emphasize = false,
  }) {
    final bg = emphasize
        ? _primary.withOpacity(_isDarkMode ? .22 : .10)
        : (_isDarkMode
            ? Colors.white.withOpacity(.06)
            : Colors.black.withOpacity(.03));

    final br = emphasize ? _primary.withOpacity(.30) : stroke;

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: br),
        ),
        child: Row(
          children: [
            // consistent icon badge (same shape everywhere)
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                color: _primary.withOpacity(_isDarkMode ? .18 : .10),
                border: Border.all(color: _primary.withOpacity(.18)),
              ),
              child: Icon(icon, color: _primary, size: 20),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: GoogleFonts.cairo(
                      fontWeight: FontWeight.w900,
                      fontSize: 12.8,
                      color: textMain,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: GoogleFonts.cairo(
                      fontWeight: FontWeight.w700,
                      fontSize: 11.8,
                      color: textSub,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              _isArabic ? Icons.chevron_left : Icons.chevron_right,
              size: 18,
              color: textSub,
            ),
          ],
        ),
      ),
    );
  }

  // ================== UI ==================
  @override
  Widget build(BuildContext context) {
    if (!_prefsLoaded) {
      return Scaffold(
        backgroundColor: const Color(0xff0B1220),
        body: Center(
          child: Text(
            "Doctor Car",
            style: GoogleFonts.cairo(
              fontSize: 20,
              fontWeight: FontWeight.w900,
              color: const Color.fromARGB(255, 219, 222, 8),
            ),
          ),
        ),
      );
    }

    return Directionality(
      textDirection: _isArabic ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        backgroundColor: bgColor,
        appBar: _buildAppBar(),
        endDrawer: _buildDrawer(), // ✅ مهم جدًا عشان menu يفتح
        bottomNavigationBar: _buildBottomNavCurvedWithCall(),
        body: SafeArea(
          bottom: false,
          child: RefreshIndicator(
            onRefresh: _refresh,
            child: CustomScrollView(
              physics: const AlwaysScrollableScrollPhysics(),
              slivers: [
                // Top padding
                const SliverToBoxAdapter(child: SizedBox(height: 16)),

                // Banner
                SliverPadding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  sliver: SliverToBoxAdapter(child: _bannerSlider()),
                ),

                const SliverToBoxAdapter(child: SizedBox(height: 18)),

                // Quick services
                SliverPadding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  sliver: SliverToBoxAdapter(child: _quickServicesRow()),
                ),

                const SliverToBoxAdapter(child: SizedBox(height: 14)),

                // ✅ Smart Hub Bar (NEW) بدل ما تشتت المستخدم بكذا كارت
                SliverPadding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  sliver: SliverToBoxAdapter(child: _smartHubBarPro()),
                ),

                // Offers title
                SliverPadding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  sliver:
                      SliverToBoxAdapter(child: _sectionTitle(trKey("offers"))),
                ),

                // Offers slider
                SliverPadding(
                  padding: const EdgeInsets.only(left: 16, right: 16),
                  sliver: SliverToBoxAdapter(child: _offersSlider()),
                ),

                const SliverToBoxAdapter(child: SizedBox(height: 22)),

                // Nearby title + filters
                SliverPadding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  sliver:
                      SliverToBoxAdapter(child: _sectionTitle(trKey("nearby"))),
                ),

                SliverPadding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  sliver: SliverToBoxAdapter(child: _radiusSelector()),
                ),

                SliverPadding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  sliver: SliverToBoxAdapter(child: _myLocationCard()),
                ),

                // Centers list
                SliverPadding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  sliver: SliverToBoxAdapter(child: _centersList()),
                ),

                const SliverToBoxAdapter(child: SizedBox(height: 24)),

                // How to use
                SliverPadding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  sliver: SliverToBoxAdapter(child: _howToUseDoctorCar()),
                ),

                const SliverToBoxAdapter(child: SizedBox(height: 24)),

                // Why Doctor Car
                SliverPadding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  sliver: SliverToBoxAdapter(child: _whyDoctorCar()),
                ),

                const SliverToBoxAdapter(child: SizedBox(height: 24)),

                // Customer service
                SliverPadding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  sliver: SliverToBoxAdapter(child: _customerService()),
                ),

                // Bottom space for curved nav + call btn
                const SliverToBoxAdapter(child: SizedBox(height: 120)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ===================== Smart Hub Sheet (يعرض الكارتين) =====================
  void _openSmartHubSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black54,
      isScrollControlled: true,
      builder: (_) {
        return ClipRRect(
          borderRadius: const BorderRadius.vertical(top: Radius.circular(26)),
          child: Container(
            color: surface,
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 18),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 60,
                    height: 6,
                    margin: const EdgeInsets.only(bottom: 14),
                    decoration: BoxDecoration(
                      color: _isDarkMode
                          ? Colors.white.withOpacity(.18)
                          : Colors.grey.shade300,
                      borderRadius: BorderRadius.circular(6),
                    ),
                  ),

                  // 1) أدوات ذكية
                  _smartToolsCard(),
                  const SizedBox(height: 14),

                  // 2) Scan & Rescue
                  _scanRescueCard(),
                  const SizedBox(height: 10),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _smartToolsCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: surface,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: stroke),
        boxShadow: [
          BoxShadow(color: shadow, blurRadius: 22, offset: const Offset(0, 12))
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  gradient: LinearGradient(
                    begin: Alignment.topRight,
                    end: Alignment.bottomLeft,
                    colors: [
                      _primary.withOpacity(.95),
                      _primary.withOpacity(.55),
                    ],
                  ),
                ),
                child: const Icon(Icons.auto_awesome,
                    color: Colors.white, size: 22),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _isArabic ? "أدوات ذكية" : "Smart Tools",
                      style: GoogleFonts.cairo(
                        fontWeight: FontWeight.w900,
                        fontSize: 16,
                        color: textMain,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      _isArabic
                          ? "تشخيص سريع بطرق مختلفة"
                          : "Quick diagnosis in multiple ways",
                      style: GoogleFonts.cairo(
                        fontWeight: FontWeight.w700,
                        fontSize: 12.5,
                        color: textSub,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: _gold.withOpacity(_isDarkMode ? .18 : .16),
                  borderRadius: BorderRadius.circular(999),
                  border: Border.all(color: _gold.withOpacity(.28)),
                ),
                child: Text(
                  "AI",
                  style: GoogleFonts.cairo(
                    fontWeight: FontWeight.w900,
                    fontSize: 12,
                    color: _isDarkMode ? Colors.white : const Color(0xff7A5400),
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 14),

          // Grid 2x2
          Row(
            children: [
              Expanded(
                child: _smartToolTile(
                  icon: Icons.flash_on,
                  title: _isArabic ? "فحص سريع" : "Quick Check",
                  subtitle: _isArabic ? "تشخيص فوري" : "Instant diagnosis",
                  onTap: _quickCheck,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _smartToolTile(
                  icon: Icons.qr_code_2,
                  title: _isArabic ? "هل يمكنني القيادة؟" : "Can I Drive?",
                  subtitle: _isArabic ? "أمان القيادة" : "Safety check",
                  onTap: _canIDrive,
                  emphasize: true,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _smartToolTile(
                  icon: Icons.photo_camera,
                  title: _isArabic ? "فحص بالصور" : "Photo Check",
                  subtitle: _isArabic ? "ارفع صورة" : "Upload a photo",
                  onTap: _photoCheck,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _smartToolTile(
                  icon: Icons.graphic_eq,
                  title: _isArabic ? "فحص بالصوت" : "Sound Check",
                  subtitle: _isArabic ? "سجل الصوت" : "Record a sound",
                  onTap: _soundCheck,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _smartToolTile({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
    bool emphasize = false,
  }) {
    final bg = emphasize
        ? _primary.withOpacity(_isDarkMode ? .22 : .10)
        : (_isDarkMode
            ? Colors.white.withOpacity(.05)
            : Colors.black.withOpacity(.03));

    final border = emphasize ? _primary.withOpacity(.30) : stroke;

    return InkWell(
      onTap: () {
        HapticFeedback.selectionClick();
        onTap();
      },
      borderRadius: BorderRadius.circular(18),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: border),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // top row (icon + arrow)
            Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16),
                    color: _primary.withOpacity(_isDarkMode ? .18 : .10),
                    border: Border.all(color: _primary.withOpacity(.18)),
                  ),
                  child: Icon(icon, color: _primary, size: 20),
                ),
                const Spacer(),
                Icon(
                  _isArabic
                      ? Icons.arrow_back_ios_new
                      : Icons.arrow_forward_ios,
                  size: 14,
                  color: textSub,
                ),
              ],
            ),

            const SizedBox(height: 10),

            Text(
              title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: GoogleFonts.cairo(
                fontWeight: FontWeight.w900,
                fontSize: 13.2,
                color: textMain,
              ),
            ),
            const SizedBox(height: 3),
            Text(
              subtitle,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: GoogleFonts.cairo(
                fontWeight: FontWeight.w700,
                fontSize: 11.8,
                color: textSub,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _scanRescueCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: stroke),
        boxShadow: [
          BoxShadow(color: shadow, blurRadius: 18, offset: const Offset(0, 10)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: _primary.withOpacity(_isDarkMode ? .18 : .10),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: _primary.withOpacity(.18)),
                ),
                child: const Icon(Icons.qr_code_scanner, color: _primary),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _isArabic ? "Scan & Rescue" : "Scan & Rescue",
                      style: GoogleFonts.cairo(
                        fontWeight: FontWeight.w900,
                        fontSize: 15.5,
                        color: textMain,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      _isArabic
                          ? "فحص أعطال كامل بالـ OBD من الموبايل"
                          : "Full OBD diagnostics from your phone",
                      style: GoogleFonts.cairo(
                        fontWeight: FontWeight.w700,
                        fontSize: 12.5,
                        color: textSub,
                      ),
                    ),
                  ],
                ),
              ),
              _pill(
                icon: Icons.bluetooth,
                text: _isArabic ? "Bluetooth" : "Bluetooth",
              ),
            ],
          ),
          const SizedBox(height: 14),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              _miniFeature(
                  Icons.code, _isArabic ? "أكواد الأعطال (DTC)" : "DTC Codes"),
              _miniFeature(Icons.translate,
                  _isArabic ? "تفسير بالعربي" : "Arabic Explanation"),
              _miniFeature(
                  Icons.traffic, _isArabic ? "درجة الخطورة" : "Severity"),
              _miniFeature(Icons.price_change,
                  _isArabic ? "تقدير تكلفة" : "Cost Estimate"),
              _miniFeature(Icons.handyman,
                  _isArabic ? "ترشيح الفني" : "Right Technician"),
              _miniFeature(Icons.assignment,
                  _isArabic ? "تقرير جاهز" : "Shareable Report"),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: _openScanRescueSheet,
                  style: ElevatedButton.styleFrom(
                    elevation: 0,
                    backgroundColor: _primary,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                    minimumSize: const Size(double.infinity, 48),
                  ),
                  icon: const Icon(Icons.play_arrow, color: Colors.white),
                  label: Text(
                    _isArabic ? "ابدأ الفحص" : "Start Scan",
                    style: GoogleFonts.cairo(
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              OutlinedButton(
                onPressed: _showObdHowItWorks,
                style: OutlinedButton.styleFrom(
                  side:
                      BorderSide(color: _primary.withOpacity(.35), width: 1.4),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  minimumSize: const Size(52, 48),
                ),
                child:
                    Icon(Icons.info_outline, color: _primary.withOpacity(.95)),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _pill({required IconData icon, required String text}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: _primary.withOpacity(_isDarkMode ? .18 : .08),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: _primary.withOpacity(.18)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: _primary),
          const SizedBox(width: 6),
          Text(
            text,
            style: GoogleFonts.cairo(
              fontWeight: FontWeight.w900,
              fontSize: 12,
              color: textMain,
            ),
          ),
        ],
      ),
    );
  }

  Widget _miniFeature(IconData icon, String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: _isDarkMode
            ? Colors.white.withOpacity(.04)
            : Colors.black.withOpacity(.03),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: stroke),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: _primary.withOpacity(.95)),
          const SizedBox(width: 6),
          Text(
            text,
            style: GoogleFonts.cairo(
              fontWeight: FontWeight.w800,
              fontSize: 12.5,
              color: textMain,
            ),
          ),
        ],
      ),
    );
  }

  // ===================== Scan & Rescue Sheets =====================
  void _openScanRescueSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black54,
      isScrollControlled: true,
      builder: (_) {
        return ClipRRect(
          borderRadius: const BorderRadius.vertical(top: Radius.circular(26)),
          child: Container(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 18),
            color: surface,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 60,
                    height: 6,
                    margin: const EdgeInsets.only(bottom: 14),
                    decoration: BoxDecoration(
                      color: _isDarkMode
                          ? Colors.white.withOpacity(.18)
                          : Colors.grey.shade300,
                      borderRadius: BorderRadius.circular(6),
                    ),
                  ),
                ),
                Row(
                  children: [
                    Container(
                      width: 46,
                      height: 46,
                      decoration: BoxDecoration(
                        color: _primary.withOpacity(_isDarkMode ? .18 : .10),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: _primary.withOpacity(.18)),
                      ),
                      child: const Icon(
                        Icons.qr_code_scanner,
                        color: _primary,
                        size: 24,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            _isArabic ? "Scan & Rescue" : "Scan & Rescue",
                            style: GoogleFonts.cairo(
                              fontWeight: FontWeight.w900,
                              fontSize: 16,
                              color: textMain,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            _isArabic
                                ? "فحص أعطال كامل من الموبايل باستخدام OBD بلوتوث"
                                : "Full car scan via Bluetooth OBD",
                            style: GoogleFonts.cairo(
                              fontWeight: FontWeight.w700,
                              fontSize: 12.5,
                              color: textSub,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(
                        color: _primary.withOpacity(_isDarkMode ? .18 : .08),
                        borderRadius: BorderRadius.circular(999),
                        border: Border.all(color: _primary.withOpacity(.18)),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.bluetooth,
                              size: 16, color: _primary),
                          const SizedBox(width: 6),
                          Text(
                            "OBD",
                            style: GoogleFonts.cairo(
                              fontWeight: FontWeight.w900,
                              fontSize: 12,
                              color: textMain,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                _sheetBullet(
                  icon: Icons.check_circle,
                  color: Colors.green,
                  text: _isArabic ? "أكواد الأعطال (DTC)" : "DTC Trouble codes",
                ),
                _sheetBullet(
                  icon: Icons.translate,
                  color: _primary,
                  text: _isArabic
                      ? "تفسير بالعربي بشكل بسيط"
                      : "Simple explanation",
                ),
                _sheetBullet(
                  icon: Icons.traffic,
                  color: Colors.orange,
                  text: _isArabic
                      ? "درجة الخطورة (تكمّل ولا توقف)"
                      : "Severity (drive or stop)",
                ),
                _sheetBullet(
                  icon: Icons.payments,
                  color: Colors.amber,
                  text: _isArabic
                      ? "سعر تقديري للإصلاح في مصر"
                      : "Estimated repair cost",
                ),
                _sheetBullet(
                  icon: Icons.engineering,
                  color: Colors.purple,
                  text: _isArabic ? "ترشيح الفني المناسب" : "Recommended tech",
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: () {
                          Navigator.pop(context);
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => ObdReportPreviewScreen(
                                isArabic: _isArabic,
                                isDarkMode: _isDarkMode,
                              ),
                            ),
                          );
                        },
                        style: ElevatedButton.styleFrom(
                          elevation: 0,
                          backgroundColor: _primary,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                          minimumSize: const Size(double.infinity, 52),
                        ),
                        icon: const Icon(Icons.play_arrow, color: Colors.white),
                        label: Text(
                          _isArabic ? "ابدأ الفحص" : "Start scan",
                          style: GoogleFonts.cairo(
                            fontWeight: FontWeight.w900,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    OutlinedButton(
                      onPressed: () {
                        Navigator.pop(context);
                        _showObdHowItWorks();
                      },
                      style: OutlinedButton.styleFrom(
                        side: BorderSide(
                          color: _primary.withOpacity(.35),
                          width: 1.4,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                        minimumSize: const Size(56, 52),
                      ),
                      child: Icon(Icons.info_outline,
                          color: _primary.withOpacity(.95)),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _sheetBullet({
    required IconData icon,
    required Color color,
    required String text,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: color.withOpacity(.12),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: color.withOpacity(.22)),
            ),
            child: Icon(icon, color: color, size: 18),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              text,
              style: GoogleFonts.cairo(
                fontWeight: FontWeight.w800,
                fontSize: 13.2,
                color: textMain,
              ),
            ),
          ),
        ],
      ),
    );
  }

// 2) Bottom sheet: How it works (إزاي تشتغل OBD)
  void _showObdHowItWorks() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black54,
      isScrollControlled: true,
      builder: (_) {
        return ClipRRect(
          borderRadius: const BorderRadius.vertical(top: Radius.circular(26)),
          child: Container(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 18),
            color: surface,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 60,
                    height: 6,
                    margin: const EdgeInsets.only(bottom: 14),
                    decoration: BoxDecoration(
                      color: _isDarkMode
                          ? Colors.white.withOpacity(.18)
                          : Colors.grey.shade300,
                      borderRadius: BorderRadius.circular(6),
                    ),
                  ),
                ),
                Text(
                  _isArabic ? "إزاي تشتغل الميزة؟" : "How does it work?",
                  style: GoogleFonts.cairo(
                    fontWeight: FontWeight.w900,
                    fontSize: 16,
                    color: textMain,
                  ),
                ),
                const SizedBox(height: 10),
                _howStep(
                  n: "1",
                  text: _isArabic
                      ? "اشتري قطعة OBD بلوتوث (رخيصة ومتوفرة)."
                      : "Get a Bluetooth OBD adapter.",
                ),
                _howStep(
                  n: "2",
                  text: _isArabic
                      ? "ركّبها في منفذ OBD في العربية (غالباً تحت الدركسيون)."
                      : "Plug it into your car’s OBD port (often under the steering wheel).",
                ),
                _howStep(
                  n: "3",
                  text: _isArabic
                      ? "افتح Doctor Car واضغط Start Scan."
                      : "Open Doctor Car and tap Start Scan.",
                ),
                _howStep(
                  n: "4",
                  text: _isArabic
                      ? "هيطلعلك التقرير: الأكواد + التفسير + خطورة + ترشيحات."
                      : "You’ll get a report: codes, explanation, severity, and suggestions.",
                ),
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () => Navigator.pop(context),
                    style: ElevatedButton.styleFrom(
                      elevation: 0,
                      backgroundColor: _primary,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                      minimumSize: const Size(double.infinity, 52),
                    ),
                    child: Text(
                      _isArabic ? "تمام" : "Got it",
                      style: GoogleFonts.cairo(
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _howStep({required String n, required String text}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _isDarkMode
            ? Colors.white.withOpacity(.04)
            : Colors.black.withOpacity(.03),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: stroke),
      ),
      child: Row(
        children: [
          Container(
            width: 30,
            height: 30,
            decoration: BoxDecoration(
              color: _primary.withOpacity(.12),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _primary.withOpacity(.18)),
            ),
            child: Center(
              child: Text(
                n,
                style: GoogleFonts.cairo(
                  fontWeight: FontWeight.w900,
                  color: textMain,
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              text,
              style: GoogleFonts.cairo(
                fontWeight: FontWeight.w800,
                fontSize: 13,
                color: textMain,
                height: 1.25,
              ),
            ),
          ),
        ],
      ),
    );
  }

// ===================== Actions for Icons =====================

  void _quickCheck() {
    _openSmartSheet(
      _isArabic ? "فحص سريع" : "Quick Check",
      _isArabic ? "تشخيص سريع لحالة السيارة." : "Quick car diagnosis.",
    );
  }

  void _photoCheck() {
    _openSmartSheet(
      _isArabic ? "فحص بالصور" : "Photo Check",
      _isArabic ? "ارفع صورة لتشخيص المشكلة." : "Upload a photo to diagnose.",
    );
  }

  void _soundCheck() {
    _openSmartSheet(
      _isArabic ? "فحص بالصوت" : "Sound Check",
      _isArabic ? "سجّل صوت المحرك." : "Record engine sound.",
    );
  }

  void _canIDrive() {
    _openSmartSheet(
      _isArabic ? "هل يمكنني القيادة؟" : "Can I Drive?",
      _isArabic
          ? "تحقق إذا كان من الآمن القيادة."
          : "Check if it's safe to drive.",
    );
  }

// ✅ دي الدالة اللي كانت ناقصة عندك
  void _openSmartSheet(String title, String body) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) {
        return ClipRRect(
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          child: Container(
            padding: const EdgeInsets.all(20),
            color: surface,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  title,
                  style: GoogleFonts.cairo(
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    color: textMain,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  body,
                  textAlign: TextAlign.center,
                  style: GoogleFonts.cairo(
                    color: textSub,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 18),

                // ✅ Buttons Example (اختياري)
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () => Navigator.pop(context),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _primary,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                        ),
                        child: Text(
                          _isArabic ? "تمام" : "OK",
                          style: GoogleFonts.cairo(fontWeight: FontWeight.w900),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ================== APP BAR ==================
  AppBar _buildAppBar() {
    return AppBar(
      elevation: 0,
      toolbarHeight: 76,
      backgroundColor: Colors.transparent,
      automaticallyImplyLeading: false,
      flexibleSpace: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xff0B1220), Color(0xff1F4BA5)],
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
          ),
        ),
      ),
      leadingWidth: 110,
      leading: Builder(
        builder: (ctx) => Padding(
          padding: const EdgeInsets.only(left: 8),
          child: Row(
            children: [
              _appBarIcon(
                icon: Icons.menu,
                onTap: () => Scaffold.of(ctx).openEndDrawer(), // ✅ FIX
              ),
              const SizedBox(width: 6),
              _appBarIcon(
                icon: Icons.notifications_none,
                onTap: () => _snack(_isArabic
                    ? "لا توجد إشعارات الآن"
                    : "No notifications yet"),
              ),
            ],
          ),
        ),
      ),
      centerTitle: true,
      title: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.car_repair, color: _gold, size: 22),
              const SizedBox(width: 6),
              Text(
                "Doctor Car",
                style: GoogleFonts.cairo(
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                  color: _gold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 2),
          Text(
            _isArabic ? "خدمات سيارات ذكية" : "Smart Car Services",
            style: GoogleFonts.cairo(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: Colors.white.withOpacity(.70),
            ),
          ),
        ],
      ),
      actions: [
        _appBarIcon(icon: Icons.language, onTap: _toggleLanguage),
        const SizedBox(width: 6),
        _appBarIcon(
          icon: _isDarkMode ? Icons.light_mode : Icons.dark_mode,
          onTap: _toggleTheme,
        ),
        const SizedBox(width: 12),
      ],
    );
  }

  Widget _appBarIcon({required IconData icon, required VoidCallback onTap}) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () {
          HapticFeedback.selectionClick();
          onTap();
        },
        borderRadius: BorderRadius.circular(12),
        child: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(.10),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.white.withOpacity(.12)),
          ),
          child: Icon(icon, color: Colors.white, size: 22),
        ),
      ),
    );
  }

  // ================== BANNER ==================
  Widget _bannerSlider() {
    return Column(
      children: [
        SizedBox(
          height: 185,
          child: PageView.builder(
            controller: _bannerController,
            itemCount: banners.length,
            onPageChanged: (i) => setState(() => _currentBanner = i),
            itemBuilder: (_, i) {
              return ClipRRect(
                borderRadius: BorderRadius.circular(18),
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    Image.asset(
                      banners[i],
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Container(
                        color: _isDarkMode
                            ? Colors.white.withOpacity(.06)
                            : Colors.grey.shade200,
                        child: Center(
                            child: Icon(Icons.image, size: 44, color: textSub)),
                      ),
                    ),
                    Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Colors.black.withOpacity(0.22),
                            Colors.transparent,
                            Colors.black.withOpacity(0.18),
                          ],
                          begin: Alignment.bottomCenter,
                          end: Alignment.topCenter,
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(
            banners.length,
            (i) => AnimatedContainer(
              duration: const Duration(milliseconds: 220),
              margin: const EdgeInsets.symmetric(horizontal: 4),
              width: _currentBanner == i ? 20 : 8,
              height: 8,
              decoration: BoxDecoration(
                color: _currentBanner == i
                    ? _primary
                    : (_isDarkMode ? Colors.white24 : Colors.grey.shade300),
                borderRadius: BorderRadius.circular(20),
              ),
            ),
          ),
        ),
      ],
    );
  }

  // ================== QUICK SERVICES ==================
  Widget _quickServicesRow() {
    return Row(
      children: [
        Expanded(
          child: _serviceCard(
            title: trKey("urgent"),
            icon: Icons.local_shipping,
            color: _primary,
            onTap: () => _goto(const RoadServicesScreen()),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _serviceCard(
            title: trKey("maint"),
            icon: Icons.warning_amber_rounded,
            color: const Color.fromARGB(255, 255, 191, 0),
            onTap: () => _goto(const MaintenanceServicesScreen()),
          ),
        ),
      ],
    );
  }

  Widget _serviceCard({
    required String title,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: () {
        HapticFeedback.selectionClick();
        onTap();
      },
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 14),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(.25),
              blurRadius: 16,
              offset: const Offset(0, 8),
            )
          ],
        ),
        child: Column(
          children: [
            Icon(icon, color: Colors.white, size: 48),
            const SizedBox(height: 12),
            Text(
              title,
              textAlign: TextAlign.center,
              style: GoogleFonts.cairo(
                color: Colors.white,
                fontWeight: FontWeight.w900,
                fontSize: 16,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ================== OFFERS ==================
  Widget _offersSlider() {
    return SizedBox(
      height: 170,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: offers.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (_, i) {
          final o = offers[i];
          return Container(
            width: 295,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: surface,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: stroke),
              boxShadow: [
                BoxShadow(
                  color: shadow,
                  blurRadius: 18,
                  offset: const Offset(0, 10),
                )
              ],
            ),
            child: Row(
              children: [
                smartImage(o.image, width: 82, height: 82, radius: 16),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        o.title,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: GoogleFonts.cairo(
                          fontWeight: FontWeight.w900,
                          fontSize: 14,
                          color: textMain,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(o.until, style: smallStyle()),
                      const Spacer(),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 6),
                            decoration: BoxDecoration(
                              color:
                                  _primary.withOpacity(_isDarkMode ? .18 : .08),
                              borderRadius: BorderRadius.circular(14),
                              border:
                                  Border.all(color: _primary.withOpacity(.15)),
                            ),
                            child: Text(
                              o.distance,
                              style:
                                  smallStyle(c: _primary, w: FontWeight.w800),
                            ),
                          ),
                          const Spacer(),
                          ElevatedButton(
                            onPressed: () => HapticFeedback.selectionClick(),
                            style: ElevatedButton.styleFrom(
                              elevation: 0,
                              backgroundColor: _primary,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(14),
                              ),
                            ),
                            child: Text(
                              trKey("getOffer"),
                              style: GoogleFonts.cairo(
                                fontWeight: FontWeight.w900,
                                fontSize: 13,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

// ---------------- DRAWER ----------------
  Drawer _buildDrawer() {
    return Drawer(
      backgroundColor: surface,
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          DrawerHeader(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xffF7B500), Color(0xffFFD56A)],
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(Icons.car_rental, size: 48, color: Colors.black),
                const SizedBox(height: 10),
                Text(
                  "Doctor Car",
                  style: GoogleFonts.cairo(
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                    color: Colors.black,
                  ),
                ),
                Text(
                  _isArabic ? "خدمات السيارات الذكية" : "Smart car services",
                  style: GoogleFonts.cairo(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: Colors.black87,
                  ),
                ),
              ],
            ),
          ),

          // MENU ITEMS
          _drawerItem(
            Icons.info_outline,
            _isArabic ? "من نحن" : "About Us",
            () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const AboutUsScreen()),
            ),
          ),

          _drawerItem(Icons.home, _isArabic ? "الرئيسية" : "Home", () {
            Navigator.pop(context);
          }),

          _drawerItem(
            Icons.local_shipping,
            _isArabic ? "خدمات الطرق" : "Road Services",
            () => _goto(const RoadServicesScreen()),
          ),

          _drawerItem(
            Icons.shield,
            _isArabic ? "التبليغ عن حادث" : "Accident Report",
            () => _goto(const SmartAccidentScreen()),
          ),

          _drawerItem(
            Icons.store,
            _isArabic ? "المتجر" : "Store",
            () => _goto(const HomePage()),
          ),

          _drawerItem(
            Icons.phone,
            _isArabic ? "تواصل معنا" : "Contact",
            () => _goto(const ContactScreen()),
          ),

          _drawerItem(
            Icons.person,
            _isArabic ? "حسابي" : "Account",
            () => _goto(const AccountSettingsScreen()),
          ),
        ],
      ),
    );
  }

  ListTile _drawerItem(IconData icon, String title, VoidCallback onTap) {
    return ListTile(
      onTap: () {
        Navigator.pop(context); // ✅ يقفل Drawer الأول
        onTap();
      },
      leading: Icon(icon, color: _primary),
      title: Text(
        title,
        style: GoogleFonts.cairo(
          color: textMain,
          fontSize: 16,
          fontWeight: FontWeight.w800,
        ),
      ),
      trailing: Icon(
        _isArabic ? Icons.arrow_back_ios_new : Icons.arrow_forward_ios,
        size: 16,
        color: textSub,
      ),
    );
  }

  // ================== CENTERS LIST ==================
  Widget _centersList() {
    return FutureBuilder<List<CenterItem>>(
      future: _centersFuture,
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return _centersLoading();
        }

        final items = snap.data ?? <CenterItem>[];

        if (_locationError != null) {
          return _locationNeededCard();
        }

        if (items.isEmpty) {
          return _emptyCentersCard();
        }

        return Column(children: items.map(_centerTile).toList());
      },
    );
  }

  Widget _centersLoading() {
    return Column(
      children: [
        _miniInfoCard(Icons.my_location, trKey("locating")),
        const SizedBox(height: 10),
        ...List.generate(4, (_) {
          return Container(
            margin: const EdgeInsets.only(bottom: 12),
            height: 86,
            decoration: BoxDecoration(
              color: surface,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: stroke),
            ),
          );
        }),
      ],
    );
  }

  Widget _locationNeededCard() {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: stroke),
      ),
      child: Row(
        children: [
          Icon(Icons.location_off, color: textSub),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              _locationError ?? trKey("needLocation"),
              style: GoogleFonts.cairo(
                color: textMain,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
          TextButton(
            onPressed: () async {
              // ✅ Web: افتح Google Maps Nearby
              if (kIsWeb) {
                try {
                  await _openGoogleMapsNearby();
                } catch (_) {
                  if (!mounted) return;
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => LocationHelpScreen(
                        isArabic: _isArabic,
                        isDarkMode: _isDarkMode,
                        onRefresh: () async => _refresh(),
                      ),
                    ),
                  );
                }
                return;
              }

              // ✅ Mobile/Desktop: open location settings
              try {
                await Geolocator.openLocationSettings();
              } catch (_) {
                if (!mounted) return;
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => LocationHelpScreen(
                      isArabic: _isArabic,
                      isDarkMode: _isDarkMode,
                      onRefresh: () async => _refresh(),
                    ),
                  ),
                );
              }
            },
            child: Text(
              kIsWeb
                  ? (_isArabic ? "فتح خرائط جوجل" : "Open Google Maps")
                  : trKey("openSettings"),
              style: GoogleFonts.cairo(
                fontWeight: FontWeight.w900,
                color: _primary,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _emptyCentersCard() {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: stroke),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.info_outline, color: textSub),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  _isArabic
                      ? "لا يوجد مراكز ضمن $_selectedRadiusKm كم حالياً"
                      : "No centers within $_selectedRadiusKm km right now",
                  style: GoogleFonts.cairo(
                    color: textMain,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 10,
            runSpacing: 8,
            children: [
              OutlinedButton.icon(
                onPressed: _refresh,
                style: OutlinedButton.styleFrom(
                  side:
                      BorderSide(color: _primary.withOpacity(.35), width: 1.4),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14)),
                ),
                icon: const Icon(Icons.refresh, size: 18),
                label: Text(
                  trKey("retry"),
                  style: GoogleFonts.cairo(fontWeight: FontWeight.w900),
                ),
              ),
              ElevatedButton.icon(
                onPressed: _openGoogleMapsNearby,
                style: ElevatedButton.styleFrom(
                  backgroundColor: _primary,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14)),
                ),
                icon: const Icon(Icons.map, size: 18, color: Colors.white),
                label: Text(
                  _isArabic ? "بحث في خرائط جوجل" : "Search on Google Maps",
                  style: GoogleFonts.cairo(
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _miniInfoCard(IconData icon, String msg) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: stroke),
      ),
      child: Row(
        children: [
          Icon(icon, color: _primary),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              msg,
              style: GoogleFonts.cairo(
                color: textMain,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _centerTile(CenterItem c) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: stroke),
        boxShadow: [
          BoxShadow(color: shadow, blurRadius: 18, offset: const Offset(0, 10))
        ],
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        leading: smartImage(c.image, width: 60, height: 60, radius: 14),
        title: Text(
          c.name,
          style: GoogleFonts.cairo(
            fontWeight: FontWeight.w900,
            fontSize: 14,
            color: textMain,
          ),
        ),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 6),
          child: Row(
            children: [
              const Icon(Icons.star, color: Colors.amber, size: 16),
              const SizedBox(width: 4),
              Text(c.rating.toStringAsFixed(1), style: smallStyle()),
              if (c.distanceText.isNotEmpty) ...[
                const SizedBox(width: 10),
                Text("• ${c.distanceText}", style: smallStyle()),
              ],
            ],
          ),
        ),
        trailing: Icon(
          _isArabic ? Icons.arrow_back_ios_new : Icons.arrow_forward_ios,
          size: 16,
          color: textSub,
        ),
        onTap: () {
          HapticFeedback.selectionClick();
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => _CenterDetailsScreen(
                center: c,
                isArabic: _isArabic,
                isDarkMode: _isDarkMode,
              ),
            ),
          );
        },
      ),
    );
  }

  // ================== HOW / WHY / CUSTOMER ==================
  Widget _howToUseDoctorCar() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _sectionTitle(trKey("how")),
        const SizedBox(height: 12),
        Row(
          children: [
            _HowCard(
                icon: Icons.star,
                text: _isArabic ? "قيم\nخدمتك" : "Rate\nService",
                isDark: _isDarkMode),
            _HowCard(
                icon: Icons.payment,
                text: _isArabic
                    ? "الدفع اون لاين\nأو كاش"
                    : "Pay Online\nor Cash",
                isDark: _isDarkMode),
            _HowCard(
                icon: Icons.assignment_turned_in,
                text: _isArabic ? "احجز\nو تابع" : "Book\n& Track",
                isDark: _isDarkMode),
            _HowCard(
                icon: Icons.location_on,
                text: _isArabic ? "اختر\nالخدمة" : "Choose\nService",
                isDark: _isDarkMode),
          ],
        ),
      ],
    );
  }

  Widget _whyDoctorCar() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: surface,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: stroke),
        boxShadow: [
          BoxShadow(color: shadow, blurRadius: 30, offset: const Offset(0, 16))
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 6,
                height: 34,
                decoration: BoxDecoration(
                    color: _primary, borderRadius: BorderRadius.circular(6)),
              ),
              const SizedBox(width: 12),
              Text(
                trKey("why"),
                textAlign: TextAlign.center,
                style: GoogleFonts.cairo(
                    fontSize: 20, fontWeight: FontWeight.w900, color: textMain),
              ),
            ],
          ),
          const SizedBox(height: 18),
          GridView(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 14,
              mainAxisSpacing: 14,
              childAspectRatio: 1.25,
            ),
            children: [
              _whyGridItem(
                icon: Icons.verified_rounded,
                title: _isArabic ? "فنيين معتمدين" : "Certified",
                subtitle:
                    _isArabic ? "خبراء موثوقين بخبرة عالية" : "Trusted experts",
              ),
              _whyGridItem(
                icon: Icons.attach_money_rounded,
                title: _isArabic ? "تسعير شفاف" : "Pricing",
                subtitle: _isArabic ? "بدون أي رسوم مخفية" : "No hidden fees",
              ),
              _whyGridItem(
                icon: Icons.security_rounded,
                title: _isArabic ? "دعم التأمين" : "Insurance",
                subtitle:
                    _isArabic ? "تغطية كاملة للحوادث" : "Accident coverage",
              ),
              _whyGridItem(
                icon: Icons.map_rounded,
                title: _isArabic ? "مراكز قريبة" : "Nearby",
                subtitle:
                    _isArabic ? "أقرب مركز ليك على الخريطة" : "Closest on map",
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _whyGridItem(
      {required IconData icon,
      required String title,
      required String subtitle}) {
    final bg =
        _isDarkMode ? Colors.white.withOpacity(.04) : _primary.withOpacity(.04);
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _primary.withOpacity(.18), width: 1.2),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
                color: _primary, borderRadius: BorderRadius.circular(14)),
            child: Icon(icon, color: Colors.white, size: 26),
          ),
          const SizedBox(height: 12),
          Text(
            title,
            textAlign: TextAlign.center,
            style: GoogleFonts.cairo(
                fontSize: 14.5, fontWeight: FontWeight.w900, color: textMain),
          ),
          const SizedBox(height: 6),
          Text(
            subtitle,
            textAlign: TextAlign.center,
            style:
                GoogleFonts.cairo(fontSize: 12.5, color: textSub, height: 1.25),
          ),
        ],
      ),
    );
  }

  Widget _customerService() {
    return Row(
      children: [
        Expanded(
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: surface,
              elevation: 0,
              minimumSize: const Size(double.infinity, 54),
              side: BorderSide(color: _primary.withOpacity(.35), width: 1.4),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30)),
            ),
            onPressed: () {
              HapticFeedback.selectionClick();
              _showCallSheet();
            },
            child: Text(
              trKey("contact"),
              style: GoogleFonts.cairo(
                  fontWeight: FontWeight.w900, fontSize: 16, color: textMain),
            ),
          ),
        ),
        const SizedBox(width: 12),
        Container(
          width: 66,
          height: 66,
          decoration:
              const BoxDecoration(color: _primary, shape: BoxShape.circle),
          child: const Icon(Icons.headset_mic, color: Colors.white, size: 34),
        ),
      ],
    );
  }

  Widget _sectionTitle(String title) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Text(title, style: titleStyle),
      );

  // ================== BOTTOM NAV ==================
  Widget _buildBottomNavCurvedWithCall() {
    return SizedBox(
      height: 92,
      child: Stack(
        alignment: Alignment.bottomCenter,
        children: [
          Container(
            height: 72,
            decoration: const BoxDecoration(
              color: _primary,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(26),
                topRight: Radius.circular(26),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _navItem(Icons.person_outline, trKey("account"), 0),
                _navItem(Icons.directions_car, trKey("vehicles"), 1),
                const SizedBox(width: 62),
                _navItem(Icons.receipt_long, trKey("orders"), 2),
                _navItem(Icons.home, trKey("home"), 4),
              ],
            ),
          ),
          Positioned(
            bottom: 30,
            child: GestureDetector(
              onTap: _showCallSheet,
              child: Container(
                width: 66,
                height: 66,
                decoration: BoxDecoration(
                  color: _primary,
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white, width: 4),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(.18),
                      blurRadius: 14,
                      offset: const Offset(0, 8),
                    )
                  ],
                ),
                child: const Icon(Icons.call, color: Colors.white, size: 32),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _navItem(IconData icon, String label, int index) {
    final isActive = _navIndex == index;
    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        setState(() => _navIndex = index);
        switch (index) {
          case 0:
            _goto(const AccountSettingsScreen());
            break;
          case 1:
            // TODO vehicles page
            break;
          case 2:
            // TODO orders page
            break;
          default:
            break;
        }
      },
      child: Semantics(
        button: true,
        selected: isActive,
        label: label,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              color: isActive ? Colors.white : Colors.white.withOpacity(.55),
              size: 26,
            ),
            const SizedBox(height: 4),
            Text(
              label,
              style: GoogleFonts.cairo(
                fontSize: 12,
                color: isActive ? Colors.white : Colors.white.withOpacity(.55),
                fontWeight: isActive ? FontWeight.w900 : FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ================== HOW CARD ==================
class _HowCard extends StatelessWidget {
  final IconData icon;
  final String text;
  final bool isDark;

  const _HowCard({
    required this.icon,
    required this.text,
    required this.isDark,
  });

  static const Color _primary = Color(0xff1F4BA5);

  @override
  Widget build(BuildContext context) {
    final bg = isDark ? const Color(0xff151A2E) : Colors.white;
    final border =
        isDark ? Colors.white.withOpacity(.10) : _primary.withOpacity(.45);
    final textColor = isDark ? Colors.white : const Color(0xff111827);

    return Expanded(
      child: Container(
        height: 140,
        margin: const EdgeInsets.symmetric(horizontal: 4),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: border, width: 1.3),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 44, color: _primary),
            const SizedBox(height: 12),
            Text(
              text,
              textAlign: TextAlign.center,
              style: GoogleFonts.cairo(
                fontWeight: FontWeight.w900,
                fontSize: 13,
                height: 1.2,
                color: textColor,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ================== CENTER DETAILS ==================
class _CenterDetailsScreen extends StatelessWidget {
  final CenterItem center;
  final bool isArabic;
  final bool isDarkMode;

  const _CenterDetailsScreen({
    required this.center,
    required this.isArabic,
    required this.isDarkMode,
  });

  Future<void> _openMaps() async {
    if (!center.hasCoords) return;
    final lat = center.lat!;
    final lng = center.lng!;
    final google =
        Uri.parse("https://www.google.com/maps/search/?api=1&query=$lat,$lng");
    if (await canLaunchUrl(google)) {
      await launchUrl(google, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    final bg = isDarkMode ? const Color(0xff0E1320) : const Color(0xffF5F6FA);
    final surface = isDarkMode ? const Color(0xff151A2E) : Colors.white;
    final textMain = isDarkMode ? Colors.white : const Color(0xff111827);
    final textSub = isDarkMode ? Colors.white70 : const Color(0xff6B7280);

    return Directionality(
      textDirection: isArabic ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        backgroundColor: bg,
        appBar: AppBar(
          title: Text(
            isArabic ? "تفاصيل" : "Details",
            style: GoogleFonts.cairo(fontWeight: FontWeight.w900),
          ),
          backgroundColor: Colors.transparent,
          elevation: 0,
        ),
        body: Padding(
          padding: const EdgeInsets.all(16),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: surface,
              borderRadius: BorderRadius.circular(22),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  center.name,
                  style: GoogleFonts.cairo(
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    color: textMain,
                  ),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    const Icon(Icons.star, color: Colors.amber, size: 18),
                    const SizedBox(width: 6),
                    Text(
                      center.rating.toStringAsFixed(1),
                      style: GoogleFonts.cairo(
                        color: textSub,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    if (center.distanceText.isNotEmpty) ...[
                      const SizedBox(width: 10),
                      Text(
                        "• ${center.distanceText}",
                        style: GoogleFonts.cairo(
                          color: textSub,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ],
                  ],
                ),
                const Spacer(),
                SizedBox(
                  width: double.infinity,
                  height: 52,
                  child: ElevatedButton.icon(
                    onPressed: center.hasCoords ? _openMaps : null,
                    icon: const Icon(Icons.map),
                    label: Text(
                      isArabic ? "افتح على الخريطة" : "Open in Maps",
                      style: GoogleFonts.cairo(fontWeight: FontWeight.w900),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
