import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;

import 'package:doctor_car_app/config/api_config.dart';

class NearbyCentersMapScreen extends StatefulWidget {
  final bool isArabic;
  final bool isDarkMode;
  final int radiusKm;

  const NearbyCentersMapScreen({
    super.key,
    required this.isArabic,
    required this.isDarkMode,
    required this.radiusKm,
  });

  @override
  State<NearbyCentersMapScreen> createState() => _NearbyCentersMapScreenState();
}

class _NearbyCentersMapScreenState extends State<NearbyCentersMapScreen> {
  GoogleMapController? _map;
  // ignore: unused_field
  Position? _pos;
  bool _loading = true;
  String? _error;

  final Set<Marker> _markers = {};
  final Set<Circle> _circles = {};

  String tr(String ar, String en) => widget.isArabic ? ar : en;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<Position> _getLocation() async {
    final service = await Geolocator.isLocationServiceEnabled();
    if (!service) throw Exception("SERVICE_OFF");

    var perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) {
      perm = await Geolocator.requestPermission();
    }
    if (perm == LocationPermission.denied) throw Exception("DENIED");
    if (perm == LocationPermission.deniedForever)
      throw Exception("DENIED_FOREVER");

    return Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.high,
      timeLimit: const Duration(seconds: 12),
    );
  }

  Future<void> _init() async {
    setState(() {
      _loading = true;
      _error = null;
      _markers.clear();
      _circles.clear();
    });

    try {
      final p = await _getLocation();
      _pos = p;

      // ✅ دايرة نطاق البحث
      _circles.add(
        Circle(
          circleId: const CircleId("radius"),
          center: LatLng(p.latitude, p.longitude),
          radius: widget.radiusKm * 1000.0,
          strokeWidth: 2,
          fillColor: Colors.blue.withOpacity(0.12),
          strokeColor: Colors.blue,
        ),
      );

      // ✅ نجيب المراكز من API
      final uri = Uri.parse(
        ApiConfig.nearbyCenters(
          lat: p.latitude,
          lng: p.longitude,
          limit: 200,
        ),
      );

      final res = await http.get(uri).timeout(const Duration(seconds: 15));
      if (res.statusCode != 200) {
        throw Exception("API_${res.statusCode}");
      }

      final decoded = jsonDecode(res.body);
      if (decoded is! List) throw Exception("BAD_RESPONSE");

      // ✅ ماركر لموقعك
      _markers.add(
        Marker(
          markerId: const MarkerId("me"),
          position: LatLng(p.latitude, p.longitude),
          infoWindow: InfoWindow(title: tr("موقعي", "My Location")),
        ),
      );

      int added = 0;

      for (final item in decoded) {
        if (item is! Map<String, dynamic>) continue;

        final lat = (item["lat"] ?? item["location"]?["lat"]) as num?;
        final lng = (item["lng"] ?? item["location"]?["lng"]) as num?;
        final name = (item["name"] ?? item["title"] ?? "Center").toString();
        final id = (item["_id"] ?? item["id"] ?? name).toString();

        if (lat == null || lng == null) continue;

        final d = Geolocator.distanceBetween(
          p.latitude,
          p.longitude,
          lat.toDouble(),
          lng.toDouble(),
        );

        // ✅ فلترة على radius
        if (d > widget.radiusKm * 1000.0) continue;

        _markers.add(
          Marker(
            markerId: MarkerId(id),
            position: LatLng(lat.toDouble(), lng.toDouble()),
            infoWindow: InfoWindow(
              title: name,
              snippet: tr(
                "${(d / 1000).toStringAsFixed(1)} كم",
                "${(d / 1000).toStringAsFixed(1)} km",
              ),
            ),
          ),
        );

        added++;
      }

      if (added == 0) {
        _error = tr("لا يوجد مراكز داخل ${widget.radiusKm} كم",
            "No centers within ${widget.radiusKm} km");
      }

      setState(() => _loading = false);

      // ✅ نزبط الكاميرا على موقعك
      _map?.animateCamera(
        CameraUpdate.newLatLngZoom(
          LatLng(p.latitude, p.longitude),
          13,
        ),
      );
    } catch (e) {
      setState(() {
        _loading = false;
        _error = tr("تعذر تحميل الخريطة: $e", "Failed to load map: $e");
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final bg =
        widget.isDarkMode ? const Color(0xff0E1320) : const Color(0xffF5F6FA);
    final surface = widget.isDarkMode ? const Color(0xff151A2E) : Colors.white;

    return Directionality(
      textDirection: widget.isArabic ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        backgroundColor: bg,
        appBar: AppBar(
          title: Text(
            tr("مراكز قريبة على الخريطة", "Nearby Centers Map"),
            style: GoogleFonts.cairo(fontWeight: FontWeight.w900),
          ),
          backgroundColor: Colors.transparent,
          elevation: 0,
        ),
        body: _loading
            ? Center(child: CircularProgressIndicator(color: Colors.blue))
            : Stack(
                children: [
                  GoogleMap(
                    initialCameraPosition: const CameraPosition(
                      target: LatLng(30.0444, 31.2357), // fallback Cairo
                      zoom: 11,
                    ),
                    myLocationEnabled: true,
                    myLocationButtonEnabled: true,
                    markers: _markers,
                    circles: _circles,
                    onMapCreated: (c) => _map = c,
                  ),
                  if (_error != null)
                    Positioned(
                      left: 12,
                      right: 12,
                      bottom: 12,
                      child: Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: surface,
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.info_outline),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                _error!,
                                style: GoogleFonts.cairo(
                                    fontWeight: FontWeight.w800),
                              ),
                            ),
                            TextButton(
                              onPressed: _init,
                              child: Text(
                                tr("تحديث", "Refresh"),
                                style: GoogleFonts.cairo(
                                    fontWeight: FontWeight.w900),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                ],
              ),
      ),
    );
  }
}
