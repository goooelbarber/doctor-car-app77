import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:doctor_car_app/services/api_service.dart';

import 'package:doctor_car_app/screens/car/add_vehicle_screen.dart';
import 'package:doctor_car_app/screens/vehicles/car_dashboard_screen.dart';

// ✅ صحح المسار هنا حسب الموجود عندك
import 'package:doctor_car_app/screens/car/edit_car_screen.dart'; // <-- الملف الحقيقي

class VehiclesScreen extends StatefulWidget {
  const VehiclesScreen({super.key});

  @override
  State<VehiclesScreen> createState() => _VehiclesScreenState();
}

class _VehiclesScreenState extends State<VehiclesScreen> {
  List<dynamic> vehicles = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _fetchVehicles();
  }

  Future<void> _fetchVehicles() async {
    if (!mounted) return;
    setState(() => loading = true);

    try {
      final res = await ApiService.getVehicles();
      if (!mounted) return;

      setState(() {
        vehicles = res;
        loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() => loading = false);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("تعذر تحميل المركبات")),
      );
    }
  }

  Future<void> _deleteVehicle(String id) async {
    if (id.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("معرّف المركبة غير صحيح")),
      );
      return;
    }

    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("تأكيد الحذف"),
        content: const Text("هل تريد حذف هذه السيارة؟"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text("إلغاء"),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text("حذف", style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (confirm != true) return;

    try {
      final res = await ApiService.deleteVehicle(id);
      if (!mounted) return;

      if (res["success"] == true) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("🚗 تم حذف المركبة")),
        );
        _fetchVehicles();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
              content: Text(res["message"]?.toString() ?? "فشل حذف المركبة")),
        );
      }
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("تعذر الاتصال بالسيرفر")),
      );
    }
  }

  Future<void> _goToAddCar() async {
    final added = await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const AddVehicleScreen()),
    );

    if (added == true) _fetchVehicles();
  }

  Widget emptyView() {
    return Container(
      width: double.infinity,
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF0A0F14), Color(0xFF1C1F27)],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const SizedBox(height: 12),
          const Icon(Icons.directions_car, size: 90, color: Colors.white24),
          const SizedBox(height: 20),
          const Text(
            "لا توجد مركبات",
            style: TextStyle(
              color: Colors.white,
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            "قم بإضافة مركبتك الآن",
            style: TextStyle(color: Colors.white54, fontSize: 16),
          ),
          const SizedBox(height: 22),
          ElevatedButton(
            onPressed: _goToAddCar,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.redAccent,
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
            ),
            child: const Text(
              "➕ إضافة مركبة",
              style: TextStyle(color: Colors.white, fontSize: 16),
            ),
          ),
        ],
      ),
    );
  }

  Widget vehicleCard(Map<String, dynamic> car) {
    final id = (car["_id"] ?? "").toString();

    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => CarDashboardScreen(vehicle: car),
          ),
        );
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFF1C1F27), Color(0xFF13161C)],
          ),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(.3),
              blurRadius: 10,
              offset: const Offset(0, 4),
            )
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  (car["brand"] ?? "").toString(),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Icon(FontAwesomeIcons.car, color: Colors.redAccent),
              ],
            ),
            const SizedBox(height: 10),
            _info("الموديل", car["model"]),
            _info("اللون", car["color"]),
            _info("اللوحة", car["plateNumber"]),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  (car["condition"] ?? "").toString(),
                  style: const TextStyle(color: Colors.white70),
                ),
                Row(
                  children: [
                    IconButton(
                      onPressed: () async {
                        final updated = await Navigator.push(
                          context,
                          MaterialPageRoute(
                            // ✅ هنا اسم الشاشة اللي موجودة داخل edit_car_screen.dart
                            builder: (_) => EditVehicleScreen(vehicle: car),
                          ),
                        );
                        if (updated == true) _fetchVehicles();
                      },
                      icon: const Icon(Icons.edit, color: Colors.orangeAccent),
                    ),
                    IconButton(
                      onPressed: () => _deleteVehicle(id),
                      icon: const Icon(Icons.delete_forever, color: Colors.red),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _info(String label, dynamic value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          value?.toString() ?? "-",
          style: const TextStyle(color: Colors.white, fontSize: 16),
        ),
        Text(label, style: const TextStyle(color: Colors.white54)),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF101418),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1C1F27),
        leading: Navigator.canPop(context)
            ? IconButton(
                icon: const Icon(Icons.arrow_back, color: Colors.white),
                onPressed: () => Navigator.pop(context),
              )
            : null,
        title: const Text(
          "لوحة المركبات",
          style: TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
      ),
      body: loading
          ? const Center(
              child: CircularProgressIndicator(color: Colors.redAccent),
            )
          : vehicles.isEmpty
              ? emptyView()
              : RefreshIndicator(
                  onRefresh: _fetchVehicles,
                  child: ListView.builder(
                    physics: const AlwaysScrollableScrollPhysics(),
                    padding: const EdgeInsets.all(16),
                    itemCount: vehicles.length,
                    itemBuilder: (_, i) {
                      final raw = vehicles[i];
                      if (raw is Map) {
                        return vehicleCard(Map<String, dynamic>.from(raw));
                      }
                      return const SizedBox.shrink();
                    },
                  ),
                ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.redAccent,
        onPressed: _goToAddCar,
        child: const Icon(Icons.add, size: 28),
      ),
    );
  }
}
