// ignore_for_file: use_build_context_synchronously

import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart'; // kIsWeb
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:doctor_car_app/services/api_service.dart';
import 'package:local_auth/local_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

// ✅ شاشة الفني
import 'package:doctor_car_app/screens/driver/driver_home_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen>
    with TickerProviderStateMixin {
  // =========================
  // Controllers
  // =========================
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  final LocalAuthentication _auth = LocalAuthentication();

  // =========================
  // Animations
  // =========================
  late final AnimationController _logoController;
  late final Animation<double> _logoScale;

  // =========================
  // State
  // =========================
  bool _obscureText = true;
  bool _isLoading = false;
  bool _rememberMe = true;
  bool _biometricEnabled = false;
  bool _deviceSupportsBiometric = false;

  // =========================
  // Pref keys
  // =========================
  static const String _kIsLoggedInKey = 'isLoggedIn';
  static const String _kTokenKey = 'token';
  static const String _kUserIdKey = 'userId';
  static const String _kUserEmailKey = 'userEmail';
  static const String _kUserNameKey = 'userName';
  static const String _kSelectedRoleKey = 'selectedRole'; // rider|driver
  static const String _kBiometricKey = 'biometric';

  // =========================
  // Google Web Client ID
  // =========================
  static const String kGoogleWebClientId =
      "261907163300-cngtqbjih04t2c5k66vfqd2tduqvt2oc.apps.googleusercontent.com";

  @override
  void initState() {
    super.initState();

    _logoController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..forward();

    _logoScale = CurvedAnimation(
      parent: _logoController,
      curve: Curves.easeOutBack,
    );

    _loadRememberedEmail();
    _initBiometric();
  }

  @override
  void dispose() {
    _logoController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  // ======================================================
  // BIOMETRIC
  // ======================================================
  Future<void> _initBiometric() async {
    if (kIsWeb) return;

    try {
      final prefs = await SharedPreferences.getInstance();
      _biometricEnabled = prefs.getBool(_kBiometricKey) ?? false;
      _deviceSupportsBiometric = await _auth.canCheckBiometrics;
      if (mounted) setState(() {});
    } catch (_) {}
  }

  Future<void> _biometricLogin() async {
    if (kIsWeb || _isLoading) return;

    final success = await _auth.authenticate(
      localizedReason: 'سجل الدخول باستخدام Face ID / Fingerprint',
      options: const AuthenticationOptions(biometricOnly: true),
    );

    if (!success) return;

    final prefs = await SharedPreferences.getInstance();
    final role = prefs.getString(_kSelectedRoleKey);
    if (role != null) _goAfterLogin(role);
  }

  // ======================================================
  // AUTH: EMAIL/PASSWORD
  // ======================================================
  Future<void> _login() async {
    if (_isLoading) return;

    FocusScope.of(context).unfocus();

    final email = _emailController.text.trim();
    final password = _passwordController.text.trim();

    if (!_isValidEmail(email)) {
      _showMessage("أدخل بريد إلكتروني صحيح");
      return;
    }

    if (password.length < 6) {
      _showMessage("كلمة المرور قصيرة");
      return;
    }

    setState(() => _isLoading = true);

    try {
      final prefs = await SharedPreferences.getInstance();
      final selectedRole = prefs.getString(_kSelectedRoleKey);

      if (selectedRole == null || selectedRole.isEmpty) {
        _showMessage("اختر (راكب / سائق) أولاً");
        return;
      }

      final res = await ApiService.login(email, password);

      if (res['token'] != null) {
        await prefs.setBool(_kIsLoggedInKey, true);
        await prefs.setString(_kTokenKey, res['token']);
        await prefs.setString(_kUserIdKey, res['user']?['_id'] ?? '');
        await prefs.setString(_kUserEmailKey, email);
        await prefs.setString(_kUserNameKey, res['user']?['name'] ?? "User");

        final roleToSave = res['user']?['role']?.toString() ?? selectedRole;

        await prefs.setString(_kSelectedRoleKey, roleToSave);

        if (!kIsWeb) {
          await prefs.setBool(_kBiometricKey, true);
        }

        await _saveRememberedEmail();
        _goAfterLogin(roleToSave);
      } else {
        _showMessage("فشل تسجيل الدخول");
      }
    } catch (_) {
      _showMessage("تعذر الاتصال بالسيرفر");
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  // ======================================================
  // AUTH: GOOGLE
  // ======================================================
  Future<void> _loginWithGoogle() async {
    if (_isLoading) return;

    setState(() => _isLoading = true);

    try {
      final prefs = await SharedPreferences.getInstance();
      final selectedRole = prefs.getString(_kSelectedRoleKey);

      if (selectedRole == null) {
        _showMessage("اختر (راكب / سائق) أولاً");
        return;
      }

      final googleSignIn = GoogleSignIn(
        scopes: const ["email", "profile", "openid"],
        clientId: kIsWeb ? kGoogleWebClientId : null,
        serverClientId: !kIsWeb ? kGoogleWebClientId : null,
      );

      await googleSignIn.signOut();
      final account = await googleSignIn.signIn();
      if (account == null) return;

      final auth = await account.authentication;
      final res =
          await ApiService.googleLogin(auth.idToken!, role: selectedRole);

      if (res['token'] != null) {
        await prefs.setBool(_kIsLoggedInKey, true);
        await prefs.setString(_kTokenKey, res['token']);
        await prefs.setString(_kUserIdKey, res['user']?['_id'] ?? '');

        final roleToSave = res['user']?['role']?.toString() ?? selectedRole;

        await prefs.setString(_kSelectedRoleKey, roleToSave);
        _goAfterLogin(roleToSave);
      }
    } catch (_) {
      _showMessage("Google login failed");
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  // ======================================================
  // 🚀 NAVIGATION (FIX النهائي)
  // ======================================================
  Future<void> _goAfterLogin(String role) async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString(_kTokenKey) ?? "";
    final userId = prefs.getString(_kUserIdKey) ?? "";

    if (!mounted) return;

    if (_isTechnicianRole(role)) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => IncomingRequestScreen(
            technicianToken: token,
            technicianId: userId,
          ),
        ),
      );
    } else {
      Navigator.pushReplacementNamed(context, '/home');
    }
  }

  // ======================================================
  // HELPERS
  // ======================================================
  bool _isTechnicianRole(String role) {
    return role == "driver" ||
        role == "technician" ||
        role == "mechanic" ||
        role == "service_provider";
  }

  bool _isValidEmail(String email) =>
      RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(email);

  void _showMessage(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg, textAlign: TextAlign.center)),
    );
  }

  Future<void> _loadRememberedEmail() async {
    final prefs = await SharedPreferences.getInstance();
    _emailController.text = prefs.getString("rememberedEmail") ?? "";
    _rememberMe = prefs.getBool("rememberMe") ?? true;
  }

  Future<void> _saveRememberedEmail() async {
    final prefs = await SharedPreferences.getInstance();
    if (_rememberMe) {
      await prefs.setString("rememberedEmail", _emailController.text.trim());
    } else {
      await prefs.remove("rememberedEmail");
    }
    await prefs.setBool("rememberMe", _rememberMe);
  }

  double _passwordStrength() {
    final p = _passwordController.text;
    if (p.isEmpty) return 0;
    if (p.length >= 12) return 1;
    if (p.length >= 8) return 0.7;
    if (p.length >= 6) return 0.5;
    return 0.25;
  }

  String _strengthLabel() {
    final v = _passwordStrength();
    if (v >= 1) return "قوية جدًا";
    if (v >= 0.7) return "قوية";
    if (v >= 0.5) return "متوسطة";
    if (v > 0) return "ضعيفة";
    return "";
  }

  // ======================================================
  // UI
  // ======================================================
  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;

    return Scaffold(
      body: Stack(
        children: [
          _background(),
          SafeArea(
            child: Align(
              alignment: Alignment.center,
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 520),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: _glassCard(width),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _glassCard(double width) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(28),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(.10),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: Colors.white.withOpacity(.18)),
            boxShadow: [
              BoxShadow(
                blurRadius: 30,
                color: Colors.black.withOpacity(.25),
                offset: const Offset(0, 18),
              ),
            ],
          ),
          child: SingleChildScrollView(
            child: Column(
              children: [
                ScaleTransition(
                  scale: _logoScale,
                  child: Container(
                    width: 92,
                    height: 92,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: const LinearGradient(
                        colors: [Color(0xFFFFD54F), Color(0xFFFFB300)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      boxShadow: [
                        BoxShadow(
                          blurRadius: 30,
                          color: Colors.amber.withOpacity(.35),
                          offset: const Offset(0, 10),
                        ),
                      ],
                    ),
                    child: const Icon(
                      Icons.directions_car_filled,
                      color: Color(0xFF0B1B2B),
                      size: 46,
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                const Text(
                  "تسجيل الدخول",
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 6),
                const Text(
                  "أكمل رحلتك بأمان — دخول سريع واحترافي",
                  style: TextStyle(color: Colors.white70),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 22),
                _field(_emailController, Icons.email, "البريد الإلكتروني"),
                const SizedBox(height: 14),
                _passwordField(),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: LinearProgressIndicator(
                        value: _passwordStrength(),
                        minHeight: 6,
                        borderRadius: BorderRadius.circular(20),
                        backgroundColor: Colors.white24,
                        color: Colors.greenAccent,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Text(
                      _strengthLabel(),
                      style: const TextStyle(
                        color: Colors.white70,
                        fontSize: 12,
                      ),
                    )
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Checkbox(
                      value: _rememberMe,
                      activeColor: Colors.amber,
                      onChanged: _isLoading
                          ? null
                          : (v) => setState(() => _rememberMe = v ?? true),
                    ),
                    const Text(
                      "تذكرني",
                      style: TextStyle(color: Colors.white),
                    ),
                    const Spacer(),
                    TextButton(
                      onPressed: _isLoading
                          ? null
                          : () => Navigator.pushNamed(
                                context,
                                '/forgot-password',
                              ),
                      child: const Text(
                        "نسيت كلمة المرور؟",
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ],
                ),
                if (!kIsWeb && _deviceSupportsBiometric && _biometricEnabled)
                  Align(
                    alignment: Alignment.centerRight,
                    child: TextButton.icon(
                      onPressed: _isLoading ? null : _biometricLogin,
                      icon: const Icon(Icons.fingerprint, color: Colors.white),
                      label: const Text(
                        "دخول بالبصمة",
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ),
                const SizedBox(height: 6),
                SizedBox(
                  width: double.infinity,
                  height: 54,
                  child: ElevatedButton(
                    onPressed: _isLoading ? null : _login,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.amber,
                      foregroundColor: const Color(0xFF0B1B2B),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18),
                      ),
                      elevation: 0,
                    ),
                    child: _isLoading
                        ? const SizedBox(
                            width: 22,
                            height: 22,
                            child: CircularProgressIndicator(
                              strokeWidth: 2.5,
                              color: Color(0xFF0B1B2B),
                            ),
                          )
                        : const Text(
                            "تسجيل الدخول",
                            style: TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: Divider(color: Colors.white.withOpacity(.25)),
                    ),
                    const Padding(
                      padding: EdgeInsets.symmetric(horizontal: 10),
                      child: Text(
                        "أو",
                        style: TextStyle(color: Colors.white70),
                      ),
                    ),
                    Expanded(
                      child: Divider(color: Colors.white.withOpacity(.25)),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  height: 54,
                  child: OutlinedButton.icon(
                    onPressed: _isLoading ? null : _loginWithGoogle,
                    icon: const Icon(FontAwesomeIcons.google, size: 18),
                    label: const Text(
                      "تسجيل بواسطة Google",
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.white,
                      side: BorderSide(
                        color: Colors.white.withOpacity(.30),
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18),
                      ),
                      backgroundColor: Colors.white.withOpacity(.06),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _social(FontAwesomeIcons.facebookF),
                    const SizedBox(width: 12),
                    _social(FontAwesomeIcons.apple),
                    const SizedBox(width: 12),
                    _social(FontAwesomeIcons.twitter),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ======================================================
  // Widgets
  // ======================================================
  Widget _background() => Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color(0xff051937),
              Color(0xff003d73),
              Color(0xff001b3a),
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: CustomPaint(
          painter: _GlowPainter(),
          child: const SizedBox.expand(),
        ),
      );

  Widget _field(TextEditingController c, IconData i, String hint) {
    return TextField(
      controller: c,
      keyboardType: TextInputType.emailAddress,
      textAlign: TextAlign.right,
      style: const TextStyle(color: Colors.white),
      decoration: _input(i, hint),
    );
  }

  Widget _passwordField() => TextField(
        controller: _passwordController,
        obscureText: _obscureText,
        style: const TextStyle(color: Colors.white),
        textAlign: TextAlign.right,
        onChanged: (_) => setState(() {}),
        decoration: _input(Icons.lock, "كلمة المرور").copyWith(
          suffixIcon: IconButton(
            icon: Icon(
              _obscureText ? Icons.visibility_off : Icons.visibility,
              color: Colors.white,
            ),
            onPressed: () => setState(() => _obscureText = !_obscureText),
          ),
        ),
      );

  InputDecoration _input(IconData icon, String hint) => InputDecoration(
        filled: true,
        fillColor: Colors.white.withOpacity(.12),
        prefixIcon: Icon(icon, color: Colors.white),
        hintText: hint,
        hintStyle: const TextStyle(color: Colors.white70),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 16),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: BorderSide(color: Colors.white.withOpacity(.18)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: const BorderSide(color: Colors.amber, width: 1.3),
        ),
      );

  Widget _social(IconData icon) => InkWell(
        onTap: () => _showMessage("سيتم تفعيلها قريبًا"),
        borderRadius: BorderRadius.circular(999),
        child: Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.white.withOpacity(.08),
            border: Border.all(color: Colors.white.withOpacity(.22)),
          ),
          child: Icon(icon, color: Colors.white, size: 18),
        ),
      );
}

// ======================================================
// Background Painter
// ======================================================
class _GlowPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 60);

    paint.color = Colors.cyanAccent.withOpacity(.10);
    canvas.drawCircle(Offset(size.width * .20, size.height * .20), 140, paint);

    paint.color = Colors.amber.withOpacity(.10);
    canvas.drawCircle(Offset(size.width * .85, size.height * .30), 170, paint);

    paint.color = Colors.blueAccent.withOpacity(.10);
    canvas.drawCircle(Offset(size.width * .70, size.height * .85), 220, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
