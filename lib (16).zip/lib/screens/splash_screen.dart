// ignore_for_file: use_build_context_synchronously

import 'dart:async';
import 'dart:math';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:connectivity_plus/connectivity_plus.dart';

import 'package:doctor_car_app/screens/login_screen.dart';
import 'package:doctor_car_app/screens/home_screen.dart';
import 'package:doctor_car_app/screens/role_selection_screen.dart';
import 'package:doctor_car_app/core/app_routes.dart';

// ✅ إضافة شاشة الفني
import 'package:doctor_car_app/screens/driver/driver_home_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  // ====== Timings ======
  static const Duration _minSplash = Duration(milliseconds: 3200);
  static const Duration _hardTimeout = Duration(seconds: 10);

  // ====== Pref keys ======
  static const String _kIsLoggedInKey = 'isLoggedIn';
  static const String _kSelectedRoleKey = 'selectedRole';
  static const String _kTokenKey = 'token';
  static const String _kUserIdKey = 'userId';

  // ====== Animations ======
  late final AnimationController _main;
  late final AnimationController _bg;
  late final AnimationController _ring;

  late final Animation<double> _fadeIn;
  late final Animation<double> _scaleIn;
  late final Animation<Offset> _slideUp;
  late final Animation<double> _progress;

  bool _navigated = false;
  bool _readyToSkip = false;

  String _version = "v1.0.0";
  String? _statusLine;
  bool _offline = false;

  @override
  void initState() {
    super.initState();
    HapticFeedback.lightImpact();

    _main = AnimationController(vsync: this, duration: _minSplash)..forward();
    _bg = AnimationController(vsync: this, duration: const Duration(seconds: 6))
      ..repeat();
    _ring =
        AnimationController(vsync: this, duration: const Duration(seconds: 2))
          ..repeat();

    _fadeIn = CurvedAnimation(parent: _main, curve: Curves.easeOut);
    _scaleIn = Tween<double>(begin: 0.92, end: 1.0).animate(
      CurvedAnimation(parent: _main, curve: Curves.easeOutBack),
    );
    _slideUp = Tween<Offset>(
      begin: const Offset(0, 0.16),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(parent: _main, curve: const Interval(0.18, 1.0)),
    );

    _progress = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _main, curve: const Interval(0.10, 1.0)),
    );

    _bootstrap();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    precacheImage(const AssetImage("assets/images/logo1.png"), context);
  }

  Future<void> _bootstrap() async {
    Future.delayed(const Duration(milliseconds: 1400), () {
      if (mounted) setState(() => _readyToSkip = true);
    });

    final minDelay = Future.delayed(_minSplash);

    final work = _initWork().timeout(_hardTimeout, onTimeout: () {
      return _decideNextSafeFallback();
    });

    await Future.wait([minDelay, work]);

    if (!mounted || _navigated) return;
    _navigated = true;

    final next = await _decideNext();
    if (!mounted) return;

    Navigator.of(context).pushReplacement(AppRoutes.fadeScale(next));
  }

  Future<void> _initWork() async {
    await Future.wait([
      _loadVersion(),
      _checkConnectivity(),
      Future.delayed(const Duration(milliseconds: 250)),
    ]);
  }

  Future<void> _loadVersion() async {
    try {
      final info = await PackageInfo.fromPlatform();
      if (!mounted) return;
      setState(() => _version = "v${info.version}+${info.buildNumber}");
    } catch (_) {}
  }

  Future<void> _checkConnectivity() async {
    try {
      final result = await Connectivity().checkConnectivity();
      final isOffline = result == ConnectivityResult.none;
      if (!mounted) return;
      setState(() {
        _offline = isOffline;
        _statusLine = isOffline ? "لا يوجد اتصال بالإنترنت" : "جاري التهيئة...";
      });
    } catch (_) {}
  }

  Future<Widget> _decideNextSafeFallback() async {
    return const LoginScreen();
  }

  // =====================================================
  // ✅ القرار الصح (الفني / العميل)
  // =====================================================
  Future<Widget> _decideNext() async {
    try {
      final prefs = await SharedPreferences.getInstance();

      final isLoggedIn = prefs.getBool(_kIsLoggedInKey) ?? false;
      final role = prefs.getString(_kSelectedRoleKey);
      final token = prefs.getString(_kTokenKey) ?? "";
      final userId = prefs.getString(_kUserIdKey) ?? "";

      if (role == null || role.isEmpty) {
        return const RoleSelectionScreen();
      }

      if (!isLoggedIn) {
        return const LoginScreen();
      }

      if (role == "driver") {
        return IncomingRequestScreen(
          technicianToken: token,
          technicianId: userId,
        );
      }

      return const HomeScreen();
    } catch (_) {
      return const LoginScreen();
    }
  }

  void _skipNow() async {
    if (_navigated) return;
    _navigated = true;
    final next = await _decideNext();
    if (!mounted) return;
    Navigator.of(context).pushReplacement(AppRoutes.fadeScale(next));
  }

  @override
  void dispose() {
    _main.dispose();
    _bg.dispose();
    _ring.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final topPad = MediaQuery.of(context).padding.top;

    return Scaffold(
      body: Stack(
        children: [
          // ===== Background =====
          AnimatedBuilder(
            animation: _bg,
            builder: (_, __) => _PremiumAnimatedBackground(t: _bg.value),
          ),

          // subtle dark overlay for contrast
          Container(color: Colors.black.withOpacity(0.10)),

          // particles
          Positioned.fill(
            child: IgnorePointer(
              child: Opacity(
                opacity: 0.35,
                child: CustomPaint(painter: _ParticlesPainter(t: _bg.value)),
              ),
            ),
          ),

          // ===== Content =====
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 22),
              child: Column(
                children: [
                  SizedBox(height: max(12, topPad * 0.25)),

                  // Top row: status + skip
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      _GlassPill(
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              _offline ? Icons.wifi_off : Icons.auto_awesome,
                              size: 16,
                              color: Colors.white.withOpacity(0.85),
                            ),
                            const SizedBox(width: 8),
                            Text(
                              _statusLine ?? "جاري التهيئة...",
                              style: TextStyle(
                                color: Colors.white.withOpacity(0.80),
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                      AnimatedOpacity(
                        opacity: _readyToSkip ? 1 : 0,
                        duration: const Duration(milliseconds: 300),
                        child: TextButton(
                          onPressed: _readyToSkip ? _skipNow : null,
                          style: TextButton.styleFrom(
                            foregroundColor: Colors.white.withOpacity(0.90),
                          ),
                          child: const Text(
                            "تخطي",
                            style: TextStyle(
                              fontWeight: FontWeight.w800,
                              letterSpacing: 0.2,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),

                  const Spacer(flex: 2),

                  FadeTransition(
                    opacity: _fadeIn,
                    child: SlideTransition(
                      position: _slideUp,
                      child: Column(
                        children: [
                          // ===== Logo Card (Glass + Neon ring) =====
                          ScaleTransition(
                            scale: _scaleIn,
                            child: _LogoNeonGlass(
                              ringAnim: _ring,
                              child: const Image(
                                image: AssetImage("assets/images/logo1.png"),
                                fit: BoxFit.contain,
                              ),
                            ),
                          ),

                          const SizedBox(height: 26),

                          // Title shimmer-ish (بدون packages)
                          _ShimmerText(
                            text: "Doctor Car",
                            baseStyle: const TextStyle(
                              fontSize: 40,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1.1,
                            ),
                            animation: _bg,
                          ),

                          const SizedBox(height: 8),

                          Text(
                            "Smart Road Assistance",
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.white.withOpacity(0.72),
                              letterSpacing: 0.9,
                              fontWeight: FontWeight.w600,
                            ),
                          ),

                          const SizedBox(height: 26),

                          // ===== Progress =====
                          _PremiumProgressBar(progress: _progress),

                          const SizedBox(height: 10),

                          AnimatedBuilder(
                            animation: _progress,
                            builder: (_, __) {
                              final p =
                                  (_progress.value * 100).clamp(0, 100).toInt();
                              return Text(
                                "جاري التحميل... $p%",
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.white.withOpacity(.58),
                                  fontWeight: FontWeight.w600,
                                ),
                              );
                            },
                          ),
                        ],
                      ),
                    ),
                  ),

                  const Spacer(flex: 3),

                  Padding(
                    padding: const EdgeInsets.only(bottom: 14),
                    child: Text(
                      _version,
                      style: TextStyle(
                        color: Colors.white.withOpacity(.32),
                        fontSize: 12,
                        letterSpacing: 0.8,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// =======================
// Background (animated gradient + blobs)
// =======================
class _PremiumAnimatedBackground extends StatelessWidget {
  const _PremiumAnimatedBackground({required this.t});

  final double t;

  @override
  Widget build(BuildContext context) {
    // shift gradient subtly
    final a = Alignment.lerp(Alignment.topLeft, Alignment.topRight, t)!;
    final b = Alignment.lerp(Alignment.bottomRight, Alignment.bottomLeft, t)!;

    return Stack(
      children: [
        Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: a,
              end: b,
              colors: const [
                Color(0xFF031A2E),
                Color(0xFF043B6A),
                Color(0xFF021128),
              ],
            ),
          ),
        ),

        // big soft blobs
        Positioned(
          top: -160,
          left: -120,
          child: _Blob(
              size: 360, color: const Color(0xFFFFC857).withOpacity(0.14)),
        ),
        Positioned(
          bottom: -190,
          right: -140,
          child: _Blob(
              size: 420, color: const Color(0xFF55DDE0).withOpacity(0.12)),
        ),
        Positioned(
          top: 140,
          right: -120,
          child: _Blob(size: 260, color: Colors.white.withOpacity(0.06)),
        ),
      ],
    );
  }
}

class _Blob extends StatelessWidget {
  const _Blob({required this.size, required this.color});

  final double size;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(size),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 46, sigmaY: 46),
        child: Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
              color: color, borderRadius: BorderRadius.circular(size)),
        ),
      ),
    );
  }
}

// =======================
// Glass pill
// =======================
class _GlassPill extends StatelessWidget {
  const _GlassPill({required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(999),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.10),
            border: Border.all(color: Colors.white.withOpacity(0.14)),
            borderRadius: BorderRadius.circular(999),
          ),
          child: child,
        ),
      ),
    );
  }
}

// =======================
// Logo Glass + Neon Ring (بديل أجمل من الدائرة التقيلة)
// =======================
class _LogoNeonGlass extends StatelessWidget {
  const _LogoNeonGlass({required this.ringAnim, required this.child});

  final Animation<double> ringAnim;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: ringAnim,
      builder: (_, __) {
        final pulse = 0.6 + 0.4 * sin(ringAnim.value * 2 * pi);

        return Stack(
          alignment: Alignment.center,
          children: [
            // outer neon ring
            Container(
              width: 160,
              height: 160,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: SweepGradient(
                  startAngle: 0,
                  endAngle: 2 * pi,
                  colors: [
                    Colors.cyanAccent.withOpacity(0.65),
                    Colors.amber.withOpacity(0.65),
                    Colors.white.withOpacity(0.30),
                    Colors.cyanAccent.withOpacity(0.65),
                  ],
                  stops: const [0.0, 0.35, 0.65, 1.0],
                  transform: GradientRotation(ringAnim.value * 2 * pi),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.cyanAccent.withOpacity(0.18 * pulse),
                    blurRadius: 40,
                    spreadRadius: 2,
                  ),
                  BoxShadow(
                    color: Colors.amber.withOpacity(0.14 * pulse),
                    blurRadius: 38,
                    spreadRadius: 2,
                    offset: const Offset(0, 10),
                  ),
                ],
              ),
            ),

            // glass card circle
            ClipOval(
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
                child: Container(
                  width: 142,
                  height: 142,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white.withOpacity(0.08),
                    border: Border.all(
                      color: Colors.white.withOpacity(0.16),
                      width: 1.2,
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(30),
                    child: child,
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

// =======================
// Premium progress bar
// =======================
class _PremiumProgressBar extends StatelessWidget {
  const _PremiumProgressBar({required this.progress});

  final Animation<double> progress;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 210,
      child: AnimatedBuilder(
        animation: progress,
        builder: (_, __) {
          final v = progress.value.clamp(0.0, 1.0);
          return ClipRRect(
            borderRadius: BorderRadius.circular(999),
            child: Stack(
              children: [
                Container(
                  height: 8,
                  color: Colors.white.withOpacity(0.10),
                ),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Container(
                    height: 8,
                    width: 210 * v,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Colors.amber.withOpacity(0.95),
                          Colors.cyanAccent.withOpacity(0.85),
                        ],
                      ),
                    ),
                  ),
                ),
                // subtle highlight line
                Positioned.fill(
                  child: Opacity(
                    opacity: 0.20,
                    child: Container(
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [Colors.white, Colors.transparent],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

// =======================
// Shimmer-like text (بدون package)
// =======================
class _ShimmerText extends StatelessWidget {
  const _ShimmerText({
    required this.text,
    required this.baseStyle,
    required this.animation,
  });

  final String text;
  final TextStyle baseStyle;
  final Animation<double> animation;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: animation,
      builder: (_, __) {
        final t = animation.value;
        return ShaderMask(
          shaderCallback: (rect) {
            final dx = lerpDouble(-rect.width, rect.width, t)!;
            return LinearGradient(
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
              stops: const [0.0, 0.45, 0.55, 1.0],
              colors: [
                Colors.white.withOpacity(0.75),
                Colors.white,
                Colors.white.withOpacity(0.78),
                Colors.white.withOpacity(0.70),
              ],
              transform: GradientTranslation(Offset(dx, 0)),
            ).createShader(rect);
          },
          blendMode: BlendMode.srcIn,
          child: Text(
            text,
            style: baseStyle.copyWith(color: Colors.white),
          ),
        );
      },
    );
  }
}

class GradientTranslation extends GradientTransform {
  const GradientTranslation(this.offset);
  final Offset offset;

  @override
  Matrix4 transform(Rect bounds, {TextDirection? textDirection}) {
    return Matrix4.translationValues(offset.dx, offset.dy, 0);
  }
}

// =======================
// Particles Painter
// =======================
class _ParticlesPainter extends CustomPainter {
  _ParticlesPainter({required this.t});

  final double t;

  @override
  void paint(Canvas canvas, Size size) {
    final rnd = Random(7);
    final paint = Paint()..style = PaintingStyle.fill;

    // عدد بسيط + خفيف
    for (int i = 0; i < 40; i++) {
      final x = rnd.nextDouble() * size.width;
      final baseY = rnd.nextDouble() * size.height;

      // حركة ناعمة لفوق/تحت
      final y = (baseY + sin((t * 2 * pi) + i) * 18) % size.height;

      final r = 0.8 + rnd.nextDouble() * 1.6;
      final o = 0.10 + rnd.nextDouble() * 0.18;

      paint.color = Colors.white.withOpacity(o);
      canvas.drawCircle(Offset(x, y), r, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _ParticlesPainter oldDelegate) =>
      oldDelegate.t != t;
}
