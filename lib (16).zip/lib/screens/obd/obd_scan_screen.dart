import 'package:doctor_car_app/services/obd/obd_elm327_service.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bluetooth_serial/flutter_bluetooth_serial.dart';
import 'package:permission_handler/permission_handler.dart';

class ObdScanScreen extends StatefulWidget {
  const ObdScanScreen({super.key});

  @override
  State<ObdScanScreen> createState() => _ObdScanScreenState();
}

class _ObdScanScreenState extends State<ObdScanScreen> {
  final obd = ObdElm327Service();

  List<BluetoothDevice> paired = [];
  BluetoothDevice? selected;
  bool loading = false;
  List<String> dtc = [];

  @override
  void initState() {
    super.initState();
    _loadPaired();
  }

  Future<void> _askPerms() async {
    await [
      Permission.bluetoothScan,
      Permission.bluetoothConnect,
      Permission.locationWhenInUse,
    ].request();
  }

  Future<void> _loadPaired() async {
    await _askPerms();
    final devices = await FlutterBluetoothSerial.instance.getBondedDevices();
    setState(() => paired = devices);
  }

  Future<void> _connect() async {
    if (selected == null) return;
    setState(() => loading = true);
    try {
      await obd.connect(selected!);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Connected ✅")),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Connect failed: $e")),
      );
    } finally {
      setState(() => loading = false);
    }
  }

  Future<void> _startScan() async {
    setState(() => loading = true);
    try {
      final codes = await obd.readDtcCodes();
      setState(() => dtc = codes);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Scan failed: $e")),
      );
    } finally {
      setState(() => loading = false);
    }
  }

  @override
  void dispose() {
    obd.disconnect();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Scan & Rescue")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            DropdownButtonFormField<BluetoothDevice>(
              value: selected,
              items: paired
                  .map((d) => DropdownMenuItem(
                        value: d,
                        child: Text(d.name ?? d.address),
                      ))
                  .toList(),
              onChanged: (d) => setState(() => selected = d),
              decoration: const InputDecoration(labelText: "Select paired OBD"),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: loading ? null : _connect,
                    child: const Text("Connect"),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton(
                    onPressed: loading ? null : _startScan,
                    child: const Text("Start Scan"),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Expanded(
              child: ListView.builder(
                itemCount: dtc.length,
                itemBuilder: (_, i) => ListTile(
                  title: Text(dtc[i]),
                  subtitle: const Text("TODO: Arabic explanation / severity"),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
