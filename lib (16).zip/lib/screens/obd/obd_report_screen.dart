import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../services/obd/dtc_dictionary.dart';

class ObdReportScreen extends StatelessWidget {
  final bool isArabic;
  final bool isDarkMode;
  final List<String> dtc;
  final int? rpm;
  final int? coolant;

  const ObdReportScreen({
    super.key,
    required this.isArabic,
    required this.isDarkMode,
    required this.dtc,
    required this.rpm,
    required this.coolant,
  });

  Color get bg =>
      isDarkMode ? const Color(0xff0E1320) : const Color(0xffF5F6FA);
  Color get surface => isDarkMode ? const Color(0xff151A2E) : Colors.white;
  Color get textMain => isDarkMode ? Colors.white : const Color(0xff111827);
  Color get textSub => isDarkMode ? Colors.white70 : const Color(0xff6B7280);
  Color get primary => const Color(0xff1F4BA5);

  String _sevLabel(String s) {
    if (s == "high") return isArabic ? "مرتفع" : "High";
    if (s == "medium") return isArabic ? "متوسط" : "Medium";
    return isArabic ? "منخفض" : "Low";
  }

  Color _sevColor(String s) {
    if (s == "high") return Colors.red;
    if (s == "medium") return Colors.orange;
    return Colors.green;
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: isArabic ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        backgroundColor: bg,
        appBar: AppBar(
          elevation: 0,
          backgroundColor: Colors.transparent,
          title: Text(
            isArabic ? "تقرير الفحص" : "Scan Report",
            style: GoogleFonts.cairo(fontWeight: FontWeight.w900),
          ),
        ),
        body: Padding(
          padding: const EdgeInsets.all(16),
          child: ListView(
            children: [
              // Info bar
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: surface,
                  borderRadius: BorderRadius.circular(18),
                ),
                child: Row(
                  children: [
                    Icon(Icons.qr_code_scanner, color: primary),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        isArabic
                            ? "Scan & Rescue - تقرير حقيقي من OBD"
                            : "Scan & Rescue - Real OBD report",
                        style: GoogleFonts.cairo(
                          fontWeight: FontWeight.w900,
                          color: textMain,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 12),

              // Live Data
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: surface,
                  borderRadius: BorderRadius.circular(18),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      isArabic ? "بيانات مباشرة" : "Live Data",
                      style: GoogleFonts.cairo(
                        fontWeight: FontWeight.w900,
                        color: textMain,
                      ),
                    ),
                    const SizedBox(height: 10),
                    _liveRow(
                      icon: Icons.speed,
                      title: isArabic ? "RPM" : "RPM",
                      value: rpm?.toString() ?? (isArabic ? "غير متاح" : "N/A"),
                    ),
                    const SizedBox(height: 8),
                    _liveRow(
                      icon: Icons.thermostat,
                      title: isArabic ? "حرارة الموتور" : "Coolant Temp",
                      value: coolant != null
                          ? "$coolant°C"
                          : (isArabic ? "غير متاح" : "N/A"),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 14),

              // DTC List
              Text(
                isArabic ? "أكواد الأعطال (DTC)" : "DTC Trouble Codes",
                style: GoogleFonts.cairo(
                  fontWeight: FontWeight.w900,
                  fontSize: 16,
                  color: textMain,
                ),
              ),
              const SizedBox(height: 10),

              if (dtc.isEmpty)
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: surface,
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: Text(
                    isArabic
                        ? "✅ لا توجد أكواد أعطال مسجلة الآن"
                        : "✅ No stored DTC codes",
                    style: GoogleFonts.cairo(
                      fontWeight: FontWeight.w900,
                      color: textMain,
                    ),
                  ),
                )
              else
                ...dtc.map((code) {
                  final info = DtcDictionary.get(code);
                  final severity = info?.severity ?? "medium";
                  final sevColor = _sevColor(severity);

                  return Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: surface,
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: sevColor.withOpacity(.25)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 6),
                              decoration: BoxDecoration(
                                color: sevColor.withOpacity(.12),
                                borderRadius: BorderRadius.circular(999),
                                border: Border.all(
                                    color: sevColor.withOpacity(.22)),
                              ),
                              child: Text(
                                _sevLabel(severity),
                                style: GoogleFonts.cairo(
                                  fontWeight: FontWeight.w900,
                                  color: sevColor,
                                ),
                              ),
                            ),
                            const Spacer(),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 12, vertical: 8),
                              decoration: BoxDecoration(
                                color: primary.withOpacity(.10),
                                borderRadius: BorderRadius.circular(14),
                                border:
                                    Border.all(color: primary.withOpacity(.20)),
                              ),
                              child: Text(
                                code,
                                style: GoogleFonts.cairo(
                                  fontWeight: FontWeight.w900,
                                  color: textMain,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Text(
                          info?.titleAr ??
                              (isArabic ? "عطل غير معروف" : "Unknown issue"),
                          style: GoogleFonts.cairo(
                            fontWeight: FontWeight.w900,
                            color: textMain,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          info?.descAr ??
                              (isArabic
                                  ? "لا يوجد تفسير متاح لهذا الكود حالياً."
                                  : "No description available."),
                          style: GoogleFonts.cairo(
                            fontWeight: FontWeight.w700,
                            color: textSub,
                          ),
                        ),
                        if (info != null && info.actionsAr.isNotEmpty) ...[
                          const SizedBox(height: 10),
                          Text(
                            isArabic ? "إصلاحات مقترحة:" : "Suggested fixes:",
                            style: GoogleFonts.cairo(
                              fontWeight: FontWeight.w900,
                              color: textMain,
                            ),
                          ),
                          const SizedBox(height: 6),
                          ...info.actionsAr.map(
                            (a) => Padding(
                              padding: const EdgeInsets.only(bottom: 4),
                              child: Text(
                                "• $a",
                                style: GoogleFonts.cairo(
                                  fontWeight: FontWeight.w700,
                                  color: textSub,
                                ),
                              ),
                            ),
                          ),
                        ]
                      ],
                    ),
                  );
                }).toList(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _liveRow({
    required IconData icon,
    required String title,
    required String value,
  }) {
    return Row(
      children: [
        Icon(icon, color: primary),
        const SizedBox(width: 10),
        Expanded(
          child: Text(
            title,
            style: GoogleFonts.cairo(
              fontWeight: FontWeight.w900,
              color: textMain,
            ),
          ),
        ),
        Text(
          value,
          style: GoogleFonts.cairo(
            fontWeight: FontWeight.w900,
            color: textMain,
          ),
        ),
      ],
    );
  }
}
