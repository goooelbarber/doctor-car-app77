import 'package:flutter/material.dart';
import 'package:flutter_bluetooth_serial/flutter_bluetooth_serial.dart';
import 'package:permission_handler/permission_handler.dart';

import '../../services/obd/obd_elm327_service.dart';
import '../../services/obd/dtc_dictionary.dart';
// ignore: unused_import
import 'obd_report_screen.dart';

class ObdScanFlowScreen extends StatefulWidget {
  final bool isArabic;
  final bool isDarkMode;

  const ObdScanFlowScreen({
    super.key,
    required this.isArabic,
    required this.isDarkMode,
  });

  @override
  State<ObdScanFlowScreen> createState() => _ObdScanFlowScreenState();
}

class _ObdScanFlowScreenState extends State<ObdScanFlowScreen> {
  final obd = ObdElm327Service();

  List<BluetoothDevice> paired = [];
  BluetoothDevice? selected;

  bool connecting = false;
  bool scanning = false;

  List<String> dtc = [];
  int? rpm;
  int? coolant;

  Future<void> _askPerms() async {
    await [
      Permission.bluetoothScan,
      Permission.bluetoothConnect,
      Permission.locationWhenInUse,
    ].request();
  }

  @override
  void initState() {
    super.initState();
    _loadPaired();
  }

  Future<void> _loadPaired() async {
    await _askPerms();
    final devices = await FlutterBluetoothSerial.instance.getBondedDevices();
    if (!mounted) return;
    setState(() => paired = devices);
  }

  Future<void> _connect() async {
    if (selected == null) return;

    setState(() => connecting = true);
    try {
      await obd.connect(selected!);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text(widget.isArabic ? "تم الاتصال ✅" : "Connected ✅")),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Connect failed: $e")),
      );
    } finally {
      if (mounted) setState(() => connecting = false);
    }
  }

  Future<void> _startScan() async {
    if (!obd.isConnected) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text(
                widget.isArabic ? "اتصل بالـ OBD أولاً" : "Connect first")),
      );
      return;
    }

    setState(() => scanning = true);
    try {
      final codes = await obd.readDtcCodes();
      final r = await obd.readRpm();
      final t = await obd.readCoolantTemp();

      if (!mounted) return;

      setState(() {
        dtc = codes;
        rpm = r;
        coolant = t;
      });

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => ObdScanFlowScreen(
            isArabic: widget.isArabic,
            isDarkMode: widget.isDarkMode,
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Scan failed: $e")),
      );
    } finally {
      if (mounted) setState(() => scanning = false);
    }
  }

  @override
  void dispose() {
    obd.disconnect();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final busy = connecting || scanning;

    return Scaffold(
      appBar: AppBar(
          title: Text(widget.isArabic ? "Scan & Rescue" : "Scan & Rescue")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            DropdownButtonFormField<BluetoothDevice>(
              value: selected,
              items: paired
                  .map((d) => DropdownMenuItem(
                        value: d,
                        child: Text(d.name ?? d.address),
                      ))
                  .toList(),
              onChanged: busy ? null : (d) => setState(() => selected = d),
              decoration: InputDecoration(
                labelText: widget.isArabic
                    ? "اختر جهاز OBD (Paired)"
                    : "Select paired OBD",
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: busy ? null : _connect,
                    child: Text(connecting
                        ? (widget.isArabic
                            ? "جاري الاتصال..."
                            : "Connecting...")
                        : (widget.isArabic ? "اتصال" : "Connect")),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton(
                    onPressed: busy ? null : _startScan,
                    child: Text(scanning
                        ? (widget.isArabic ? "جاري الفحص..." : "Scanning...")
                        : (widget.isArabic ? "ابدأ الفحص" : "Start Scan")),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Expanded(
              child: ListView(
                children: [
                  if (dtc.isNotEmpty) ...[
                    Text(widget.isArabic
                        ? "آخر أكواد مقروءة:"
                        : "Last read codes:"),
                    const SizedBox(height: 8),
                    ...dtc.map((c) {
                      final info = DtcDictionary.get(c);
                      return ListTile(
                        title: Text(c),
                        subtitle: Text(info?.titleAr ??
                            (widget.isArabic ? "غير معروف" : "Unknown")),
                      );
                    }),
                  ] else
                    Text(widget.isArabic
                        ? "قم بالاتصال ثم ابدأ الفحص."
                        : "Connect and start scan."),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
