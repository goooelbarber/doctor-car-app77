import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../services/socket_service.dart';

class TechnicianTrackingScreen extends StatefulWidget {
  final String orderId;
  final String userId; // ✅ لازم

  const TechnicianTrackingScreen({
    super.key,
    required this.orderId,
    required this.userId,
  });

  @override
  State<TechnicianTrackingScreen> createState() =>
      _TechnicianTrackingScreenState();
}

class _TechnicianTrackingScreenState extends State<TechnicianTrackingScreen> {
  GoogleMapController? _mapController;
  final SocketService socketService = SocketService();

  LatLng techPos = const LatLng(30.05, 31.23);
  bool socketConnected = false;

  @override
  void initState() {
    super.initState();

    // ✅ بدل connect()
    socketService.initUser(userId: widget.userId);

    socketService.onConnectionChanged((connected) {
      if (!mounted) return;
      setState(() => socketConnected = connected);

      // ✅ مهم: بعد الاتصال انضم لغرفة الطلب (احتياط لو socket اتصل متأخر)
      if (connected) {
        socketService.joinOrderRoom(widget.orderId);
      }
    });

    // 🚪 انضم لغرفة الطلب
    socketService.joinOrderRoom(widget.orderId);

    // 📡 استقبل تحديثات موقع الفني
    socketService.onTechnicianLocation((lat, lng) {
      if (!mounted) return;

      final newPos = LatLng(lat, lng);

      setState(() => techPos = newPos);

      _mapController?.animateCamera(
        CameraUpdate.newLatLng(newPos),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("تتبع الفني"),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: Icon(
              socketConnected ? Icons.wifi : Icons.wifi_off,
              color: socketConnected ? Colors.green : Colors.red,
            ),
          )
        ],
      ),
      body: GoogleMap(
        initialCameraPosition: CameraPosition(
          target: techPos,
          zoom: 15,
        ),
        markers: {
          Marker(
            markerId: const MarkerId("tech"),
            position: techPos,
            icon: BitmapDescriptor.defaultMarkerWithHue(
              BitmapDescriptor.hueOrange,
            ),
          ),
        },
        onMapCreated: (controller) => _mapController = controller,
      ),
    );
  }
}
