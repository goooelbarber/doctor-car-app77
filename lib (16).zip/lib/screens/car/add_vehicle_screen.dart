// 📁 lib/screens/car/add_vehicle_screen.dart

import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:doctor_car_app/services/api_service.dart';

class AddVehicleScreen extends StatefulWidget {
  const AddVehicleScreen({super.key});

  @override
  State<AddVehicleScreen> createState() => _AddVehicleScreenState();
}

class _AddVehicleScreenState extends State<AddVehicleScreen> {
  final _formKey = GlobalKey<FormState>();

  final plateCtrl = TextEditingController();
  final chassisCtrl = TextEditingController();

  // ✅ نخليها dynamic عشان لو السيرفر بيرجع Map فيه name/id
  List<dynamic> brands = [];

  List<String> models = [];
  List<String> years = [];

  String? selectedBrand;
  String? selectedModel;
  String? selectedYear;
  String? selectedFuel;
  String? selectedCondition;
  String? selectedColor;

  bool loadingBrands = false;
  bool loadingModels = false;
  bool loadingYears = false;
  bool saving = false;

  final fuelTypes = const ["بنزين", "ديزل", "هايبرد", "كهرباء"];
  final conditions = const ["ممتازة", "جيدة جدًا", "جيدة", "تحتاج صيانة"];
  final colors = const ["أبيض", "أسود", "فضي", "رمادي", "أزرق", "أحمر", "ذهبي"];

  @override
  void initState() {
    super.initState();
    _loadBrands();
  }

  @override
  void dispose() {
    plateCtrl.dispose();
    chassisCtrl.dispose();
    super.dispose();
  }

  // ============================
  // 🔵 Load Brands
  // ============================
  Future<void> _loadBrands() async {
    if (!mounted) return;
    setState(() => loadingBrands = true);

    try {
      final list = await ApiService.getCarBrands();

      // ✅ يدعم حالتين:
      // 1) لو ApiService بيرجع List<Map> => نخزنها زي ما هي
      // 2) لو بيرجع List<String> => نحولها لمابس فيها name
      // ignore: unnecessary_type_check
      if (list is List) {
        if (list.isNotEmpty && list.first is Map) {
          brands = list;
        } else {
          brands = list.map((e) => {"name": e.toString()}).toList();
        }
      } else {
        brands = [];
      }
    } catch (_) {
      brands = [];
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("تعذر تحميل الماركات")),
      );
    } finally {
      if (!mounted) return;
      setState(() => loadingBrands = false);
    }
  }

  // ============================
  // 🟩 Load Models
  // ============================
  Future<void> _loadModels() async {
    if (selectedBrand == null || selectedBrand!.isEmpty) return;

    if (!mounted) return;
    setState(() {
      loadingModels = true;
      models = [];
      years = [];
      selectedModel = null;
      selectedYear = null;
    });

    try {
      final list = await ApiService.getModelsByBrand(selectedBrand!);

      // ✅ لو رجعت dynamic، احولها لـ String
      models = List<String>.from(list.map((e) => e.toString()));
    } catch (_) {
      models = [];
    } finally {
      if (!mounted) return;
      setState(() => loadingModels = false);
    }
  }

  // ============================
  // 🟧 Load Years
  // ============================
  Future<void> _loadYears() async {
    if (selectedBrand == null ||
        selectedBrand!.isEmpty ||
        selectedModel == null ||
        selectedModel!.isEmpty) return;

    if (!mounted) return;
    setState(() {
      loadingYears = true;
      years = [];
      selectedYear = null;
    });

    try {
      final list = await ApiService.getYears(selectedBrand!, selectedModel!);
      years = List<String>.from(list.map((e) => e.toString()));
    } catch (_) {
      years = [];
    } finally {
      if (!mounted) return;
      setState(() => loadingYears = false);
    }
  }

  // ============================
  // 💾 Save
  // ============================
  Future<void> _saveVehicle() async {
    if (!_formKey.currentState!.validate()) return;

    if (selectedBrand == null ||
        selectedModel == null ||
        selectedYear == null ||
        selectedFuel == null ||
        selectedCondition == null ||
        selectedColor == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("⚠️ برجاء استكمال كل البيانات"),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    if (!mounted) return;
    setState(() => saving = true);

    try {
      final res = await ApiService.addVehicle(
        brand: selectedBrand!,
        model: selectedModel!,
        fuel: selectedFuel!,
        condition: selectedCondition!,
        plateNumber: plateCtrl.text.trim(),
        year: selectedYear!,
        color: selectedColor!,
        chassisNumber: chassisCtrl.text.trim(),
      );

      if (!mounted) return;

      if (res["error"] == true || res["success"] == false) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(res["message"]?.toString() ?? "فشل إضافة المركبة"),
            backgroundColor: Colors.red,
          ),
        );
        return;
      }

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("🚗 تم إضافة السيارة"),
          backgroundColor: Colors.green,
        ),
      );

      Navigator.pop(context, true);
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("تعذر الاتصال بالسيرفر"),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      if (!mounted) return;
      setState(() => saving = false);
    }
  }

  // ============================
  // UI Helpers
  // ============================
  InputDecoration _inputStyle(String hint, IconData icon) {
    return InputDecoration(
      hintText: hint,
      hintStyle: const TextStyle(color: Colors.white54),
      prefixIcon: Icon(icon, color: Colors.amber),
      filled: true,
      // ignore: deprecated_member_use
      fillColor: Colors.white.withOpacity(.12),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        // ignore: deprecated_member_use
        borderSide: BorderSide(color: Colors.white.withOpacity(.2)),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        // ignore: deprecated_member_use
        borderSide: BorderSide(color: Colors.white.withOpacity(.2)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(color: Colors.amber, width: 1.4),
      ),
    );
  }

  Widget _dropdown({
    required String label,
    required IconData icon,
    required String? value,
    required List<String> items,
    required bool isLoading,
    required void Function(String?) onChanged,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Text(label, style: const TextStyle(color: Colors.white, fontSize: 16)),
        const SizedBox(height: 6),
        DropdownButtonFormField<String>(
          value: (value != null && items.contains(value)) ? value : null,
          dropdownColor: Colors.black87,
          decoration: _inputStyle(label, icon),
          style: const TextStyle(color: Colors.white),
          items: isLoading
              ? const []
              : items
                  .map((e) => DropdownMenuItem(
                        value: e,
                        child: Text(e,
                            style: const TextStyle(color: Colors.white)),
                      ))
                  .toList(),
          onChanged: isLoading ? null : onChanged,
          validator: (v) => v == null ? "مطلوب" : null,
        ),
        const SizedBox(height: 14),
      ],
    );
  }

  Widget _textField({
    required String label,
    required IconData icon,
    required TextEditingController controller,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Text(label, style: const TextStyle(color: Colors.white, fontSize: 16)),
        const SizedBox(height: 6),
        TextFormField(
          controller: controller,
          textAlign: TextAlign.right,
          style: const TextStyle(color: Colors.white),
          decoration: _inputStyle(label, icon),
          validator: (v) => (v == null || v.trim().isEmpty) ? "مطلوب" : null,
        ),
        const SizedBox(height: 14),
      ],
    );
  }

  // ============================
  // UI
  // ============================
  @override
  Widget build(BuildContext context) {
    // ✅ حوّل brands(dynamic) لـ List<String> للعرض
    final brandNames = brands
        .map((e) => (e is Map ? e["name"] : e).toString())
        .where((x) => x.trim().isNotEmpty)
        .toList();

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text("إضافة مركبة", style: TextStyle(color: Colors.white)),
        centerTitle: true,
      ),
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Color(0xFF0F2027),
                  Color(0xFF203A43),
                  Color(0xFF2C5364)
                ],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),
          SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(26),
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
                child: Container(
                  padding: const EdgeInsets.all(22),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(.08),
                    borderRadius: BorderRadius.circular(26),
                    border: Border.all(color: Colors.white.withOpacity(.15)),
                  ),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      children: [
                        _dropdown(
                          label: "الماركة",
                          icon: FontAwesomeIcons.car,
                          value: selectedBrand,
                          items: brandNames, // ✅ هنا التصحيح
                          isLoading: loadingBrands,
                          onChanged: (v) async {
                            selectedBrand = v;
                            selectedModel = null;
                            selectedYear = null;
                            await _loadModels();
                            if (mounted) setState(() {});
                          },
                        ),
                        if (selectedBrand != null)
                          _dropdown(
                            label: "الموديل",
                            icon: FontAwesomeIcons.gear,
                            value: selectedModel,
                            items: models,
                            isLoading: loadingModels,
                            onChanged: (v) async {
                              selectedModel = v;
                              selectedYear = null;
                              await _loadYears();
                              if (mounted) setState(() {});
                            },
                          ),
                        if (selectedModel != null)
                          _dropdown(
                            label: "سنة الصنع",
                            icon: FontAwesomeIcons.calendar,
                            value: selectedYear,
                            items: years,
                            isLoading: loadingYears,
                            onChanged: (v) => setState(() => selectedYear = v),
                          ),
                        _dropdown(
                          label: "نوع الوقود",
                          icon: FontAwesomeIcons.gasPump,
                          value: selectedFuel,
                          items: fuelTypes,
                          isLoading: false,
                          onChanged: (v) => setState(() => selectedFuel = v),
                        ),
                        _dropdown(
                          label: "الحالة",
                          icon: FontAwesomeIcons.screwdriverWrench,
                          value: selectedCondition,
                          items: conditions,
                          isLoading: false,
                          onChanged: (v) =>
                              setState(() => selectedCondition = v),
                        ),
                        _dropdown(
                          label: "اللون",
                          icon: FontAwesomeIcons.palette,
                          value: selectedColor,
                          items: colors,
                          isLoading: false,
                          onChanged: (v) => setState(() => selectedColor = v),
                        ),
                        _textField(
                          label: "رقم اللوحة",
                          icon: FontAwesomeIcons.idCard,
                          controller: plateCtrl,
                        ),
                        _textField(
                          label: "رقم الهيكل (الشاصي)",
                          icon: FontAwesomeIcons.carBurst,
                          controller: chassisCtrl,
                        ),
                        const SizedBox(height: 16),
                        SizedBox(
                          width: double.infinity,
                          height: 55,
                          child: ElevatedButton(
                            onPressed: saving ? null : _saveVehicle,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.amber,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(18),
                              ),
                            ),
                            child: Text(
                              saving ? "جاري الحفظ..." : "إضافة المركبة",
                              style: const TextStyle(
                                color: Colors.black,
                                fontSize: 18,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
