// 📁 lib/screens/role_selection_screen.dart
// ignore_for_file: use_build_context_synchronously

import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:doctor_car_app/core/app_routes.dart';
import 'package:doctor_car_app/screens/login_screen.dart';

class RoleSelectionScreen extends StatefulWidget {
  const RoleSelectionScreen({super.key});

  @override
  State<RoleSelectionScreen> createState() => _RoleSelectionScreenState();
}

class _RoleSelectionScreenState extends State<RoleSelectionScreen>
    with SingleTickerProviderStateMixin {
  String? selectedRole;

  late final AnimationController _controller;
  late final Animation<double> _fade;
  late final Animation<double> _scale;

  // ✅ مفاتيح التخزين (نفس اللي في Login / Splash)
  static const String _kSelectedRoleKey = 'selectedRole';
  static const String _kIsLoggedInKey = 'isLoggedIn';
  static const String _kTokenKey = 'token';
  static const String _kUserIdKey = 'userId';

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 650),
    )..forward();

    _fade = CurvedAnimation(parent: _controller, curve: Curves.easeOut);
    _scale = Tween<double>(begin: .98, end: 1).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOutBack),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  // ============================================================
  // ✅ Save Role + Reset Session + Navigate
  // ============================================================
  Future<void> _continue() async {
    if (selectedRole == null) return;

    HapticFeedback.lightImpact();
    final prefs = await SharedPreferences.getInstance();

    // ✅ خزّن الدور
    await prefs.setString(_kSelectedRoleKey, selectedRole!);

    // ✅ امسح أي Login قديم (مهم جدًا)
    await prefs.remove(_kIsLoggedInKey);
    await prefs.remove(_kTokenKey);
    await prefs.remove(_kUserIdKey);

    if (!mounted) return;

    Navigator.of(context).pushReplacement(
      AppRoutes.fadeScale(const LoginScreen()),
    );
  }

  void _select(String role) {
    HapticFeedback.selectionClick();
    setState(() => selectedRole = role);
  }

  // ============================================================
  // 🎨 Background
  // ============================================================
  Widget _background() {
    return Stack(
      children: [
        Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Color(0xFF051937),
                Color(0xFF003D73),
                Color(0xFF001B3A),
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
        Positioned(
          top: -120,
          left: -80,
          child: _blurBlob(
            size: 260,
            color: Colors.amber.withOpacity(.22),
          ),
        ),
        Positioned(
          bottom: -140,
          right: -80,
          child: _blurBlob(
            size: 320,
            color: Colors.cyanAccent.withOpacity(.16),
          ),
        ),
        Positioned(
          top: 120,
          right: -70,
          child: _blurBlob(
            size: 200,
            color: Colors.white.withOpacity(.10),
          ),
        ),
        Container(color: Colors.black.withOpacity(.05)),
      ],
    );
  }

  Widget _blurBlob({required double size, required Color color}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(size),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 40, sigmaY: 40),
        child: Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(size),
          ),
        ),
      ),
    );
  }

  Widget _glassCard({required Widget child}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(28),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(.10),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: Colors.white.withOpacity(.16)),
            boxShadow: [
              BoxShadow(
                blurRadius: 32,
                color: Colors.black.withOpacity(.28),
                offset: const Offset(0, 18),
              ),
            ],
          ),
          child: child,
        ),
      ),
    );
  }

  Widget _roleCard({
    required String role,
    required String title,
    required String subtitle,
    required IconData icon,
    required String badge,
  }) {
    final bool isActive = selectedRole == role;

    return InkWell(
      borderRadius: BorderRadius.circular(22),
      onTap: () => _select(role),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 260),
        curve: Curves.easeOut,
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          color: isActive
              ? Colors.white.withOpacity(.16)
              : Colors.white.withOpacity(.10),
          border: Border.all(
            color: isActive
                ? Colors.amber.withOpacity(.75)
                : Colors.white.withOpacity(.14),
            width: isActive ? 1.4 : 1.0,
          ),
        ),
        child: Row(
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 260),
              width: 54,
              height: 54,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: isActive
                      ? const [Color(0xFFFFD54F), Color(0xFFFFB300)]
                      : [
                          Colors.white.withOpacity(.14),
                          Colors.white.withOpacity(.06),
                        ],
                ),
              ),
              child: Icon(
                icon,
                color: isActive ? const Color(0xFF0B1B2B) : Colors.white,
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: const TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.w900,
                          color: Colors.white)),
                  const SizedBox(height: 6),
                  Text(subtitle,
                      style: TextStyle(
                          fontSize: 13, color: Colors.white.withOpacity(.72))),
                ],
              ),
            ),
            Icon(
              isActive ? Icons.check_circle : Icons.circle_outlined,
              color: isActive ? Colors.greenAccent : Colors.white38,
            )
          ],
        ),
      ),
    );
  }

  // ============================================================
  // UI
  // ============================================================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          _background(),
          SafeArea(
            child: FadeTransition(
              opacity: _fade,
              child: ScaleTransition(
                scale: _scale,
                child: Column(
                  children: [
                    Expanded(
                      child: SingleChildScrollView(
                        padding: const EdgeInsets.all(18),
                        child: _glassCard(
                          child: Column(
                            children: [
                              _roleCard(
                                role: "rider",
                                title: "راكب",
                                subtitle: "اطلب ميكانيكي أو خدمة طريق بسهولة.",
                                icon: Icons.person,
                                badge: "طلب سريع",
                              ),
                              const SizedBox(height: 14),
                              _roleCard(
                                role: "driver",
                                title: "سائق / فني",
                                subtitle: "استقبل الطلبات وابدأ العمل فورًا.",
                                icon: Icons.handyman,
                                badge: "وضع العمل",
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(18),
                      child: SizedBox(
                        width: double.infinity,
                        height: 56,
                        child: ElevatedButton(
                          onPressed: selectedRole == null ? null : _continue,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.amber,
                            foregroundColor: const Color(0xFF0B1B2B),
                          ),
                          child: const Text(
                            "متابعة",
                            style: TextStyle(
                                fontSize: 16, fontWeight: FontWeight.w900),
                          ),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
