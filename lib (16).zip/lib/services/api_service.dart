import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

class ApiService {
  // ============================================================
  // 🌍 SERVER BASE URL (SMART & STABLE)
  // ============================================================
  static const int _port = 5555;

  // ✅ عدّل IP ده لو السيرفر على جهاز مختلف أو اتغير
  static const String _lanIP = "192.168.1.11";

  // ✅ لو السيرفر شغال على نفس جهازك (Windows/Mac) والموبايل على نفس الشبكة
  // خليه LAN IP، لو على جهاز مختلف عدّل _lanIP

  static String get baseUrl {
    // ✅ Flutter Web
    if (kIsWeb) {
      return "http://localhost:$_port/api";
      // لو عايز web يضرب LAN بدل localhost:
      // return "http://$_lanIP:$_port/api";
    }

    // ✅ Mobile/Desktop (غير web)
    // Android Emulator
    if (defaultTargetPlatform == TargetPlatform.android) {
      // لو Emulator: استخدم 10.0.2.2
      // لو جهاز حقيقي: استخدم LAN IP
      // مفيش طريقة 100% معرفة emulator من غير plugins
      // فخلينا نستخدم LAN IP كـ default "أكثر أمانًا" للموبايل الحقيقي
      // ولو عايز Emulator: بدّل في المتغير ده
      const bool isAndroidEmulator = true;
      return isAndroidEmulator
          ? "http://10.0.2.2:$_port/api"
          // ignore: dead_code
          : "http://$_lanIP:$_port/api";
    }

    // iOS Simulator غالبًا يشتغل مع 127.0.0.1 لو السيرفر على نفس الماك
    if (defaultTargetPlatform == TargetPlatform.iOS) {
      // لو بتجرّب على Simulator على نفس الجهاز:
      // return "http://127.0.0.1:$_port/api";
      // لو جهاز حقيقي/شبكة:
      return "http://$_lanIP:$_port/api";
    }

    // Desktop (Windows/macOS/Linux) غالبًا localhost
    return "http://localhost:$_port/api";
  }

  // ============================================================
  // ⏱ HTTP TIMEOUT
  // ============================================================
  static const Duration _timeout = Duration(seconds: 18);

  // ============================================================
  // HEADERS HELPERS
  // ============================================================
  static Map<String, String> _jsonHeaders() => const {
        "Content-Type": "application/json",
        "Accept": "application/json",
      };

  static Future<Map<String, String>> _authHeaders() async {
    final token = await getToken();
    return {
      ..._jsonHeaders(),
      if (token != null && token.isNotEmpty) "Authorization": "Bearer $token",
    };
  }

  static dynamic _decodeBody(http.Response res) {
    // بعض الأحيان السيرفر يرجع نص/HTML (error page)
    // هنحاول JSON وبعدين fallback
    try {
      return jsonDecode(res.body);
    } catch (_) {
      final body = res.body;
      final preview = body.length > 250 ? body.substring(0, 250) : body;
      return {
        "error": true,
        "message": "رد غير JSON من السيرفر",
        "raw": preview,
      };
    }
  }

  static Map<String, dynamic> _normalizeError(
    http.Response res,
    dynamic decoded, {
    String fallback = "حدث خطأ",
  }) {
    String msg = fallback;

    if (decoded is Map) {
      if (decoded["message"] != null)
        msg = decoded["message"].toString();
      else if (decoded["error"] == true && decoded["raw"] != null) {
        msg = decoded["raw"].toString();
      }
    }

    return {
      "error": true,
      "success": false,
      "statusCode": res.statusCode,
      "message": msg,
    };
  }

  // ============================================================
  // TOKEN HELPERS
  // ============================================================
  static Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString("token");
  }

  // ============================================================
  // 🔌 اختبار الاتصال ✅
  // ============================================================
  static Future<Map<String, dynamic>> checkConnection() async {
    try {
      final res =
          await http.get(Uri.parse("$baseUrl/users/")).timeout(_timeout);

      final decoded = _decodeBody(res);
      if (res.statusCode == 200) {
        return {"success": true, "data": decoded};
      }
      return _normalizeError(res, decoded, fallback: "Health check failed");
    } on TimeoutException {
      return {"error": true, "message": "السيرفر مش بيرد (Timeout)"};
    } catch (_) {
      return {"error": true, "message": "تعذر الاتصال بالسيرفر"};
    }
  }

  // ============================================================
  // 🔐 تسجيل الدخول (Email + Password)
  // ============================================================
  static Future<Map<String, dynamic>> login(
      String email, String password) async {
    try {
      final res = await http
          .post(
            Uri.parse("$baseUrl/users/login"),
            headers: _jsonHeaders(),
            body: jsonEncode({
              "email": email.trim(),
              "password": password.trim(),
            }),
          )
          .timeout(_timeout);

      final decoded = _decodeBody(res);

      if (res.statusCode == 200 && decoded is Map<String, dynamic>) {
        if (decoded["success"] == false || decoded["error"] == true) {
          return {"error": true, "message": decoded["message"] ?? "فشل الدخول"};
        }
        return decoded;
      }

      return _normalizeError(res, decoded, fallback: "بيانات غير صحيحة");
    } on TimeoutException {
      return {"error": true, "message": "السيرفر مش بيرد (Timeout)"};
    } catch (_) {
      return {"error": true, "message": "تعذر الاتصال بالسيرفر"};
    }
  }

  // ============================================================
  // ✅ تسجيل حساب (Register) | role: rider/driver
  // ============================================================
  static Future<Map<String, dynamic>> register(
    String name,
    String email,
    String password,
    String role,
  ) async {
    try {
      final res = await http
          .post(
            Uri.parse("$baseUrl/users/register"),
            headers: _jsonHeaders(),
            body: jsonEncode({
              "name": name.trim(),
              "email": email.trim(),
              "password": password.trim(),
              "role": role.trim(),
            }),
          )
          .timeout(_timeout);

      final decoded = _decodeBody(res);

      if ((res.statusCode == 201 || res.statusCode == 200) &&
          decoded is Map<String, dynamic>) {
        if (decoded["success"] == false || decoded["error"] == true) {
          return {
            "error": true,
            "message": decoded["message"] ?? "فشل إنشاء الحساب",
          };
        }
        return decoded;
      }

      return _normalizeError(res, decoded, fallback: "فشل إنشاء الحساب");
    } on TimeoutException {
      return {"error": true, "message": "السيرفر مش بيرد (Timeout)"};
    } catch (_) {
      return {"error": true, "message": "تعذر الاتصال بالسيرفر"};
    }
  }

  // ============================================================
  // ✅ Google Login (REAL)
  // POST /api/users/google
  // Body: { idToken, role? }
  // ============================================================
  static Future<Map<String, dynamic>> googleLogin(
    String idToken, {
    String? role,
  }) async {
    try {
      final res = await http
          .post(
            Uri.parse("$baseUrl/users/google"),
            headers: _jsonHeaders(),
            body: jsonEncode({
              "idToken": idToken,
              if (role != null && role.trim().isNotEmpty) "role": role.trim(),
            }),
          )
          .timeout(_timeout);

      final decoded = _decodeBody(res);

      // ✅ رجّع رسالة السيرفر حتى لو status مش 200 (مهم جدًا للتشخيص)
      if (decoded is Map<String, dynamic>) {
        if (res.statusCode == 200) {
          if (decoded["success"] == false || decoded["error"] == true) {
            return {
              "error": true,
              "message": decoded["message"] ?? "فشل تسجيل الدخول بجوجل",
            };
          }
          return decoded;
        }

        return _normalizeError(res, decoded,
            fallback: "فشل تسجيل الدخول بجوجل");
      }

      return {
        "error": true,
        "success": false,
        "statusCode": res.statusCode,
        "message": "رد غير متوقع من السيرفر",
      };
    } on TimeoutException {
      return {"error": true, "message": "السيرفر مش بيرد (Timeout)"};
    } catch (_) {
      return {"error": true, "message": "تعذر الاتصال بالسيرفر"};
    }
  }

  // ============================================================
  // 🚘 جلب سيارات المستخدم (Token من Storage تلقائي)
  // ============================================================
  static Future<List> getVehicles() async {
    try {
      final headers = await _authHeaders();

      final res = await http
          .get(Uri.parse("$baseUrl/vehicles/my-vehicles"), headers: headers)
          .timeout(_timeout);

      final data = _decodeBody(res);

      if (res.statusCode == 200) {
        if (data is List) return data;
        if (data is Map && data["vehicles"] != null) return data["vehicles"];
      }

      return [];
    } catch (e) {
      debugPrint("❌ getVehicles error: $e");
      return [];
    }
  }

  // ============================================================
  // 🚘 إضافة مركبة
  // ============================================================
  static Future<Map<String, dynamic>> addVehicle({
    required String brand,
    required String model,
    required String fuel,
    required String condition,
    required String plateNumber,
    required String year,
    required String color,
    required String chassisNumber,
  }) async {
    try {
      final headers = await _authHeaders();

      final res = await http
          .post(
            Uri.parse("$baseUrl/vehicles"),
            headers: headers,
            body: jsonEncode({
              "brand": brand,
              "model": model,
              "fuel": fuel,
              "condition": condition,
              "plateNumber": plateNumber,
              "year": year,
              "color": color,
              "chassisNumber": chassisNumber,
            }),
          )
          .timeout(_timeout);

      final decoded = _decodeBody(res);

      if (res.statusCode == 201 && decoded is Map<String, dynamic>) {
        return decoded;
      }

      return _normalizeError(res, decoded, fallback: "فشل إضافة المركبة");
    } on TimeoutException {
      return {"error": true, "message": "السيرفر مش بيرد (Timeout)"};
    } catch (_) {
      return {"error": true, "message": "تعذر الاتصال بالسيرفر"};
    }
  }

  // ============================================================
  // ✏ تعديل مركبة
  // ============================================================
  static Future<Map<String, dynamic>> updateVehicle({
    required String vehicleId,
    String? brand,
    String? model,
    String? fuel,
    String? condition,
    String? plateNumber,
    String? year,
    String? color,
    String? chassisNumber,
  }) async {
    try {
      final headers = await _authHeaders();

      final res = await http
          .put(
            Uri.parse("$baseUrl/vehicles/$vehicleId"),
            headers: headers,
            body: jsonEncode({
              if (brand != null) "brand": brand,
              if (model != null) "model": model,
              if (fuel != null) "fuel": fuel,
              if (condition != null) "condition": condition,
              if (plateNumber != null) "plateNumber": plateNumber,
              if (year != null) "year": year,
              if (color != null) "color": color,
              if (chassisNumber != null) "chassisNumber": chassisNumber,
            }),
          )
          .timeout(_timeout);

      final decoded = _decodeBody(res);

      if (res.statusCode == 200 && decoded is Map<String, dynamic>) {
        return decoded;
      }

      return _normalizeError(res, decoded, fallback: "فشل تعديل المركبة");
    } on TimeoutException {
      return {"error": true, "message": "السيرفر مش بيرد (Timeout)"};
    } catch (_) {
      return {"error": true, "message": "تعذر الاتصال بالسيرفر"};
    }
  }

  // ============================================================
  // ❌ حذف مركبة
  // ============================================================
  static Future<Map<String, dynamic>> deleteVehicle(String id) async {
    try {
      final headers = await _authHeaders();

      final res = await http
          .delete(Uri.parse("$baseUrl/vehicles/$id"), headers: headers)
          .timeout(_timeout);

      if (res.statusCode == 200) return {"success": true};

      final decoded = _decodeBody(res);
      return _normalizeError(res, decoded, fallback: "فشل حذف المركبة");
    } on TimeoutException {
      return {"error": true, "message": "السيرفر مش بيرد (Timeout)"};
    } catch (_) {
      return {"error": true, "message": "تعذر الاتصال بالسيرفر"};
    }
  }

  // ============================================================
  // 🚘 Brands / Models / Years
  // ============================================================
  static Future<List<String>> getCarBrands() async {
    try {
      final res = await http
          .get(Uri.parse("$baseUrl/car-types/brands"))
          .timeout(_timeout);

      final decoded = _decodeBody(res);
      if (res.statusCode == 200 && decoded is List) {
        return decoded.map((e) => e["name"].toString()).toList();
      }
      return [];
    } catch (_) {
      return [];
    }
  }

  static Future<List<String>> getModelsByBrand(String brand) async {
    try {
      final br = brand.toLowerCase().trim();
      final res = await http
          .get(Uri.parse("$baseUrl/car-types/models/$br"))
          .timeout(_timeout);

      final decoded = _decodeBody(res);
      if (res.statusCode == 200 && decoded is List) {
        return List<String>.from(decoded);
      }
      return [];
    } catch (_) {
      return [];
    }
  }

  static Future<List<String>> getYears(String brand, String model) async {
    try {
      final res = await http
          .get(Uri.parse(
              "$baseUrl/car-types/years/${brand.toLowerCase()}/${model.toLowerCase()}"))
          .timeout(_timeout);

      final decoded = _decodeBody(res);
      if (res.statusCode == 200 && decoded is List) {
        return List<String>.from(decoded);
      }
      return [];
    } catch (_) {
      return [];
    }
  }

  // ============================================================
  // 🔧 Add maintenance
  // ============================================================
  static Future<Map<String, dynamic>> addMaintenance({
    required String vehicleId,
    required String type,
    required String km,
    required String cost,
    required String notes,
    required String date,
  }) async {
    try {
      final headers = await _authHeaders();

      final res = await http
          .post(
            Uri.parse("$baseUrl/maintenance/$vehicleId"),
            headers: headers,
            body: jsonEncode({
              "type": type,
              "km": km,
              "cost": cost,
              "notes": notes,
              "date": date,
            }),
          )
          .timeout(_timeout);

      final decoded = _decodeBody(res);
      if (decoded is Map<String, dynamic>) return decoded;

      return {"error": true, "message": "فشل إضافة الصيانة"};
    } on TimeoutException {
      return {"error": true, "message": "السيرفر مش بيرد (Timeout)"};
    } catch (_) {
      return {"error": true, "message": "تعذر الاتصال بالسيرفر"};
    }
  }

  // ============================================================
  // 🟣 Get maintenance history
  // ============================================================
  static Future<List> getMaintenanceHistory(String vehicleId) async {
    try {
      final headers = await _authHeaders();

      final res = await http
          .get(Uri.parse("$baseUrl/maintenance/$vehicleId"), headers: headers)
          .timeout(_timeout);

      final decoded = _decodeBody(res);
      if (decoded is List) return decoded;
      if (decoded is Map && decoded["history"] is List)
        return decoded["history"];
      return [];
    } catch (_) {
      return [];
    }
  }

  // ============================================================
  // ❌ Delete maintenance
  // ============================================================
  static Future<Map<String, dynamic>> deleteMaintenance(String id) async {
    try {
      final headers = await _authHeaders();

      final res = await http
          .delete(Uri.parse("$baseUrl/maintenance/$id"), headers: headers)
          .timeout(_timeout);

      if (res.statusCode == 200) return {"success": true};

      final decoded = _decodeBody(res);
      return _normalizeError(res, decoded, fallback: "فشل حذف الصيانة");
    } on TimeoutException {
      return {"error": true, "message": "السيرفر مش بيرد (Timeout)"};
    } catch (_) {
      return {"error": true, "message": "تعذر الاتصال بالسيرفر"};
    }
  }

  // ============================================================
  // 🔁 Forgot Password
  // ============================================================
  static Future<Map<String, dynamic>> forgotPassword(String email) async {
    try {
      final res = await http
          .post(
            Uri.parse("$baseUrl/users/forgot-password"),
            headers: _jsonHeaders(),
            body: jsonEncode({"email": email.trim()}),
          )
          .timeout(_timeout);

      final decoded = _decodeBody(res);
      if (res.statusCode == 200 && decoded is Map<String, dynamic>)
        return decoded;

      return _normalizeError(res, decoded, fallback: "فشل إرسال طلب الاستعادة");
    } on TimeoutException {
      return {"error": true, "message": "السيرفر مش بيرد (Timeout)"};
    } catch (_) {
      return {"error": true, "message": "تعذر الاتصال بالسيرفر"};
    }
  }
}
