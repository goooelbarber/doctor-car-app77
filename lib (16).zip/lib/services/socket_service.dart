// ignore: unused_import
import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;

import '../config/api_config.dart';

enum SocketRole { user, technician }

class SocketService {
  // ===============================
  // 🧠 Singleton
  // ===============================
  static final SocketService _instance = SocketService._internal();
  factory SocketService() => _instance;
  SocketService._internal();

  IO.Socket? _socket;

  SocketRole? _role;
  String? _userId;
  String? _technicianId;
  String? _token;

  bool get isConnected => _socket?.connected ?? false;

  // ===============================
  // 🔌 Init & Connect
  // ===============================

  /// استخدمها في تطبيق المستخدم
  void initUser({required String userId}) {
    _role = SocketRole.user;
    _userId = userId;
    _technicianId = null;
    _token = null;
    _connect();
  }

  /// استخدمها في تطبيق الفني
  void initTechnician({required String technicianId, String? token}) {
    _role = SocketRole.technician;
    _technicianId = technicianId;
    _userId = null;
    _token = token;
    _connect();
  }

  void _connect() {
    // لو socket شغال ومتصل، بس اعمل presence
    if (_socket != null) {
      if (!_socket!.connected) {
        _socket!.connect();
      } else {
        _emitPresence();
      }
      return;
    }

    final opts = IO.OptionBuilder()
        .setTransports(['polling', 'websocket'])
        .disableAutoConnect()
        .enableReconnection()
        .enableForceNew() // مهم لمنع instances قديمة
        .build();

    // Auth للفني (اختياري)
    if (_token != null && _token!.isNotEmpty) {
      opts['auth'] = {'token': _token};
    }

    _socket = IO.io(ApiConfig.socketUrl, opts);

    _socket!.onConnect((_) {
      debugPrint("🔌 Socket connected: ${_socket!.id}");
      _emitPresence();
    });

    _socket!.onDisconnect((_) {
      debugPrint("🔴 Socket disconnected");
    });

    _socket!.onConnectError((e) {
      debugPrint("❌ Socket connect error: $e");
    });

    _socket!.onError((e) {
      debugPrint("❌ Socket error: $e");
    });

    _socket!.connect();
  }

  void _emitPresence() {
    if (_socket == null || !_socket!.connected) return;

    if (_role == SocketRole.user && _userId != null) {
      _socket!.emit("user:online", {"userId": _userId});
      debugPrint("👤 user:online emitted ($_userId)");
    }

    if (_role == SocketRole.technician && _technicianId != null) {
      _socket!.emit("technician:online", {"technicianId": _technicianId});
      debugPrint("🛠️ technician:online emitted ($_technicianId)");
    }
  }

  // ===============================
  // 🔄 Connection status
  // ===============================
  void onConnectionChanged(void Function(bool connected) cb) {
    cb(isConnected);
    _socket?.off("connect");
    _socket?.off("disconnect");
    _socket?.onConnect((_) => cb(true));
    _socket?.onDisconnect((_) => cb(false));
  }

  // ===============================
  // 🧹 Support listeners cleanup
  // ===============================
  void clearSupportListeners() {
    _socket?.off("supportMessage:new");
    _socket?.off("supportMessage:ack");
    _socket?.off("supportChat:typing");
    _socket?.off("supportChat:read");
  }

  // ===============================
  // 📦 Orders (للفني)
  // ===============================

  /// الفني يستقبل طلبات جديدة
  void onNewOrder(void Function(Map<String, dynamic> order) cb) {
    _socket?.off("order:new");
    _socket?.on("order:new", (data) {
      if (data == null) return;
      if (data is Map) cb(Map<String, dynamic>.from(data));
    });
  }

  void acceptOrder(String orderId) {
    if (_technicianId == null) return;
    _socket?.emit(
        "order:accept", {"orderId": orderId, "technicianId": _technicianId});
  }

  void rejectOrder(String orderId) {
    if (_technicianId == null) return;
    _socket?.emit(
        "order:reject", {"orderId": orderId, "technicianId": _technicianId});
  }

  void joinOrderRoom(String orderId) {
    _socket?.emit("joinOrderRoom", orderId);
  }

  void onOrderAccepted(void Function(Map<String, dynamic>) cb) {
    _socket?.off("order:accepted");
    _socket?.on("order:accepted", (data) {
      if (data == null) return;
      if (data is Map) cb(Map<String, dynamic>.from(data));
    });
  }

  void onOrderStatusUpdated(void Function(String status) cb) {
    _socket?.off("orderStatusUpdated");
    _socket?.on("orderStatusUpdated", (data) {
      if (data == null) return;
      cb((data["status"] ?? "").toString());
    });
  }

  void onTechnicianLocation(void Function(double lat, double lng) cb) {
    _socket?.off("technicianLocationUpdate");
    _socket?.on("technicianLocationUpdate", (data) {
      if (data == null) return;
      final loc = data["location"];
      if (loc == null) return;
      cb(
        (loc["lat"] as num).toDouble(),
        (loc["lng"] as num).toDouble(),
      );
    });
  }

  // ===============================
  // 💬 Support Chat
  // ===============================

  void joinSupportChat(String chatId) {
    _socket?.emit("joinSupportChat", {"chatId": chatId});
  }

  /// (اختياري) حتى لو السيرفر مش عاملها، مش هتضر
  void leaveSupportChat(String chatId) {
    _socket?.emit("leaveSupportChat", {"chatId": chatId});
  }

  void sendSupportMessage({
    required String chatId,
    required String text,
    required String senderType, // user | technician
    String? senderId,
    String? clientTempId,
  }) {
    _socket?.emit("supportMessage:send", {
      "chatId": chatId,
      "text": text,
      "senderType": senderType,
      if (senderId != null) "senderId": senderId,
      if (clientTempId != null) "clientTempId": clientTempId,
    });
  }

  void onSupportMessage(void Function(Map<String, dynamic>) cb) {
    _socket?.off("supportMessage:new");
    _socket?.on("supportMessage:new", (data) {
      if (data == null) return;
      if (data is Map) cb(Map<String, dynamic>.from(data));
    });
  }

  void onSupportAck(void Function(Map<String, dynamic>) cb) {
    _socket?.off("supportMessage:ack");
    _socket?.on("supportMessage:ack", (data) {
      if (data == null) return;
      if (data is Map) cb(Map<String, dynamic>.from(data));
    });
  }

  void emitSupportTyping({
    required String chatId,
    required bool typing,
    required String senderType,
  }) {
    _socket?.emit("supportChat:typing", {
      "chatId": chatId,
      "typing": typing,
      "senderType": senderType,
    });
  }

  void onSupportTyping(void Function(Map<String, dynamic>) cb) {
    _socket?.off("supportChat:typing");
    _socket?.on("supportChat:typing", (data) {
      if (data == null) return;
      if (data is Map) cb(Map<String, dynamic>.from(data));
    });
  }

  void emitSupportRead({
    required String chatId,
    required String readerType, // user | technician
  }) {
    _socket?.emit(
        "supportChat:read", {"chatId": chatId, "readerType": readerType});
  }

  // ===============================
  // 🔌 Disconnect
  // ===============================
  void disconnect() {
    _socket?.clearListeners();
    _socket?.disconnect();
    _socket = null;
    _role = null;
    _userId = null;
    _technicianId = null;
    _token = null;
  }
}
