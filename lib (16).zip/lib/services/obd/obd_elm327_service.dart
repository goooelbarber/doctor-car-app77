import 'dart:async';
import 'dart:convert';
import 'package:flutter_bluetooth_serial/flutter_bluetooth_serial.dart';

class ObdElm327Service {
  BluetoothConnection? _conn;

  final _rx = StringBuffer();
  StreamSubscription<List<int>>? _sub;

  bool get isConnected => _conn?.isConnected ?? false;

  Future<void> connect(BluetoothDevice device) async {
    _conn = await BluetoothConnection.toAddress(device.address);

    _sub = _conn!.input!.listen((data) {
      _rx.write(ascii.decode(data, allowInvalid: true));
    });

    // Init ELM327
    await _cmd("ATZ", timeout: const Duration(seconds: 4));
    await _cmd("ATE0");
    await _cmd("ATL0");
    await _cmd("ATS0");
    await _cmd("ATH0");
    await _cmd("ATSP0"); // auto protocol
  }

  Future<void> disconnect() async {
    await _sub?.cancel();
    _sub = null;
    await _conn?.close();
    _conn = null;
  }

  Future<String> _cmd(String cmd,
      {Duration timeout = const Duration(seconds: 3)}) async {
    if (_conn == null || !isConnected) throw Exception("OBD_NOT_CONNECTED");

    _rx.clear();
    _conn!.output.add(ascii.encode("$cmd\r"));
    await _conn!.output.allSent;

    final deadline = DateTime.now().add(timeout);

    while (DateTime.now().isBefore(deadline)) {
      final s = _rx.toString();
      if (s.contains(">")) {
        return _cleanResponse(s);
      }
      await Future.delayed(const Duration(milliseconds: 40));
    }

    throw TimeoutException("OBD_TIMEOUT: $cmd");
  }

  String _cleanResponse(String raw) {
    var s = raw
        .replaceAll("\r", "")
        .replaceAll("\n", "")
        .replaceAll(">", "")
        .trim();

    // remove common ELM noisy tokens
    s = s.replaceAll("SEARCHING...", "");
    s = s.replaceAll("BUSINIT...", "");
    s = s.replaceAll("NO DATA", "");
    return s.trim();
  }

  /// Mode 03: Read stored DTCs
  Future<List<String>> readDtcCodes() async {
    final resp = await _cmd("03", timeout: const Duration(seconds: 4));
    return _parseDtcMode03(resp);
  }

  /// Mode 01 PID 0C: RPM
  Future<int?> readRpm() async {
    final resp = await _cmd("010C");
    // expected: 410C A B
    final hex = resp.replaceAll(" ", "").toUpperCase();
    final idx = hex.indexOf("410C");
    if (idx < 0 || hex.length < idx + 8) return null;
    final a = int.parse(hex.substring(idx + 4, idx + 6), radix: 16);
    final b = int.parse(hex.substring(idx + 6, idx + 8), radix: 16);
    return ((a * 256) + b) ~/ 4;
  }

  /// Mode 01 PID 05: Coolant Temp (°C)
  Future<int?> readCoolantTemp() async {
    final resp = await _cmd("0105");
    final hex = resp.replaceAll(" ", "").toUpperCase();
    final idx = hex.indexOf("4105");
    if (idx < 0 || hex.length < idx + 6) return null;
    final a = int.parse(hex.substring(idx + 4, idx + 6), radix: 16);
    return a - 40;
  }

  List<String> _parseDtcMode03(String raw) {
    final s = raw.replaceAll(" ", "").toUpperCase();
    final start = s.indexOf("43");
    if (start < 0) return [];

    final data = s.substring(start + 2);
    final codes = <String>[];

    for (int i = 0; i + 4 <= data.length; i += 4) {
      final chunk = data.substring(i, i + 4);
      if (chunk == "0000") continue;
      final code = _decodeDtc(chunk);
      if (code.isNotEmpty) codes.add(code);
    }

    return codes;
  }

  String _decodeDtc(String hex4) {
    final a = int.tryParse(hex4.substring(0, 2), radix: 16);
    final b = int.tryParse(hex4.substring(2, 4), radix: 16);
    if (a == null || b == null) return "";

    final typeBits = (a & 0xC0) >> 6;
    final first = ["P", "C", "B", "U"][typeBits];

    final d1 = ((a & 0x30) >> 4); // 0..3
    final d2 = (a & 0x0F);
    final d3 = ((b & 0xF0) >> 4);
    final d4 = (b & 0x0F);

    return "$first$d1${d2.toRadixString(16).toUpperCase()}${d3.toRadixString(16).toUpperCase()}${d4.toRadixString(16).toUpperCase()}";
  }
}

extension _SB on StringBuffer {
  void clear() {
    // reset buffer by replacing content
    this
      ..write("")
      ..clear(); // will recurse? no; StringBuffer has no clear; ignore below
  }
}
