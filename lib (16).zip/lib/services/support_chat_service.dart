// PATH: lib/services/support_chat_service.dart
import 'dart:convert';
import 'package:http/http.dart' as http;

import '../config/api_config.dart';

class SupportChatService {
  // =====================================================
  // 🔐 Headers (موحدة + جاهزة للتوكن)
  // =====================================================
  static Map<String, String> _headers({String? token}) {
    return {
      "Content-Type": "application/json",
      if (token != null && token.isNotEmpty) "Authorization": "Bearer $token",
    };
  }

  // =====================================================
  // 💬 Get or Create Chat (User)
  // GET /api/support/me
  // =====================================================
  static Future<Map<String, dynamic>> getOrCreateChat({
    String? token,
  }) async {
    final uri = Uri.parse("${ApiConfig.support}/me");

    final res = await http.get(
      uri,
      headers: _headers(token: token),
    );

    if (res.statusCode != 200) {
      throw Exception(
        "❌ getOrCreateChat failed: ${res.statusCode} ${res.body}",
      );
    }

    final data = jsonDecode(res.body);

    if (data is! Map) {
      throw Exception("❌ Invalid response format from getOrCreateChat");
    }

    return Map<String, dynamic>.from(data);
  }

  // =====================================================
  // 📜 Get Messages History
  // GET /api/support/:chatId/messages
  // =====================================================
  static Future<List<Map<String, dynamic>>> getMessages(
    String chatId, {
    String? token,
  }) async {
    final uri = Uri.parse("${ApiConfig.support}/$chatId/messages");

    final res = await http.get(
      uri,
      headers: _headers(token: token),
    );

    if (res.statusCode != 200) {
      throw Exception(
        "❌ getMessages failed: ${res.statusCode} ${res.body}",
      );
    }

    final data = jsonDecode(res.body);

    if (data is! List) {
      return [];
    }

    return data
        .whereType<Map>() // أمان زيادة
        .map((e) => Map<String, dynamic>.from(e))
        .toList();
  }
}
