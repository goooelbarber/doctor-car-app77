// =======================
// main.dart (Fixed + Production-ready)
// =======================

import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart'; // kIsWeb
import 'package:easy_localization/easy_localization.dart';
import 'package:google_fonts/google_fonts.dart';

import 'package:doctor_car_app/screens/splash_screen.dart';
import 'package:doctor_car_app/screens/login_screen.dart';
import 'package:doctor_car_app/screens/SignUp_Screen.dart';
import 'package:doctor_car_app/screens/home_screen.dart';
import 'package:doctor_car_app/screens/road_services_screen.dart';
import 'package:doctor_car_app/screens/vehicles/vehicle_screen.dart';
import 'package:doctor_car_app/screens/smart_accident_screen.dart';
import 'package:doctor_car_app/screens/settings_screen.dart';
import 'package:doctor_car_app/screens/auth/forgot_password_screen.dart';
import 'package:doctor_car_app/screens/role_selection_screen.dart';

// ✅ شاشة الفني
import 'package:doctor_car_app/screens/driver/driver_home_screen.dart';

// ✅ Conditional import (Web vs Non-web)
import 'web/google_maps_loader_stub.dart'
    if (dart.library.html) 'web/google_maps_loader_web.dart';

// ⚠️ Google Maps API Key
const String kGoogleMapsApiKey = "AIzaSyD9BGSScE-DU9nbdFgIbJV4fbNspNdPg_M";

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await EasyLocalization.ensureInitialized();

  // ✅ تحميل Google Maps للويب فقط
  if (kIsWeb) {
    await loadGoogleMapsJS(kGoogleMapsApiKey);
  }

  runApp(
    EasyLocalization(
      supportedLocales: const [Locale('ar'), Locale('en')],
      path: 'assets/translations',
      fallbackLocale: const Locale('ar'),
      saveLocale: true,
      child: const DoctorCarApp(),
    ),
  );
}

// ======================
// DoctorCarApp
// ======================
class DoctorCarApp extends StatelessWidget {
  const DoctorCarApp({super.key});

  static const Color brandPrimary = Color(0xFF1F4BA5);

  ThemeData _buildLightTheme() {
    final base = ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: brandPrimary),
    );

    return base.copyWith(
      textTheme: GoogleFonts.cairoTextTheme(base.textTheme),
      scaffoldBackgroundColor: const Color(0xffF5F6FA),
      appBarTheme: AppBarTheme(
        elevation: 0,
        centerTitle: true,
        backgroundColor: Colors.transparent,
        titleTextStyle: GoogleFonts.cairo(
          fontSize: 18,
          fontWeight: FontWeight.w800,
          color: const Color(0xff111827),
        ),
        iconTheme: const IconThemeData(color: Color(0xff111827)),
      ),
    );
  }

  ThemeData _buildDarkTheme() {
    final base = ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      colorScheme: ColorScheme.fromSeed(
        seedColor: brandPrimary,
        brightness: Brightness.dark,
      ),
    );

    return base.copyWith(
      textTheme: GoogleFonts.cairoTextTheme(base.textTheme),
      scaffoldBackgroundColor: const Color(0xff0E1320),
      appBarTheme: AppBarTheme(
        elevation: 0,
        centerTitle: true,
        backgroundColor: Colors.transparent,
        titleTextStyle: GoogleFonts.cairo(
          fontSize: 18,
          fontWeight: FontWeight.w800,
          color: Colors.white,
        ),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Doctor Car',

      // Themes
      theme: _buildLightTheme(),
      darkTheme: _buildDarkTheme(),
      themeMode: ThemeMode.system,

      // Localization
      localizationsDelegates: context.localizationDelegates,
      supportedLocales: context.supportedLocales,
      locale: context.locale,

      // ✅ Splash هو المتحكم الوحيد في التوجيه
      home: const SplashScreen(),

      routes: {
        '/login': (_) => const LoginScreen(),
        '/home': (_) => const HomeScreen(),
        '/driver-home': (_) => const IncomingRequestScreen(
              technicianToken: '',
              technicianId: '',
            ),
        '/road': (_) => const RoadServicesScreen(),
        '/signup': (_) => const SignUpScreen(),
        '/vehicle': (_) => const VehiclesScreen(),
        '/smart-accident': (_) => const SmartAccidentScreen(),
        '/settings': (_) => const SettingsScreen(),
        '/forgot-password': (_) => const ForgotPasswordScreen(),
        '/role': (_) => const RoleSelectionScreen(),
      },
    );
  }
}
