// ignore_for_file: depend_on_referenced_packages

import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'package:doctor_car_app/screens/supplementary_services_screen.dart';
import 'package:doctor_car_app/pages/home/home_page.dart';

class MaintenanceServicesScreen extends StatefulWidget {
  const MaintenanceServicesScreen({super.key});

  @override
  State<MaintenanceServicesScreen> createState() =>
      _MaintenanceServicesScreenState();
}

class _MaintenanceServicesScreenState extends State<MaintenanceServicesScreen>
    with TickerProviderStateMixin {
  String? selected;

  // ignore: unused_field
  static const Color _primary = Color(0xff1F4BA5);
  static const Color _accent = Colors.amber;

  final List<Map<String, dynamic>> services = [
    {
      "key": "maintenance",
      "name": "صيانة",
      "icon": Icons.build_circle,
    },
    {
      "key": "wash",
      "name": "غسيل و عناية",
      "icon": Icons.local_car_wash,
    },
    {
      "key": "accessories",
      "name": "إكسسوارات",
      "icon": Icons.shopping_bag_rounded,
    },
    {
      "key": "check",
      "name": "كشف",
      "icon": Icons.assignment_rounded,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: const Color(0xff0B1220),
        foregroundColor: Colors.white,
        centerTitle: true,
        title: Text(
          "🛠️ خدمات الصيانة",
          style: GoogleFonts.cairo(
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Stack(
        children: [
          // ===== Background =====
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Color(0xff0D1B2A),
                  Color(0xff0F2A44),
                  Color(0xff12395B),
                ],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),

          // ===== Content =====
          Padding(
            padding: const EdgeInsets.only(top: 120, left: 16, right: 16),
            child: Column(
              children: [
                Text(
                  "اختر خدمة الصيانة",
                  style: GoogleFonts.cairo(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 20),
                Expanded(
                  child: GridView.builder(
                    itemCount: services.length,
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      mainAxisSpacing: 14,
                      crossAxisSpacing: 14,
                      childAspectRatio: 0.9,
                    ),
                    itemBuilder: (_, index) {
                      final item = services[index];
                      final isSelected = selected == item["key"];

                      return GestureDetector(
                        onTap: () {
                          setState(() {
                            selected = item["key"] as String;
                          });
                        },
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 280),
                          curve: Curves.easeOut,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(22),
                            border: Border.all(
                              color: isSelected
                                  ? _accent
                                  : Colors.white.withOpacity(0.2),
                              width: isSelected ? 3 : 1.2,
                            ),
                            color: Colors.white.withOpacity(0.08),
                            boxShadow: [
                              if (isSelected)
                                BoxShadow(
                                  color: _accent.withOpacity(0.45),
                                  blurRadius: 26,
                                  offset: const Offset(0, 6),
                                ),
                            ],
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(22),
                            child: BackdropFilter(
                              filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Container(
                                    width: 70,
                                    height: 70,
                                    decoration: BoxDecoration(
                                      color: Colors.white.withOpacity(0.15),
                                      shape: BoxShape.circle,
                                    ),
                                    child: Icon(
                                      item["icon"] as IconData,
                                      color: _accent,
                                      size: 36,
                                    ),
                                  ),
                                  const SizedBox(height: 14),
                                  Text(
                                    item["name"] as String,
                                    style: GoogleFonts.cairo(
                                      color: Colors.white,
                                      fontSize: 17,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 90),
              ],
            ),
          ),

          // ===== Bottom Action Button =====
          Positioned(
            bottom: 25,
            left: 20,
            right: 20,
            child: GestureDetector(
              onTap: selected == null ? null : () => _openService(selected!),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                height: 62,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(18),
                  color: selected == null ? Colors.grey.shade600 : _accent,
                  boxShadow: [
                    if (selected != null)
                      BoxShadow(
                        color: _accent.withOpacity(0.45),
                        blurRadius: 30,
                        offset: const Offset(0, 8),
                      ),
                  ],
                ),
                child: Center(
                  child: Text(
                    selected == null ? "اختر خدمة للمتابعة" : "🚀 فتح الخدمة",
                    style: GoogleFonts.cairo(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 19,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ===== Navigation =====
  void _openService(String key) {
    switch (key) {
      case "maintenance":
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => const SupplementaryServicesScreen(),
          ),
        );
        break;

      case "accessories":
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => const HomePage(),
          ),
        );
        break;

      default:
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              "الخدمة ستتوفر قريبًا",
              style: GoogleFonts.cairo(),
            ),
          ),
        );
    }
  }
}
