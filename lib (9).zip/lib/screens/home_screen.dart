// ignore_for_file: depend_on_referenced_packages, use_build_context_synchronously

import 'dart:ui';
import 'package:doctor_car_app/pages/home/home_page.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

// SCREENS
import 'contact_screen.dart';
import 'road_services_screen.dart';
import 'smart_accident_screen.dart';
import 'account_settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  bool isArabic = true;

  late AnimationController fadeCtrl;
  late Animation<double> fadeAnim;

  late PageController bannerCtrl;
  int currentBanner = 0;

  @override
  void initState() {
    super.initState();

    bannerCtrl = PageController();
    Future.delayed(const Duration(milliseconds: 700), autoSlide);

    fadeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    fadeAnim = CurvedAnimation(parent: fadeCtrl, curve: Curves.easeOut);
    fadeCtrl.forward();
  }

  @override
  void dispose() {
    bannerCtrl.dispose();
    fadeCtrl.dispose();
    super.dispose();
  }

  void autoSlide() {
    if (!mounted) return;
    currentBanner++;
    bannerCtrl.animateToPage(
      currentBanner % 3,
      duration: const Duration(milliseconds: 600),
      curve: Curves.easeOut,
    );
    Future.delayed(const Duration(seconds: 4), autoSlide);
  }

  Color get darkBg => const Color(0xff0A0D14);
  LinearGradient get gold => const LinearGradient(
        colors: [Color(0xffE8C87A), Color(0xffB68A32)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );

  void goto(Widget page) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }

  // ---------------------------- BANNER ----------------------------
  Widget _bannerSlider() {
    final items = [
      "assets/images/offer1.png",
      "assets/images/offer2.png",
      "assets/images/offer3.png",
    ];

    return FadeTransition(
      opacity: fadeAnim,
      child: SizedBox(
        height: 160,
        child: PageView.builder(
          controller: bannerCtrl,
          itemCount: items.length,
          itemBuilder: (_, i) {
            return AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              margin: const EdgeInsets.symmetric(horizontal: 14),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(22),
                image: DecorationImage(
                  image: AssetImage(items[i]),
                  fit: BoxFit.cover,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(.4),
                    blurRadius: 18,
                  )
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  // ---------------------------- HEADER ----------------------------
  Widget _header() {
    return FadeTransition(
      opacity: fadeAnim,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Icon(Icons.menu, size: 30, color: Colors.white),
          ShaderMask(
            shaderCallback: (b) => gold.createShader(b),
            child: Text(
              "Doctor Car",
              style: GoogleFonts.cairo(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ),
          const Icon(Icons.language, size: 28, color: Colors.white),
        ],
      ),
    );
  }

  // ---------------------- BUTTON WITH TITLE ABOVE IMAGE ----------------------
  Widget _bigBtn(String title, String imgPath, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 170,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          color: const Color(0xff111822),
          border: Border.all(color: Colors.white24, width: 1.4),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(.35),
              blurRadius: 15,
              offset: const Offset(0, 6),
            )
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              title,
              style: GoogleFonts.cairo(
                color: Colors.white,
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            Container(
              width: 220,
              height: 120,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                image: DecorationImage(
                  image: AssetImage(imgPath),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ---------------------- BOTTOM ICON ----------------------
  Widget _bottomIcon(IconData icon, String title, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            width: 62,
            height: 62,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white60, width: 2),
              color: Colors.white.withOpacity(.10),
            ),
            child: Icon(icon, color: Colors.white, size: 28),
          ),
          const SizedBox(height: 5),
          Text(
            title,
            style: GoogleFonts.cairo(color: Colors.white, fontSize: 16),
          ),
        ],
      ),
    );
  }

  // ---------------------------- MAIN BUILD ----------------------------
  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: isArabic ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        backgroundColor: darkBg,
        bottomNavigationBar: SizedBox(
          height: 108,
          child: Container(
            color: darkBg,
            child: Stack(
              alignment: Alignment.center,
              children: [
                Positioned(
                  bottom: 30,
                  child: Container(
                    width: 75,
                    height: 75,
                    decoration: BoxDecoration(
                      gradient: gold,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.amber.withOpacity(.45),
                          blurRadius: 35,
                        ),
                      ],
                    ),
                    child:
                        const Icon(Icons.call, size: 40, color: Colors.black),
                  ),
                ),
                Positioned(
                  bottom: 14,
                  left: 30,
                  child: _bottomIcon(Icons.person, "حسابي",
                      () => goto(const AccountSettingsScreen())),
                ),
                Positioned(
                  bottom: 14,
                  right: 30,
                  child: _bottomIcon(Icons.home, "الرئيسية", () {}),
                ),
              ],
            ),
          ),
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
            child: Column(
              children: [
                _header(),
                const SizedBox(height: 15),
                _bannerSlider(),
                const SizedBox(height: 25),

                // ---------------- ROW 1 ----------------
                Row(
                  children: [
                    Expanded(
                      child: _bigBtn(
                        "Road Services",
                        "assets/images/tow_truck.png",
                        () => goto(const RoadServicesScreen()),
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: _bigBtn(
                        "Accient",
                        "assets/images/accient.png",
                        () => goto(const SmartAccidentScreen()),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 20),

                // ---------------- ROW 2 ----------------
                Row(
                  children: [
                    Expanded(
                      child: _bigBtn(
                        "Store",
                        "assets/images/offer1.png",
                        () => goto(const HomePage()), // ⬅⬅ المتجر الحقيقي
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: _bigBtn(
                        "Privacy",
                        "assets/images/offer1.png",
                        () => goto(const ContactScreen()),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
