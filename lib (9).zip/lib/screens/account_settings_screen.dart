// ================================================================
// FILE: lib/screens/account/account_settings_screen.dart
// PRO VERSION (Apple Glass + Uber Dashboard Hybrid UI)
// ================================================================

import 'dart:io';
import 'package:doctor_car_app/pages/home/home_page.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:image_picker/image_picker.dart';
import 'package:easy_localization/easy_localization.dart';

import 'package:doctor_car_app/screens/vehicles/vehicle_screen.dart';

class AccountSettingsScreen extends StatefulWidget {
  const AccountSettingsScreen({super.key});

  @override
  State<AccountSettingsScreen> createState() => _AccountSettingsScreenState();
}

class _AccountSettingsScreenState extends State<AccountSettingsScreen> {
  bool _notificationsEnabled = true;
  String _language = 'ar';
  String _userName = 'مستخدم التطبيق';
  bool _isDarkMode = false;
  File? _profileImage;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _notificationsEnabled = prefs.getBool('notificationsEnabled') ?? true;
      _language = prefs.getString('language') ?? 'ar';
      _userName = prefs.getString('userName') ?? 'مستخدم التطبيق';
      _isDarkMode = prefs.getBool('darkMode') ?? false;
    });
  }

  Future<void> _saveSettings() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('notificationsEnabled', _notificationsEnabled);
    await prefs.setString('language', _language);
    await prefs.setString('userName', _userName);
    await prefs.setBool('darkMode', _isDarkMode);
  }

  Future<void> _changeLanguage(String lang) async {
    setState(() => _language = lang);
    await _saveSettings();
    await context.setLocale(Locale(lang));
  }

  void _toggleDarkMode(bool value) {
    setState(() => _isDarkMode = value);
    _saveSettings();
  }

  Future<void> _pickProfileImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null && mounted) {
      setState(() => _profileImage = File(pickedFile.path));
    }
  }

  Future<void> _contactSupport(String method) async {
    final whatsapp = Uri.parse("https://wa.me/201275649151");
    final email = Uri.parse("mailto:support@doctorcar.com?subject=Support");
    final phone = Uri.parse("tel:+201275649151");

    final Uri link = (method == 'whatsapp')
        ? whatsapp
        : (method == 'email')
            ? email
            : phone;

    if (await canLaunchUrl(link)) {
      await launchUrl(link, mode: LaunchMode.externalApplication);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تعذر فتح التطبيق')),
      );
    }
  }

  Future<void> _editName() async {
    final controller = TextEditingController(text: _userName);

    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('تعديل الاسم'),
        content: TextField(controller: controller, textAlign: TextAlign.right),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("إلغاء")),
          ElevatedButton(
            onPressed: () {
              setState(() => _userName = controller.text);
              _saveSettings();
              Navigator.pop(context);
            },
            child: const Text("حفظ"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = _isDarkMode;
    final bg = isDark ? const Color(0xff0D0F22) : const Color(0xffF6F7FB);
    final txt = isDark ? Colors.white : Colors.black87;

    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text("حسابي",
            style: TextStyle(
                fontSize: 22, fontWeight: FontWeight.bold, color: txt)),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // ==============================================================
          // PROFILE CARD (Glass Effect)
          // ==============================================================
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: Colors.white.withOpacity(.2)),
              gradient: LinearGradient(
                colors: [
                  Colors.white.withOpacity(.25),
                  Colors.white.withOpacity(.05),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(.18),
                  blurRadius: 18,
                  offset: const Offset(0, 6),
                )
              ],
            ),
            child: Column(
              children: [
                Stack(
                  alignment: Alignment.bottomRight,
                  children: [
                    CircleAvatar(
                      radius: 58,
                      backgroundImage: _profileImage != null
                          ? FileImage(_profileImage!)
                          : null,
                      backgroundColor: Colors.blueGrey,
                      child: _profileImage == null
                          ? const Icon(Icons.person, size: 60)
                          : null,
                    ),
                    GestureDetector(
                      onTap: _pickProfileImage,
                      child: Container(
                        padding: const EdgeInsets.all(5),
                        decoration: const BoxDecoration(
                            shape: BoxShape.circle, color: Colors.blue),
                        child: const Icon(Icons.camera_alt,
                            color: Colors.white, size: 20),
                      ),
                    )
                  ],
                ),
                const SizedBox(height: 10),
                Text(_userName,
                    style: TextStyle(
                        fontSize: 22, fontWeight: FontWeight.bold, color: txt)),
                TextButton(
                  onPressed: _editName,
                  child: const Text("تعديل الاسم",
                      style: TextStyle(color: Colors.blueAccent)),
                )
              ],
            ),
          ),

          const SizedBox(height: 25),

          // ==============================================================
          // DASHBOARD BUTTONS (Marketplace – Wallet – Orders – Cars)
          // ==============================================================
          Text("لوحة التحكم",
              style: TextStyle(
                  fontSize: 19, fontWeight: FontWeight.bold, color: txt)),

          const SizedBox(height: 15),

          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            childAspectRatio: 1.2,
            mainAxisSpacing: 15,
            crossAxisSpacing: 15,
            children: [
              _dashButton(
                  FontAwesomeIcons.store,
                  "المتجر",
                  Colors.teal,
                  () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const HomePage()))),
              _dashButton(Icons.wallet, "المحفظة", Colors.orange, () {}),
              _dashButton(Icons.history, "الطلبات", Colors.blue, () {}),
              _dashButton(
                  Icons.car_rental,
                  "مركباتي",
                  Colors.green,
                  () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => const VehiclesScreen()))),
            ],
          ),

          const SizedBox(height: 30),

          // ==============================================================
          // SETTINGS
          // ==============================================================
          Text("الإعدادات",
              style: TextStyle(
                  fontSize: 19, fontWeight: FontWeight.bold, color: txt)),
          const SizedBox(height: 15),

          _settingCard(Icons.language, Colors.blue, "اللغة",
              subtitle: _language == 'ar' ? "العربية" : "English",
              trailing: _languageDropdown()),

          _switchSetting(
              Icons.notifications_active,
              Colors.orange,
              "الإشعارات",
              _notificationsEnabled,
              (v) => setState(() => _notificationsEnabled = v)),

          _switchSetting(Icons.dark_mode, Colors.purple, "الوضع الليلي",
              _isDarkMode, _toggleDarkMode),

          const SizedBox(height: 30),

          // ==============================================================
          // SUPPORT
          // ==============================================================
          Text("الدعم الفني",
              style: TextStyle(
                  fontSize: 19, fontWeight: FontWeight.bold, color: txt)),
          const SizedBox(height: 15),

          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _supportBtn(FontAwesomeIcons.whatsapp, "WhatsApp", Colors.green,
                  () => _contactSupport("whatsapp")),
              _supportBtn(Icons.email, "Email", Colors.blue,
                  () => _contactSupport("email")),
              _supportBtn(Icons.phone, "Call", Colors.orange,
                  () => _contactSupport("call")),
            ],
          ),

          const SizedBox(height: 35),

          // ==============================================================
          // LOGOUT
          // ==============================================================
          ElevatedButton.icon(
            onPressed: () async {
              final prefs = await SharedPreferences.getInstance();
              await prefs.clear();
              if (!mounted) return;
              Navigator.of(context)
                  .pushNamedAndRemoveUntil('/login', (route) => false);
            },
            icon: const Icon(Icons.logout),
            label: const Text("تسجيل الخروج"),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.redAccent,
              minimumSize: const Size(double.infinity, 55),
            ),
          ),
        ],
      ),
    );
  }

  // =======================================================================
  // REUSABLE UI COMPONENTS
  // =======================================================================

  Widget _dashButton(
      IconData icon, String label, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: LinearGradient(
            colors: [
              color.withOpacity(.8),
              color.withOpacity(.5),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          boxShadow: [
            BoxShadow(
                color: color.withOpacity(.5),
                blurRadius: 18,
                offset: const Offset(0, 6))
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white, size: 38),
            const SizedBox(height: 10),
            Text(label,
                style: const TextStyle(
                    color: Colors.white, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }

  Widget _settingCard(IconData icon, Color color, String title,
      {String? subtitle, Widget? trailing}) {
    return Card(
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: color.withOpacity(.15),
          child: Icon(icon, color: color),
        ),
        title: Text(title),
        subtitle: subtitle != null ? Text(subtitle) : null,
        trailing: trailing ?? const Icon(Icons.arrow_forward_ios, size: 18),
      ),
    );
  }

  Widget _switchSetting(IconData icon, Color color, String title, bool value,
      Function(bool) onChanged) {
    return Card(
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      child: SwitchListTile(
        value: value,
        onChanged: onChanged,
        title: Text(title),
        secondary: CircleAvatar(
          backgroundColor: color.withOpacity(.15),
          child: Icon(icon, color: color),
        ),
      ),
    );
  }

  Widget _languageDropdown() {
    return DropdownButton<String>(
      value: _language,
      underline: const SizedBox(),
      items: const [
        DropdownMenuItem(value: 'ar', child: Text("العربية")),
        DropdownMenuItem(value: 'en', child: Text("English")),
      ],
      onChanged: (v) => _changeLanguage(v!),
    );
  }

  Widget _supportBtn(
      IconData icon, String label, Color color, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      child: Container(
        width: 95,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: color.withOpacity(.12),
          border: Border.all(color: color),
        ),
        child: Column(
          children: [
            Icon(icon, size: 30, color: color),
            const SizedBox(height: 5),
            Text(label,
                style: TextStyle(
                    fontSize: 13, fontWeight: FontWeight.bold, color: color)),
          ],
        ),
      ),
    );
  }
}
