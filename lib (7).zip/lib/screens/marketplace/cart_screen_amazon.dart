import 'package:flutter/material.dart';
import '../../models/product_model.dart';

class CartScreenAmazon extends StatefulWidget {
  static List<ProductModel> cart = []; // 🔥 السلة العامة

  const CartScreenAmazon({super.key});

  static get cartItems => null;

  @override
  State<CartScreenAmazon> createState() => _CartScreenAmazonState();
}

class _CartScreenAmazonState extends State<CartScreenAmazon> {
  double get total =>
      CartScreenAmazon.cart.fold(0, (sum, item) => sum + item.price);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade200,
      appBar: AppBar(
        backgroundColor: Colors.amber.shade700,
        iconTheme: const IconThemeData(color: Colors.black),
        title: const Text(
          "Shopping Cart",
          style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
        ),
      ),
      body: CartScreenAmazon.cart.isEmpty
          ? _emptyCart()
          : ListView(
              children: [
                const SizedBox(height: 10),
                ...CartScreenAmazon.cart.map(_cartItem),

                const SizedBox(height: 100), // مساحة للبوتوم بار
              ],
            ),
      bottomSheet: CartScreenAmazon.cart.isEmpty ? null : _checkoutBar(),
    );
  }

  // ----------------------------------------------------
  // EMPTY CART UI
  Widget _emptyCart() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.network(
            "https://i.imgur.com/AvLhKf8.png",
            height: 180,
          ),
          const SizedBox(height: 20),
          const Text(
            "Your cart is empty",
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          ElevatedButton(
            onPressed: () => Navigator.pop(context),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.amber.shade700,
              padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 14),
            ),
            child: const Text("Continue Shopping",
                style: TextStyle(color: Colors.black)),
          )
        ],
      ),
    );
  }

  // ----------------------------------------------------
  // EACH CART ITEM
  Widget _cartItem(ProductModel p) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Image.network(p.image, width: 90, height: 90),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  p.name,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 16),
                ),
                const SizedBox(height: 6),
                Text(
                  "${p.price} EGP",
                  style: const TextStyle(
                    color: Colors.green,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.delete, color: Colors.red),
            onPressed: () {
              setState(() {
                CartScreenAmazon.cart.remove(p);
              });
            },
          )
        ],
      ),
    );
  }

  // ----------------------------------------------------
  // CHECKOUT BAR
  Widget _checkoutBar() {
    return Container(
      height: 110,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(.2), blurRadius: 8)
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Subtotal (${CartScreenAmazon.cart.length} items): "
            "${total.toStringAsFixed(2)} EGP",
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 10),
          ElevatedButton(
            onPressed: () {},
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.amber.shade800,
              padding: const EdgeInsets.symmetric(vertical: 14),
              minimumSize: const Size(double.infinity, 45),
            ),
            child: const Text(
              "Proceed to Buy",
              style: TextStyle(fontSize: 18, color: Colors.black),
            ),
          ),
        ],
      ),
    );
  }
}
