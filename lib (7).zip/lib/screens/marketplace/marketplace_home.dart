// lib/screens/marketplace/marketplace_home.dart

import 'package:doctor_car_app/screens/marketplace/product_details_screen.dart';
import 'package:flutter/material.dart';
import '../../models/product_model.dart';
import 'cart_screen.dart';
import 'search_screen.dart';

class MarketplaceHome extends StatelessWidget {
  MarketplaceHome({super.key});

  final List<ProductModel> products = ProductModel.demo;
  final List<String> brands = [
    "ACDelco",
    "VARTA",
    "Michelin",
    "Firestone",
    "Mobil",
    "Toyota"
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xff0A1124),
      appBar: AppBar(
        backgroundColor: const Color(0xff0D1A33),
        elevation: 0,
        title: const Text("AutoZone Marketplace"),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.search, size: 28),
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const SearchScreen())),
          ),
          IconButton(
            icon: const Icon(Icons.shopping_cart_outlined, size: 28),
            onPressed: () => Navigator.push(
                context, MaterialPageRoute(builder: (_) => const CartScreen())),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          _banner(),
          const SizedBox(height: 20),
          _title("🔥 عروض مميزة"),
          _horizontal(products.where((e) => e.hasDiscount).toList(), context),
          const SizedBox(height: 20),
          _title("⭐ الأعلى تقييماً"),
          _horizontal(products.where((e) => e.rating > 4.7).toList(), context),
          const SizedBox(height: 20),
          _title("🏷 أشهر الماركات"),
          _brandSection(),
          const SizedBox(height: 20),
          _title("📦 جميع المنتجات"),
          _grid(products, context),
        ],
      ),
    );
  }

  // Banner
  Widget _banner() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: Image.network(
        "https://i.ibb.co/hg83tzZ/autozone-banner.jpg",
        height: 180,
        fit: BoxFit.cover,
      ),
    );
  }

  Widget _title(String t) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Text(
        t,
        style: const TextStyle(
            color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
      ),
    );
  }

  Widget _horizontal(List<ProductModel> items, BuildContext c) {
    return SizedBox(
      height: 260,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: items.length,
        itemBuilder: (_, i) {
          final p = items[i];
          return GestureDetector(
            onTap: () => Navigator.push(c,
                MaterialPageRoute(builder: (_) => ProductDetails(product: p))),
            child: Container(
              width: 170,
              margin: const EdgeInsets.only(right: 10),
              decoration: BoxDecoration(
                color: const Color(0xff131B33),
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(color: Colors.black.withOpacity(.25), blurRadius: 6)
                ],
              ),
              child: Column(
                children: [
                  Expanded(
                    child: Hero(
                      tag: p.id,
                      child: Image.network(p.image, fit: BoxFit.contain),
                    ),
                  ),
                  Text(p.name,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: Colors.white)),
                  Text("${p.price} EGP",
                      style: const TextStyle(
                          color: Colors.greenAccent,
                          fontWeight: FontWeight.bold)),
                  const SizedBox(height: 5),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _brandSection() {
    return SizedBox(
      height: 90,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: brands.length,
        itemBuilder: (_, i) {
          return Container(
            width: 120,
            margin: const EdgeInsets.only(left: 10),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Center(
              child: Text(brands[i],
                  style: const TextStyle(color: Colors.white, fontSize: 18)),
            ),
          );
        },
      ),
    );
  }

  Widget _grid(List<ProductModel> items, BuildContext c) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: items.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: 14,
          crossAxisSpacing: 14,
          childAspectRatio: .75),
      itemBuilder: (_, i) {
        final p = items[i];
        return GestureDetector(
          onTap: () => Navigator.push(
              c, MaterialPageRoute(builder: (_) => ProductDetails(product: p))),
          child: Container(
            decoration: BoxDecoration(
              color: const Color(0xff131B33),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              children: [
                Expanded(
                    child: Hero(
                        tag: p.id,
                        child: Image.network(p.image, fit: BoxFit.contain))),
                Text(p.name,
                    maxLines: 2,
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.white)),
                Text("${p.price} EGP",
                    style: const TextStyle(
                        color: Colors.greenAccent,
                        fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
              ],
            ),
          ),
        );
      },
    );
  }
}
