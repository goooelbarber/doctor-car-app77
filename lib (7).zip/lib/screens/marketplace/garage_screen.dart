// lib/screens/marketplace/garage_screen.dart

import 'package:flutter/material.dart';

class GarageScreen extends StatefulWidget {
  const GarageScreen({super.key});

  @override
  State<GarageScreen> createState() => _GarageScreenState();
}

class _GarageScreenState extends State<GarageScreen> {
  List<Map<String, String>> cars = [];

  final TextEditingController brandCtrl = TextEditingController();
  final TextEditingController modelCtrl = TextEditingController();
  final TextEditingController yearCtrl = TextEditingController();

  void addCar() {
    if (brandCtrl.text.isEmpty ||
        modelCtrl.text.isEmpty ||
        yearCtrl.text.isEmpty) return;

    setState(() {
      cars.add({
        "brand": brandCtrl.text,
        "model": modelCtrl.text,
        "year": yearCtrl.text,
      });
    });

    brandCtrl.clear();
    modelCtrl.clear();
    yearCtrl.clear();

    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade200,
      appBar: AppBar(
        backgroundColor: Colors.green.shade700,
        title: const Text("🚗 جراج سياراتي"),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.green,
        child: const Icon(Icons.add),
        onPressed: () {
          showModalBottomSheet(
            context: context,
            backgroundColor: Colors.white,
            shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
            ),
            builder: (_) => Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  TextField(
                      controller: brandCtrl,
                      decoration: const InputDecoration(labelText: "الماركة")),
                  TextField(
                      controller: modelCtrl,
                      decoration: const InputDecoration(labelText: "الموديل")),
                  TextField(
                      controller: yearCtrl,
                      decoration:
                          const InputDecoration(labelText: "سنة الصنع")),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: addCar,
                    child: const Text("إضافة سيارة"),
                  )
                ],
              ),
            ),
          );
        },
      ),
      body: ListView.builder(
        itemCount: cars.length,
        itemBuilder: (_, i) {
          final c = cars[i];
          return Card(
            child: ListTile(
              title: Text("${c["brand"]} - ${c["model"]}"),
              subtitle: Text("سنة الصنع: ${c["year"]}"),
              trailing: IconButton(
                icon: const Icon(Icons.delete, color: Colors.red),
                onPressed: () => setState(() => cars.removeAt(i)),
              ),
            ),
          );
        },
      ),
    );
  }
}
