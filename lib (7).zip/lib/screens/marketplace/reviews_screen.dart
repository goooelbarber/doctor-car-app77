// lib/screens/marketplace/reviews_screen.dart

import 'package:flutter/material.dart';
import '../../models/product_model.dart';

class ReviewsScreen extends StatelessWidget {
  final ProductModel product;

  const ReviewsScreen({super.key, required this.product});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> reviews = [
      {
        "name": "أحمد",
        "rating": 5,
        "comment": "منتج ممتاز وركبته في العربية وفرق معايا جدًا."
      },
      {
        "name": "محمود",
        "rating": 4,
        "comment": "جودة كويسة وسعر مناسب مقارنة بالسوق."
      },
      {
        "name": "ياسمين",
        "rating": 5,
        "comment": "الخدمة ممتازة والتوصيل كان سريع جدًا."
      },
    ];

    return Scaffold(
      backgroundColor: const Color(0xff0A1124),
      appBar: AppBar(
        backgroundColor: const Color(0xff0D1A33),
        title: const Text("التقييمات"),
        centerTitle: true,
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: reviews.length,
        itemBuilder: (_, i) {
          final r = reviews[i];
          return Card(
            color: Colors.white.withOpacity(.06),
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: ListTile(
              title: Text(
                r["name"],
                style: const TextStyle(color: Colors.white),
              ),
              subtitle: Text(
                r["comment"],
                style: const TextStyle(color: Colors.white70),
              ),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.star, color: Colors.amber, size: 18),
                  Text("${r["rating"]}",
                      style: const TextStyle(color: Colors.white)),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
