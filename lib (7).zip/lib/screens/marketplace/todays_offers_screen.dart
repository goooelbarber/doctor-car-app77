// lib/screens/marketplace/todays_offers_screen.dart

import 'package:flutter/material.dart';
import '../../models/product_model.dart';
import 'product_details_amazon.dart';

class TodaysOffersScreen extends StatelessWidget {
  final List<ProductModel> today = ProductModel.demo.take(6).toList();

  TodaysOffersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        backgroundColor: Colors.orange.shade700,
        title: const Text("⚡ عروض اليوم"),
        centerTitle: true,
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(14),
        itemCount: today.length,
        itemBuilder: (_, i) {
          final p = today[i];
          return Card(
            elevation: 3,
            child: ListTile(
              leading: Image.network(p.image),
              title: Text(p.name, maxLines: 1),
              subtitle: Text("${p.price} EGP",
                  style: const TextStyle(color: Colors.green)),
              trailing: const Icon(Icons.arrow_forward_ios),
              onTap: () {
                Navigator.push(
                  _,
                  MaterialPageRoute(
                      builder: (_) => ProductDetailsAmazon(product: p)),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
