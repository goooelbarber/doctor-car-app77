// lib/screens/marketplace/products_by_brand_screen.dart

import 'package:flutter/material.dart';
import '../../models/product_model.dart';
import 'product_details_amazon.dart';

class ProductsByBrandScreen extends StatelessWidget {
  final String brand;

  const ProductsByBrandScreen({super.key, required this.brand});

  @override
  Widget build(BuildContext context) {
    // فلترة المنتجات حسب الماركة
    List<ProductModel> products =
        ProductModel.demo.where((p) => p.brand == brand).toList();

    return Scaffold(
      backgroundColor: Colors.grey.shade200,
      appBar: AppBar(
        backgroundColor: Colors.amber.shade700,
        elevation: 0,
        title: Text("منتجات $brand"),
        centerTitle: true,
      ),
      body: products.isEmpty
          ? Center(
              child: Text(
                "لا توجد منتجات متاحة لهذه الماركة",
                style: TextStyle(fontSize: 18, color: Colors.grey.shade700),
              ),
            )
          : GridView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: products.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: .70,
              ),
              itemBuilder: (_, i) {
                final p = products[i];

                return GestureDetector(
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => ProductDetailsAmazon(product: p)),
                  ),
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      children: [
                        Expanded(
                          child: Image.network(
                            p.image,
                            fit: BoxFit.contain,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Column(
                            children: [
                              Text(
                                p.name,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(fontSize: 14),
                                textAlign: TextAlign.center,
                              ),
                              const SizedBox(height: 4),
                              Text(
                                "${p.price} EGP",
                                style: const TextStyle(
                                  color: Colors.green,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}
