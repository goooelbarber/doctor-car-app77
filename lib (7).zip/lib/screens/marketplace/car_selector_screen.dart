import 'package:flutter/material.dart';

class CarSelectorScreen extends StatefulWidget {
  const CarSelectorScreen({super.key});

  @override
  State<CarSelectorScreen> createState() => _CarSelectorScreenState();
}

class _CarSelectorScreenState extends State<CarSelectorScreen> {
  String? brand;
  String? model;
  String? year;

  List<String> brands = ["Hyundai", "Kia", "Toyota", "BMW", "Mercedes"];
  List<String> hyundaiModels = ["Verna", "Accent", "Elantra"];
  List<String> kiaModels = ["Cerato", "Sportage"];
  List<String> toyotaModels = ["Corolla", "Yaris"];
  List<String> years = ["2015", "2016", "2017", "2018", "2019", "2020"];

  List<String> getModels() {
    if (brand == "Hyundai") return hyundaiModels;
    if (brand == "Kia") return kiaModels;
    if (brand == "Toyota") return toyotaModels;
    return [];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xff0A1124),
      appBar: AppBar(
        backgroundColor: const Color(0xff0D1A33),
        title: const Text("اختر سيارتك"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            _dropdown(
                "ماركة السيارة", brands, (v) => setState(() => brand = v)),
            const SizedBox(height: 12),
            _dropdown("الموديل", getModels(), (v) => setState(() => model = v)),
            const SizedBox(height: 12),
            _dropdown("سنة الصنع", years, (v) => setState(() => year = v)),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {},
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blueAccent,
                minimumSize: const Size(double.infinity, 50),
              ),
              child: const Text("عرض قطع الغيار المناسبة"),
            )
          ],
        ),
      ),
    );
  }

  Widget _dropdown(
      String label, List<String> items, Function(String?) onChange) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
          color: Colors.white.withOpacity(.08),
          borderRadius: BorderRadius.circular(12)),
      child: DropdownButton<String>(
        hint: Text(label, style: const TextStyle(color: Colors.white54)),
        value: items.contains(label) ? null : null,
        onChanged: onChange,
        dropdownColor: const Color(0xff0D1A33),
        isExpanded: true,
        underline: const SizedBox(),
        items: items
            .map((e) => DropdownMenuItem(
                value: e,
                child: Text(e, style: const TextStyle(color: Colors.white))))
            .toList(),
      ),
    );
  }
}
