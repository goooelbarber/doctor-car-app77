// lib/screens/marketplace/ai_advisor_widget.dart

import 'package:flutter/material.dart';

class AIAdvisorWidget extends StatelessWidget {
  const AIAdvisorWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        gradient: const LinearGradient(
          colors: [Color(0xff3D8BFF), Color(0xff64A8FF)],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.blue.withOpacity(.4),
            blurRadius: 18,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Row(
        children: [
          const Icon(Icons.smart_toy, color: Colors.white, size: 34),
          const SizedBox(width: 12),
          const Expanded(
            child: Text(
              "مش عارف تختار القطعة المناسبة لعربيتك؟ اسأل مستشار دكتور كار الذكي يساعدك تختار أفضل منتج.",
              style: TextStyle(
                color: Colors.white,
                height: 1.4,
              ),
            ),
          ),
          const SizedBox(width: 8),
          ElevatedButton(
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text("🤖 نسخة تجريبية: سيتم ربطه بالشات لاحقًا"),
                ),
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.white,
              foregroundColor: Colors.blueAccent,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            ),
            child: const Text("اسأل الآن"),
          )
        ],
      ),
    );
  }
}
