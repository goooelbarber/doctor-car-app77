import 'dart:async';
import 'package:flutter/material.dart';

class FlashSaleWidget extends StatefulWidget {
  const FlashSaleWidget({super.key});

  @override
  State<FlashSaleWidget> createState() => _FlashSaleWidgetState();
}

class _FlashSaleWidgetState extends State<FlashSaleWidget> {
  Duration timeLeft = const Duration(hours: 5);

  @override
  void initState() {
    super.initState();
    Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) {
        setState(() => timeLeft -= const Duration(seconds: 1));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 180,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.red.withOpacity(.1),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text("🔥 Flash Sale",
              style: TextStyle(
                  color: Colors.redAccent,
                  fontSize: 22,
                  fontWeight: FontWeight.bold)),
          Text(
              "الوقت المتبقي: ${timeLeft.inHours}:${timeLeft.inMinutes % 60}:${timeLeft.inSeconds % 60}",
              style: const TextStyle(color: Colors.white, fontSize: 16)),
          const SizedBox(height: 10),
          Expanded(
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                _saleItem(
                    "زيت موبيل 1", "https://i.imgur.com/EB5scLH.png", 950, 750),
                _saleItem("بطارية ACDelco", "https://i.imgur.com/Vz5h9CU.png",
                    3500, 2999),
                _saleItem(
                    "مساحات بوش", "https://i.imgur.com/SlWwYlH.png", 400, 250),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _saleItem(String name, String img, int oldPrice, int newPrice) {
    return Container(
      width: 140,
      margin: const EdgeInsets.only(right: 12),
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.05),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        children: [
          Image.network(img, height: 70),
          const SizedBox(height: 6),
          Text(name,
              style: const TextStyle(color: Colors.white),
              textAlign: TextAlign.center),
          const SizedBox(height: 4),
          Text("$newPrice ج.م",
              style: const TextStyle(color: Colors.yellow, fontSize: 16)),
          Text("$oldPrice ج.م",
              style: const TextStyle(
                  color: Colors.white54,
                  decoration: TextDecoration.lineThrough)),
        ],
      ),
    );
  }
}
