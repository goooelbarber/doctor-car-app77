import 'package:flutter/material.dart';
import '../products_by_brand_screen.dart';

class BrandsHorizontalList extends StatelessWidget {
  const BrandsHorizontalList({super.key});

  final List<Map<String, String>> brands = const [
    {"name": "BMW", "logo": "https://i.imgur.com/aOe0qZk.png"},
    {"name": "Mercedes", "logo": "https://i.imgur.com/LCWruM2.png"},
    {"name": "Audi", "logo": "https://i.imgur.com/58FIP3V.png"},
    {"name": "Toyota", "logo": "https://i.imgur.com/9p0C2aq.png"},
    {"name": "Hyundai", "logo": "https://i.imgur.com/S6O8L7p.png"},
    {"name": "Kia", "logo": "https://i.imgur.com/dpc8i8W.png"},
    {"name": "Nissan", "logo": "https://i.imgur.com/lvz9X1M.png"},
    {"name": "Chevrolet", "logo": "https://i.imgur.com/i4NdtJr.png"},
    {"name": "Mitsubishi", "logo": "https://i.imgur.com/d8nkqLZ.png"},
    {"name": "Peugeot", "logo": "https://i.imgur.com/401FNLS.png"},
    {"name": "Renault", "logo": "https://i.imgur.com/9bEo5Be.png"},
    {"name": "Fiat", "logo": "https://i.imgur.com/t3P4sax.png"},
    {"name": "Volkswagen", "logo": "https://i.imgur.com/0HZG9Nl.png"},
    {"name": "Skoda", "logo": "https://i.imgur.com/SXSPaag.png"},
    {"name": "Jeep", "logo": "https://i.imgur.com/L8ZqGRx.png"},
    {"name": "MG", "logo": "https://i.imgur.com/DLUyKxC.png"},
  ];

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 110,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: brands.length,
        itemBuilder: (context, i) {
          final item = brands[i];

          return GestureDetector(
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => ProductsByBrandScreen(brand: item["name"]!),
              ),
            ),
            child: Container(
              width: 100,
              margin: const EdgeInsets.only(right: 12),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(14),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(.08),
                    blurRadius: 6,
                    offset: const Offset(0, 3),
                  )
                ],
              ),
              child: Column(
                children: [
                  Expanded(
                    child: Image.network(item["logo"]!, fit: BoxFit.contain),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    item["name"]!,
                    style: const TextStyle(
                        fontSize: 14, fontWeight: FontWeight.bold),
                  )
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
