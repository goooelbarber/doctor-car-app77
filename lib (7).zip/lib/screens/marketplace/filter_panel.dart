import 'package:flutter/material.dart';

class FilterPanel extends StatefulWidget {
  final Function(String category, String model, int? year) onFilterChanged;

  const FilterPanel({super.key, required this.onFilterChanged});

  @override
  State<FilterPanel> createState() => _FilterPanelState();
}

class _FilterPanelState extends State<FilterPanel> {
  String selectedCategory = "All";
  String selectedModel = "All";
  int? selectedYear;

  final categories = ["All", "Battery", "Tires", "Oil", "Filters", "Brakes"];

  @override
  Widget build(BuildContext context) {
    return ExpansionTile(
      collapsedBackgroundColor: Colors.white.withOpacity(.06),
      backgroundColor: Colors.white.withOpacity(.08),
      title: const Text("Filters",
          style: TextStyle(color: Colors.white, fontSize: 16)),
      iconColor: Colors.white,
      children: [
        // Category
        _filterTitle("Category"),
        SizedBox(
          height: 50,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: categories.map((c) {
              final bool active = selectedCategory == c;
              return GestureDetector(
                onTap: () {
                  setState(() => selectedCategory = c);
                  widget.onFilterChanged(
                      selectedCategory, selectedModel, selectedYear);
                },
                child: _chip(c, active),
              );
            }).toList(),
          ),
        ),

        const SizedBox(height: 10),

        // Model search
        _filterTitle("Model"),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: TextField(
            style: const TextStyle(color: Colors.white),
            decoration: InputDecoration(
              filled: true,
              fillColor: Colors.white.withOpacity(.08),
              hintText: "Example: Elantra 2015",
              hintStyle: const TextStyle(color: Colors.white54),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
              ),
            ),
            onChanged: (v) {
              selectedModel = v.trim().isEmpty ? "All" : v.trim();
              widget.onFilterChanged(
                  selectedCategory, selectedModel, selectedYear);
            },
          ),
        ),

        const SizedBox(height: 10),
      ],
    );
  }

  Widget _chip(String text, bool active) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 6),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: active ? Colors.blueAccent : Colors.white.withOpacity(.06),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Text(text, style: const TextStyle(color: Colors.white)),
    );
  }

  Widget _filterTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(left: 12, bottom: 6),
      child: Text(title,
          style: const TextStyle(color: Colors.white70, fontSize: 14)),
    );
  }
}
