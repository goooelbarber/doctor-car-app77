// lib/screens/marketplace/brand_explorer.dart

import 'package:flutter/material.dart';
import '../../models/product_model.dart';

class BrandExplorer extends StatelessWidget {
  const BrandExplorer({super.key});

  @override
  Widget build(BuildContext context) {
    final all = ProductModel.demoProducts;

    // تجميع المنتجات حسب الماركة
    final Map<String, int> brandCounts = {};
    for (final p in all) {
      brandCounts[p.brand] = (brandCounts[p.brand] ?? 0) + 1;
    }

    final brands = brandCounts.entries.toList();

    return SizedBox(
      height: 70,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: brands.length,
        itemBuilder: (_, i) {
          final entry = brands[i];
          return Container(
            margin: const EdgeInsets.only(right: 10),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(.06),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.white.withOpacity(.12)),
            ),
            child: Row(
              children: [
                const Icon(Icons.directions_car, color: Colors.white, size: 18),
                const SizedBox(width: 6),
                Text(
                  entry.key,
                  style: const TextStyle(color: Colors.white),
                ),
                const SizedBox(width: 6),
                Text(
                  "(${entry.value})",
                  style: const TextStyle(color: Colors.white70, fontSize: 12),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
