import 'package:doctor_car_app/screens/marketplace/cart_screen.dart';
import 'package:flutter/material.dart';
import '../../models/product_model.dart';
// ignore: unused_import
import 'package:doctor_car_app/marketplace/product_details_screen.dart';

class MarketplaceScreen extends StatelessWidget {
  const MarketplaceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final products = ProductModel.demoProducts;

    return Scaffold(
      backgroundColor: const Color(0xff0A1124),
      appBar: AppBar(
        backgroundColor: const Color(0xff0D1A33),
        title: const Text("Marketplace"),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.shopping_cart_outlined),
            onPressed: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const CartScreen()));
            },
          )
        ],
      ),
      body: GridView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: products.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            mainAxisSpacing: 14,
            crossAxisSpacing: 14,
            childAspectRatio: .75),
        itemBuilder: (context, i) {
          final p = products[i];

          return GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => ProductDetailsScreen(product: p)),
              );
            },
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(.06),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                children: [
                  const SizedBox(height: 10),
                  Hero(tag: p.id, child: Image.network(p.image, height: 110)),
                  const SizedBox(height: 8),
                  Text(
                    p.name,
                    maxLines: 2,
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.white),
                  ),
                  const SizedBox(height: 4),
                  Text("${p.price} EGP",
                      style: const TextStyle(
                          color: Colors.greenAccent, fontSize: 16)),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // ignore: non_constant_identifier_names
  ProductDetailsScreen({required product}) {}
}
