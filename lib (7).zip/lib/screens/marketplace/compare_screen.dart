// lib/screens/marketplace/compare_screen.dart

import 'package:flutter/material.dart';
import '../../models/product_model.dart';

class CompareScreen extends StatelessWidget {
  final ProductModel product;

  const CompareScreen({super.key, required this.product});

  @override
  Widget build(BuildContext context) {
    // منتج منافس وهمي للمقارنة
    final competitorPrice = product.price * 1.2;

    return Scaffold(
      backgroundColor: const Color(0xff0A1124),
      appBar: AppBar(
        backgroundColor: const Color(0xff0D1A33),
        title: const Text("مقارنة الأسعار"),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          children: [
            _row(
              "منتج دكتور كار",
              "${product.price} ج.م",
              Colors.greenAccent,
            ),
            const SizedBox(height: 12),
            _row(
              "متوسط سعر السوق",
              "$competitorPrice ج.م",
              Colors.orangeAccent,
            ),
            const SizedBox(height: 30),
            Text(
              "توفر لك دكتور كار منتج ${product.brand} بسعر منافس أقل من متوسط السوق.",
              style: const TextStyle(color: Colors.white70, height: 1.6),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _row(String title, String value, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.05),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(.6)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(title,
              style: const TextStyle(
                  color: Colors.white, fontWeight: FontWeight.bold)),
          Text(value, style: TextStyle(color: color, fontSize: 16)),
        ],
      ),
    );
  }
}
