// lib/screens/marketplace/marketplace_amazon_home.dart

import 'package:flutter/material.dart';
import '../../models/product_model.dart';

import 'product_details_amazon.dart';
import 'cart_screen_amazon.dart';
// ignore: unused_import
import 'products_by_brand_screen.dart';
import 'search_screen.dart';
import 'deals_screen.dart';
import 'todays_offers_screen.dart';
import 'categories_screen.dart';
import 'garage_screen.dart';
import 'ai_market_advisor.dart';

// ★★ IMPORT للماركات الاحترافية ★★
import 'widgets/brands_horizontal_list.dart';

class MarketplaceAmazonHome extends StatefulWidget {
  const MarketplaceAmazonHome({super.key});

  @override
  State<MarketplaceAmazonHome> createState() => _MarketplaceAmazonHomeState();
}

class _MarketplaceAmazonHomeState extends State<MarketplaceAmazonHome> {
  List<ProductModel> products = ProductModel.demo;
  List<ProductModel> trending = [];
  List<ProductModel> offers = [];

  @override
  void initState() {
    super.initState();
    trending = products.where((e) => e.rating > 4.7).toList();
    offers = products.where((e) => e.hasDiscount).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade200,
      appBar: AppBar(
        backgroundColor: Colors.amber.shade700,
        elevation: 0,
        title: GestureDetector(
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const SearchScreen()),
          ),
          child: Container(
            height: 42,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              children: [
                const Icon(Icons.search, color: Colors.black54),
                const SizedBox(width: 8),
                Text(
                  "ابحث عن منتجات سيارات…",
                  style: TextStyle(color: Colors.grey.shade600),
                ),
              ],
            ),
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.local_offer_outlined, color: Colors.black),
            onPressed: () => Navigator.push(
                context, MaterialPageRoute(builder: (_) => DealsScreen())),
          ),
          IconButton(
            icon: const Icon(Icons.calendar_today, color: Colors.black),
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => TodaysOffersScreen())),
          ),
          IconButton(
            icon: const Icon(Icons.shopping_cart_outlined, color: Colors.black),
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const CartScreenAmazon())),
          ),
        ],
      ),
      body: ListView(
        children: [
          _amazonBanner(),

          // 🧠 AI Assistant
          AIMarketAdvisor(products: products),

          const SizedBox(height: 10),
          _section("🔥 العروض المميزة"),
          _horizontalProducts(offers),

          const SizedBox(height: 20),
          _section("⭐ الأكثر رواجاً"),
          _horizontalProducts(trending),

          const SizedBox(height: 20),

          // ⭐⭐ هنا تمت إضافة قائمة الماركات ⭐⭐
          _section("🏷 أشهر الماركات"),
          const SizedBox(height: 10),
          const BrandsHorizontalList(),
          // ⭐⭐ انتهى إدراج الماركات ⭐⭐

          const SizedBox(height: 20),
          _section("📦 الأقسام"),
          _categoriesShortcut(),

          const SizedBox(height: 20),
          _section("📦 جميع المنتجات"),
          _productGrid(products),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.white,
        selectedItemColor: Colors.amber.shade800,
        unselectedItemColor: Colors.grey,
        items: const [
          BottomNavigationBarItem(
              icon: Icon(Icons.storefront), label: "المتجر"),
          BottomNavigationBarItem(icon: Icon(Icons.category), label: "الأقسام"),
          BottomNavigationBarItem(
              icon: Icon(Icons.directions_car), label: "جراج"),
        ],
        onTap: (index) {
          if (index == 1) {
            Navigator.push(
                context, MaterialPageRoute(builder: (_) => CategoriesScreen()));
          } else if (index == 2) {
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const GarageScreen()));
          }
        },
      ),
    );
  }

  // ============================================================
  Widget _amazonBanner() {
    return SizedBox(
      height: 180,
      child: PageView(
        children: [
          _bannerItem("https://i.imgur.com/CK1NRhE.jpeg"),
          _bannerItem("https://i.imgur.com/I0g7cRL.jpeg"),
          _bannerItem("https://i.imgur.com/dceuYdO.jpeg"),
        ],
      ),
    );
  }

  Widget _bannerItem(String url) {
    return Padding(
      padding: const EdgeInsets.all(8),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Image.network(url, fit: BoxFit.cover),
      ),
    );
  }

  Widget _section(String t) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        child: Text(
          t,
          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
      );

  // ============================================================
  Widget _horizontalProducts(List<ProductModel> items) {
    return SizedBox(
      height: 260,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: items.length,
        itemBuilder: (_, i) {
          final p = items[i];

          return GestureDetector(
            onTap: () => Navigator.push(
              _,
              MaterialPageRoute(
                  builder: (_) => ProductDetailsAmazon(product: p)),
            ),
            child: Container(
              width: 170,
              margin: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(.1),
                    blurRadius: 5,
                    offset: const Offset(2, 3),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Expanded(child: Image.network(p.image)),
                  Padding(
                    padding: const EdgeInsets.all(6),
                    child: Column(
                      children: [
                        Text(p.name,
                            maxLines: 2, overflow: TextOverflow.ellipsis),
                        Text("${p.price} EGP",
                            style: const TextStyle(
                                color: Colors.green,
                                fontWeight: FontWeight.bold)),
                      ],
                    ),
                  )
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // ============================================================
  Widget _categoriesShortcut() {
    return SizedBox(
      height: 110,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _catBtn("زيوت", Icons.oil_barrel),
          _catBtn("بطاريات", Icons.battery_full),
          _catBtn("كاوتش", Icons.circle),
          _catBtn("فلاتر", Icons.filter_alt),
        ],
      ),
    );
  }

  Widget _catBtn(String title, IconData icon) {
    return Column(
      children: [
        CircleAvatar(
          radius: 28,
          backgroundColor: Colors.amber.shade600,
          child: Icon(icon, color: Colors.white, size: 28),
        ),
        const SizedBox(height: 6),
        Text(title),
      ],
    );
  }

  Widget _productGrid(List<ProductModel> items) {
    return GridView.builder(
      padding: const EdgeInsets.all(12),
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: items.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 12,
        crossAxisSpacing: 12,
        childAspectRatio: .70,
      ),
      itemBuilder: (_, i) {
        final p = items[i];

        return GestureDetector(
          onTap: () => Navigator.push(
            _,
            MaterialPageRoute(builder: (_) => ProductDetailsAmazon(product: p)),
          ),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: [
                Expanded(child: Image.network(p.image)),
                Padding(
                  padding: const EdgeInsets.all(8),
                  child: Column(
                    children: [
                      Text(
                        p.name,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        "${p.price} EGP",
                        style: const TextStyle(
                            color: Colors.green, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
        );
      },
    );
  }
}
