import 'package:flutter/material.dart';
import '../../models/car_brand_model.dart';

class BrandSelector extends StatelessWidget {
  final List<CarBrand> brands;
  final Function(String brand) onBrandSelected;

  const BrandSelector({
    super.key,
    required this.brands,
    required this.onBrandSelected,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 110,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        itemCount: brands.length + 1,
        itemBuilder: (_, i) {
          if (i == 0) {
            return GestureDetector(
              onTap: () => onBrandSelected("All"),
              child: _brandItem("All", "https://i.imgur.com/2yaf2jm.png"),
            );
          }

          final b = brands[i - 1];
          return GestureDetector(
            onTap: () => onBrandSelected(b.name),
            child: _brandItem(b.name, b.logo),
          );
        },
      ),
    );
  }

  Widget _brandItem(String name, String logo) {
    return Container(
      width: 95,
      margin: const EdgeInsets.symmetric(horizontal: 8),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.08),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white.withOpacity(.15)),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.network(logo, height: 45),
          const SizedBox(height: 5),
          Text(
            name,
            style: const TextStyle(color: Colors.white, fontSize: 12),
          )
        ],
      ),
    );
  }
}
