import 'package:flutter/material.dart';
import '../../models/product_model.dart';

class FilterScreen extends StatefulWidget {
  final List<ProductModel> allProducts;

  const FilterScreen({super.key, required this.allProducts});

  @override
  State<FilterScreen> createState() => _FilterScreenState();
}

class _FilterScreenState extends State<FilterScreen> {
  String? selectedBrand;
  String? selectedCategory;
  double minPrice = 0;
  double maxPrice = 10000;
  double minRating = 0;

  // جميع الماركات الموجودة
  List<String> brands = [];
  List<String> categories = [];

  @override
  void initState() {
    super.initState();

    brands = widget.allProducts.map((e) => e.brand).toSet().toList();
    categories = widget.allProducts.map((e) => e.category).toSet().toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade200,
      appBar: AppBar(
        backgroundColor: Colors.amber.shade700,
        title: const Text("فلترة المنتجات"),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _title("الماركة"),
          _dropdown(brands, selectedBrand, (v) {
            setState(() => selectedBrand = v);
          }),
          const SizedBox(height: 20),
          _title("الفئة"),
          _dropdown(categories, selectedCategory, (v) {
            setState(() => selectedCategory = v);
          }),
          const SizedBox(height: 20),
          _title("السعر (حد أدنى)"),
          Slider(
            value: minPrice,
            min: 0,
            max: maxPrice,
            divisions: 20,
            label: "${minPrice.round()}",
            onChanged: (v) => setState(() => minPrice = v),
          ),
          const SizedBox(height: 20),
          _title("الحد الأقصى للسعر"),
          Slider(
            value: maxPrice,
            min: minPrice,
            max: 50000,
            divisions: 20,
            label: "${maxPrice.round()}",
            onChanged: (v) => setState(() => maxPrice = v),
          ),
          const SizedBox(height: 20),
          _title("التقييم (نجوم)"),
          Slider(
            value: minRating,
            min: 0,
            max: 5,
            divisions: 5,
            label: "$minRating ⭐",
            onChanged: (v) => setState(() => minRating = v),
          ),
          const SizedBox(height: 35),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.amber.shade700,
              minimumSize: const Size(double.infinity, 50),
            ),
            onPressed: _applyFilter,
            child: const Text(
              "تطبيق الفلتر",
              style: TextStyle(fontSize: 18),
            ),
          ),
        ],
      ),
    );
  }

  // ================================================================
  Widget _dropdown(
      List<String> items, String? value, Function(String?) onChange) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.black12),
      ),
      child: DropdownButton<String>(
        value: value,
        hint: const Text("اختر"),
        isExpanded: true,
        underline: const SizedBox(),
        onChanged: onChange,
        items: items.map((e) {
          return DropdownMenuItem(
            value: e,
            child: Text(e),
          );
        }).toList(),
      ),
    );
  }

  // ================================================================
  Widget _title(String t) => Text(
        t,
        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
      );

  // ================================================================
  void _applyFilter() {
    List<ProductModel> result = widget.allProducts.where((p) {
      bool ok = true;

      if (selectedBrand != null && selectedBrand!.isNotEmpty) {
        ok &= p.brand == selectedBrand;
      }

      if (selectedCategory != null && selectedCategory!.isNotEmpty) {
        ok &= p.category == selectedCategory;
      }

      ok &= p.price >= minPrice && p.price <= maxPrice;
      ok &= p.rating >= minRating;

      return ok;
    }).toList();

    Navigator.pop(context, result);
  }
}
