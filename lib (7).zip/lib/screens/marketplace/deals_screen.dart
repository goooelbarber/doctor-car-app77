// lib/screens/marketplace/deals_screen.dart

import 'package:flutter/material.dart';
import '../../models/product_model.dart';
import 'product_details_amazon.dart';

class DealsScreen extends StatelessWidget {
  final List<ProductModel> deals =
      ProductModel.demo.where((p) => p.hasDiscount).toList();

  DealsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade200,
      appBar: AppBar(
        backgroundColor: Colors.red.shade700,
        title: const Text("🔥 عروض قوية"),
        centerTitle: true,
      ),
      body: GridView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: deals.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          childAspectRatio: .72,
        ),
        itemBuilder: (_, i) {
          final p = deals[i];
          return GestureDetector(
            onTap: () => Navigator.push(
              _,
              MaterialPageRoute(
                  builder: (_) => ProductDetailsAmazon(product: p)),
            ),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.red.shade300, width: 1.5),
              ),
              child: Column(
                children: [
                  Expanded(child: Image.network(p.image)),
                  const SizedBox(height: 6),
                  Text(p.name,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 15)),
                  const SizedBox(height: 4),
                  Text("${p.price} EGP",
                      style: const TextStyle(
                          color: Colors.green, fontWeight: FontWeight.bold)),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
