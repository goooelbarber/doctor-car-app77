// lib/screens/marketplace/cart_screen.dart

import 'package:flutter/material.dart';
import '../../models/product_model.dart';

class CartScreen extends StatefulWidget {
  static List<ProductModel> cartItems = [];

  const CartScreen({super.key});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  double get totalPrice {
    return CartScreen.cartItems.fold(
      0,
      (sum, item) => sum + item.price,
    );
  }

  @override
  Widget build(BuildContext context) {
    final items = CartScreen.cartItems;

    return Scaffold(
      backgroundColor: const Color(0xff0A1124),
      appBar: AppBar(
        backgroundColor: const Color(0xff0D1A33),
        title: const Text("سلة المشتريات"),
        centerTitle: true,
      ),
      body: items.isEmpty
          ? const Center(
              child: Text(
                "السلة فارغة",
                style: TextStyle(color: Colors.white, fontSize: 20),
              ),
            )
          : Column(
              children: [
                Expanded(
                  child: ListView.builder(
                    itemCount: items.length,
                    padding: const EdgeInsets.all(10),
                    itemBuilder: (_, i) {
                      final product = items[i];

                      return Container(
                        margin: const EdgeInsets.symmetric(vertical: 8),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: const Color(0xff131B33),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Row(
                          children: [
                            // IMAGE
                            Container(
                              width: 80,
                              height: 80,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(10),
                                image: DecorationImage(
                                  image: NetworkImage(product.image),
                                  fit: BoxFit.contain,
                                ),
                              ),
                            ),

                            const SizedBox(width: 12),

                            // NAME + PRICE
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    product.name,
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                        fontSize: 15, color: Colors.white),
                                  ),
                                  const SizedBox(height: 6),
                                  Text(
                                    "${product.price} EGP",
                                    style: const TextStyle(
                                      color: Colors.greenAccent,
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                            ),

                            // DELETE BTN
                            IconButton(
                              icon: const Icon(Icons.delete,
                                  color: Colors.redAccent),
                              onPressed: () {
                                setState(() {
                                  CartScreen.cartItems.removeAt(i);
                                });
                              },
                            )
                          ],
                        ),
                      );
                    },
                  ),
                ),

                // ================= TOTAL BOX =================
                Container(
                  padding:
                      const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
                  decoration: const BoxDecoration(
                    color: Color(0xff0D1A33),
                    borderRadius:
                        BorderRadius.vertical(top: Radius.circular(18)),
                  ),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            "الإجمالي:",
                            style: TextStyle(color: Colors.white, fontSize: 18),
                          ),
                          Text(
                            "$totalPrice EGP",
                            style: const TextStyle(
                              color: Colors.greenAccent,
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 16),

                      // CHECKOUT BUTTON
                      SizedBox(
                        width: double.infinity,
                        height: 55,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.greenAccent.shade700,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                          onPressed: () {
                            _showCheckoutDialog();
                          },
                          child: const Text(
                            "إتمام الطلب",
                            style: TextStyle(color: Colors.white, fontSize: 18),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
    );
  }

  // ====================== CHECKOUT POPUP ======================
  void _showCheckoutDialog() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xff131B33),
        title: const Text("إتمام الطلب", style: TextStyle(color: Colors.white)),
        content: const Text(
          "هل تريد تأكيد الشراء؟",
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            child: const Text("إلغاء", style: TextStyle(color: Colors.red)),
            onPressed: () => Navigator.pop(context),
          ),
          TextButton(
            child: const Text("تأكيد",
                style: TextStyle(color: Colors.greenAccent)),
            onPressed: () {
              CartScreen.cartItems.clear();
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text("✔ تم إتمام الطلب بنجاح"),
                  backgroundColor: Colors.green,
                ),
              );
              setState(() {});
            },
          ),
        ],
      ),
    );
  }
}
