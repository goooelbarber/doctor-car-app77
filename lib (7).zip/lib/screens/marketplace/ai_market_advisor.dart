// lib/screens/marketplace/ai_market_advisor.dart

import 'package:flutter/material.dart';
import '../../models/product_model.dart';
import 'product_details_amazon.dart';

class AIMarketAdvisor extends StatelessWidget {
  final List<ProductModel> products;

  const AIMarketAdvisor({super.key, required this.products});

  List<ProductModel> getSuggestions() {
    return products.where((p) => p.rating > 4.6).take(4).toList();
  }

  @override
  Widget build(BuildContext context) {
    final suggestions = getSuggestions();

    return Container(
      margin: const EdgeInsets.all(12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.blue.shade50,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.blue.shade200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text("🤖 توصيات ذكية لك:",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          SizedBox(
            height: 150,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: suggestions.length,
              itemBuilder: (_, i) {
                final p = suggestions[i];
                return GestureDetector(
                  onTap: () {
                    Navigator.push(
                      _,
                      MaterialPageRoute(
                          builder: (_) => ProductDetailsAmazon(product: p)),
                    );
                  },
                  child: Container(
                    width: 130,
                    margin: const EdgeInsets.only(right: 10),
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      children: [
                        Expanded(child: Image.network(p.image)),
                        Text(
                          p.name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        )
                      ],
                    ),
                  ),
                );
              },
            ),
          )
        ],
      ),
    );
  }
}
