// lib/screens/marketplace/checkout_screen.dart

import 'package:flutter/material.dart';

class CheckoutScreen extends StatelessWidget {
  final double total;

  const CheckoutScreen({super.key, required this.total});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xff0A1124),
      appBar: AppBar(
        backgroundColor: const Color(0xff0D1A33),
        title: const Text("إتمام الشراء"),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "مراجعة الطلب",
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            Text(
              "إجمالي المبلغ المستحق: $total ج.م",
              style: const TextStyle(
                  color: Colors.greenAccent,
                  fontSize: 22,
                  fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 30),
            const Text(
              "سيتم التواصل معك من خدمة العملاء لتأكيد العنوان وطريقة الدفع.",
              style: TextStyle(color: Colors.white70, height: 1.6),
            ),
            const Spacer(),
            ElevatedButton(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text("✅ تم إرسال طلبك بنجاح"),
                  ),
                );
                Navigator.pop(context); // رجوع من صفحة الدفع
                Navigator.pop(context); // رجوع من السلة
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blueAccent,
                minimumSize: const Size(double.infinity, 55),
              ),
              child: const Text(
                "تأكيد الطلب",
                style: TextStyle(fontSize: 18),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
