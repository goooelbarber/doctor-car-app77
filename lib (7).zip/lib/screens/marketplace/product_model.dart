// lib/screens/marketplace/product_model.dart

class ProductModel {
  final String name;
  final String image;
  final String description;
  final double price;
  final bool homeService;
  final bool workshopService;
  final bool deliveryOnly;

  ProductModel({
    required this.name,
    required this.image,
    required this.description,
    required this.price,
    required this.homeService,
    required this.workshopService,
    required this.deliveryOnly,
  });
}
