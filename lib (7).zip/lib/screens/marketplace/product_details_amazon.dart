import 'package:flutter/material.dart';
import '../../models/product_model.dart';
import 'cart_screen_amazon.dart';

class ProductDetailsAmazon extends StatefulWidget {
  final ProductModel product;
  const ProductDetailsAmazon({super.key, required this.product});

  @override
  State<ProductDetailsAmazon> createState() => _ProductDetailsAmazonState();
}

class _ProductDetailsAmazonState extends State<ProductDetailsAmazon> {
  int quantity = 1;

  @override
  Widget build(BuildContext context) {
    final p = widget.product;

    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        backgroundColor: Colors.amber.shade700,
        title: Text(
          p.name,
          style: const TextStyle(fontSize: 16),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.shopping_cart_outlined),
            onPressed: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const CartScreenAmazon()));
            },
          )
        ],
      ),
      body: ListView(
        children: [
          // ===================== PRODUCT IMAGES =====================
          Container(
            height: 300,
            padding: const EdgeInsets.all(12),
            child: Hero(
              tag: p.id,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.network(p.image, fit: BoxFit.contain),
              ),
            ),
          ),

          // ===================== BLOCK =====================
          Container(
            padding: const EdgeInsets.all(14),
            color: Colors.white,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  p.name,
                  style: const TextStyle(
                      fontSize: 20, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 6),

                // Rating Stars
                Row(
                  children: [
                    Icon(Icons.star, color: Colors.amber.shade700, size: 22),
                    Text(" ${p.rating} ", style: const TextStyle(fontSize: 16)),
                    Text("(تقييمات ممتازة)",
                        style: TextStyle(color: Colors.grey.shade700)),
                  ],
                ),

                const SizedBox(height: 14),

                // Price Section
                Row(
                  children: [
                    Text(
                      "${p.price} EGP",
                      style: const TextStyle(
                          color: Colors.green,
                          fontSize: 26,
                          fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(width: 10),
                    if (p.hasDiscount)
                      Text(
                        "${p.oldPrice} EGP",
                        style: const TextStyle(
                          color: Colors.red,
                          fontSize: 16,
                          decoration: TextDecoration.lineThrough,
                        ),
                      ),
                  ],
                ),

                const SizedBox(height: 10),

                // Shipping Badge
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: Colors.green.shade600,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Text(
                    "✔ شحن مجاني | توصيل خلال 24 ساعة",
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 10),

          // ===================== DESCRIPTION =====================
          Container(
            padding: const EdgeInsets.all(14),
            color: Colors.white,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("الوصف",
                    style:
                        TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text(
                  p.description,
                  style: TextStyle(
                      fontSize: 15, color: Colors.grey.shade800, height: 1.5),
                ),
              ],
            ),
          ),

          const SizedBox(height: 10),

          // ===================== QUANTITY =====================
          Container(
            padding: const EdgeInsets.all(14),
            color: Colors.white,
            child: Row(
              children: [
                const Text("الكمية:",
                    style:
                        TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(width: 10),
                IconButton(
                    onPressed: () {
                      if (quantity > 1) {
                        setState(() => quantity--);
                      }
                    },
                    icon: const Icon(Icons.remove_circle_outline)),
                Text("$quantity",
                    style: const TextStyle(
                        fontSize: 20, fontWeight: FontWeight.bold)),
                IconButton(
                    onPressed: () {
                      setState(() => quantity++);
                    },
                    icon: const Icon(Icons.add_circle_outline)),
              ],
            ),
          ),

          const SizedBox(height: 10),

          // ===================== ADD TO CART =====================
          Container(
            padding: const EdgeInsets.all(14),
            color: Colors.white,
            child: Column(
              children: [
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.amber.shade700,
                        padding: const EdgeInsets.symmetric(vertical: 14)),
                    onPressed: () {
                      CartScreenAmazon.cartItems.addAll(List.generate(
                          quantity, (_) => p)); // add multiple quantity
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                          content: Text("✔ تم إضافة المنتج إلى السلة")));
                    },
                    icon: const Icon(Icons.add_shopping_cart),
                    label: const Text("أضف إلى السلة",
                        style: TextStyle(fontSize: 16)),
                  ),
                ),
                const SizedBox(height: 10),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton(
                    style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14)),
                    onPressed: () {},
                    child: const Text("أضف إلى المقارنة",
                        style: TextStyle(fontSize: 16)),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 30),
        ],
      ),
    );
  }
}
