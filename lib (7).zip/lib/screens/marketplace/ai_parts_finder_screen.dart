import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class AIPartsFinderScreen extends StatefulWidget {
  const AIPartsFinderScreen({super.key});

  @override
  State<AIPartsFinderScreen> createState() => _AIPartsFinderScreenState();
}

class _AIPartsFinderScreenState extends State<AIPartsFinderScreen> {
  final TextEditingController _controller = TextEditingController();
  String? responseText;

  final String apiKey = "YOUR_OPENAI_KEY";

  Future<void> askAI() async {
    String query = _controller.text.trim();
    if (query.isEmpty) return;

    setState(() => responseText = "جارِ تحليل المشكلة...");

    final r = await http.post(
      Uri.parse("https://api.openai.com/v1/chat/completions"),
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer $apiKey",
      },
      body: jsonEncode({
        "model": "gpt-3.5-turbo",
        "messages": [
          {
            "role": "system",
            "content":
                "You are an AI Auto Parts Expert. Your job is to suggest the correct spare parts based on car model and problem. Answer in Arabic. Include estimated prices in Egypt."
          },
          {"role": "user", "content": query}
        ]
      }),
    );

    final data = jsonDecode(r.body);
    setState(() {
      responseText = data["choices"][0]["message"]["content"];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xff0A1124),
      appBar: AppBar(
        backgroundColor: const Color(0xff0D1A33),
        title: const Text("AI Auto Parts Finder"),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Input Field
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(.08),
                borderRadius: BorderRadius.circular(12),
              ),
              child: TextField(
                controller: _controller,
                style: const TextStyle(color: Colors.white),
                maxLines: 2,
                decoration: const InputDecoration(
                  border: InputBorder.none,
                  hintText: "اكتب موديل سيارتك والمشكلة...",
                  hintStyle: TextStyle(color: Colors.white54),
                ),
              ),
            ),

            const SizedBox(height: 12),

            ElevatedButton(
              onPressed: askAI,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blueAccent,
                minimumSize: const Size(double.infinity, 50),
              ),
              child: const Text("🔍 ابحث بالذكاء الاصطناعي",
                  style: TextStyle(fontSize: 18)),
            ),

            const SizedBox(height: 20),

            // AI Response
            Expanded(
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(.05),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: SingleChildScrollView(
                  child: Text(
                    responseText ??
                        "استخدم الذكاء الاصطناعي للعثور على قطع سيارتك",
                    style: const TextStyle(
                        color: Colors.white, fontSize: 16, height: 1.5),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
