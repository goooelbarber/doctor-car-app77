import 'package:flutter/material.dart';
import '../../models/product_model.dart';
// ignore: unused_import
import 'product_details_screen.dart';

class ProductsByBrandScreen extends StatelessWidget {
  final String brand;

  const ProductsByBrandScreen({super.key, required this.brand});

  @override
  Widget build(BuildContext context) {
    final filtered =
        ProductModel.demoProducts.where((p) => p.brand == brand).toList();

    return Scaffold(
      backgroundColor: const Color(0xff0A1124),
      appBar: AppBar(
        backgroundColor: const Color(0xff0D1A33),
        title: Text("منتجات $brand"),
      ),
      body: GridView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: filtered.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            mainAxisSpacing: 14,
            crossAxisSpacing: 14,
            childAspectRatio: .78),
        itemBuilder: (_, i) {
          final p = filtered[i];
          return GestureDetector(
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => ProductDetailsScreen(product: p),
              ),
            ),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(.08),
                borderRadius: BorderRadius.circular(18),
              ),
              child: Column(
                children: [
                  const SizedBox(height: 12),
                  Image.network(p.image, height: 110),
                  const SizedBox(height: 6),
                  Text(p.name,
                      maxLines: 2,
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.white)),
                  const SizedBox(height: 6),
                  Text("${p.price} EGP",
                      style: const TextStyle(
                          color: Colors.greenAccent,
                          fontSize: 16,
                          fontWeight: FontWeight.bold)),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // ignore: non_constant_identifier_names
  ProductDetailsScreen({required product}) {}
}
