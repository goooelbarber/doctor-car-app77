// lib/screens/marketplace/product_details.dart

import 'package:flutter/material.dart';
import '../../models/product_model.dart';
import 'cart_screen.dart';

class ProductDetails extends StatelessWidget {
  final ProductModel product;

  const ProductDetails({super.key, required this.product});

  @override
  Widget build(BuildContext context) {
    final related = ProductModel.demo
        .where((p) => p.category == product.category && p.id != product.id)
        .toList();

    return Scaffold(
      backgroundColor: const Color(0xff0A1124),
      appBar: AppBar(
        backgroundColor: const Color(0xff0D1A33),
        title: Text(product.name, maxLines: 1),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.shopping_cart_outlined),
            onPressed: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const CartScreen()));
            },
          )
        ],
      ),

      // BODY
      body: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          // ===================== IMAGE =====================
          Hero(
            tag: product.id,
            child: Container(
              height: 260,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                image: DecorationImage(
                  image: NetworkImage(product.image),
                  fit: BoxFit.contain,
                ),
              ),
            ),
          ),

          const SizedBox(height: 20),

          // ===================== TITLE =====================
          Text(
            product.name,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 10),

          // ===================== PRICE =====================
          Row(
            children: [
              Text(
                "${product.price} EGP",
                style: const TextStyle(
                  color: Colors.greenAccent,
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              if (product.hasDiscount && product.oldPrice != null)
                Padding(
                  padding: const EdgeInsets.only(left: 8.0),
                  child: Text(
                    "${product.oldPrice} EGP",
                    style: const TextStyle(
                      color: Colors.red,
                      fontSize: 16,
                      decoration: TextDecoration.lineThrough,
                    ),
                  ),
                ),
            ],
          ),

          const SizedBox(height: 15),

          // ===================== RATING =====================
          Row(
            children: [
              const Icon(Icons.star, color: Colors.amber, size: 22),
              const SizedBox(width: 5),
              Text(
                product.rating.toString(),
                style: const TextStyle(color: Colors.white, fontSize: 16),
              ),
              const SizedBox(width: 10),
              const Text("(تقييم العملاء)",
                  style: TextStyle(color: Colors.grey)),
            ],
          ),

          const SizedBox(height: 20),

          // ===================== DESCRIPTION =====================
          const Text(
            "الوصف",
            style: TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            product.description,
            style: const TextStyle(color: Colors.white70, height: 1.5),
          ),

          const SizedBox(height: 25),

          // ===================== ADD TO CART =====================
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.greenAccent.shade700,
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            onPressed: () {
              CartScreen.cartItems.add(product);

              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text("✔ تم إضافة المنتج إلى السلة"),
                  backgroundColor: Colors.green,
                ),
              );
            },
            icon: const Icon(Icons.add_shopping_cart, color: Colors.white),
            label: const Text(
              "إضافة إلى السلة",
              style: TextStyle(color: Colors.white, fontSize: 18),
            ),
          ),

          const SizedBox(height: 25),

          // ===================== RELATED ITEMS =====================
          if (related.isNotEmpty) ...[
            const Text(
              "منتجات مشابهة",
              style: TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 14),
            SizedBox(
              height: 250,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: related.length,
                itemBuilder: (_, i) {
                  final r = related[i];
                  return GestureDetector(
                    onTap: () {
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ProductDetails(product: r),
                        ),
                      );
                    },
                    child: Container(
                      width: 160,
                      margin: const EdgeInsets.only(right: 12),
                      decoration: BoxDecoration(
                        color: const Color(0xff131B33),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Column(
                        children: [
                          Expanded(child: Image.network(r.image)),
                          Padding(
                            padding: const EdgeInsets.all(6),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(r.name,
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                        color: Colors.white, fontSize: 14)),
                                const SizedBox(height: 4),
                                Text(
                                  "${r.price} EGP",
                                  style: const TextStyle(
                                      color: Colors.greenAccent,
                                      fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                          )
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ],
      ),
    );
  }
}
