// lib/screens/marketplace/categories_screen.dart

import 'package:flutter/material.dart';
import '../../models/product_model.dart';
import 'product_details_amazon.dart';

class CategoriesScreen extends StatelessWidget {
  CategoriesScreen({super.key});

  final categories = {
    "زيوت المحرك": ProductModel.demo.where((e) => e.category == "oil").toList(),
    "بطاريات": ProductModel.demo.where((e) => e.category == "battery").toList(),
    "كاوتش / اطارات":
        ProductModel.demo.where((e) => e.category == "tire").toList(),
    "فلاتر": ProductModel.demo.where((e) => e.category == "filter").toList(),
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        backgroundColor: Colors.blue.shade700,
        title: const Text("📦 الأقسام"),
      ),
      body: ListView(
        children: categories.entries.map((entry) {
          return ExpansionTile(
            title: Text(entry.key,
                style:
                    const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            children: entry.value.map((p) {
              return ListTile(
                leading: Image.network(p.image),
                title: Text(p.name),
                subtitle: Text("${p.price} EGP"),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) => ProductDetailsAmazon(product: p)),
                ),
              );
            }).toList(),
          );
        }).toList(),
      ),
    );
  }
}
