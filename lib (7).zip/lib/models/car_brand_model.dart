class CarBrand {
  final String name;
  final String logo;
  final List<CarModel> models;

  CarBrand({
    required this.name,
    required this.logo,
    required this.models,
  });
}

class CarModel {
  final String name;
  final List<int> years;

  CarModel({required this.name, required this.years});
}

List<CarBrand> carBrands = [
  CarBrand(
    name: "Hyundai",
    logo: "https://i.imgur.com/7Ak9COZ.png",
    models: [
      CarModel(name: "Elantra", years: [2010, 2011, 2012, 2015, 2016, 2020]),
      CarModel(name: "Tucson", years: [2014, 2015, 2016, 2017, 2018]),
    ],
  ),
  CarBrand(
    name: "Kia",
    logo: "https://i.imgur.com/dg0bq2U.png",
    models: [
      CarModel(name: "Cerato", years: [2010, 2011, 2014, 2015, 2016, 2020]),
      CarModel(name: "Sportage", years: [2013, 2014, 2015, 2016, 2017]),
    ],
  ),
];
