// lib/models/product_model.dart

class ProductModel {
  final String id;
  final String name;
  final double price;
  final String image;
  final String description;
  final String brand;
  final String category;
  final double rating;
  final bool hasDiscount;
  final double? oldPrice;

  ProductModel({
    required this.id,
    required this.name,
    required this.price,
    required this.image,
    required this.description,
    required this.brand,
    required this.category,
    required this.rating,
    this.hasDiscount = false,
    this.oldPrice,
  });

  // ===========================
  // 🚗 منتجات جاهزة AutoZone 6.0
  // ===========================
  static List<ProductModel> demo = [
    ProductModel(
      id: "b1",
      name: "بطارية AC Delco 70 أمبير",
      price: 1850,
      oldPrice: 2100,
      brand: "ACDelco",
      category: "Batteries",
      image: "https://i.ibb.co/tPCjD5J/acdelco70.jpg",
      description: "بطارية ACDelco عالية الأداء، تناسب أغلب السيارات.",
      rating: 4.8,
      hasDiscount: true,
    ),
    ProductModel(
      id: "b2",
      name: "بطارية فارتا الألمانية 55 أمبير",
      price: 2100,
      oldPrice: 2400,
      brand: "VARTA",
      category: "Batteries",
      image: "https://i.ibb.co/9c0wV4f/varta55.jpg",
      description: "أفضل بطارية ألمانية، قوة تشغيل ممتازة.",
      rating: 4.9,
      hasDiscount: true,
    ),
    ProductModel(
      id: "t1",
      name: "كاوتش Michelin R17",
      price: 2500,
      brand: "Michelin",
      category: "Tires",
      image: "https://i.ibb.co/DV6fM6D/michelin17.jpg",
      description: "كاوتش فرنسي ممتاز مناسب لجميع الطرق.",
      rating: 4.7,
    ),
    ProductModel(
      id: "t2",
      name: "Firestone Tire R16",
      price: 1950,
      brand: "Firestone",
      category: "Tires",
      image: "https://i.ibb.co/2n7P0cw/firestone16.jpg",
      description: "كاوتش يتحمل الضغط والتحميل، ثبات ممتاز.",
      rating: 4.6,
    ),
    ProductModel(
      id: "o1",
      name: "زيت Mobil 1 تخليقي 5W-30",
      price: 1150,
      brand: "Mobil",
      category: "Oils",
      image: "https://i.ibb.co/ZM0wcBB/mobil1.jpg",
      description: "أفضل زيت تخليقي لحماية المحرك وزيادة العمر.",
      rating: 4.9,
    ),
    ProductModel(
      id: "f1",
      name: "فلتر هواء أصلي Toyota",
      price: 450,
      brand: "Toyota",
      category: "Filters",
      image: "https://i.ibb.co/5kQJ86R/toyota-air.jpg",
      description: "فلتر عالي الجودة يحسن أداء المحرك.",
      rating: 4.8,
    ),
  ];

  static get demoProducts => null;
}
