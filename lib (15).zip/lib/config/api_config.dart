// PATH: lib/config/api_config.dart

class ApiConfig {
  // ===============================
  // 🌐 Backend (Local Network)
  // ⚠️ لازم يكون نفس IP + PORT اللي السيرفر شغال عليهم
  // ===============================
  static const String baseUrl = "http://192.168.1.8:5000";
  static const String socketUrl = "http://192.168.1.8:5000";

  // ===============================
  // 🗺️ Google Maps
  // ===============================
  static const String googleMapsApiKey =
      "AIzaSyD9BGSScE-DU9nbdFgIbJV4fbNspNdPg_M";

  static String autocomplete(String text) =>
      "https://maps.googleapis.com/maps/api/place/autocomplete/json"
      "?input=$text&key=$googleMapsApiKey&language=ar&components=country:eg";

  static String placeDetails(String placeId) =>
      "https://maps.googleapis.com/maps/api/place/details/json"
      "?place_id=$placeId&key=$googleMapsApiKey&language=ar";

  // ===============================
  // 📦 Backend APIs
  // ===============================
  static String get orders => "$baseUrl/api/orders";
  static String get technicians => "$baseUrl/api/technicians";
  static String get feedback => "$baseUrl/api/feedback";
  static String get payments => "$baseUrl/api/payments";

  // ===============================
  // 💬 Support Chat REST
  // ===============================
  static String get support => "$baseUrl/api/support";
  static String get supportChats => "$baseUrl/api/support/chats";
  static String supportMessages(String chatId) =>
      "$baseUrl/api/support/chats/$chatId/messages";

  // ===============================
  // 🚕 Orders
  // ===============================
  static String get createOrder => "$baseUrl/api/orders";

  // ===============================
  // 🔐 Auth
  // ===============================
  static String get userLogin => "$baseUrl/api/users/login";
  static String get technicianLogin => "$baseUrl/api/technicians/login";
}
