// PATH: lib/screens/support_chat_screen.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../services/socket_service.dart';
import '../services/support_chat_service.dart';

class ChatMessage {
  final String localId;
  String? id;
  final String senderType; // user | technician
  final String text;
  final DateTime createdAt;
  String status; // sending | sent | failed
  final DateTime? readByTechnicianAt;

  ChatMessage({
    required this.localId,
    required this.senderType,
    required this.text,
    required this.createdAt,
    required this.status,
    this.id,
    this.readByTechnicianAt,
  });

  static DateTime _parse(dynamic v) {
    if (v == null) return DateTime.now();
    try {
      return DateTime.parse(v.toString()).toLocal();
    } catch (_) {
      return DateTime.now();
    }
  }

  factory ChatMessage.fromServer(Map<String, dynamic> m) {
    return ChatMessage(
      localId:
          (m["clientTempId"] ?? m["_id"] ?? UniqueKey().toString()).toString(),
      id: m["_id"]?.toString(),
      senderType: (m["senderType"] ?? "system").toString(),
      text: (m["text"] ?? "").toString(),
      createdAt: _parse(m["createdAt"]),
      status: "sent",
      readByTechnicianAt: m["readByTechnicianAt"] != null
          ? _parse(m["readByTechnicianAt"])
          : null,
    );
  }
}

class SupportChatScreen extends StatefulWidget {
  final String chatId;

  const SupportChatScreen({
    super.key,
    required this.chatId,
  });

  @override
  State<SupportChatScreen> createState() => _SupportChatScreenState();
}

class _SupportChatScreenState extends State<SupportChatScreen> {
  final SocketService socket = SocketService();

  final TextEditingController _controller = TextEditingController();
  final ScrollController _scroll = ScrollController();

  bool loading = true;
  bool socketConnected = false;
  bool otherTyping = false;

  final List<ChatMessage> _messages = [];
  Timer? _typingTimer;
  bool _nearBottom = true;

  // ======================================================
  // INIT
  // ======================================================

  @override
  void initState() {
    super.initState();
    _scroll.addListener(_onScroll);
    _init();
  }

  void _onScroll() {
    if (!_scroll.hasClients) return;
    final max = _scroll.position.maxScrollExtent;
    final cur = _scroll.position.pixels;
    _nearBottom = (max - cur) < 140;
  }

  Future<void> _init() async {
    try {
      socket.connect();

      socket.onConnectionChanged((c) {
        if (!mounted) return;
        setState(() => socketConnected = c);
      });

      // join chat room
      socket.joinSupportChat(widget.chatId);

      // mark as read
      socket.emitSupportRead(
        chatId: widget.chatId,
        readerType: "user",
      );

      // load history
      final old = await SupportChatService.getMessages(widget.chatId);
      _messages
        ..clear()
        ..addAll(old.map(ChatMessage.fromServer));

      // realtime
      socket.onSupportMessage(_onNewMessage);
      socket.onSupportTyping(_onTyping);
      socket.onSupportAck(_onAck);

      setState(() => loading = false);

      WidgetsBinding.instance.addPostFrameCallback((_) => _jumpDown());
    } catch (e) {
      debugPrint("❌ SupportChat init error: $e");
      if (mounted) setState(() => loading = false);
    }
  }

  // ======================================================
  // SOCKET EVENTS
  // ======================================================

  void _onNewMessage(Map<String, dynamic> m) {
    if (!mounted) return;

    final msg = ChatMessage.fromServer(m);
    final exists = _messages.any((x) => x.id != null && x.id == msg.id);

    if (!exists) {
      setState(() => _messages.add(msg));
      _maybeScrollDown();
    }

    socket.emitSupportRead(
      chatId: widget.chatId,
      readerType: "user",
    );
  }

  void _onAck(Map<String, dynamic> ack) {
    final tempId = ack["clientTempId"]?.toString();
    final serverId = ack["serverId"]?.toString();

    final i = _messages.indexWhere((m) => m.localId == tempId);
    if (i != -1) {
      setState(() {
        _messages[i].status = "sent";
        _messages[i].id = serverId;
      });
    }
  }

  void _onTyping(Map<String, dynamic> payload) {
    if (!mounted) return;
    if (payload["senderType"] == "user") return;
    setState(() => otherTyping = payload["typing"] == true);
  }

  // ======================================================
  // SEND
  // ======================================================

  void _send() {
    if (!socketConnected) return;

    final text = _controller.text.trim();
    if (text.isEmpty) return;

    final tempId = DateTime.now().microsecondsSinceEpoch.toString();

    final msg = ChatMessage(
      localId: tempId,
      senderType: "user",
      text: text,
      createdAt: DateTime.now(),
      status: "sending",
    );

    setState(() => _messages.add(msg));
    _controller.clear();
    _jumpDown();

    socket.sendSupportMessage(
      chatId: widget.chatId,
      text: text,
      senderType: "user",
      clientTempId: tempId,
    );

    Future.delayed(const Duration(seconds: 7), () {
      final i = _messages.indexWhere((m) => m.localId == tempId);
      if (!mounted || i == -1) return;
      if (_messages[i].status == "sending") {
        setState(() => _messages[i].status = "failed");
      }
    });

    _emitTyping(false);
  }

  void _emitTyping(bool typing) {
    socket.emitSupportTyping(
      chatId: widget.chatId,
      typing: typing,
      senderType: "user",
    );
  }

  void _onTypingChanged(String _) {
    _emitTyping(true);
    _typingTimer?.cancel();
    _typingTimer =
        Timer(const Duration(milliseconds: 600), () => _emitTyping(false));
  }

  // ======================================================
  // SCROLL
  // ======================================================

  void _maybeScrollDown() {
    if (_nearBottom) _jumpDown();
  }

  void _jumpDown() {
    if (!_scroll.hasClients) return;
    _scroll.jumpTo(_scroll.position.maxScrollExtent);
  }

  // ======================================================
  // UI
  // ======================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF070B14),
      appBar: AppBar(
        backgroundColor: const Color(0xFF070B14),
        elevation: 0,
        title: Text(
          "الدعم الفني",
          style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
        ),
        bottom: otherTyping
            ? PreferredSize(
                preferredSize: const Size.fromHeight(26),
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Text(
                    "الميكانيكي يكتب…",
                    style: GoogleFonts.cairo(
                      fontSize: 12,
                      color: Colors.amber,
                    ),
                  ),
                ),
              )
            : null,
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Expanded(child: _messagesView()),
                _composer(),
              ],
            ),
    );
  }

  Widget _messagesView() {
    return ListView.builder(
      controller: _scroll,
      padding: const EdgeInsets.all(14),
      itemCount: _messages.length,
      itemBuilder: (_, i) => _bubble(_messages[i]),
    );
  }

  Widget _bubble(ChatMessage m) {
    final isUser = m.senderType == "user";

    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 6),
        padding: const EdgeInsets.all(12),
        constraints: const BoxConstraints(maxWidth: 320),
        decoration: BoxDecoration(
          color: isUser ? const Color(0xFFF7C948) : const Color(0xFF111A2E),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Text(
          m.text,
          style: GoogleFonts.cairo(
            color: isUser ? Colors.black : Colors.white,
            fontSize: 14.5,
          ),
        ),
      ),
    );
  }

  Widget _composer() {
    final canSend = socketConnected && _controller.text.trim().isNotEmpty;

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
        child: Row(
          children: [
            Expanded(
              child: TextField(
                controller: _controller,
                onChanged: _onTypingChanged,
                minLines: 1,
                maxLines: 4,
                style: GoogleFonts.cairo(color: Colors.white),
                decoration: InputDecoration(
                  hintText: "اكتب رسالة...",
                  hintStyle: GoogleFonts.cairo(color: Colors.white38),
                  filled: true,
                  fillColor: const Color(0xFF111A2E),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 10),
            IconButton(
              icon: const Icon(Icons.send, color: Colors.amber),
              onPressed: canSend ? _send : null,
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _typingTimer?.cancel();
    _controller.dispose();
    _scroll.dispose();
    super.dispose();
  }
}
