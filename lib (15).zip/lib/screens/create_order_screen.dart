import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../config/api_config.dart';
import '../services/socket_service.dart';
import 'support_chat_screen.dart';

class CreateOrderScreen extends StatefulWidget {
  const CreateOrderScreen({super.key});

  @override
  State<CreateOrderScreen> createState() => _CreateOrderScreenState();
}

class _CreateOrderScreenState extends State<CreateOrderScreen> {
  final SocketService socket = SocketService();

  bool loading = false;
  String? currentOrderId;

  bool _orderAcceptedListenerAdded = false;

  String selectedService = "battery";

  final Map<String, String> services = const {
    "battery": "خدمة البطارية",
    "tow": "خدمة السحب",
    "fuel": "توصيل وقود",
    "tire": "تبديل الإطارات",
  };

  // ======================================================
  // Helpers
  // ======================================================

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg, style: GoogleFonts.cairo())),
    );
  }

  Future<String> _getUserId() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString("userId");
    if (saved != null && saved.isNotEmpty) return saved;
    return "TEMP_USER_ID";
  }

  Map<String, double> _getTempLocation() {
    return {"lat": 30.0444, "lng": 31.2357};
  }

  // ======================================================
  // SOCKET: Order Accepted
  // ======================================================

  void _listenOrderAcceptedOnce() {
    if (_orderAcceptedListenerAdded) return;
    _orderAcceptedListenerAdded = true;

    socket.onOrderAccepted((payload) {
      if (!mounted) return;

      final chatId =
          payload["chatId"]?.toString() ?? payload["_id"]?.toString();

      if (chatId == null || chatId.isEmpty) {
        _snack("تم قبول الطلب لكن chatId غير موجود");
        return;
      }

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => SupportChatScreen(chatId: chatId),
        ),
      );
    });
  }

  // ======================================================
  // CREATE ORDER
  // ======================================================

  Future<void> createOrder() async {
    if (loading) return;
    setState(() => loading = true);

    try {
      final userId = await _getUserId();
      final loc = _getTempLocation();

      final res = await http.post(
        Uri.parse(ApiConfig.createOrder),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "userId": userId,
          "serviceType": selectedService,
          "location": {
            "lat": loc["lat"],
            "lng": loc["lng"],
          },
        }),
      );

      if (res.statusCode != 201) {
        final body = res.body.isNotEmpty ? jsonDecode(res.body) : {};
        final msg = body is Map ? body["message"]?.toString() : null;
        throw Exception(msg ?? "فشل إنشاء الطلب");
      }

      final order = jsonDecode(res.body) as Map<String, dynamic>;

      currentOrderId = (order["_id"] ?? order["id"])?.toString();
      if (currentOrderId == null || currentOrderId!.isEmpty) {
        throw Exception("orderId غير موجود");
      }

      // ================= SOCKET FLOW =================

      // 1️⃣ عرف المستخدم للـ socket
      socket.emitUserOnline(userId);

      // 2️⃣ listener مرة واحدة
      _listenOrderAcceptedOnce();

      // 3️⃣ join order room
      socket.joinOrderRoom(currentOrderId!);

      _snack("تم إرسال الطلب ✅ جاري البحث عن فني قريب...");
    } catch (e) {
      _snack(
        e.toString().replaceAll("Exception:", "").trim(),
      );
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  // ======================================================
  // UI
  // ======================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0B1220),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0B1220),
        elevation: 0,
        title: Text("طلب خدمة", style: GoogleFonts.cairo()),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            _serviceSelector(),
            const SizedBox(height: 40),
            _submitButton(),
          ],
        ),
      ),
    );
  }

  Widget _serviceSelector() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "اختر نوع الخدمة",
          style: GoogleFonts.cairo(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        ...services.entries.map(
          (e) => RadioListTile<String>(
            value: e.key,
            groupValue: selectedService,
            onChanged:
                loading ? null : (v) => setState(() => selectedService = v!),
            title: Text(
              e.value,
              style: GoogleFonts.cairo(color: Colors.white),
            ),
            activeColor: Colors.amber,
          ),
        ),
      ],
    );
  }

  Widget _submitButton() {
    return SizedBox(
      width: double.infinity,
      height: 54,
      child: ElevatedButton(
        onPressed: loading ? null : createOrder,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.amber,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
        child: loading
            ? const SizedBox(
                width: 22,
                height: 22,
                child: CircularProgressIndicator(
                  color: Colors.black,
                  strokeWidth: 2.5,
                ),
              )
            : Text(
                "طلب الفني الآن",
                style: GoogleFonts.cairo(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
      ),
    );
  }
}
