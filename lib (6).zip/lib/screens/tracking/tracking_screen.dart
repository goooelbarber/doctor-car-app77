// ignore_for_file: depend_on_referenced_packages, use_build_context_synchronously

import 'dart:async';
import 'dart:ui';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

import 'engines/socket_engine.dart';
import 'engines/motion_engine.dart';
import 'engines/map_engine.dart';
import 'engines/status_engine.dart';

import 'ui/driver_card.dart';
import 'ui/payment_sheet.dart';
import 'ui/action_buttons.dart';

class TrackingScreen extends StatefulWidget {
  final String orderId;
  final String userId;
  final String baseUrl;

  const TrackingScreen({
    super.key,
    required this.orderId,
    required this.userId,
    required this.baseUrl,
  });

  @override
  State<TrackingScreen> createState() => _TrackingScreenState();
}

class _TrackingScreenState extends State<TrackingScreen>
    with TickerProviderStateMixin {
  // Engines
  final SocketEngine socketEngine = SocketEngine();
  final MotionEngine motion = MotionEngine();
  final MapEngine mapEngine = MapEngine();
  final StatusEngine statusEngine = StatusEngine();

  LatLng userLocation = const LatLng(31.416, 31.813);
  LatLng? driverLocation;
  LatLng? oldDriverLocation;

  GoogleMapController? mapController;

  // Animations
  late AnimationController rippleCtrl;
  late AnimationController sheetCtrl;
  late Animation<double> rippleAnim;

  double driverRotation = 0;

  // Extra Data
  double speedMs = 0;
  double distanceToUser = 0;
  int eta = 0;

  Timer? calcTimer;

  @override
  void initState() {
    super.initState();

    sheetCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900))
      ..forward();

    rippleCtrl =
        AnimationController(vsync: this, duration: const Duration(seconds: 2))
          ..repeat();

    rippleAnim = Tween<double>(begin: 0, end: 130).animate(
      CurvedAnimation(parent: rippleCtrl, curve: Curves.easeOut),
    );

    mapEngine.loadIcons();
    _connectSocket();

    // Speed / Distance update
    calcTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      _updateSpeedAndDistance();
    });
  }

  // SOCKET CONNECTION
  void _connectSocket() {
    socketEngine.connect(
      baseUrl: widget.baseUrl,
      orderId: widget.orderId,
      onDriverUpdate: (newPos) => _handleDriverMovement(newPos),
      onStatusChange: (status, data) {
        statusEngine.update(status);

        if (status == "assigned") {
          driverLocation = LatLng(
            data["driver"]["lat"],
            data["driver"]["lng"],
          );
        }

        if (status == "completed") {
          _showPaymentSheet();
        }

        setState(() {});
      },
    );
  }

  // DRIVER MOVING
  void _handleDriverMovement(LatLng newPos) {
    mapEngine.addTrailPoint(newPos);

    if (driverLocation == null) {
      setState(() => driverLocation = newPos);
      return;
    }

    oldDriverLocation = driverLocation;

    motion.animateDriver(
      vsync: this,
      oldPos: oldDriverLocation!,
      newPos: newPos,
      onMove: (pos) => setState(() => driverLocation = pos),
      onRotate: (rot) => setState(() => driverRotation = rot),
    );
  }

  // SPEED & DISTANCE
  void _updateSpeedAndDistance() {
    if (driverLocation == null || oldDriverLocation == null) return;

    speedMs = _distanceBetween(oldDriverLocation!, driverLocation!);
    distanceToUser = _distanceBetween(driverLocation!, userLocation);

    setState(() {});
  }

  double _distanceBetween(LatLng a, LatLng b) {
    const double R = 6371e3;
    final lat1 = a.latitude * math.pi / 180;
    final lat2 = b.latitude * math.pi / 180;
    final dLat = (b.latitude - a.latitude) * math.pi / 180;
    final dLng = (b.longitude - a.longitude) * math.pi / 180;

    final h = math.sin(dLat / 2) * math.sin(dLat / 2) +
        math.cos(lat1) *
            math.cos(lat2) *
            math.sin(dLng / 2) *
            math.sin(dLng / 2);

    final c = 2 * math.atan2(math.sqrt(h), math.sqrt(1 - h));
    return R * c;
  }

  // ETA BANNER (Uber Style)
  Widget _etaBanner() {
    if (driverLocation == null) return const SizedBox();

    final m = distanceToUser;
    String text;
    Color color;

    if (m > 2000) {
      text = "🚗 الفني سيصل خلال ${(m / 80).round()} دقيقة";
      color = Colors.blueAccent;
    } else if (m > 700) {
      text = "🚗 الفني يقترب…";
      color = Colors.orangeAccent;
    } else if (m > 100) {
      text = "📍 الفني على بعد ${m.toStringAsFixed(0)} مترًا";
      color = Colors.green;
    } else {
      text = "✔ الفني وصل الآن!";
      color = Colors.greenAccent;
    }

    return Positioned(
      top: MediaQuery.of(context).padding.top + 90,
      left: 16,
      right: 16,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: color.withOpacity(.85),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Text(
          text,
          style: const TextStyle(
              color: Colors.white, fontWeight: FontWeight.bold, fontSize: 17),
        ),
      ),
    );
  }

  // PHONE ACTIONS
  Future<void> _callTech() async {
    await launchUrl(Uri(scheme: "tel", path: "0123456789"));
  }

  Future<void> _whatsappTech() async {
    await launchUrl(
      Uri.parse("https://wa.me/201234567890"),
      mode: LaunchMode.externalApplication,
    );
  }

  // PAYMENT SHEET
  void _showPaymentSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => PaymentSheet(
        onConfirm: () {
          Navigator.pop(context);
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("💳 جاري تنفيذ الدفع…")),
          );
        },
      ),
    );
  }

  // BUILD UI
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          _map(),
          if (driverLocation != null) _ripple(),
          _topPanel(),
          _etaBanner(),
          _recenterButton(),
          _bottomSheet(),
        ],
      ),
    );
  }

  Widget _map() {
    return GoogleMap(
      initialCameraPosition: CameraPosition(target: userLocation, zoom: 14),
      onMapCreated: (c) {
        mapController = c;
        c.setMapStyle(mapEngine.darkMapStyle);
      },
      markers: mapEngine.buildMarkers(
        userLocation: userLocation,
        driverLocation: driverLocation,
        rotation: driverRotation,
      ),
      polylines: mapEngine.buildPolylines(),
      zoomControlsEnabled: false,
      myLocationButtonEnabled: false,
      compassEnabled: false,
    );
  }

  // RIPPLE EFFECT
  Widget _ripple() {
    return AnimatedBuilder(
      animation: rippleAnim,
      builder: (_, __) {
        final size = rippleAnim.value;
        final op = 1 - (size / 130);
        return Positioned.fill(
          child: Center(
            child: Container(
              width: size,
              height: size,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.amber.withOpacity(op),
              ),
            ),
          ),
        );
      },
    );
  }

  // TOP PANEL
  Widget _topPanel() {
    return Positioned(
      top: MediaQuery.of(context).padding.top + 20,
      left: 16,
      right: 16,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(.35),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white12),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _info(Icons.speed, "${speedMs.toStringAsFixed(1)} m/s", "السرعة"),
            _info(Icons.route,
                "${(distanceToUser / 1000).toStringAsFixed(2)} كم", "المسافة"),
            _info(Icons.timer, "$eta دقيقة", "الوصول"),
          ],
        ),
      ),
    );
  }

  Widget _info(IconData i, String v, String l) => Column(
        children: [
          Icon(i, color: Colors.amber, size: 20),
          const SizedBox(height: 4),
          Text(v,
              style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 14)),
          Text(l, style: TextStyle(color: Colors.grey.shade300, fontSize: 11)),
        ],
      );

  // RECENTER BUTTON
  Widget _recenterButton() {
    return Positioned(
      right: 16,
      bottom: 200,
      child: FloatingActionButton(
        backgroundColor: Colors.white,
        mini: true,
        child: const Icon(Icons.my_location, color: Colors.black),
        onPressed: () {
          mapController?.animateCamera(
            CameraUpdate.newLatLngZoom(driverLocation ?? userLocation,
                driverLocation != null ? 16 : 14),
          );
        },
      ),
    );
  }

  // BOTTOM SHEET
  Widget _bottomSheet() {
    return Align(
      alignment: Alignment.bottomCenter,
      child: SlideTransition(
        position: Tween(begin: const Offset(0, 1), end: Offset.zero).animate(
          CurvedAnimation(parent: sheetCtrl, curve: Curves.easeOutExpo),
        ),
        child: ClipRRect(
          borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 25, sigmaY: 25),
            child: Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(.55),
                borderRadius:
                    const BorderRadius.vertical(top: Radius.circular(30)),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Handle
                  Container(
                    width: 60,
                    height: 5,
                    decoration: BoxDecoration(
                      color: Colors.white24,
                      borderRadius: BorderRadius.circular(20),
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Status
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: Colors.white12,
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Icon(
                          statusEngine.getStatusIcon(),
                          color: Colors.amber,
                          size: 32,
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Text(
                          statusEngine.getStatusText(eta),
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      )
                    ],
                  ),

                  const SizedBox(height: 22),

                  const DriverCard(
                    name: "محمد إبراهيم",
                    carModel: "هيونداي النترا",
                    plate: "ط ن د 1234",
                    rating: 4.9,
                  ),

                  const SizedBox(height: 22),

                  ActionButtons(onCall: _callTech, onWhatsapp: _whatsappTech),

                  const SizedBox(height: 22),

                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _showPaymentSheet,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.redAccent,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16)),
                      ),
                      child: const Text(
                        "إنهاء الخدمة (الدفع)",
                        style: TextStyle(color: Colors.white, fontSize: 18),
                      ),
                    ),
                  ),

                  const SizedBox(height: 12),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // DISPOSE
  @override
  void dispose() {
    socketEngine.dispose();
    motion.dispose();
    rippleCtrl.dispose();
    sheetCtrl.dispose();
    calcTimer?.cancel();
    super.dispose();
  }
}
