// ignore_for_file: depend_on_referenced_packages

import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;

// ignore: unused_import
import '../config/api_config.dart';

// شاشات التطبيق
import 'about_screen.dart';
import 'contact_screen.dart';
import 'road_services_screen.dart';
// ignore: unused_import
import 'select_location_screen.dart';
import 'settings_screen.dart';
import 'account_settings_screen.dart';
import 'smart_accident_screen.dart';
// ignore: unused_import
import 'road_services_selection_screen.dart';
import 'previous_services_screen.dart';
import 'supplementary_services_screen.dart';

// شاشة البحث الجديدة الصحيحة
import 'searching_technician_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  // =====================================================
  // AI SYSTEM
  // =====================================================

  final TextEditingController _searchController = TextEditingController();

  final String openAIApiKey = "YOUR_API_KEY";
  bool isProcessingAI = false;

  Future<String?> aiDiagnose(String problem) async {
    try {
      setState(() => isProcessingAI = true);

      final response = await http.post(
        Uri.parse("https://api.openai.com/v1/chat/completions"),
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer $openAIApiKey",
        },
        body: jsonEncode({
          "model": "gpt-3.5-turbo",
          "messages": [
            {
              "role": "system",
              "content": "You are an automotive AI assistant."
            },
            {"role": "user", "content": problem}
          ]
        }),
      );

      if (response.statusCode != 200) return null;

      final data = jsonDecode(response.body);
      return data["choices"][0]["message"]["content"].trim();
    } catch (_) {
      return null;
    } finally {
      setState(() => isProcessingAI = false);
    }
  }

  void handleSearch() async {
    String query = _searchController.text.trim();
    if (query.isEmpty) return;

    FocusScope.of(context).unfocus();

    String? result = await aiDiagnose(query);

    if (result == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("AI Error — Try Again")),
      );
      return;
    }

    openTracking(result);
  }

  // =====================================================
  // ✔ تعديل هذه الوظيفة فقط
  // =====================================================
  void openTracking(String serviceType) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => SearchingTechnicianScreen(
          userId: "USER_001",
          serviceType: serviceType,
          lat: 31.4175, // ضع الإحداثيات الصحيحة لديك
          lng: 31.8153, orderId: '',
        ),
      ),
    );
  }

  // =====================================================
  // UI MODE SYSTEM (Light + Dark)
  // =====================================================

  bool darkMode = false;
  bool drawerOpen = false;
  bool isArabic = true;

  Color get primaryBg =>
      darkMode ? const Color(0xFF0A1124) : const Color(0xFFF4F6FA);

  Color get textColor => darkMode ? Colors.white : const Color(0xFF002B5B);

  Color get cardColor =>
      darkMode ? Colors.black.withOpacity(.25) : Colors.white.withOpacity(.75);

  Color get accent =>
      darkMode ? const Color(0xFFFFC107) : const Color(0xFFFFB300);

  String t(String ar, String en) => isArabic ? ar : en;

  // Animation controllers
  late AnimationController waveCtrl;
  late AnimationController pulseCtrl;

  @override
  void initState() {
    super.initState();

    waveCtrl =
        AnimationController(vsync: this, duration: const Duration(seconds: 3))
          ..repeat(reverse: true);

    pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
      lowerBound: .92,
      upperBound: 1.15,
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    waveCtrl.dispose();
    pulseCtrl.dispose();
    super.dispose();
  }

  // =====================================================
  // UI COMPONENTS
  // =====================================================

  Widget topHeader() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        GestureDetector(
          onTap: () => setState(() => drawerOpen = !drawerOpen),
          child: Icon(Icons.menu, size: 30, color: accent),
        ),
        Row(
          children: [
            const Icon(Icons.directions_car, size: 28, color: Colors.amber),
            const SizedBox(width: 6),
            Text(
              "Doctor Car",
              style: GoogleFonts.cairo(
                fontWeight: FontWeight.bold,
                fontSize: 24,
                color: textColor,
              ),
            ),
          ],
        ),
        Row(
          children: [
            IconButton(
              onPressed: () => setState(() => isArabic = !isArabic),
              icon: Icon(Icons.language, color: accent),
            ),
            IconButton(
              onPressed: () => setState(() => darkMode = !darkMode),
              icon: Icon(
                darkMode ? Icons.light_mode : Icons.dark_mode,
                color: accent,
              ),
            )
          ],
        ),
      ],
    );
  }

  Widget searchBar(double w) {
    return Container(
      height: 55,
      margin: EdgeInsets.symmetric(horizontal: w * .06),
      padding: const EdgeInsets.symmetric(horizontal: 20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        color: darkMode
            ? Colors.white.withOpacity(.08)
            : Colors.black.withOpacity(.05),
        border: Border.all(color: accent, width: 2),
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: handleSearch,
            child: Icon(Icons.search, color: accent),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: TextField(
              controller: _searchController,
              style: GoogleFonts.cairo(color: textColor, fontSize: 17),
              decoration: InputDecoration(
                border: InputBorder.none,
                hintText: t("اكتب مشكلتك هنا...", "Describe your problem..."),
                hintStyle: GoogleFonts.cairo(color: textColor.withOpacity(.5)),
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget frostedButton(
      String title, IconData icon, VoidCallback onTap, double h) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(22),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: GestureDetector(
          onTap: onTap,
          child: Container(
            height: h,
            decoration: BoxDecoration(
              color: cardColor,
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: accent, width: 2),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, color: accent, size: 42),
                const SizedBox(height: 12),
                Text(
                  title,
                  style: GoogleFonts.cairo(
                    color: textColor,
                    fontSize: 26,
                    fontWeight: FontWeight.bold,
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget quickBtn(IconData icon, String title, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            width: 65,
            height: 65,
            decoration: BoxDecoration(
              color: accent,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: accent.withOpacity(.4),
                  blurRadius: 25,
                  spreadRadius: 4,
                )
              ],
            ),
            child: Icon(icon, size: 30, color: Colors.black),
          ),
          const SizedBox(height: 8),
          Text(title, style: GoogleFonts.cairo(color: textColor, fontSize: 17)),
        ],
      ),
    );
  }

  Widget drawer(double w) {
    return Container(
      width: w * .60,
      color: darkMode ? const Color(0xFF0A1124) : Colors.white,
      padding: const EdgeInsets.only(top: 85, left: 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.directions_car, size: 55, color: accent),
          Text(
            "Doctor Car",
            style: GoogleFonts.cairo(fontSize: 22, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 25),
          drawerItem(Icons.info, t("من نحن", "About Us"),
              () => goto(const AboutScreen())),
          drawerItem(Icons.phone, t("تواصل معنا", "Contact Us"),
              () => goto(const ContactScreen())),
          drawerItem(Icons.settings, t("الإعدادات", "Settings"),
              () => goto(const SettingsScreen())),
          drawerItem(Icons.history, t("السجل", "History"),
              () => goto(const PreviousServicesScreen())),
        ],
      ),
    );
  }

  Widget drawerItem(IconData icon, String text, VoidCallback onTap) {
    return InkWell(
      onTap: () {
        Navigator.pop(context);
        onTap();
      },
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 14),
        child: Row(
          children: [
            Icon(icon, size: 26, color: accent),
            const SizedBox(width: 12),
            Text(text,
                style: GoogleFonts.cairo(fontSize: 18, color: textColor)),
          ],
        ),
      ),
    );
  }

  void goto(Widget p) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => p),
    );
  }

  Widget buildContent(double w, double h) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.only(bottom: 200),
          child: Column(
            children: [
              const SizedBox(height: 20),
              topHeader(),
              const SizedBox(height: 25),
              Text(
                t("التشخيص والخدمات الذكية", "Diagnosis & Smart Services"),
                style: GoogleFonts.cairo(
                    fontWeight: FontWeight.bold,
                    fontSize: 22,
                    color: textColor),
              ),
              const SizedBox(height: 20),
              searchBar(w),
              const SizedBox(height: 50),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: w * .06),
                child: Row(
                  children: [
                    Expanded(
                      child: frostedButton(
                        t("خدمات الطريق", "Road Services"),
                        Icons.alt_route,
                        () => goto(const RoadServicesScreen()),
                        145,
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: frostedButton(
                        t("الطوارئ", "Emergency"),
                        Icons.emergency,
                        () => openTracking("Emergency"),
                        145,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 35),
              Text(
                t("المساعدة والتشخيص المتقدمة", "Advanced Assistance"),
                style: GoogleFonts.cairo(
                  color: textColor,
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                ),
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  quickBtn(Icons.history, t("السابقة", "History"),
                      () => goto(const PreviousServicesScreen())),
                  quickBtn(Icons.handyman, t("الدعم", "Support"), () {}),
                  quickBtn(Icons.more_horiz, t("المزيد", "More"), () async {
                    final res = await Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => const SupplementaryServicesScreen()),
                    );
                    if (res != null) openTracking(res["type"]);
                  }),
                  quickBtn(Icons.car_crash, t("حادث", "Accident"),
                      () => goto(const SmartAccidentScreen())),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // =====================================================
  // MAIN BUILD
  // =====================================================

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;

    return Directionality(
      textDirection: isArabic ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        backgroundColor: primaryBg,
        body: Stack(
          children: [
            Positioned.fill(
              child: CustomPaint(painter: BackgroundPainter(darkMode)),
            ),
            AnimatedPositioned(
              duration: const Duration(milliseconds: 260),
              left: drawerOpen ? 0 : -w * .60,
              top: 0,
              bottom: 0,
              child: drawer(w),
            ),
            AnimatedScale(
              scale: drawerOpen ? 0.88 : 1,
              duration: const Duration(milliseconds: 320),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 320),
                transform: Matrix4.translationValues(
                  drawerOpen ? w * .45 : 0,
                  drawerOpen ? h * .02 : 0,
                  0,
                ),
                child: buildContent(w, h),
              ),
            ),
          ],
        ),

        // Bottom Call Button
        bottomNavigationBar: SizedBox(
          height: 170,
          child: Stack(
            alignment: Alignment.center,
            clipBehavior: Clip.none,
            children: [
              Positioned.fill(
                child: AnimatedBuilder(
                  animation: waveCtrl,
                  builder: (_, __) =>
                      CustomPaint(painter: BottomWave(waveCtrl.value)),
                ),
              ),
              Positioned(
                top: 25,
                child: ScaleTransition(
                  scale: pulseCtrl,
                  child: Container(
                    width: 95,
                    height: 95,
                    decoration: BoxDecoration(
                      color: accent,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: accent.withOpacity(.5),
                          blurRadius: 55,
                          spreadRadius: 10,
                        ),
                      ],
                    ),
                    child:
                        const Icon(Icons.call, size: 40, color: Colors.black),
                  ),
                ),
              ),
              Positioned(
                top: 120,
                child: Text(
                  t("اتصال سريع", "Quick Call"),
                  style: GoogleFonts.cairo(
                    color: darkMode ? Colors.white : Colors.black,
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  ),
                ),
              ),
              Positioned(
                bottom: 25,
                left: 35,
                child: bottomIcon(Icons.person, t("حسابي", "Account"),
                    () => goto(const AccountSettingsScreen())),
              ),
              Positioned(
                bottom: 25,
                right: 35,
                child: bottomIcon(Icons.home, t("الرئيسية", "Home"), () {}),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget bottomIcon(IconData icon, String label, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              color: accent.withOpacity(.25),
              shape: BoxShape.circle,
              border: Border.all(color: accent, width: 2),
            ),
            child: Icon(icon, size: 28, color: accent),
          ),
          const SizedBox(height: 8),
          Text(label, style: GoogleFonts.cairo(color: textColor, fontSize: 15)),
        ],
      ),
    );
  }
}

// =====================================================
// PAINTERS
// =====================================================

class BackgroundPainter extends CustomPainter {
  final bool dark;
  BackgroundPainter(this.dark);

  @override
  void paint(Canvas canvas, Size size) {
    final bg = Paint()
      ..shader = LinearGradient(
        colors: dark
            ? [
                const Color(0xFF0A1124),
                const Color(0xFF0E2A47),
              ]
            : [
                const Color(0xFFF4F6FA),
                const Color(0xFFE9EFF5),
              ],
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));

    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), bg);

    final path = Path();
    path.moveTo(0, size.height * .22);
    path.quadraticBezierTo(
        size.width * .40, size.height * .15, size.width, size.height * .24);

    final curvePaint = Paint()
      ..color = dark
          ? Colors.blue.shade900.withOpacity(.25)
          : Colors.blue.shade200.withOpacity(.25);

    canvas.drawPath(path, curvePaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

class BottomWave extends CustomPainter {
  final double t;
  BottomWave(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    double shift = 30 * t;

    Path path = Path()
      ..moveTo(0, 50 + shift)
      ..quadraticBezierTo(
          size.width * .25, 0 + shift, size.width * .50, 40 + shift)
      ..quadraticBezierTo(size.width * .85, 100 + shift, size.width, 50 + shift)
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();

    final paint = Paint()..color = Colors.black.withOpacity(.12);

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
