// ignore_for_file: use_build_context_synchronously, depend_on_referenced_packages

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;

import '../config/api_config.dart';
import 'technician_selection_screen.dart';

class SearchingTechnicianScreen extends StatefulWidget {
  final String userId;
  final String serviceType;
  final double lat;
  final double lng;
  final String orderId; // ← تمت الإضافة

  const SearchingTechnicianScreen({
    super.key,
    required this.userId,
    required this.serviceType,
    required this.lat,
    required this.lng,
    required this.orderId, // ← تمت الإضافة
  });

  @override
  State<SearchingTechnicianScreen> createState() =>
      _SearchingTechnicianScreenState();
}

class _SearchingTechnicianScreenState extends State<SearchingTechnicianScreen>
    with TickerProviderStateMixin {
  late AnimationController _pulseCtrl;

  @override
  void initState() {
    super.initState();

    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 1),
      lowerBound: 0.9,
      upperBound: 1.1,
    )..repeat(reverse: true);

    _fetchTechnicians();
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    super.dispose();
  }

  Future<void> _fetchTechnicians() async {
    try {
      final techRes = await http.post(
        Uri.parse("${ApiConfig.technicians}/nearby"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "lat": widget.lat,
          "lng": widget.lng,
          "serviceType": widget.serviceType,
        }),
      );

      final techData = jsonDecode(techRes.body);

      if (techData["success"] != true) {
        throw Exception("لا يوجد فنيون متاحون الآن");
      }

      final technicians =
          List<Map<String, dynamic>>.from(techData["technicians"]);

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => TechnicianSelectionScreen(
            orderId: widget.orderId, // ← مهم جداً
            userId: widget.userId,
            serviceType: widget.serviceType,
            lat: widget.lat,
            lng: widget.lng,
            technicians: technicians,
          ),
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("⚠️ حدث خطأ: $e")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF6F7FA),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ScaleTransition(
              scale: _pulseCtrl,
              child: Image.asset(
                "assets/images/searching.gif",
                height: 150,
              ),
            ),
            const SizedBox(height: 20),
            Text(
              "جارٍ البحث عن أقرب فني…",
              style: GoogleFonts.cairo(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              "نحدد موقعك الآن ونجمع الفنيين الأقرب إليك…",
              textAlign: TextAlign.center,
              style: GoogleFonts.cairo(
                fontSize: 16,
                color: Colors.grey.shade700,
              ),
            ),
            const SizedBox(height: 30),
            const CircularProgressIndicator(
              color: Colors.blueAccent,
              strokeWidth: 3,
            ),
          ],
        ),
      ),
    );
  }
}
