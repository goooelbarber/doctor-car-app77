// ignore_for_file: use_build_context_synchronously

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:doctor_car_app/screens/login_screen.dart';
import 'package:doctor_car_app/screens/home_screen.dart';
import 'package:doctor_car_app/core/app_routes.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  late final Animation<double> _fade;
  // ignore: unused_field
  late final Animation<double> _scale;
  late final Animation<double> _glow;
  late final Animation<double> _pulse;
  late final Animation<Offset> _slideTitle;
  late final Animation<Offset> _slideSubtitle;

  static const Duration _splashDuration = Duration(seconds: 6);
  static const Duration _animationDuration = Duration(milliseconds: 2600);

  @override
  void initState() {
    super.initState();
    _initAnimations();
    _handleNavigation();
  }

  // ======================================================
  // Animations
  // ======================================================
  void _initAnimations() {
    _controller = AnimationController(
      vsync: this,
      duration: _animationDuration,
    );

    _fade = CurvedAnimation(
      parent: _controller,
      curve: const Interval(0.0, 0.6, curve: Curves.easeOut),
    );

    _scale = Tween<double>(begin: 0.85, end: 1.05).animate(
      CurvedAnimation(
        parent: _controller,
        curve: const Interval(0.0, 0.6, curve: Curves.easeOutBack),
      ),
    );

    _pulse = Tween<double>(begin: 1.0, end: 1.06).animate(
      CurvedAnimation(
        parent: _controller,
        curve: Curves.easeInOut,
      ),
    );

    _glow = Tween<double>(begin: 0.25, end: 0.55).animate(
      CurvedAnimation(
        parent: _controller,
        curve: Curves.easeInOut,
      ),
    );

    _slideTitle = Tween<Offset>(
      begin: const Offset(0, 0.5),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(
        parent: _controller,
        curve: const Interval(0.5, 0.8, curve: Curves.easeOut),
      ),
    );

    _slideSubtitle = Tween<Offset>(
      begin: const Offset(0, 0.7),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(
        parent: _controller,
        curve: const Interval(0.65, 1.0, curve: Curves.easeOut),
      ),
    );

    _controller.repeat(reverse: true);
  }

  // ======================================================
  // Navigation
  // ======================================================
  Future<void> _handleNavigation() async {
    final prefs = await SharedPreferences.getInstance();
    final bool isLoggedIn = prefs.getBool('isLoggedIn') ?? false;

    await Future.delayed(_splashDuration);

    if (!mounted) return;

    Navigator.of(context).pushReplacement(
      AppRoutes.fadeScale(
        isLoggedIn ? const HomeScreen() : const LoginScreen(),
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  // ======================================================
  // UI
  // ======================================================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AnimatedContainer(
        duration: const Duration(seconds: 2),
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color(0xFF051937),
              Color(0xFF0D47A1),
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Center(
          child: FadeTransition(
            opacity: _fade,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _buildAnimatedLogo(),
                const SizedBox(height: 40),
                SlideTransition(
                  position: _slideTitle,
                  child: _buildTitle(),
                ),
                const SizedBox(height: 12),
                SlideTransition(
                  position: _slideSubtitle,
                  child: _buildSubtitle(),
                ),
                const SizedBox(height: 40),
                const CircularProgressIndicator(
                  color: Colors.white70,
                  strokeWidth: 2.6,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ======================================================
  // Widgets
  // ======================================================
  Widget _buildAnimatedLogo() {
    return ScaleTransition(
      scale: _pulse,
      child: AnimatedBuilder(
        animation: _glow,
        builder: (_, __) {
          return Container(
            width: 260, // 🔥 لوجو أكبر
            height: 260,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                colors: [
                  Color(0xFF0D47A1),
                  Color(0xFF1976D2),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.blueAccent.withOpacity(_glow.value),
                  blurRadius: 55,
                  spreadRadius: 6,
                ),
              ],
            ),
            child: Padding(
              padding: const EdgeInsets.all(36),
              child: Image.asset(
                "assets/images/logo1.png",
                fit: BoxFit.contain,
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildTitle() {
    return const Text(
      "Doctor Car",
      style: TextStyle(
        fontSize: 36,
        fontWeight: FontWeight.w800,
        color: Colors.white,
        letterSpacing: 1.6,
      ),
    );
  }

  Widget _buildSubtitle() {
    return const Text(
      "Smart Road Assistance",
      style: TextStyle(
        fontSize: 16,
        color: Colors.white70,
        letterSpacing: 1.0,
      ),
    );
  }
}
