import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class RatingScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("تقييم الخدمة", style: GoogleFonts.cairo()),
        backgroundColor: Colors.green,
      ),
      body: Column(
        children: [
          Text("كيف كانت تجربتك معنا؟", style: GoogleFonts.cairo(fontSize: 22)),
          Slider(
            value: 3,
            min: 1,
            max: 5,
            onChanged: (v) {},
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context),
            child: Text("إرسال التقييم", style: GoogleFonts.cairo()),
          )
        ],
      ),
    );
  }
}
