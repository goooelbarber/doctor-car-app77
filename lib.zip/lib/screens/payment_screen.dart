import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
// ignore: unused_import
import 'package:doctor_car_app/config/api_config.dart';

class PaymentScreen extends StatefulWidget {
  final String orderId;
  final double totalCost;

  const PaymentScreen({
    super.key,
    required this.orderId,
    required this.totalCost,
  });

  @override
  State<PaymentScreen> createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> {
  String _selectedMethod = "cash"; // 💵 افتراضي نقداً

  void _completePayment() async {
    // 🔹 محاكاة عملية الدفع
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );

    await Future.delayed(const Duration(seconds: 2));
    Navigator.pop(context); // إغلاق التحميل

    // 🔹 بعد الدفع — الانتقال لرسالة نجاح
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => const PaymentSuccessScreen(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final Color accentColor = Colors.orangeAccent;
    final Color primaryColor = Colors.blueAccent;

    return Scaffold(
      appBar: AppBar(
        title: const Text("الدفع والفاتورة 💳"),
        backgroundColor: primaryColor,
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Text(
                "تفاصيل الفاتورة",
                style: GoogleFonts.cairo(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: primaryColor,
                ),
              ),
            ),
            const SizedBox(height: 25),

            // 💰 المبلغ الكلي
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "إجمالي التكلفة:",
                  style: GoogleFonts.cairo(
                      fontSize: 18, fontWeight: FontWeight.w600),
                ),
                Text(
                  "${widget.totalCost.toStringAsFixed(2)} ج.م",
                  style: GoogleFonts.cairo(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: accentColor,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 30),
            Text(
              "اختر طريقة الدفع:",
              style:
                  GoogleFonts.cairo(fontSize: 18, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 10),

            // 🏦 خيارات الدفع
            _buildPaymentOption("نقدًا عند التسليم", "cash", Icons.money),
            _buildPaymentOption(
                "بطاقة بنكية (Visa / MasterCard)", "card", Icons.credit_card),
            _buildPaymentOption("Apple Pay", "apple", Icons.phone_iphone),

            const Spacer(),

            // ✅ زر إتمام الدفع
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton.icon(
                onPressed: _completePayment,
                icon:
                    const Icon(Icons.check_circle_outline, color: Colors.white),
                label: Text(
                  "إتمام الدفع",
                  style: GoogleFonts.cairo(
                      fontSize: 18, fontWeight: FontWeight.bold),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: primaryColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 10),
          ],
        ),
      ),
    );
  }

  Widget _buildPaymentOption(String title, String value, IconData icon) {
    return GestureDetector(
      onTap: () => setState(() => _selectedMethod = value),
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 8),
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          color: _selectedMethod == value
              ? Colors.blueAccent.withOpacity(0.1)
              : Colors.white,
          border: Border.all(
            color: _selectedMethod == value
                ? Colors.blueAccent
                : Colors.grey.shade300,
            width: 1.5,
          ),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            Icon(icon, color: Colors.blueAccent),
            const SizedBox(width: 15),
            Expanded(
              child: Text(
                title,
                style: GoogleFonts.cairo(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            if (_selectedMethod == value)
              const Icon(Icons.check_circle, color: Colors.blueAccent),
          ],
        ),
      ),
    );
  }
}

// ✅ شاشة النجاح بعد الدفع
class PaymentSuccessScreen extends StatelessWidget {
  const PaymentSuccessScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(30.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.check_circle_outline,
                  color: Colors.green, size: 100),
              const SizedBox(height: 20),
              Text(
                "تم الدفع بنجاح ✅",
                style: GoogleFonts.cairo(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.green,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                "شكرًا لاستخدامك Doctor Car!\nنتمنى لك تجربة مريحة وآمنة 🚗💨",
                textAlign: TextAlign.center,
                style: GoogleFonts.cairo(fontSize: 16),
              ),
              const SizedBox(height: 30),
              ElevatedButton(
                onPressed: () {
                  Navigator.popUntil(context, (route) => route.isFirst);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blueAccent,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 40, vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                child: Text(
                  "العودة إلى الرئيسية",
                  style: GoogleFonts.cairo(fontSize: 16, color: Colors.white),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
