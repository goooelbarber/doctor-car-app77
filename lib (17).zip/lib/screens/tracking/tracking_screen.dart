// PATH: lib/screens/tracking/tracking_screen.dart
// ignore_for_file: depend_on_referenced_packages, use_build_context_synchronously

import 'dart:async';
import 'dart:math' as math;
import 'dart:ui';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show HapticFeedback, rootBundle;
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

import '../payment_screen.dart';
import '../../services/socket_service.dart';

/// ✅ كاميرا التتبع
enum TrackingCameraMode { driverOnly, fitBoth }

class TrackingScreen extends StatefulWidget {
  final String orderId;
  final String userId;
  final String baseUrl;
  final String serviceType;

  /// ✅ Fake testing (لو orderId فاضي)
  final bool fakeMode;

  const TrackingScreen({
    super.key,
    required this.orderId,
    required this.userId,
    required this.baseUrl,
    required this.serviceType,
    this.fakeMode = false,
  });

  @override
  State<TrackingScreen> createState() => _TrackingScreenState();
}

class _TrackingScreenState extends State<TrackingScreen>
    with TickerProviderStateMixin {
  // ======================
  // DoctorCar THEME
  // ======================
  static const Color _brand = Color(0xFFA8F12A); // ✅ neon lime
  static const Color _bg1 = Color(0xFF0B1220);
  static const Color _bg2 = Color(0xFF081837);
  static const Color _bg3 = Color(0xFF0A2038);

  static const Color _sheet = Color(0xFF111A2C);
  static const Color _sheet2 = Color(0xFF0F1830);

  static const Color _danger = Color(0xFFFF4D4D);
  // ignore: unused_field
  static const Color _muted = Color(0xFF9CA3AF);

  // ======================
  // Socket
  // ======================
  final SocketService socketService = SocketService();
  bool socketConnected = false;

  // ======================
  // Map
  // ======================
  GoogleMapController? _map;
  bool _mapReady = false;

  /// ✅ المفروض تيجي من order / GPS
  LatLng userLocation = const LatLng(31.416, 31.813);

  // live driver
  LatLng driverLocation = const LatLng(31.4182, 31.8152);
  LatLng _lastDriverLocation = const LatLng(31.4182, 31.8152);
  LatLng? _targetDriver;

  // follow behavior
  bool _follow = true;
  TrackingCameraMode _cameraMode = TrackingCameraMode.fitBoth;
  DateTime _lastCamMove = DateTime.fromMillisecondsSinceEpoch(0);

  // rotation
  double _bearing = 0.0;

  // ======================
  // Route + metrics
  // ======================
  final Dio _dio = Dio();

  /// route الحقيقي (directions) أو route fallback (straight)
  List<LatLng> _routePoints = [];
  DateTime _lastRouteFetch = DateTime.fromMillisecondsSinceEpoch(0);

  /// ✅ Trail = خط حركة الفني (دايمًا شغال حتى Fake)
  final List<LatLng> _trailPoints = [];
  DateTime _lastTrailAdd = DateTime.fromMillisecondsSinceEpoch(0);

  double speedMs = 0;
  double distanceToUser = 0; // meters
  int etaMin = 3;
  bool _hasDirectionsEta = false;

  // ======================
  // Arrival realism
  // ======================
  double _arrivalDistanceMeters = 45;
  int _arrivalStableSeconds = 6;

  int _arrivalStableCounter = 0;
  bool _arrived = false;
  bool _arrivalHapticDone = false;
  bool _arrivalZoomDone = false;

  // ======================
  // Pulse + smooth
  // ======================
  double _pulse = 0.0;
  Timer? _pulseTimer;

  Timer? _smoothTimer;
  Timer? _metricsTimer;
  Timer? _routeRefreshTimer;

  // ======================
  // Route flow animation (dots moving on route)
  // ======================
  Timer? _flowTimer;
  int _flowTick = 0;
  List<LatLng> _routeSampled = [];
  int _flowEveryN = 6;

  // ======================
  // Map assets
  // ======================
  BitmapDescriptor? _carIcon;
  BitmapDescriptor? _userIcon;
  String? _mapStyle;

  // ======================
  // knobs
  // ======================
  static const double _followTilt = 62;
  static const double _baseZoomNear = 17.4;

  int _routeRefreshSeconds = 6;
  int _cameraThrottleMs = 260;

  // ✅ Trail knobs
  int _trailMaxPoints = 140;
  int _trailMinAddMs = 700;
  double _trailMinMoveMeters = 8;

  // Fake mode effective
  late final bool _effectiveFake;

  @override
  void initState() {
    super.initState();

    _effectiveFake = widget.fakeMode || widget.orderId.trim().isEmpty;

    _loadEnvKnobs();
    _loadAssets();
    if (!_effectiveFake) _initSocket();

    // pulse
    _pulseTimer = Timer.periodic(const Duration(milliseconds: 40), (_) {
      if (!mounted) return;
      setState(() {
        _pulse += 0.03;
        if (_pulse >= 1.0) _pulse = 0.0;
      });
    });

    // metrics + camera + arrival
    _metricsTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      _updateMetrics();
      _maybeMoveCamera();
      _handleArrivalLogic();
    });

    // smooth interpolation
    _smoothTimer = Timer.periodic(const Duration(milliseconds: 50), (_) {
      if (!mounted) return;
      _tickSmoothMovement();
    });

    // auto route refresh
    _routeRefreshTimer =
        Timer.periodic(Duration(seconds: _routeRefreshSeconds), (_) {
      if (!mounted) return;
      _maybeFetchRoute(force: false);
    });

    // route flow animation
    _flowTimer = Timer.periodic(const Duration(milliseconds: 120), (_) {
      if (!mounted) return;
      if (_routeSampled.length < 2) return;
      setState(() => _flowTick++);
    });

    // Fake: حركة بسيطة لو مفيش سوكيت
    if (_effectiveFake) {
      Timer.periodic(const Duration(milliseconds: 900), (_) {
        if (!mounted) return;
        if (_arrived) return;

        final next = _moveTowards(driverLocation, userLocation, metersStep: 12);
        _feedDriverLocation(next);
      });
    }

    // أول نقطة trail
    _trailPoints.add(driverLocation);
  }

  void _loadEnvKnobs() {
    final r = int.tryParse(dotenv.env["ROUTE_REFRESH_SECONDS"] ?? "");
    final c = int.tryParse(dotenv.env["CAMERA_THROTTLE_MS"] ?? "");
    final aDist = double.tryParse(dotenv.env["ARRIVAL_DISTANCE_METERS"] ?? "");
    final aStable = int.tryParse(dotenv.env["ARRIVAL_STABLE_SECONDS"] ?? "");

    final trailMax = int.tryParse(dotenv.env["TRAIL_MAX_POINTS"] ?? "");
    final trailMs = int.tryParse(dotenv.env["TRAIL_MIN_ADD_MS"] ?? "");
    final trailMove =
        double.tryParse(dotenv.env["TRAIL_MIN_MOVE_METERS"] ?? "");

    final flowEvery = int.tryParse(dotenv.env["ROUTE_FLOW_EVERY_N"] ?? "");

    if (r != null && r >= 3 && r <= 60) _routeRefreshSeconds = r;
    if (c != null && c >= 100 && c <= 1500) _cameraThrottleMs = c;

    if (aDist != null && aDist >= 10 && aDist <= 200) {
      _arrivalDistanceMeters = aDist;
    }
    if (aStable != null && aStable >= 2 && aStable <= 20) {
      _arrivalStableSeconds = aStable;
    }

    if (trailMax != null && trailMax >= 40 && trailMax <= 600) {
      _trailMaxPoints = trailMax;
    }
    if (trailMs != null && trailMs >= 200 && trailMs <= 5000) {
      _trailMinAddMs = trailMs;
    }
    if (trailMove != null && trailMove >= 2 && trailMove <= 100) {
      _trailMinMoveMeters = trailMove;
    }

    if (flowEvery != null && flowEvery >= 3 && flowEvery <= 20) {
      _flowEveryN = flowEvery;
    }
  }

  // ======================
  // Socket
  // ======================
  void _initSocket() {
    socketService.initUser(userId: widget.userId);

    socketService.onConnectionChanged((connected) {
      if (!mounted) return;
      setState(() => socketConnected = connected);
      if (connected) socketService.joinOrderRoom(widget.orderId);
    });

    socketService.joinOrderRoom(widget.orderId);

    socketService.onTechnicianLocation((lat, lng) {
      if (!mounted) return;
      _feedDriverLocation(LatLng(lat, lng));
    });
  }

  void _feedDriverLocation(LatLng next) {
    _lastDriverLocation = driverLocation;
    _targetDriver = next;

    _bearing = _computeBearing(driverLocation, next);

    _maybeAddTrailPoint(next);
    _maybeFetchRoute(force: false);
  }

  void _maybeAddTrailPoint(LatLng next) {
    final now = DateTime.now();
    if (now.difference(_lastTrailAdd).inMilliseconds < _trailMinAddMs) return;

    final last = _trailPoints.isNotEmpty ? _trailPoints.last : driverLocation;
    final moved = _distanceBetween(last, next);
    if (moved < _trailMinMoveMeters) return;

    _lastTrailAdd = now;
    _trailPoints.add(next);

    if (_trailPoints.length > _trailMaxPoints) {
      _trailPoints.removeRange(0, _trailPoints.length - _trailMaxPoints);
    }
  }

  // ======================
  // Assets
  // ======================
  Future<void> _loadAssets() async {
    await Future.wait([
      _loadMarkerIcons(),
      _loadMapStyle(),
    ]);
  }

  Future<void> _loadMapStyle() async {
    try {
      final s = await rootBundle.loadString("assets/map_styles/uber_dark.json");
      if (!mounted) return;
      setState(() => _mapStyle = s);
      if (_map != null) await _map!.setMapStyle(_mapStyle);
    } catch (_) {}
  }

  Future<void> _loadMarkerIcons() async {
    try {
      final car = await BitmapDescriptor.asset(
        const ImageConfiguration(size: Size(78, 78)),
        "assets/icons/car_marker.png",
      );
      final pin = await BitmapDescriptor.asset(
        const ImageConfiguration(size: Size(72, 72)),
        "assets/icons/user_pin.png",
      );

      if (!mounted) return;
      setState(() {
        _carIcon = car;
        _userIcon = pin;
      });
    } catch (_) {}
  }

  // ======================
  // Smooth movement
  // ======================
  void _tickSmoothMovement() {
    if (_targetDriver == null) return;

    const t = 0.18;
    final cur = driverLocation;
    final tar = _targetDriver!;

    final newPos = LatLng(
      cur.latitude + (tar.latitude - cur.latitude) * t,
      cur.longitude + (tar.longitude - cur.longitude) * t,
    );

    final dist = _distanceBetween(newPos, tar);
    if (dist < 2.2) {
      driverLocation = tar;
      _targetDriver = null;
    } else {
      driverLocation = newPos;
    }

    if (mounted) setState(() {});
  }

  // ======================
  // Metrics + camera
  // ======================
  void _updateMetrics() {
    final delta = _distanceBetween(_lastDriverLocation, driverLocation);
    speedMs = _clamp(delta, 0, 60);
    distanceToUser = _distanceBetween(driverLocation, userLocation);

    if (!_hasDirectionsEta) {
      final assumedSpeed = (speedMs >= 2.0) ? speedMs : 10.0;
      final seconds = distanceToUser / assumedSpeed;
      etaMin = (seconds / 60).ceil().clamp(1, 99);
    }

    if (mounted) setState(() {});
  }

  void _maybeMoveCamera() async {
    if (!_follow || !_mapReady || _map == null) return;

    if (_arrived) {
      _doArrivalZoomOnce();
      return;
    }

    final now = DateTime.now();
    if (now.difference(_lastCamMove).inMilliseconds < _cameraThrottleMs) return;
    _lastCamMove = now;

    if (_cameraMode == TrackingCameraMode.fitBoth) {
      await _fitUserAndDriver(padding: 140);
      return;
    }

    final zoom = _zoomFromDistance(distanceToUser);
    _map!.animateCamera(
      CameraUpdate.newCameraPosition(
        CameraPosition(
          target: driverLocation,
          zoom: zoom,
          tilt: zoom >= 16 ? _followTilt : 45,
          bearing: _bearing,
        ),
      ),
    );
  }

  Future<void> _fitUserAndDriver({double padding = 120}) async {
    if (_map == null) return;

    final pts = <LatLng>[userLocation, driverLocation];
    double minLat = pts.first.latitude;
    double maxLat = pts.first.latitude;
    double minLng = pts.first.longitude;
    double maxLng = pts.first.longitude;

    for (final p in pts) {
      minLat = math.min(minLat, p.latitude);
      maxLat = math.max(maxLat, p.latitude);
      minLng = math.min(minLng, p.longitude);
      maxLng = math.max(maxLng, p.longitude);
    }

    final bounds = LatLngBounds(
      southwest: LatLng(minLat, minLng),
      northeast: LatLng(maxLat, maxLng),
    );

    try {
      await _map!.animateCamera(CameraUpdate.newLatLngBounds(bounds, padding));
    } catch (_) {
      await Future.delayed(const Duration(milliseconds: 220));
      try {
        await _map!
            .animateCamera(CameraUpdate.newLatLngBounds(bounds, padding));
      } catch (_) {}
    }
  }

  double _zoomFromDistance(double meters) {
    if (meters <= 200) return _baseZoomNear;
    if (meters <= 500) return 16.8;
    if (meters <= 1500) return 15.9;
    if (meters <= 4000) return 15.0;
    return 14.4;
  }

  // ======================
  // Arrival logic
  // ======================
  void _handleArrivalLogic() {
    if (_arrived) return;

    if (distanceToUser <= _arrivalDistanceMeters) {
      _arrivalStableCounter++;
      if (_arrivalStableCounter >= _arrivalStableSeconds) {
        _arrived = true;
        _triggerArrivalHapticsOnce();
        _doArrivalZoomOnce();
        if (mounted) setState(() {});
      }
    } else {
      if (_arrivalStableCounter != 0) _arrivalStableCounter = 0;
    }
  }

  Future<void> _triggerArrivalHapticsOnce() async {
    if (_arrivalHapticDone) return;
    _arrivalHapticDone = true;

    try {
      await HapticFeedback.mediumImpact();
      await Future.delayed(const Duration(milliseconds: 120));
      await HapticFeedback.heavyImpact();
    } catch (_) {}
  }

  void _doArrivalZoomOnce() {
    if (_arrivalZoomDone || _map == null) return;
    _arrivalZoomDone = true;
    _fitRouteBounds(padding: 150);
  }

  // ======================
  // Directions API + Fallback
  // ======================
  Future<void> _maybeFetchRoute({required bool force}) async {
    final now = DateTime.now();
    if (!force &&
        now.difference(_lastRouteFetch).inSeconds < _routeRefreshSeconds) {
      return;
    }
    _lastRouteFetch = now;

    final key =
        (dotenv.env["GOOGLE_DIRECTIONS_KEY"]?.trim().isNotEmpty ?? false)
            ? dotenv.env["GOOGLE_DIRECTIONS_KEY"]!.trim()
            : (dotenv.env["GOOGLE_MAPS_KEY"] ?? "").trim();

    if (key.isEmpty) {
      _buildFallbackStraightRoute();
      return;
    }

    try {
      final origin = "${driverLocation.latitude},${driverLocation.longitude}";
      final dest = "${userLocation.latitude},${userLocation.longitude}";

      final res = await _dio.get(
        "https://maps.googleapis.com/maps/api/directions/json",
        queryParameters: {
          "origin": origin,
          "destination": dest,
          "mode": "driving",
          "key": key,
          "alternatives": "false",
          "language": "ar",
          "region": "eg",
        },
      );

      final data = res.data;
      if (data is! Map) {
        _buildFallbackStraightRoute();
        return;
      }
      if ((data["status"] ?? "") != "OK") {
        _buildFallbackStraightRoute();
        return;
      }

      final routes = data["routes"];
      if (routes is! List || routes.isEmpty) {
        _buildFallbackStraightRoute();
        return;
      }

      final route0 = routes.first;
      final poly = route0["overview_polyline"]?["points"];
      if (poly is! String || poly.isEmpty) {
        _buildFallbackStraightRoute();
        return;
      }

      final decodedPoints = PolylinePoints().decodePolyline(poly);
      final decoded =
          decodedPoints.map((p) => LatLng(p.latitude, p.longitude)).toList();

      // ETA + distance from legs
      final legs = route0["legs"];
      if (legs is List && legs.isNotEmpty) {
        final leg0 = legs.first;
        final durVal = leg0["duration"]?["value"];
        final distVal = leg0["distance"]?["value"];
        if (durVal is num) {
          etaMin = (durVal.toDouble() / 60).ceil().clamp(1, 99);
          _hasDirectionsEta = true;
        }
        if (distVal is num) {
          distanceToUser = distVal.toDouble();
        }
      }

      if (!mounted) return;
      setState(() {
        _routePoints = decoded;
        _rebuildRouteSampled();
      });
    } catch (_) {
      _buildFallbackStraightRoute();
    }
  }

  void _buildFallbackStraightRoute() {
    final pts = _interpolatePoints(driverLocation, userLocation, steps: 28);
    if (!mounted) return;
    setState(() {
      _routePoints = pts;
      _rebuildRouteSampled();

      final meters = _distanceBetween(driverLocation, userLocation);
      final assumed = (speedMs >= 2.0) ? speedMs : 10.0;
      etaMin = (meters / assumed / 60).ceil().clamp(1, 99);
      _hasDirectionsEta = false;
    });
  }

  void _rebuildRouteSampled() {
    if (_routePoints.length < 2) {
      _routeSampled = [];
      return;
    }
    final sampled = <LatLng>[];
    for (int i = 0; i < _routePoints.length; i += _flowEveryN) {
      sampled.add(_routePoints[i]);
    }
    if (sampled.length < 2) {
      sampled
        ..clear()
        ..addAll(_routePoints);
    }
    _routeSampled = sampled;
    _flowTick = 0;
  }

  void _fitRouteBounds({double padding = 90}) {
    if (_map == null) return;

    final pts = <LatLng>[userLocation, driverLocation, ..._routePoints];
    if (pts.isEmpty) return;

    double minLat = pts.first.latitude;
    double maxLat = pts.first.latitude;
    double minLng = pts.first.longitude;
    double maxLng = pts.first.longitude;

    for (final p in pts) {
      minLat = math.min(minLat, p.latitude);
      maxLat = math.max(maxLat, p.latitude);
      minLng = math.min(minLng, p.longitude);
      maxLng = math.max(maxLng, p.longitude);
    }

    final bounds = LatLngBounds(
      southwest: LatLng(minLat, minLng),
      northeast: LatLng(maxLat, maxLng),
    );

    try {
      _map!.animateCamera(CameraUpdate.newLatLngBounds(bounds, padding));
    } catch (_) {}
  }

  // ======================
  // UI
  // ======================
  @override
  Widget build(BuildContext context) {
    final mapPadding = EdgeInsets.only(
      top: MediaQuery.of(context).padding.top + 78,
      bottom: 280,
    );

    return Scaffold(
      backgroundColor: _bg1,
      body: Stack(
        children: [
          _backgroundGlow(),
          _buildMap(mapPadding),
          _buildTopDoctorBar(),
          _buildRightControls(),
          _buildBottomSheet(),
        ],
      ),
    );
  }

  Widget _backgroundGlow() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [_bg1, _bg2, _bg3],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
    );
  }

  Widget _buildMap(EdgeInsets padding) {
    return Listener(
      onPointerDown: (_) {
        if (_follow) setState(() => _follow = false);
      },
      child: GoogleMap(
        padding: padding,
        initialCameraPosition: CameraPosition(target: userLocation, zoom: 14.8),
        onMapCreated: (c) async {
          _map = c;
          if (_mapStyle != null) await c.setMapStyle(_mapStyle);
          setState(() => _mapReady = true);

          await _maybeFetchRoute(force: true);

          await Future.delayed(const Duration(milliseconds: 120));
          await _fitUserAndDriver(padding: 150);
        },
        zoomControlsEnabled: false,
        myLocationButtonEnabled: false,
        compassEnabled: false,
        buildingsEnabled: false,
        indoorViewEnabled: false,
        trafficEnabled: false,
        circles: _buildMapCircles(),
        polylines: _buildPolylines(),
        markers: {
          Marker(
            markerId: const MarkerId("user"),
            position: userLocation,
            anchor: const Offset(0.5, 1.0),
            icon: _userIcon ?? BitmapDescriptor.defaultMarker,
          ),
          Marker(
            markerId: const MarkerId("driver"),
            position: driverLocation,
            anchor: const Offset(0.5, 0.5),
            flat: true,
            rotation: _bearing,
            icon: _carIcon ??
                BitmapDescriptor.defaultMarkerWithHue(
                  BitmapDescriptor.hueGreen,
                ),
          ),
        },
      ),
    );
  }

  Set<Polyline> _buildPolylines() {
    final set = <Polyline>{};

    // Route Glow + Main (DoctorCar Lime)
    if (_routePoints.isNotEmpty) {
      set.add(
        Polyline(
          polylineId: const PolylineId("routeGlow"),
          points: _routePoints,
          width: 16,
          color: _brand.withOpacity(0.16),
          geodesic: true,
          endCap: Cap.roundCap,
          startCap: Cap.roundCap,
          jointType: JointType.round,
        ),
      );

      set.add(
        Polyline(
          polylineId: const PolylineId("routeShadow"),
          points: _routePoints,
          width: 11,
          color: Colors.black.withOpacity(0.55),
          geodesic: true,
          endCap: Cap.roundCap,
          startCap: Cap.roundCap,
          jointType: JointType.round,
        ),
      );

      set.add(
        Polyline(
          polylineId: const PolylineId("route"),
          points: _routePoints,
          width: 7,
          color: _brand.withOpacity(0.92),
          geodesic: true,
          endCap: Cap.roundCap,
          startCap: Cap.roundCap,
          jointType: JointType.round,
        ),
      );
    }

    // Trail movement
    if (_trailPoints.length >= 2) {
      set.add(
        Polyline(
          polylineId: const PolylineId("trail"),
          points: _trailPoints,
          width: 5,
          color: Colors.white.withOpacity(0.30),
          geodesic: true,
          endCap: Cap.roundCap,
          startCap: Cap.roundCap,
          jointType: JointType.round,
        ),
      );
    }

    return set;
  }

  Set<Circle> _buildMapCircles() {
    final all = <Circle>{};
    all.addAll(_buildDriverPulseCircles());
    all.addAll(_buildRouteFlowCircles());
    return all;
  }

  Set<Circle> _buildDriverPulseCircles() {
    final r1 = 28 + (_pulse * 82);
    final r2 = 28 + (((_pulse + 0.5) % 1.0) * 82);

    double opacity(double t) => (1 - t).clamp(0.0, 1.0);
    final t2 = ((_pulse + 0.5) % 1.0);

    return {
      Circle(
        circleId: const CircleId("p1"),
        center: driverLocation,
        radius: r1,
        fillColor: _brand.withOpacity(0.12 * opacity(_pulse)),
        strokeColor: _brand.withOpacity(0.25 * opacity(_pulse)),
        strokeWidth: 1,
      ),
      Circle(
        circleId: const CircleId("p2"),
        center: driverLocation,
        radius: r2,
        fillColor: _brand.withOpacity(0.08 * opacity(t2)),
        strokeColor: _brand.withOpacity(0.20 * opacity(t2)),
        strokeWidth: 1,
      ),
    };
  }

  Set<Circle> _buildRouteFlowCircles() {
    if (_routeSampled.length < 2) return {};

    const int kDots = 7;
    const int spacing = 4;

    final circles = <Circle>{};
    final n = _routeSampled.length;

    for (int i = 0; i < kDots; i++) {
      final idx = (_flowTick + i * spacing) % n;
      final p = _routeSampled[idx];

      final t = i / (kDots - 1);
      final alpha = (1.0 - t) * 0.55;

      final radius = 6.5 + i * 1.8;

      circles.add(
        Circle(
          circleId: CircleId("rf_$i"),
          center: p,
          radius: radius,
          fillColor: _brand.withOpacity(alpha),
          strokeColor: _brand.withOpacity(alpha * 0.6),
          strokeWidth: 1,
        ),
      );
    }

    return circles;
  }

  // ======================
  // Top bar
  // ======================
  Widget _buildTopDoctorBar() {
    final km = (distanceToUser / 1000);
    final statusText = _arrived ? "وصل" : "قيد الوصول";
    final liveText =
        socketConnected ? "Live" : (_effectiveFake ? "Fake" : "Offline");

    final liveColor = socketConnected
        ? _brand
        : (_effectiveFake ? Colors.orangeAccent : Colors.redAccent);

    return Positioned(
      top: MediaQuery.of(context).padding.top + 10,
      left: 12,
      right: 12,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(.35),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.white10),
            ),
            child: Row(
              children: [
                _miniStat(
                    icon: Icons.place, title: "الحالة", value: statusText),
                const SizedBox(width: 8),
                _miniStat(
                  icon: Icons.route,
                  title: "المسافة",
                  value: "${km.toStringAsFixed(2)} كم",
                ),
                const SizedBox(width: 8),
                _miniStat(icon: Icons.timer, title: "ETA", value: "$etaMin د"),
                const Spacer(),
                _chip(
                  icon: Icons.wifi,
                  text: liveText,
                  color: liveColor,
                ),
                const SizedBox(width: 8),
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(.35),
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.white12),
                    ),
                    child:
                        const Icon(Icons.close, color: Colors.white, size: 20),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _chip(
      {required IconData icon, required String text, required Color color}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.06),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: Colors.white10),
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 16),
          const SizedBox(width: 6),
          Text(
            text,
            style: GoogleFonts.cairo(
              color: Colors.white,
              fontWeight: FontWeight.w900,
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }

  Widget _miniStat({
    required IconData icon,
    required String title,
    required String value,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.06),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white10),
      ),
      child: Row(
        children: [
          Icon(icon, color: _brand, size: 18),
          const SizedBox(width: 8),
          Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                value,
                style: GoogleFonts.cairo(
                  color: Colors.white,
                  fontWeight: FontWeight.w900,
                  fontSize: 13,
                ),
              ),
              Text(
                title,
                style: GoogleFonts.cairo(
                  color: Colors.white70,
                  fontWeight: FontWeight.w700,
                  fontSize: 10,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ======================
  // Right controls
  // ======================
  Widget _buildRightControls() {
    return Positioned(
      right: 14,
      bottom: 300,
      child: Column(
        children: [
          _pillBtn(
            icon: _follow ? Icons.gps_fixed : Icons.gps_not_fixed,
            label: _follow ? "Follow" : "Free",
            onTap: () async {
              setState(() => _follow = !_follow);
              if (_follow) {
                await _fitUserAndDriver(padding: 150);
              }
            },
          ),
          const SizedBox(height: 10),
          _pillBtn(
            icon: _cameraMode == TrackingCameraMode.fitBoth
                ? Icons.center_focus_strong
                : Icons.directions_car,
            label: _cameraMode == TrackingCameraMode.fitBoth
                ? "FitBoth"
                : "Driver",
            onTap: () {
              setState(() {
                _cameraMode = _cameraMode == TrackingCameraMode.fitBoth
                    ? TrackingCameraMode.driverOnly
                    : TrackingCameraMode.fitBoth;
              });
              _maybeMoveCamera();
            },
          ),
          const SizedBox(height: 10),
          _pillBtn(
            icon: Icons.fit_screen,
            label: "Fit",
            onTap: () => _fitRouteBounds(padding: 120),
          ),
          const SizedBox(height: 10),
          _pillBtn(
            icon: Icons.refresh,
            label: "Route",
            onTap: () => _maybeFetchRoute(force: true),
          ),
        ],
      ),
    );
  }

  Widget _pillBtn({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.black.withOpacity(.35),
      elevation: 6,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, color: Colors.white, size: 18),
              const SizedBox(width: 8),
              Text(
                label,
                style: GoogleFonts.cairo(
                  color: Colors.white,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ======================
  // Bottom sheet
  // ======================
  Widget _buildBottomSheet() {
    return DraggableScrollableSheet(
      initialChildSize: 0.23,
      minChildSize: 0.18,
      maxChildSize: 0.62,
      builder: (context, controller) {
        return ClipRRect(
          borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
            child: Container(
              decoration: BoxDecoration(
                color: _sheet.withOpacity(.92),
                borderRadius:
                    const BorderRadius.vertical(top: Radius.circular(28)),
                border: Border.all(color: Colors.white10),
              ),
              child: ListView(
                controller: controller,
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
                children: [
                  Center(
                    child: Container(
                      width: 56,
                      height: 5,
                      decoration: BoxDecoration(
                        color: Colors.white24,
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  _statusCard(),
                  const SizedBox(height: 12),
                  _techCard(),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: _actionBtn(
                          icon: Icons.call,
                          label: "اتصال",
                          kind: _ActionKind.primary,
                          onTap: _callTechDemo,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _actionBtn(
                          icon: Icons.chat_bubble,
                          label: "محادثة",
                          kind: _ActionKind.secondary,
                          onTap: _chatDemo,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _actionBtn(
                          icon: Icons.share,
                          label: "مشاركة",
                          kind: _ActionKind.secondary,
                          onTap: _shareDemo,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () async {
                            await _maybeFetchRoute(force: true);
                            if (!mounted) return;
                            _toast("تم تحديث المسار");
                          },
                          icon:
                              Icon(Icons.route, color: _brand.withOpacity(.9)),
                          label: Text(
                            "تحديث المسار",
                            style: GoogleFonts.cairo(
                              color: Colors.white,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          style: OutlinedButton.styleFrom(
                            side: const BorderSide(color: Colors.white24),
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: _cancelOrder,
                          icon: const Icon(Icons.cancel, color: _danger),
                          label: Text(
                            "إلغاء",
                            style: GoogleFonts.cairo(
                              color: Colors.white,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          style: OutlinedButton.styleFrom(
                            side: const BorderSide(color: Colors.white24),
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) =>
                                PaymentScreen(orderId: widget.orderId),
                          ),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _danger,
                        padding: const EdgeInsets.symmetric(vertical: 15),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                      ),
                      child: Text(
                        "إنهاء الخدمة (الدفع)",
                        style: GoogleFonts.cairo(
                          color: Colors.white,
                          fontSize: 17,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _statusCard() {
    final km = distanceToUser / 1000;
    final text = _arrived
        ? "✔ الفني وصل لموقعك الآن"
        : "🚗 الفني في الطريق — ${km.toStringAsFixed(2)} كم • ETA $etaMin د";

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(.22),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white10),
      ),
      child: Row(
        children: [
          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _brand.withOpacity(.14),
              border: Border.all(color: _brand.withOpacity(.18)),
            ),
            child: Icon(
              _arrived ? Icons.check_circle : Icons.directions_car,
              color: _brand,
              size: 24,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              text,
              textDirection: TextDirection.rtl,
              style: GoogleFonts.cairo(
                color: Colors.white,
                fontSize: 15.5,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _techCard() {
    final liveText = socketConnected
        ? "Live tracking"
        : (_effectiveFake ? "Fake" : "Offline");
    final liveColor = socketConnected
        ? _brand
        : (_effectiveFake ? Colors.orangeAccent : Colors.redAccent);

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _sheet2.withOpacity(.78),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white10),
      ),
      child: Row(
        children: [
          Container(
            width: 54,
            height: 54,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _brand.withOpacity(.14),
              border: Border.all(color: _brand.withOpacity(.18)),
            ),
            child: Icon(Icons.person, color: _brand, size: 26),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "الفني المعين",
                  style: GoogleFonts.cairo(
                    color: Colors.white,
                    fontSize: 17,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  "الخدمة: ${widget.serviceType}",
                  style: GoogleFonts.cairo(
                    color: Colors.white70,
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  liveText,
                  style: GoogleFonts.cairo(
                    color: liveColor,
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ],
            ),
          ),
          Row(
            children: [
              Icon(Icons.star, color: _brand, size: 18),
              const SizedBox(width: 4),
              Text(
                "4.9",
                style: GoogleFonts.cairo(
                  color: Colors.white,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          )
        ],
      ),
    );
  }

  Widget _actionBtn({
    required IconData icon,
    required String label,
    required _ActionKind kind,
    required VoidCallback onTap,
  }) {
    final bool primary = kind == _ActionKind.primary;

    return Material(
      color: primary ? _brand : Colors.white10,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
          alignment: Alignment.center,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon,
                  color: primary ? Colors.black : Colors.white, size: 18),
              const SizedBox(width: 8),
              Text(
                label,
                style: GoogleFonts.cairo(
                  color: primary ? Colors.black : Colors.white,
                  fontWeight: FontWeight.w900,
                  fontSize: 13,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ======================
  // Actions (demo)
  // ======================
  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: _sheet.withOpacity(.96),
        content: Text(
          msg,
          textAlign: TextAlign.center,
          style: GoogleFonts.cairo(
            color: Colors.white,
            fontWeight: FontWeight.w900,
          ),
        ),
      ),
    );
  }

  Future<void> _callTechDemo() async {
    // لو السيرفر بيرجع رقم الفني: بدل الرقم هنا
    const phone = "tel:+201000000000";
    final uri = Uri.parse(phone);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    } else {
      _toast("اربط رقم الفني من السيرفر");
    }
  }

  void _chatDemo() => _toast("اربط شاشة الشات هنا");
  void _shareDemo() => _toast("اربط مشاركة تفاصيل الطلب هنا");

  void _cancelOrder() {
    if (!_effectiveFake) {
      try {
        socketService.cancelOrder(widget.orderId);
      } catch (_) {}
    }
    Navigator.pop(context);
  }

  // ======================
  // Math helpers
  // ======================
  double _distanceBetween(LatLng a, LatLng b) {
    const double R = 6371e3;
    final lat1 = a.latitude * math.pi / 180;
    final lat2 = b.latitude * math.pi / 180;
    final dLat = (b.latitude - a.latitude) * math.pi / 180;
    final dLng = (b.longitude - a.longitude) * math.pi / 180;

    final h = math.sin(dLat / 2) * math.sin(dLat / 2) +
        math.cos(lat1) *
            math.cos(lat2) *
            math.sin(dLng / 2) *
            math.sin(dLng / 2);

    final c = 2 * math.atan2(math.sqrt(h), math.sqrt(1 - h));
    return R * c;
  }

  double _clamp(double v, double min, double max) {
    if (v < min) return min;
    if (v > max) return max;
    return v;
  }

  double _computeBearing(LatLng from, LatLng to) {
    final lat1 = _degToRad(from.latitude);
    final lon1 = _degToRad(from.longitude);
    final lat2 = _degToRad(to.latitude);
    final lon2 = _degToRad(to.longitude);

    final dLon = lon2 - lon1;
    final y = math.sin(dLon) * math.cos(lat2);
    final x = math.cos(lat1) * math.sin(lat2) -
        math.sin(lat1) * math.cos(lat2) * math.cos(dLon);

    var brng = math.atan2(y, x);
    brng = _radToDeg(brng);
    brng = (brng + 360) % 360;

    return brng.isNaN ? 0.0 : brng;
  }

  double _degToRad(double deg) => deg * (math.pi / 180.0);
  double _radToDeg(double rad) => rad * (180.0 / math.pi);

  LatLng _moveTowards(LatLng from, LatLng to, {required double metersStep}) {
    final dist = _distanceBetween(from, to);
    if (dist <= metersStep || dist == 0) return to;

    final t = metersStep / dist;
    return LatLng(
      from.latitude + (to.latitude - from.latitude) * t,
      from.longitude + (to.longitude - from.longitude) * t,
    );
  }

  List<LatLng> _interpolatePoints(LatLng from, LatLng to,
      {required int steps}) {
    final pts = <LatLng>[];
    for (int i = 0; i <= steps; i++) {
      final t = i / steps;
      pts.add(
        LatLng(
          from.latitude + (to.latitude - from.latitude) * t,
          from.longitude + (to.longitude - from.longitude) * t,
        ),
      );
    }
    return pts;
  }

  @override
  void dispose() {
    _pulseTimer?.cancel();
    _smoothTimer?.cancel();
    _metricsTimer?.cancel();
    _routeRefreshTimer?.cancel();
    _flowTimer?.cancel();

    if (!_effectiveFake) {
      try {
        socketService.dispose();
      } catch (_) {}
    }
    super.dispose();
  }
}

enum _ActionKind { primary, secondary }
