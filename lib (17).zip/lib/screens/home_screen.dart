// PATH: lib/screens/home_screen.dart
// ignore_for_file: depend_on_referenced_packages

import 'dart:async';
import 'dart:convert';
import 'dart:io';

// ignore: unused_import
import 'package:dio/dio.dart'; // ✅ NEW (for AI upload later, used inside parts)
import 'package:image_picker/image_picker.dart'; // ✅ for photo check

import 'package:doctor_car_app/features/photo_diagnosis/photo_preview_screen.dart';
import 'package:doctor_car_app/maintenance_services_screen.dart';
import 'package:doctor_car_app/pages/home/home_page.dart';
import 'package:doctor_car_app/screens/about/about_us_screen.dart';
import 'package:doctor_car_app/screens/orders/orders_screen.dart';
// ignore: unused_import
import 'package:doctor_car_app/services/orders/orders_store.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:http/http.dart' as http;
import 'package:geolocator/geolocator.dart';
import 'package:doctor_car_app/screens/location_help_screen.dart';
// ignore: unused_import
import 'package:provider/provider.dart';

// ✅ NEW: real OBD scan flow screen (بدل ObdReportPreviewScreen)
import 'package:doctor_car_app/screens/obd/obd_scan_screen.dart';

import 'account_settings_screen.dart';
import 'road_services_screen.dart';
import 'package:doctor_car_app/screens/support_chat_screen.dart';
import 'package:doctor_car_app/services/support_chat_service.dart';
import 'package:doctor_car_app/config/api_config.dart';
import 'package:doctor_car_app/screens/contact_screen.dart';
import 'package:doctor_car_app/screens/smart_accident_screen.dart';

// ✅ parts (لازم الملفات تكون داخل: lib/screens/home/)
part 'home/home_models.dart';
part 'home/home_strings.dart';
part 'home/home_theme.dart';
part 'home/home_location.dart';
part 'home/home_smart_hub.dart';
part 'home/home_widgets.dart';
part 'home/home_how_card.dart';
part 'home/home_center_details.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  // ================== SETTINGS ==================
  bool _isArabic = true;
  bool _isDarkMode = false;
  bool _prefsLoaded = false;

  // ================== LOCATION STATE ==================
  Position? _myPos;
  String? _locationError;

  // ✅✅ Location Cache (NEW) — لازم يبقى هنا مش جوه extension
  // ignore: unused_field
  Position? _cachedPos;
  // ignore: unused_field
  DateTime? _cachedPosAt;

  // ================== RADIUS FEATURE ==================
  static const List<int> _radiusOptionsKm = [5, 10, 20, 50];
  int _selectedRadiusKm = 20; // default

  double get _maxRadiusMeters => _selectedRadiusKm * 1000.0;
  static const int _centersLimit = 50;

  // ================== CONTROLLERS ==================
  final PageController _bannerController = PageController();
  int _currentBanner = 0;
  Timer? _timer;

  // Bottom nav active index
  int _navIndex = 4;

  // ================== COLORS ==================
  // ✅ اللون الجديد الموحد (Neon Lime)
  static const Color _primary = Color(0xFFA8F12A);
  // ignore: unused_field
  static const Color _accent = Color(0xFF8FDB19);

  // ================== DATA ==================
  final List<String> banners = const [
    "assets/images/v.png",
    "assets/images/vv.png",
    "assets/images/vvv.png",
  ];

  final List<OfferItem> offers = const [
    OfferItem(
      title: "خصم 25% على الصيانة",
      image: "assets/offers/1.png",
      distance: "12 كم",
      until: "صالح حتى 31-01-2026",
    ),
    OfferItem(
      title: "خصم 8% على الزجاج المحلي",
      image: "assets/offers/2.png",
      distance: "15 كم",
      until: "صالح حتى 15-01-2026",
    ),
    OfferItem(
      title: "خصم 20% على السطحة",
      image: "assets/offers/3.png",
      distance: "9 كم",
      until: "صالح حتى 01-02-2026",
    ),
  ];

  late Future<List<CenterItem>> _centersFuture;

  static Color? get _gold => null;

  // ================== INIT ==================
  @override
  void initState() {
    super.initState();

    _centersFuture = _fetchCentersNearMe(); // ✅ موجودة في home_location.dart
    _loadPrefs(); // ✅ موجودة في home_location.dart

    _timer = Timer.periodic(const Duration(seconds: 4), (_) {
      if (!mounted) return;
      if (banners.isEmpty) return;
      _currentBanner = (_currentBanner + 1) % banners.length;
      _bannerController.animateToPage(
        _currentBanner,
        duration: const Duration(milliseconds: 550),
        curve: Curves.easeInOutCubic,
      );
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _bannerController.dispose();
    super.dispose();
  }

  // ================== UI ==================
  @override
  Widget build(BuildContext context) {
    if (!_prefsLoaded) {
      return Scaffold(
        backgroundColor: const Color(0xff0B1220),
        body: Center(
          child: Text(
            "Doctor Car",
            style: GoogleFonts.cairo(
              fontSize: 17,
              fontWeight: FontWeight.w900,
              color: _primary,
            ),
          ),
        ),
      );
    }

    // ✅ Dynamic bottom spacing بدل 120 ثابت (عشان موبايلات مختلفة)
    final bottomSafe = MediaQuery.of(context).padding.bottom;
    final bottomSpacer = 90 + bottomSafe;

    // ✅ OPTIONAL: لو الخط بيكبر وبيكسر UI على أجهزة مختلفة
    // تقدر تمسح الجزء ده لو مش عايزه
    final mq = MediaQuery.of(context);
    final clampedScaler = mq.textScaler.clamp(
      minScaleFactor: 0.95,
      maxScaleFactor: 1.10,
    );

    return MediaQuery(
      data: mq.copyWith(textScaler: clampedScaler),
      child: Directionality(
        textDirection: _isArabic ? TextDirection.rtl : TextDirection.ltr,
        child: Scaffold(
          backgroundColor: bgColor, // ✅ جاي من home_theme.dart
          appBar: _buildAppBar(),
          endDrawer: _buildDrawer(),
          bottomNavigationBar: _buildBottomNavCurvedWithCall(), // ✅ متدرج
          body: SafeArea(
            bottom: false,
            child: RefreshIndicator(
              color: _primary,
              onRefresh: _refresh, // ✅ موجودة في home_location.dart
              child: CustomScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                slivers: [
                  const SliverToBoxAdapter(child: SizedBox(height: 16)),
                  SliverPadding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    sliver: SliverToBoxAdapter(child: _bannerSlider()),
                  ),
                  const SliverToBoxAdapter(child: SizedBox(height: 18)),
                  SliverPadding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    sliver: SliverToBoxAdapter(child: _quickServicesRow()),
                  ),
                  const SliverToBoxAdapter(child: SizedBox(height: 14)),
                  SliverPadding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    sliver: SliverToBoxAdapter(child: _smartHubBarPro()),
                  ),
                  SliverPadding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    sliver: SliverToBoxAdapter(
                        child: _sectionTitle(trKey("offers"))),
                  ),
                  SliverPadding(
                    padding: const EdgeInsets.only(left: 16, right: 16),
                    sliver: SliverToBoxAdapter(child: _offersSlider()),
                  ),
                  const SliverToBoxAdapter(child: SizedBox(height: 22)),
                  SliverPadding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    sliver: SliverToBoxAdapter(
                        child: _sectionTitle(trKey("nearby"))),
                  ),
                  SliverPadding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    sliver: SliverToBoxAdapter(child: _radiusSelector()),
                  ),
                  SliverPadding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    sliver: SliverToBoxAdapter(child: _myLocationCard()),
                  ),
                  SliverPadding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    sliver: SliverToBoxAdapter(child: _centersList()),
                  ),
                  const SliverToBoxAdapter(child: SizedBox(height: 24)),
                  SliverPadding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    sliver: SliverToBoxAdapter(child: _howToUseDoctorCar()),
                  ),
                  const SliverToBoxAdapter(child: SizedBox(height: 24)),
                  SliverPadding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    sliver: SliverToBoxAdapter(
                        child: _whyDoctorCar()), // ✅ هنعدل Grid لمنع overflow
                  ),
                  const SliverToBoxAdapter(child: SizedBox(height: 24)),
                  SliverPadding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    sliver: SliverToBoxAdapter(
                        child: _customerService()), // ✅ هنخليه متدرج
                  ),

                  // ✅ بدل 120 ثابت
                  SliverToBoxAdapter(child: SizedBox(height: bottomSpacer)),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
