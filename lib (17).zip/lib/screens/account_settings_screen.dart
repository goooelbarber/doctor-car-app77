// ================================================================
// FILE: lib/screens/account/account_settings_screen.dart
// PRO GRADIENT + GLASS VERSION (Green -> White)
// ================================================================

import 'dart:io';
import 'dart:ui';

import 'package:doctor_car_app/screens/account/notifications_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:image_picker/image_picker.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:google_fonts/google_fonts.dart';

import 'package:doctor_car_app/pages/home/home_page.dart';
import 'package:doctor_car_app/widgets/account/account_quick_actions.dart';
import 'package:doctor_car_app/screens/vehicles/vehicle_screen.dart';
import 'package:doctor_car_app/screens/account/security_center_screen.dart';

class AccountSettingsScreen extends StatefulWidget {
  const AccountSettingsScreen({super.key});

  @override
  State<AccountSettingsScreen> createState() => _AccountSettingsScreenState();
}

class _AccountSettingsScreenState extends State<AccountSettingsScreen> {
  bool _notificationsEnabled = true;
  bool _isDarkMode = false;
  String _language = 'ar';
  String _userName = 'مستخدم التطبيق';

  File? _profileImage;
  String? _profileImagePath;

  // ===== BRAND =====
  static const Color _brand = Color.fromARGB(255, 26, 217, 105);
  static const Color _bg1 = Color(0xff0B1220);
  // ignore: unused_field
  static const Color _bg2 = Color(0xff081837);
  static const Color _bg3 = Color(0xff06101C);

  Color get _brand2 => Color.lerp(_brand, const Color(0xff0B1220), 0.22)!;
  Color get _brand3 => Color.lerp(_brand, Colors.white, 0.18)!;

  Color get _textMain => _isDarkMode ? const Color(0xffF9FAFB) : Colors.white;
  Color get _textSub =>
      _isDarkMode ? const Color(0xffCBD5E1) : Colors.white.withOpacity(.78);

  Color get _stroke => _isDarkMode
      ? Colors.white.withOpacity(.10)
      : Colors.white.withOpacity(.12);

  LinearGradient get _screenBgGradient => LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          _bg1,
          Color.lerp(_bg1, _brand2, .06)!,
          _bg3,
        ],
      );

  /// ✅ Green -> White gradient (Main Request)
  LinearGradient get _greenWhiteGradient => LinearGradient(
        begin: Alignment.topRight,
        end: Alignment.bottomLeft,
        colors: [
          _brand.withOpacity(.92),
          Color.lerp(_brand, Colors.white, .62)!,
          Colors.white.withOpacity(1),
        ],
        stops: const [0.0, 0.56, 1.0],
      );

  /// Glass card gradient (dark)
  LinearGradient get _glassGradient => LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: _isDarkMode
            ? [
                Colors.white.withOpacity(.08),
                Colors.white.withOpacity(.05),
                Colors.white.withOpacity(.03),
              ]
            : [
                Colors.white.withOpacity(.10),
                Colors.white.withOpacity(.07),
                Colors.white.withOpacity(.05),
              ],
        stops: const [0.0, 0.55, 1.0],
      );

  List<BoxShadow> get _glow => [
        BoxShadow(
          color: _brand.withOpacity(_isDarkMode ? .28 : .22),
          blurRadius: 28,
          offset: const Offset(0, 14),
        ),
        BoxShadow(
          color: Colors.black.withOpacity(.22),
          blurRadius: 18,
          offset: const Offset(0, 10),
        ),
      ];

  List<BoxShadow> get _shadowSm => [
        BoxShadow(
          color: Colors.black.withOpacity(.22),
          blurRadius: 16,
          offset: const Offset(0, 10),
        ),
      ];

  // ===== PREFS KEYS =====
  static const String _kNoti = 'notifications';
  static const String _kDark = 'darkMode';
  static const String _kLang = 'lang';
  static const String _kName = 'name';
  static const String _kProfilePath = 'profileImagePath';

  @override
  void initState() {
    super.initState();
    _load();
  }

  void _tap(VoidCallback fn) {
    HapticFeedback.selectionClick();
    fn();
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        backgroundColor: Colors.black.withOpacity(.85),
        content: Text(
          msg,
          textAlign: TextAlign.center,
          style: GoogleFonts.cairo(
            color: Colors.white,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
    );
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;

    final p = prefs.getString(_kProfilePath);
    setState(() {
      _notificationsEnabled = prefs.getBool(_kNoti) ?? true;
      _isDarkMode = prefs.getBool(_kDark) ?? false;
      _language = prefs.getString(_kLang) ?? 'ar';
      _userName = prefs.getString(_kName) ?? 'مستخدم التطبيق';
      _profileImagePath = p;
      if (p != null && p.isNotEmpty) {
        final f = File(p);
        if (f.existsSync()) _profileImage = f;
      }
    });
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_kNoti, _notificationsEnabled);
    await prefs.setBool(_kDark, _isDarkMode);
    await prefs.setString(_kLang, _language);
    await prefs.setString(_kName, _userName);
    if (_profileImagePath != null) {
      await prefs.setString(_kProfilePath, _profileImagePath!);
    }
  }

  Future<void> _changeLang(String lang) async {
    setState(() => _language = lang);
    await context.setLocale(Locale(lang));
    await _save();
    _snack(lang == 'ar' ? "تم تغيير اللغة ✅" : "Language changed ✅");
  }

  Future<void> _pickImage() async {
    try {
      final img = await ImagePicker().pickImage(source: ImageSource.gallery);
      if (img == null) return;
      final f = File(img.path);
      setState(() {
        _profileImage = f;
        _profileImagePath = img.path;
      });
      await _save();
      _snack("تم تحديث الصورة ✅");
    } catch (_) {
      _snack("تعذر اختيار الصورة");
    }
  }

  Future<void> _editName() async {
    final c = TextEditingController(text: _userName);
    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: Text("تعديل الاسم",
            style: GoogleFonts.cairo(fontWeight: FontWeight.w900)),
        content: TextField(
          controller: c,
          decoration: InputDecoration(
            hintText: "اكتب اسمك",
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("إلغاء",
                style: GoogleFonts.cairo(fontWeight: FontWeight.w900)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: _brand,
              foregroundColor: Colors.black,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
              elevation: 0,
            ),
            onPressed: () {
              setState(() => _userName =
                  c.text.trim().isEmpty ? _userName : c.text.trim());
              _save();
              Navigator.pop(context);
              _snack("تم حفظ الاسم ✅");
            },
            child: Text("حفظ",
                style: GoogleFonts.cairo(fontWeight: FontWeight.w900)),
          ),
        ],
      ),
    );
  }

  Future<void> _contact(String t) async {
    final map = {
      'whatsapp': Uri.parse("https://wa.me/201275649151"),
      'email': Uri.parse("mailto:support@doctorcar.com"),
      'call': Uri.parse("tel:+201275649151"),
    };

    final uri = map[t];
    if (uri == null) return;

    try {
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      } else {
        _snack("تعذر فتح الرابط");
      }
    } catch (_) {
      _snack("تعذر فتح الرابط");
    }
  }

  double _profileCompletion() {
    // بسيطة: اسم + صورة + لغة + اشعارات
    double v = 0.45;
    if (_userName.trim().isNotEmpty && _userName != 'مستخدم التطبيق') v += 0.20;
    if (_profileImage != null) v += 0.20;
    if (_language.isNotEmpty) v += 0.10;
    if (_notificationsEnabled) v += 0.05;
    return v.clamp(0.0, 1.0);
  }

  @override
  Widget build(BuildContext context) {
    // ✅ clamp text scaling لمنع overflow مع تكبير الخط
    final mq = MediaQuery.of(context);
    final scale = mq.textScaler.scale(1.0);
    final clamped = scale.clamp(1.0, 1.12);
    final fixedMq = mq.copyWith(textScaler: TextScaler.linear(clamped));

    return MediaQuery(
      data: fixedMq,
      child: Scaffold(
        backgroundColor: _bg1,
        appBar: _buildAppBar(),
        body: Stack(
          children: [
            Container(decoration: BoxDecoration(gradient: _screenBgGradient)),
            SafeArea(
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  _profileCard(),
                  const SizedBox(height: 18),
                  const AccountQuickActions(),
                  const SizedBox(height: 22),
                  _title("لوحة التحكم"),
                  const SizedBox(height: 10),
                  _dashboard(),
                  const SizedBox(height: 22),
                  _title("الإعدادات"),
                  const SizedBox(height: 10),
                  _settingCard(
                    icon: Icons.language,
                    title: "اللغة",
                    subtitle: _language == 'ar' ? "العربية" : "English",
                    trailing: _langDropdown(),
                  ),
                  _switchCard(
                    icon: Icons.notifications,
                    title: "الإشعارات",
                    value: _notificationsEnabled,
                    onChanged: (v) {
                      setState(() => _notificationsEnabled = v);
                      _save();
                    },
                  ),
                  _switchCard(
                    icon: Icons.dark_mode,
                    title: "الوضع الليلي",
                    value: _isDarkMode,
                    onChanged: (v) {
                      setState(() => _isDarkMode = v);
                      _save();
                    },
                  ),
                  _settingCard(
                    icon: Icons.security,
                    title: "الأمان",
                    subtitle: "إعدادات الحماية والخصوصية",
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const SecurityCenterScreen(),
                      ),
                    ),
                  ),
                  _settingCard(
                    icon: Icons.notifications_active,
                    title: "مركز الإشعارات",
                    subtitle: "عرض آخر التنبيهات",
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const NotificationsScreen(),
                      ),
                    ),
                  ),
                  const SizedBox(height: 22),
                  _title("الدعم الفني"),
                  const SizedBox(height: 10),
                  _support(),
                  const SizedBox(height: 26),
                  _logout(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ================= AppBar =================
  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      elevation: 0,
      backgroundColor: Colors.transparent,
      foregroundColor: Colors.white,
      centerTitle: true,
      title: Text(
        "حسابي",
        style: GoogleFonts.cairo(
          color: Colors.white,
          fontWeight: FontWeight.w900,
          fontSize: 18,
        ),
      ),
      flexibleSpace: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              _bg3,
              Color.lerp(_bg3, _brand2, 0.10)!,
              Colors.transparent,
            ],
            stops: const [0.0, 0.78, 1.0],
          ),
        ),
      ),
    );
  }

  // ================= UI Widgets =================

  Widget _title(String t) => Row(
        children: [
          Container(
            width: 6,
            height: 22,
            decoration: BoxDecoration(
              color: _brand,
              borderRadius: BorderRadius.circular(6),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              t,
              style: GoogleFonts.cairo(
                fontSize: 17,
                fontWeight: FontWeight.w900,
                color: Colors.white,
              ),
            ),
          ),
        ],
      );

  Widget _glassCard({
    required Widget child,
    EdgeInsets padding = const EdgeInsets.all(16),
    BorderRadius borderRadius = const BorderRadius.all(Radius.circular(22)),
    bool withGlow = false,
  }) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: borderRadius,
        boxShadow: withGlow ? _glow : _shadowSm,
      ),
      child: ClipRRect(
        borderRadius: borderRadius,
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
          child: Container(
            padding: padding,
            decoration: BoxDecoration(
              gradient: _glassGradient,
              borderRadius: borderRadius,
              border: Border.all(color: _stroke),
            ),
            child: child,
          ),
        ),
      ),
    );
  }

  Widget _profileCard() {
    final progress = _profileCompletion();
    final percent = (progress * 100).round();

    return _glassCard(
      withGlow: true,
      child: Column(
        children: [
          Stack(
            alignment: Alignment.bottomRight,
            children: [
              Container(
                width: 112,
                height: 112,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: _greenWhiteGradient,
                  boxShadow: [
                    BoxShadow(
                      color: _brand.withOpacity(.22),
                      blurRadius: 18,
                      offset: const Offset(0, 10),
                    )
                  ],
                ),
                child: CircleAvatar(
                  radius: 54,
                  backgroundColor: Colors.black.withOpacity(.10),
                  backgroundImage:
                      _profileImage != null ? FileImage(_profileImage!) : null,
                  child: _profileImage == null
                      ? const Icon(Icons.person_rounded,
                          size: 60, color: Colors.black)
                      : null,
                ),
              ),
              GestureDetector(
                onTap: _pickImage,
                child: Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    gradient: _greenWhiteGradient,
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.black.withOpacity(.08)),
                  ),
                  child: const Icon(Icons.camera_alt_rounded,
                      size: 18, color: Colors.black),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            _userName,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: GoogleFonts.cairo(
              color: _textMain,
              fontSize: 20,
              fontWeight: FontWeight.w900,
            ),
          ),
          TextButton(
            onPressed: _editName,
            child: Text(
              "تعديل الاسم",
              style: GoogleFonts.cairo(
                fontWeight: FontWeight.w900,
                color: _brand.withOpacity(.95),
              ),
            ),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(999),
                  child: LinearProgressIndicator(
                    value: progress,
                    minHeight: 10,
                    backgroundColor: Colors.white.withOpacity(.08),
                    valueColor: AlwaysStoppedAnimation<Color>(_brand),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: _brand.withOpacity(.16),
                  borderRadius: BorderRadius.circular(999),
                  border: Border.all(color: _brand.withOpacity(.22)),
                ),
                child: Text(
                  "$percent%",
                  style: GoogleFonts.cairo(
                    color: _brand.withOpacity(.95),
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            "اكتمال الحساب",
            style: GoogleFonts.cairo(
              color: _textSub,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }

  Widget _dashboard() => GridView.count(
        crossAxisCount: 2,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        mainAxisSpacing: 14,
        crossAxisSpacing: 14,
        childAspectRatio: 1.18,
        children: [
          _dash(
            FontAwesomeIcons.store,
            "المتجر",
            "تصفح المنتجات",
            () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const HomePage()),
            ),
          ),
          _dash(Icons.wallet_rounded, "المحفظة", "رصيدك وعملياتك", () {
            _snack("ميزة المحفظة قريبًا 💳");
          }),
          _dash(Icons.history_rounded, "الطلبات", "طلباتك السابقة", () {
            _snack("ميزة الطلبات قريبًا 🧾");
          }),
          _dash(
            Icons.car_rental_rounded,
            "مركباتي",
            "إدارة سياراتك",
            () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const VehiclesScreen()),
            ),
          ),
        ],
      );

  Widget _dash(IconData i, String t, String sub, VoidCallback onTap) => InkWell(
        onTap: () => _tap(onTap),
        borderRadius: BorderRadius.circular(22),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: _glassGradient,
            border: Border.all(color: _stroke),
            boxShadow: _shadowSm,
          ),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(
                    gradient: _greenWhiteGradient,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: _brand.withOpacity(.18)),
                  ),
                  child: Icon(i, color: Colors.black, size: 24),
                ),
                const SizedBox(height: 10),
                Text(
                  t,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.cairo(
                    color: _textMain,
                    fontWeight: FontWeight.w900,
                    fontSize: 14.5,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  sub,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.cairo(
                    color: _textSub,
                    fontWeight: FontWeight.w700,
                    fontSize: 12.2,
                  ),
                ),
              ],
            ),
          ),
        ),
      );

  Widget _support() => Row(
        children: [
          Expanded(
            child: _supportBtn(
              FontAwesomeIcons.whatsapp,
              "WhatsApp",
              () => _contact('whatsapp'),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _supportBtn(
              Icons.email_rounded,
              "Email",
              () => _contact('email'),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _supportBtn(
              Icons.phone_rounded,
              "Call",
              () => _contact('call'),
            ),
          ),
        ],
      );

  Widget _supportBtn(IconData i, String t, VoidCallback onTap) => InkWell(
        onTap: () => _tap(onTap),
        borderRadius: BorderRadius.circular(18),
        child: Container(
          height: 58,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            gradient: _glassGradient,
            border: Border.all(color: _stroke),
            boxShadow: _shadowSm,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  gradient: _greenWhiteGradient,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(i, color: Colors.black, size: 18),
              ),
              const SizedBox(width: 10),
              Text(
                t,
                style: GoogleFonts.cairo(
                  color: _textMain,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
        ),
      );

  Widget _logout() => SizedBox(
        height: 54,
        child: ElevatedButton.icon(
          icon: const Icon(Icons.logout_rounded, color: Colors.black),
          label: Text(
            "تسجيل الخروج",
            style: GoogleFonts.cairo(
              fontWeight: FontWeight.w900,
              color: Colors.black,
              fontSize: 15.5,
            ),
          ),
          style: ElevatedButton.styleFrom(
            elevation: 0,
            backgroundColor: _brand,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
          ),
          onPressed: () async {
            final prefs = await SharedPreferences.getInstance();
            await prefs.clear();
            if (!mounted) return;
            Navigator.pushNamedAndRemoveUntil(context, '/login', (_) => false);
          },
        ),
      );

  Widget _settingCard({
    required IconData icon,
    required String title,
    String? subtitle,
    Widget? trailing,
    VoidCallback? onTap,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 7),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        boxShadow: _shadowSm,
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
          child: ListTile(
            onTap: onTap != null ? () => _tap(onTap) : null,
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            tileColor: Colors.white.withOpacity(.04),
            leading: Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                gradient: _greenWhiteGradient,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(icon, color: Colors.black, size: 22),
            ),
            title: Text(
              title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: GoogleFonts.cairo(
                color: _textMain,
                fontWeight: FontWeight.w900,
                fontSize: 15,
              ),
            ),
            subtitle: subtitle != null
                ? Padding(
                    padding: const EdgeInsets.only(top: 3),
                    child: Text(
                      subtitle,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.cairo(
                        color: _textSub,
                        fontWeight: FontWeight.w700,
                        fontSize: 12.8,
                      ),
                    ),
                  )
                : null,
            trailing: trailing ??
                Icon(Icons.chevron_right_rounded,
                    color: Colors.white.withOpacity(.70)),
          ),
        ),
      ),
    );
  }

  Widget _switchCard({
    required IconData icon,
    required String title,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 7),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        boxShadow: _shadowSm,
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
          child: SwitchListTile(
            value: value,
            onChanged: (v) => _tap(() => onChanged(v)),
            tileColor: Colors.white.withOpacity(.04),
            title: Text(
              title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: GoogleFonts.cairo(
                color: _textMain,
                fontWeight: FontWeight.w900,
              ),
            ),
            secondary: Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                gradient: _greenWhiteGradient,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(icon, color: Colors.black, size: 22),
            ),
            activeColor: _brand,
          ),
        ),
      ),
    );
  }

  Widget _langDropdown() => DropdownButton<String>(
        value: _language,
        underline: const SizedBox(),
        dropdownColor: const Color(0xff0E1626),
        style: GoogleFonts.cairo(
          color: Colors.white,
          fontWeight: FontWeight.w900,
        ),
        items: const [
          DropdownMenuItem(value: 'ar', child: Text("العربية")),
          DropdownMenuItem(value: 'en', child: Text("English")),
        ],
        onChanged: (v) {
          if (v == null) return;
          _changeLang(v);
        },
      );
}
