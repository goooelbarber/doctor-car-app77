// PATH: lib/screens/payment_screen.dart
// ignore_for_file: depend_on_referenced_packages, use_build_context_synchronously

import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:url_launcher/url_launcher.dart';

import 'review_screen.dart';

class PaymentScreen extends StatefulWidget {
  final String orderId;

  /// optional: لو جاي من السيرفر/الأوردر
  final double? amount;

  /// optional: نوع الخدمة للعرض
  final String? serviceType;

  const PaymentScreen({
    super.key,
    required this.orderId,
    this.amount,
    this.serviceType,
  });

  @override
  State<PaymentScreen> createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> {
  // ================== DoctorCar Theme ==================
  static const Color _bg = Color(0xff0B1220);
  static const Color _surface = Color(0xff0E1626);
  static const Color _surface2 = Color(0xff0C1322);

  static const Color _brand = Color(0xFFA8F12A);
  static const Color _danger = Color(0xFFEF4444);
  static const Color _yellow = Color(0xFFFFC107);

  static const Color _textMain = Color(0xffF9FAFB);
  static const Color _textSub = Color(0xffCBD5E1);

  Color get brand2 => Color.lerp(_brand, const Color(0xff0B1220), 0.22)!;
  Color get brand3 => Color.lerp(_brand, Colors.white, 0.18)!;

  LinearGradient get screenBgGradient => LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          _bg,
          Color.lerp(_bg, brand2, 0.10)!,
          const Color(0xff07101C),
        ],
      );

  LinearGradient get greenToWhiteGradient => LinearGradient(
        begin: Alignment.centerLeft,
        end: Alignment.centerRight,
        colors: [
          _brand.withOpacity(.95),
          Colors.white,
        ],
        stops: const [0.0, 1.0],
      );

  LinearGradient get glassGradient => LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          Colors.white.withOpacity(.08),
          Colors.white.withOpacity(.05),
          Colors.white.withOpacity(.03),
        ],
        stops: const [0.0, 0.55, 1.0],
      );

  List<BoxShadow> get glowNeon => [
        BoxShadow(
          color: _brand.withOpacity(.28),
          blurRadius: 28,
          spreadRadius: 1,
          offset: const Offset(0, 12),
        ),
        BoxShadow(
          color: brand3.withOpacity(.12),
          blurRadius: 50,
          spreadRadius: 2,
          offset: const Offset(0, 22),
        ),
      ];

  // ================== State ==================
  String selected = "cash";
  final String walletNumber = "01275649151";
  bool _isPaying = false;

  // 💰 Demo values (اربطها بالـ API)
  late final double servicePrice;
  final double fees = 30;
  final double discount = 0;

  double get total => servicePrice + fees - discount;

  @override
  void initState() {
    super.initState();
    servicePrice = widget.amount ?? 120;
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: _bg,
        extendBodyBehindAppBar: true,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          centerTitle: true,
          iconTheme: const IconThemeData(color: _textMain),
          title: Text(
            "الدفع",
            style: GoogleFonts.cairo(
              color: _textMain,
              fontWeight: FontWeight.w900,
              fontSize: 18,
            ),
          ),
        ),
        body: Stack(
          children: [
            _background(),
            _content(),
            if (_isPaying) _loadingOverlay(),
          ],
        ),
      ),
    );
  }

  // ================= BACKGROUND =================
  Widget _background() {
    return Stack(
      children: [
        Container(decoration: BoxDecoration(gradient: screenBgGradient)),
        Positioned(
          left: -60,
          top: -40,
          child: Container(
            width: 220,
            height: 220,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [_brand.withOpacity(.18), Colors.transparent],
              ),
            ),
          ),
        ),
        Positioned(
          right: -80,
          bottom: -60,
          child: Container(
            width: 260,
            height: 260,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [_brand.withOpacity(.12), Colors.transparent],
              ),
            ),
          ),
        ),
      ],
    );
  }

  // ================= CONTENT =================
  Widget _content() {
    final bottomPad = MediaQuery.of(context).padding.bottom;

    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: EdgeInsets.fromLTRB(16, 92, 16, 24 + bottomPad),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _glassHeader(),
          const SizedBox(height: 16),
          Text(
            "اختر طريقة الدفع",
            style: GoogleFonts.cairo(
              fontSize: 20,
              fontWeight: FontWeight.w900,
              color: _textMain,
            ),
          ),
          const SizedBox(height: 14),
          _paymentCard(
            id: "cash",
            title: "الدفع نقدًا",
            subtitle: "الدفع بعد انتهاء الخدمة",
            icon: Icons.payments_rounded,
            accent: _brand,
          ),
          _paymentCard(
            id: "visa",
            title: "فيزا / ماستر كارد",
            subtitle: "الدفع الإلكتروني الآمن",
            icon: Icons.credit_card_rounded,
            accent: Colors.lightBlueAccent,
          ),
          _paymentCard(
            id: "wallet",
            title: "فودافون كاش",
            subtitle: "تحويل للمحفظة",
            icon: Icons.account_balance_wallet_rounded,
            accent: _danger,
          ),
          if (selected == "wallet") ...[
            const SizedBox(height: 10),
            _walletBox(),
          ],
          const SizedBox(height: 18),
          _invoiceCard(),
          const SizedBox(height: 18),
          _payButton(),
        ],
      ),
    );
  }

  Widget _glassHeader() {
    final serviceName = (widget.serviceType ?? "").trim();

    return ClipRRect(
      borderRadius: BorderRadius.circular(22),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            gradient: glassGradient,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: Colors.white.withOpacity(.10)),
          ),
          child: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _yellow.withOpacity(.18),
                  border: Border.all(color: _yellow.withOpacity(.18)),
                ),
                child: const Icon(Icons.receipt_long, color: _yellow),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "تفاصيل الدفع",
                      style: GoogleFonts.cairo(
                        color: _textMain,
                        fontWeight: FontWeight.w900,
                        fontSize: 16,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      serviceName.isEmpty ? "خدمة" : "الخدمة: $serviceName",
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.cairo(
                        color: _textSub,
                        fontWeight: FontWeight.w700,
                        fontSize: 12.5,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: _brand.withOpacity(.25)),
                  color: _brand.withOpacity(.10),
                ),
                child: Text(
                  "${total.toStringAsFixed(0)} ج.م",
                  style: GoogleFonts.cairo(
                    color: _textMain,
                    fontWeight: FontWeight.w900,
                    fontSize: 14.5,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ================= PAYMENT CARD =================
  Widget _paymentCard({
    required String id,
    required String title,
    required String subtitle,
    required IconData icon,
    required Color accent,
  }) {
    final bool isActive = selected == id;

    return InkWell(
      onTap: _isPaying
          ? null
          : () {
              HapticFeedback.selectionClick();
              setState(() => selected = id);
            },
      borderRadius: BorderRadius.circular(18),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: isActive ? accent.withOpacity(.85) : Colors.white24,
            width: isActive ? 2 : 1,
          ),
          color: Colors.white.withOpacity(isActive ? .07 : .06),
          gradient: isActive
              ? LinearGradient(
                  colors: [
                    accent.withOpacity(.18),
                    Colors.white.withOpacity(.04),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                )
              : null,
          boxShadow: [
            if (isActive)
              BoxShadow(
                color: accent.withOpacity(.18),
                blurRadius: 24,
                offset: const Offset(0, 10),
              ),
            BoxShadow(
              color: Colors.black.withOpacity(.20),
              blurRadius: 18,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 52,
              height: 52,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                color: accent.withOpacity(.18),
                border: Border.all(color: accent.withOpacity(.22)),
              ),
              child: Icon(icon, size: 28, color: accent),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: GoogleFonts.cairo(
                      fontSize: 16,
                      fontWeight: FontWeight.w900,
                      color: _textMain,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: GoogleFonts.cairo(
                      fontSize: 12.5,
                      color: _textSub,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              isActive ? Icons.check_circle : Icons.circle_outlined,
              size: 24,
              color: isActive ? accent : Colors.white38,
            ),
          ],
        ),
      ),
    );
  }

  // ================= WALLET BOX =================
  Widget _walletBox() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _surface2.withOpacity(.75),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _danger.withOpacity(.55)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "رقم فودافون كاش",
            style: GoogleFonts.cairo(
              color: _textMain,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: Text(
                  walletNumber,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.cairo(
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                    color: _textMain,
                    letterSpacing: 1,
                  ),
                ),
              ),
              IconButton(
                icon: const Icon(Icons.copy, color: _textMain),
                onPressed: () {
                  Clipboard.setData(ClipboardData(text: walletNumber));
                  _snack("تم نسخ رقم المحفظة");
                },
              ),
            ],
          ),
          Text(
            "حوّل المبلغ ثم اضغط (تأكيد الدفع).",
            style: GoogleFonts.cairo(color: _textSub),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _openWhatsAppPayMessage,
                  style: OutlinedButton.styleFrom(
                    foregroundColor: _textMain,
                    side: BorderSide(color: _brand.withOpacity(.35)),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  icon: Icon(Icons.chat, color: _brand),
                  label: Text(
                    "إرسال رسالة واتساب",
                    style: GoogleFonts.cairo(fontWeight: FontWeight.w900),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Future<void> _openWhatsAppPayMessage() async {
    final msg =
        "تم التحويل فودافون كاش ✅\nرقم الطلب: ${widget.orderId}\nالمبلغ: ${total.toStringAsFixed(0)} جنيه\nرقم المحفظة: $walletNumber";
    final uri = Uri.parse(
        "https://wa.me/2$walletNumber?text=${Uri.encodeComponent(msg)}");
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
      _snack("تعذر فتح واتساب");
    }
  }

  // ================= INVOICE =================
  Widget _invoiceCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _surface.withOpacity(.92),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white.withOpacity(.10)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "الفاتورة",
            style: GoogleFonts.cairo(
              color: _textMain,
              fontWeight: FontWeight.w900,
              fontSize: 16,
            ),
          ),
          const SizedBox(height: 10),
          _row("سعر الخدمة", servicePrice),
          _row("رسوم إضافية", fees),
          if (discount != 0) _row("خصم", -discount),
          const SizedBox(height: 10),
          Divider(color: Colors.white.withOpacity(.18), height: 18),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "الإجمالي",
                style: GoogleFonts.cairo(
                  color: _textMain,
                  fontWeight: FontWeight.w900,
                  fontSize: 16,
                ),
              ),
              ShaderMask(
                shaderCallback: (b) => greenToWhiteGradient.createShader(b),
                child: Text(
                  "${total.toStringAsFixed(2)} ج.م",
                  style: GoogleFonts.cairo(
                    color: Colors.white,
                    fontWeight: FontWeight.w900,
                    fontSize: 18,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _row(String t, double v) {
    final isNeg = v < 0;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            t,
            style: GoogleFonts.cairo(
              color: _textSub,
              fontWeight: FontWeight.w700,
            ),
          ),
          Text(
            "${v.toStringAsFixed(2)} ج.م",
            style: GoogleFonts.cairo(
              color: isNeg ? _brand : _textMain,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }

  // ================= PAY BUTTON =================
  Widget _payButton() {
    final btnText = selected == "cash"
        ? "تأكيد (دفع نقدًا)"
        : (selected == "wallet" ? "تأكيد (فودافون كاش)" : "تأكيد (بطاقة)");

    return SizedBox(
      width: double.infinity,
      height: 56,
      child: AbsorbPointer(
        absorbing: _isPaying,
        child: InkWell(
          onTap: _pay,
          borderRadius: BorderRadius.circular(18),
          child: Ink(
            decoration: BoxDecoration(
              gradient: greenToWhiteGradient,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: _brand.withOpacity(.28)),
              boxShadow: glowNeon,
            ),
            child: Center(
              child: Text(
                btnText,
                style: GoogleFonts.cairo(
                  fontSize: 16.5,
                  fontWeight: FontWeight.w900,
                  color: Colors.black,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _pay() async {
    if (_isPaying) return;

    HapticFeedback.mediumImpact();
    setState(() => _isPaying = true);

    // TODO: هنا تربط الدفع الحقيقي:
    // - cash: confirm order paid on delivery
    // - wallet: verify transfer / upload receipt
    // - visa: Stripe/Paymob/etc.
    await Future.delayed(const Duration(seconds: 2));

    if (!mounted) return;
    setState(() => _isPaying = false);

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => ReviewScreen(orderId: widget.orderId),
      ),
    );
  }

  // ================= LOADING =================
  Widget _loadingOverlay() {
    return Container(
      color: Colors.black.withOpacity(.45),
      child: Center(
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: _surface.withOpacity(.92),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: Colors.white.withOpacity(.10)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(color: _brand),
              const SizedBox(height: 12),
              Text(
                "جاري تأكيد الدفع...",
                style: GoogleFonts.cairo(
                  fontWeight: FontWeight.w900,
                  color: _textMain,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                "من فضلك متقفلش الشاشة",
                style: GoogleFonts.cairo(
                  fontWeight: FontWeight.w700,
                  color: _textSub,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: _surface.withOpacity(.95),
        content: Text(
          msg,
          textAlign: TextAlign.center,
          style: GoogleFonts.cairo(
            color: _textMain,
            fontWeight: FontWeight.w900,
          ),
        ),
      ),
    );
  }
}
