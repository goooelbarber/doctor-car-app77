// PATH: lib/screens/road_services_screen.dart
// ignore_for_file: depend_on_referenced_packages, use_build_context_synchronously

import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

import 'package:doctor_car_app/screens/smart_accident_screen.dart';
import 'package:doctor_car_app/screens/supplementary_services_screen.dart';
import 'package:doctor_car_app/screens/searching_technician_screen.dart';
import 'package:doctor_car_app/screens/confirm_request_screen.dart';
import 'select_location_screen.dart';

class RoadServicesScreen extends StatefulWidget {
  const RoadServicesScreen({super.key});

  @override
  State<RoadServicesScreen> createState() => _RoadServicesScreenState();
}

class _RoadServicesScreenState extends State<RoadServicesScreen>
    with SingleTickerProviderStateMixin {
  String? selected;
  bool _opening = false;

  // Search
  final TextEditingController _searchCtrl = TextEditingController();
  String _query = '';

  // ✅ DoctorCar Brand
  static const Color _brand = Color(0xFFA8F12A);

  // Background (Dark)
  static const Color _bg1 = Color(0xFF0B1220);
  static const Color _bg2 = Color(0xFF081837);
  static const Color _bg3 = Color(0xFF0A2038);

  static const Color _card = Color(0xFF121B2E);

  // Demo user id
  String get _userId => "68fe4505493ae17aa81d605b";

  final List<Map<String, dynamic>> services = const [
    {"key": "tow", "name": "خدمة ونش", "img": "assets/images/png.png"},
    {"key": "battery", "name": "خدمة بطارية", "img": "assets/images/l.png"},
    {"key": "fuel", "name": "خدمة بنزين", "img": "assets/images/b.png"},
    {"key": "tire", "name": "خدمة الكاوتش", "img": "assets/images/tire.png"},
    {"key": "ride", "name": "سيارة ركاب", "img": "assets/images/car.png"},
    {
      "key": "more",
      "name": "الخدمات الإضافية",
      "img": "assets/images/ff.png",
      "openDirect": true
    },
    {
      "key": "accident",
      "name": "تبليغ عن حادث",
      "img": "assets/images/acc.png",
      "openDirect": true
    },
  ];

  // Animation (for subtle background movement)
  late final AnimationController _bgCtrl;

  @override
  void initState() {
    super.initState();
    _bgCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 4200),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    _bgCtrl.dispose();
    super.dispose();
  }

  void _tap(VoidCallback fn) {
    HapticFeedback.selectionClick();
    fn();
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, textAlign: TextAlign.center),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  List<Map<String, dynamic>> get _filteredServices {
    final q = _query.trim();
    if (q.isEmpty) return services;

    // Arabic-friendly contains
    return services.where((s) {
      final name = (s["name"] as String).trim();
      return name.contains(q) || name.toLowerCase().contains(q.toLowerCase());
    }).toList();
  }

  // ================== Gradients / Shadows ==================

  LinearGradient get _bgGradient => const LinearGradient(
        colors: [_bg1, _bg2, _bg3],
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
      );

  LinearGradient get _ctaGradient => LinearGradient(
        begin: Alignment.centerLeft,
        end: Alignment.centerRight,
        colors: [
          Color.lerp(_brand, Colors.white, 0.25)!,
          _brand,
          Color.lerp(_brand, const Color(0xFF0B1220), 0.18)!,
        ],
        stops: const [0.0, 0.55, 1.0],
      );

  LinearGradient get _glassGradient => LinearGradient(
        begin: Alignment.topRight,
        end: Alignment.bottomLeft,
        colors: [
          Colors.white.withOpacity(.10),
          Colors.white.withOpacity(.06),
          Colors.white.withOpacity(.03),
        ],
        stops: const [0.0, 0.55, 1.0],
      );

  LinearGradient get _selectedGradient => LinearGradient(
        begin: Alignment.topRight,
        end: Alignment.bottomLeft,
        colors: [
          _brand.withOpacity(.20),
          Colors.white.withOpacity(.09),
          Colors.white.withOpacity(.06),
        ],
        stops: const [0.0, 0.60, 1.0],
      );

  List<BoxShadow> get _softShadow => [
        BoxShadow(
          color: Colors.black.withOpacity(.22),
          blurRadius: 22,
          offset: const Offset(0, 12),
        ),
      ];

  List<BoxShadow> get _brandGlow => [
        BoxShadow(
          color: _brand.withOpacity(.28),
          blurRadius: 34,
          offset: const Offset(0, 18),
        ),
        BoxShadow(
          color: Colors.black.withOpacity(.18),
          blurRadius: 22,
          offset: const Offset(0, 12),
        ),
      ];

  // ================== UI ==================

  @override
  Widget build(BuildContext context) {
    final bottomPad = MediaQuery.of(context).padding.bottom;

    // Respectable text scaling (avoid layout breaking)
    final mq = MediaQuery.of(context);
    final scale = mq.textScaler.scale(1.0);
    final clamped = scale.clamp(1.0, 1.15);
    final fixedMq = mq.copyWith(textScaler: TextScaler.linear(clamped));

    final items = _filteredServices;

    return MediaQuery(
      data: fixedMq,
      child: Scaffold(
        backgroundColor: _bg1,
        body: Stack(
          children: [
            _proBackground(),

            CustomScrollView(
              physics: const BouncingScrollPhysics(),
              slivers: [
                _sliverAppBar(),
                SliverToBoxAdapter(
                  child: Padding(
                    padding: EdgeInsets.fromLTRB(16, 14, 16, 114 + bottomPad),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _heroHeader(),
                        const SizedBox(height: 12),
                        _searchBar(),
                        const SizedBox(height: 12),
                        _quickChips(),
                        const SizedBox(height: 14),

                        // Grid
                        LayoutBuilder(
                          builder: (context, c) {
                            final w = c.maxWidth;
                            final crossAxisCount = w >= 560 ? 3 : 2;
                            final aspect = w >= 560 ? 1.02 : 0.92;

                            return GridView.builder(
                              itemCount: items.length,
                              shrinkWrap: true,
                              physics: const NeverScrollableScrollPhysics(),
                              gridDelegate:
                                  SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: crossAxisCount,
                                mainAxisSpacing: 14,
                                crossAxisSpacing: 14,
                                childAspectRatio: aspect,
                              ),
                              itemBuilder: (_, index) {
                                final item = items[index];
                                final String key = item["key"] as String;
                                final String name = item["name"] as String;
                                final String img = item["img"] as String;
                                final bool openDirect =
                                    (item["openDirect"] == true);

                                final isSel = selected == key;

                                return Semantics(
                                  button: true,
                                  selected: isSel,
                                  label: name,
                                  child: _serviceCard(
                                    keyId: key,
                                    name: name,
                                    img: img,
                                    openDirect: openDirect,
                                    selected: isSel,
                                    onTap: _opening
                                        ? null
                                        : () {
                                            _tap(() => setState(() {
                                                  selected = key;
                                                }));

                                            if (openDirect) {
                                              _openSelected(key);
                                            }
                                          },
                                  ),
                                );
                              },
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),

            // Bottom CTA
            Positioned(
              left: 16,
              right: 16,
              bottom: 14,
              child: SafeArea(
                top: false,
                child: _bottomCta(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ================== PRO BACKGROUND (Green in White effects) ==================

  Widget _proBackground() {
    return AnimatedBuilder(
      animation: _bgCtrl,
      builder: (_, __) {
        final t = _bgCtrl.value; // 0..1
        final dx = lerpDouble(-0.18, 0.18, t)!;
        final dy = lerpDouble(0.06, -0.04, t)!;

        return Stack(
          children: [
            // Base gradient
            Container(decoration: BoxDecoration(gradient: _bgGradient)),

            // Green glow blobs (soft)
            Align(
              alignment: Alignment(dx, -0.92),
              child: _glowBlob(size: 260, opacity: 0.18),
            ),
            Align(
              alignment: Alignment(-0.85, dy),
              child: _glowBlob(size: 320, opacity: 0.14),
            ),
            Align(
              alignment: Alignment(0.95, 0.25 - dy),
              child: _glowBlob(size: 240, opacity: 0.12),
            ),

            // Top vignette (makes it premium)
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withOpacity(0.28),
                    Colors.transparent,
                    Colors.black.withOpacity(0.18),
                  ],
                  stops: const [0.0, 0.55, 1.0],
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _glowBlob({required double size, required double opacity}) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [
            _brand.withOpacity(opacity),
            _brand.withOpacity(opacity * 0.35),
            Colors.transparent,
          ],
          stops: const [0.0, 0.45, 1.0],
        ),
      ),
    );
  }

  // ================== AppBar ==================

  SliverAppBar _sliverAppBar() {
    return SliverAppBar(
      pinned: true,
      backgroundColor: Colors.transparent,
      elevation: 0,
      leading: IconButton(
        icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white),
        onPressed: () => Navigator.pop(context),
      ),
      title: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 30,
            height: 30,
            decoration: BoxDecoration(
              color: _brand.withOpacity(.14),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _brand.withOpacity(.26)),
            ),
            child: const Icon(
              Icons.directions_car_rounded,
              color: _brand,
              size: 18,
            ),
          ),
          const SizedBox(width: 8),
          Text(
            "خدمات الطريق",
            style: GoogleFonts.cairo(
              fontSize: 18,
              fontWeight: FontWeight.w900,
              color: Colors.white,
            ),
          ),
        ],
      ),
      centerTitle: true,
      flexibleSpace: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Colors.black.withOpacity(0.62),
              Colors.black.withOpacity(0.20),
              Colors.transparent,
            ],
            stops: const [0.0, 0.7, 1.0],
          ),
        ),
      ),
    );
  }

  // ================== Header ==================

  Widget _heroHeader() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(22),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(.06),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: Colors.white10),
          ),
          child: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _brand.withOpacity(.14),
                  border: Border.all(color: _brand.withOpacity(.22)),
                ),
                child:
                    const Icon(Icons.handyman_rounded, color: _brand, size: 24),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "اطلب خدمتك في ثواني",
                      style: GoogleFonts.cairo(
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                        fontSize: 17,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      "اختار الخدمة → حدد موقعك → نوصلك بأقرب فني",
                      style: GoogleFonts.cairo(
                        color: Colors.white70,
                        fontWeight: FontWeight.w700,
                        fontSize: 12.5,
                      ),
                    ),
                  ],
                ),
              ),
              if (selected != null)
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(.20),
                    borderRadius: BorderRadius.circular(999),
                    border: Border.all(color: _brand.withOpacity(.24)),
                  ),
                  child: Text(
                    "مختار",
                    style: GoogleFonts.cairo(
                      color: _brand,
                      fontSize: 12,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  // ================== Search ==================

  Widget _searchBar() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(18),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
        child: Container(
          height: 54,
          decoration: BoxDecoration(
            gradient: _glassGradient,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: Colors.white.withOpacity(.14)),
          ),
          child: TextField(
            controller: _searchCtrl,
            onChanged: (v) => setState(() => _query = v.trim()),
            style: GoogleFonts.cairo(
              color: Colors.white,
              fontWeight: FontWeight.w800,
            ),
            cursorColor: _brand,
            decoration: InputDecoration(
              border: InputBorder.none,
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 16),
              prefixIcon: Icon(Icons.search_rounded,
                  color: Colors.white.withOpacity(.70)),
              hintText: "ابحث عن خدمة (ونش، بطارية، بنزين...)",
              hintStyle: GoogleFonts.cairo(
                color: Colors.white.withOpacity(.55),
                fontWeight: FontWeight.w700,
              ),
              suffixIcon: _query.isEmpty
                  ? null
                  : IconButton(
                      onPressed: () {
                        _tap(() {
                          _searchCtrl.clear();
                          setState(() => _query = '');
                        });
                      },
                      icon: Icon(Icons.close_rounded,
                          color: Colors.white.withOpacity(.75)),
                    ),
            ),
          ),
        ),
      ),
    );
  }

  // ================== Quick chips ==================

  Widget _quickChips() {
    final chips = <Map<String, dynamic>>[
      {"key": "tow", "label": "ونش", "icon": Icons.fire_truck_rounded},
      {
        "key": "battery",
        "label": "بطارية",
        "icon": Icons.battery_charging_full
      },
      {"key": "fuel", "label": "بنزين", "icon": Icons.local_gas_station},
      {"key": "tire", "label": "كاوتش", "icon": Icons.tire_repair},
      {"key": "more", "label": "إضافية", "icon": Icons.grid_view_rounded},
    ];

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      physics: const BouncingScrollPhysics(),
      child: Row(
        children: chips.map((c) {
          final k = c["key"] as String;
          final active = selected == k;

          return Padding(
            padding: const EdgeInsets.only(right: 10),
            child: GestureDetector(
              onTap: _opening
                  ? null
                  : () {
                      _tap(() => setState(() => selected = k));
                      // لو chip direct
                      if (k == "more") _openSelected(k);
                    },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                decoration: BoxDecoration(
                  color: active ? _brand.withOpacity(.16) : Colors.white10,
                  borderRadius: BorderRadius.circular(999),
                  border: Border.all(
                    color: active ? _brand.withOpacity(.70) : Colors.white12,
                    width: active ? 1.4 : 1.0,
                  ),
                ),
                child: Row(
                  children: [
                    Icon(c["icon"] as IconData,
                        color: active ? _brand : Colors.white70, size: 18),
                    const SizedBox(width: 8),
                    Text(
                      c["label"] as String,
                      style: GoogleFonts.cairo(
                        color: active ? Colors.white : Colors.white70,
                        fontWeight: FontWeight.w900,
                        fontSize: 12.5,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  // ================== Service card ==================

  Widget _serviceCard({
    required String keyId,
    required String name,
    required String img,
    required bool openDirect,
    required bool selected,
    required VoidCallback? onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(22),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        curve: Curves.easeOutCubic,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          border: Border.all(
            color: selected ? _brand.withOpacity(.95) : Colors.white12,
            width: selected ? 2.4 : 1.2,
          ),
          gradient: selected ? _selectedGradient : _glassGradient,
          boxShadow: selected ? _brandGlow : _softShadow,
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(22),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _serviceImage(img),
                  const SizedBox(height: 12),
                  Text(
                    name,
                    textAlign: TextAlign.center,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: GoogleFonts.cairo(
                      color: Colors.white,
                      fontSize: 15.5,
                      fontWeight: FontWeight.w900,
                      height: 1.18,
                    ),
                  ),
                  if (openDirect) ...[
                    const SizedBox(height: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: _brand.withOpacity(.14),
                        borderRadius: BorderRadius.circular(999),
                        border: Border.all(color: _brand.withOpacity(.22)),
                      ),
                      child: Text(
                        "يفتح مباشرة",
                        style: GoogleFonts.cairo(
                          color: _brand.withOpacity(0.98),
                          fontSize: 12,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _serviceImage(String img) {
    return Container(
      height: 88,
      width: double.infinity,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.10),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.10)),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      child: FittedBox(
        fit: BoxFit.contain,
        child: Image.asset(
          img,
          errorBuilder: (_, __, ___) => Icon(
            Icons.image_not_supported,
            color: Colors.white.withOpacity(0.70),
            size: 46,
          ),
        ),
      ),
    );
  }

  // ================== Bottom CTA ==================

  Widget _bottomCta() {
    final disabled = (selected == null || _opening);

    final btnText = _buttonLabel();
    final sub =
        (selected == null) ? "اختار خدمة عشان تكمل" : "هنبدأ طلب الخدمة فورًا";

    return ClipRRect(
      borderRadius: BorderRadius.circular(18),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: _card.withOpacity(.72),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: Colors.white12),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (selected != null)
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 7),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(.20),
                        borderRadius: BorderRadius.circular(999),
                        border: Border.all(color: _brand.withOpacity(.24)),
                      ),
                      child: Text(
                        "الخدمة: ${_selectedName()}",
                        style: GoogleFonts.cairo(
                          color: Colors.white,
                          fontWeight: FontWeight.w900,
                          fontSize: 12.5,
                        ),
                      ),
                    ),
                    const Spacer(),
                    Icon(Icons.verified_rounded,
                        color: _brand.withOpacity(.9), size: 18),
                    const SizedBox(width: 6),
                    Text(
                      "DoctorCar",
                      style: GoogleFonts.cairo(
                        color: Colors.white70,
                        fontWeight: FontWeight.w900,
                        fontSize: 12.5,
                      ),
                    )
                  ],
                ),
              if (selected != null) const SizedBox(height: 10),
              SizedBox(
                height: 56,
                width: double.infinity,
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      if (!disabled)
                        BoxShadow(
                          color: _brand.withOpacity(0.30),
                          blurRadius: 26,
                          offset: const Offset(0, 12),
                        ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(16),
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        AnimatedOpacity(
                          opacity: disabled ? 0.45 : 1,
                          duration: const Duration(milliseconds: 180),
                          child: Container(
                            decoration: BoxDecoration(
                              gradient: disabled
                                  ? LinearGradient(
                                      colors: [
                                        Colors.white.withOpacity(.14),
                                        Colors.white.withOpacity(.10),
                                      ],
                                    )
                                  : _ctaGradient,
                            ),
                          ),
                        ),
                        Material(
                          color: Colors.transparent,
                          child: InkWell(
                            onTap: disabled
                                ? null
                                : () {
                                    HapticFeedback.mediumImpact();
                                    _openSelected(selected!);
                                  },
                            child: Center(
                              child: _opening
                                  ? const SizedBox(
                                      width: 22,
                                      height: 22,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2.3,
                                        color: Colors.black,
                                      ),
                                    )
                                  : Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        const Icon(Icons.flash_on_rounded,
                                            color: Colors.black, size: 18),
                                        const SizedBox(width: 8),
                                        Text(
                                          btnText,
                                          style: GoogleFonts.cairo(
                                            color: Colors.black,
                                            fontWeight: FontWeight.w900,
                                            fontSize: 16.5,
                                          ),
                                        ),
                                      ],
                                    ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Text(
                sub,
                textAlign: TextAlign.center,
                style: GoogleFonts.cairo(
                  color: Colors.white70,
                  fontWeight: FontWeight.w700,
                  fontSize: 12.5,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _selectedName() {
    final k = selected;
    if (k == null) return "";
    final m = services.where((e) => e["key"] == k).toList();
    return m.isEmpty ? k : (m.first["name"] as String);
  }

  String _buttonLabel() {
    if (selected == null) return "اختر خدمة أولاً";
    if (selected == "more") return "عرض الخدمات الإضافية";
    if (selected == "accident") return "فتح نظام الحوادث الذكي";
    return "🚗 طلب الخدمة الآن";
  }

  // ================== Navigation / Flow ==================

  Future<void> _openSelected(String key) async {
    if (_opening) return;
    setState(() => _opening = true);

    try {
      if (key == "more") {
        await Navigator.push(
          context,
          MaterialPageRoute(
              builder: (_) => const SupplementaryServicesScreen()),
        );
        return;
      }

      if (key == "accident") {
        await Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => const SmartAccidentScreen()),
        );
        return;
      }

      // 1) Select location
      final PickedLocation? picked = await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => SelectLocationScreen(
            serviceType: key,
            userId: _userId,
            selectedServices: [key],
          ),
        ),
      );

      if (picked == null) return;

      // 2) Confirm request
      final ConfirmRequestResult? confirm = await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => ConfirmRequestScreen(
            args: ConfirmRequestArgs(
              serviceType: key,
              userId: _userId,
              selectedServices: [key],
              lat: picked.lat,
              lng: picked.lng,
              address: picked.address,
            ),
          ),
        ),
      );

      if (confirm == null) return;

      // 3) Searching technician
      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => SearchingTechnicianScreen(
            serviceType: key,
            userId: _userId,
            selectedServices: [key],
            lat: picked.lat,
            lng: picked.lng,
            address: picked.address,

            // ✅ لو عندك orderId من confirm حطه هنا:
            // orderId: confirm.orderId,
            orderId: '',
          ),
        ),
      );
    } catch (e) {
      _snack("حصل خطأ: $e");
    } finally {
      if (mounted) setState(() => _opening = false);
    }
  }
}
