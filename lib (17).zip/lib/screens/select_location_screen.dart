// ignore_for_file: depend_on_referenced_packages, use_build_context_synchronously

import 'dart:async';
import 'dart:convert';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show HapticFeedback, rootBundle;
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:google_fonts/google_fonts.dart';

import '../services/google_places_service.dart';

/// ✅ Result model
class PickedLocation {
  final double lat;
  final double lng;
  final String address;

  const PickedLocation({
    required this.lat,
    required this.lng,
    required this.address,
  });

  LatLng get latLng => LatLng(lat, lng);
}

class SelectLocationScreen extends StatefulWidget {
  final String serviceType;
  final String userId;
  final List<String> selectedServices;

  const SelectLocationScreen({
    super.key,
    required this.serviceType,
    required this.userId,
    required this.selectedServices,
  });

  @override
  State<SelectLocationScreen> createState() => _SelectLocationScreenState();
}

class _SelectLocationScreenState extends State<SelectLocationScreen>
    with TickerProviderStateMixin {
  // ======================
  // THEME (DoctorCar)
  // ======================
  static const Color _bg = Color(0xFF0B1220);
  static const Color _bg2 = Color(0xFF081837);
  static const Color _bg3 = Color(0xFF0A2038);

  static const Color _card = Color(0xFF121B2E);
  static const Color _card2 = Color(0xFF0F1A30);

  static const Color _brand = Color(0xFFA8F12A);
  // ignore: unused_field
  static const Color _danger = Color(0xFFFF4D4D);

  GoogleMapController? _map;
  bool _mapReady = false;

  LatLng _selected = const LatLng(31.4175, 31.8153);

  String get _googleApiKey => (dotenv.env['GOOGLE_MAPS_KEY'] ?? '').trim();
  late final GooglePlacesService _places = GooglePlacesService(_googleApiKey);

  final TextEditingController _search = TextEditingController();
  Timer? _debounce;

  List<Map<String, dynamic>> _results = [];
  bool _showResults = false;

  late final AnimationController _pinAnim;
  late final AnimationController _pulseAnim;

  String _currentAddress = "جارِ تحديد العنوان…";
  bool _reverseLoading = false;

  String? _mapStyle;

  Timer? _reverseDebounce;
  DateTime _lastReverseReq = DateTime.fromMillisecondsSinceEpoch(0);

  String? _lastResolvedAddress;
  LatLng? _lastResolvedLatLng;

  CameraPosition? _lastCameraPosition;

  static const double _bottomUiPadding = 240;

  // animated background
  late final AnimationController _bgCtrl;

  @override
  void initState() {
    super.initState();

    _pinAnim = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 650),
      lowerBound: 0,
      upperBound: 10,
    )..repeat(reverse: true);

    _pulseAnim = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1300),
    )..repeat();

    _bgCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 4200),
    )..repeat(reverse: true);

    _loadMapStyle();
    _initMyLocation();
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _reverseDebounce?.cancel();
    _pinAnim.dispose();
    _pulseAnim.dispose();
    _bgCtrl.dispose();
    _search.dispose();
    super.dispose();
  }

  // ======================
  // Helpers UI
  // ======================
  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        backgroundColor: Colors.black.withOpacity(.92),
        content: Text(
          msg,
          textDirection: TextDirection.rtl,
          style: GoogleFonts.cairo(
              color: Colors.white, fontWeight: FontWeight.w700),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }

  LinearGradient get _ctaGradient => LinearGradient(
        begin: Alignment.centerLeft,
        end: Alignment.centerRight,
        colors: [
          Color.lerp(_brand, Colors.white, 0.20)!,
          _brand,
          Color.lerp(_brand, _bg, 0.18)!,
        ],
        stops: const [0.0, 0.55, 1.0],
      );

  // ======================
  // Assets
  // ======================
  Future<void> _loadMapStyle() async {
    try {
      _mapStyle =
          await rootBundle.loadString('assets/map_styles/uber_dark.json');
    } catch (_) {
      _mapStyle = null;
    }
  }

  // ======================
  // Location Permission
  // ======================
  Future<bool> _ensureLocationPermission() async {
    final serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      _snack("فعّل GPS أولًا");
      return false;
    }

    var perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) {
      perm = await Geolocator.requestPermission();
    }

    if (perm == LocationPermission.deniedForever) {
      _snack("إذن الموقع مرفوض نهائيًا.. افتح الإعدادات وفعّل الإذن");
      return false;
    }

    if (perm == LocationPermission.denied) {
      _snack("تم رفض صلاحية الموقع");
      return false;
    }

    return true;
  }

  Future<void> _initMyLocation() async {
    try {
      final ok = await _ensureLocationPermission();
      if (!ok) return;

      final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
        timeLimit: const Duration(seconds: 10),
      );

      final me = LatLng(pos.latitude, pos.longitude);

      if (!mounted) return;
      setState(() {
        _selected = me;
        _currentAddress = "جارِ تحديد العنوان…";
      });

      _animateTo(me, zoom: 16.7);
      _scheduleReverseGeocode(me);
    } catch (_) {}
  }

  // ======================
  // Map callbacks
  // ======================
  void _onMapCreated(GoogleMapController c) async {
    _map = c;

    try {
      await _map!.setMapStyle(_mapStyle);
    } catch (_) {}

    if (!mounted) return;
    setState(() => _mapReady = true);

    _animateTo(_selected, zoom: 16.7);
    _scheduleReverseGeocode(_selected);
  }

  void _animateTo(LatLng target, {double zoom = 16.7}) {
    if (_map == null) return;
    _map!.animateCamera(CameraUpdate.newLatLngZoom(target, zoom));
  }

  void _onCameraMove(CameraPosition pos) {
    if (!_mapReady) return;
    _lastCameraPosition = pos;
  }

  void _onCameraIdle() {
    if (!_mapReady) return;

    final cam = _lastCameraPosition;
    if (cam == null) return;

    setState(() {
      _selected = cam.target;
      _currentAddress = "جارِ تحديد العنوان…";
    });

    _scheduleReverseGeocode(_selected);
  }

  // ============================================================
  // 🔎 SEARCH
  // ============================================================
  Future<void> _onSearchChanged(String value) async {
    if (_debounce?.isActive ?? false) _debounce!.cancel();

    _debounce = Timer(const Duration(milliseconds: 320), () async {
      final q = value.trim();
      if (q.isEmpty) {
        if (!mounted) return;
        setState(() {
          _results = [];
          _showResults = false;
        });
        return;
      }

      if (_googleApiKey.isEmpty) {
        _snack("GOOGLE_MAPS_KEY غير موجود في .env");
        return;
      }

      final items = await _places.autocomplete(q);
      if (!mounted) return;
      setState(() {
        _results = items;
        _showResults = items.isNotEmpty;
      });
    });
  }

  Future<void> _onSelectPlace(Map<String, dynamic> item) async {
    final placeId = (item["place_id"] ?? "").toString();
    if (placeId.isEmpty) return;

    final details = await _places.getPlaceLatLng(placeId);
    if (details == null) return;

    final point = LatLng(details.lat, details.lng);

    if (!mounted) return;
    setState(() {
      _selected = point;
      _currentAddress =
          details.address.isNotEmpty ? details.address : "جارِ تحديد العنوان…";
      _search.text = details.name;
      _showResults = false;
    });

    HapticFeedback.selectionClick();
    _animateTo(point, zoom: 16.9);
    _scheduleReverseGeocode(point);
  }

  // ============================================================
  // 🧭 Reverse Geocoding
  // ============================================================
  void _scheduleReverseGeocode(LatLng p) {
    _reverseDebounce?.cancel();
    _reverseDebounce = Timer(const Duration(milliseconds: 450), () {
      _reverseGeocode(p);
    });
  }

  Future<void> _reverseGeocode(LatLng p) async {
    if (_googleApiKey.isEmpty) return;

    // cache if same-ish
    if (_lastResolvedLatLng != null &&
        _lastResolvedAddress != null &&
        _lastResolvedAddress!.trim().isNotEmpty) {
      final d = Geolocator.distanceBetween(
        _lastResolvedLatLng!.latitude,
        _lastResolvedLatLng!.longitude,
        p.latitude,
        p.longitude,
      );
      if (d < 15) {
        if (!mounted) return;
        setState(() => _currentAddress = _lastResolvedAddress!);
        return;
      }
    }

    final now = DateTime.now();
    if (now.difference(_lastReverseReq).inMilliseconds < 700) return;
    _lastReverseReq = now;

    if (!mounted) return;
    setState(() {
      _reverseLoading = true;
      _currentAddress = "جارِ تحديد العنوان…";
    });

    try {
      final uri = Uri.https(
        "maps.googleapis.com",
        "/maps/api/geocode/json",
        {
          "latlng": "${p.latitude},${p.longitude}",
          "key": _googleApiKey,
          "language": "ar",
          "region": "eg",
        },
      );

      final res = await http.get(uri).timeout(const Duration(seconds: 8));
      if (!mounted) return;

      if (res.statusCode == 200) {
        final decoded = jsonDecode(res.body);
        final status = (decoded["status"] ?? "").toString();

        if (status == "OK") {
          final results = decoded["results"];
          if (results is List && results.isNotEmpty) {
            final formatted =
                (results.first["formatted_address"] ?? "").toString();
            final addr = formatted.isNotEmpty ? formatted : "تم تثبيت الموقع";

            _lastResolvedLatLng = p;
            _lastResolvedAddress = addr;

            setState(() => _currentAddress = addr);
          } else {
            setState(() => _currentAddress = "تم تثبيت الموقع");
          }
        } else {
          setState(() => _currentAddress = "تم تثبيت الموقع");
        }
      } else {
        setState(() => _currentAddress = "تم تثبيت الموقع");
      }
    } catch (_) {
      if (!mounted) return;
      setState(() => _currentAddress = "تم تثبيت الموقع");
    } finally {
      if (mounted) setState(() => _reverseLoading = false);
    }
  }

  // ============================================================
  // UI ACTIONS
  // ============================================================
  Future<void> _goToMyLocation() async {
    HapticFeedback.mediumImpact();
    await _initMyLocation();
  }

  void _confirm() {
    final addr = (_currentAddress.trim().isEmpty)
        ? "تم تثبيت الموقع"
        : _currentAddress.trim();

    HapticFeedback.heavyImpact();
    Navigator.pop(
      context,
      PickedLocation(
        lat: _selected.latitude,
        lng: _selected.longitude,
        address: addr,
      ),
    );
  }

  // ======================
  // Background glow
  // ======================
  Widget _proBackground() {
    return AnimatedBuilder(
      animation: _bgCtrl,
      builder: (_, __) {
        final t = _bgCtrl.value;
        final dx = lerpDouble(-0.18, 0.18, t)!;
        final dy = lerpDouble(0.10, -0.06, t)!;

        return Stack(
          children: [
            Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [_bg, _bg2, _bg3],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
            ),
            Align(
              alignment: Alignment(dx, -0.90),
              child: _glowBlob(size: 320, opacity: 0.16),
            ),
            Align(
              alignment: Alignment(-0.90, dy),
              child: _glowBlob(size: 380, opacity: 0.12),
            ),
            Align(
              alignment: Alignment(0.95, 0.30 - dy),
              child: _glowBlob(size: 300, opacity: 0.10),
            ),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withOpacity(0.35),
                    Colors.transparent,
                    Colors.black.withOpacity(0.20),
                  ],
                  stops: const [0.0, 0.58, 1.0],
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _glowBlob({required double size, required double opacity}) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [
            _brand.withOpacity(opacity),
            _brand.withOpacity(opacity * 0.35),
            Colors.transparent,
          ],
          stops: const [0.0, 0.50, 1.0],
        ),
      ),
    );
  }

  // ======================
  // BUILD
  // ======================
  @override
  Widget build(BuildContext context) {
    final mapPadding = EdgeInsets.only(
      top: MediaQuery.of(context).padding.top + 98,
      bottom: _bottomUiPadding,
    );

    return Scaffold(
      backgroundColor: _bg,
      extendBodyBehindAppBar: true,
      body: Stack(
        children: [
          _proBackground(),

          // Map
          Listener(
            onPointerDown: (_) {
              if (_showResults) setState(() => _showResults = false);
            },
            child: ClipRRect(
              borderRadius: BorderRadius.circular(0),
              child: GoogleMap(
                padding: mapPadding,
                initialCameraPosition:
                    CameraPosition(target: _selected, zoom: 15),
                onMapCreated: _onMapCreated,
                onCameraMove: _onCameraMove,
                onCameraIdle: _onCameraIdle,
                myLocationEnabled: true,
                myLocationButtonEnabled: false,
                zoomControlsEnabled: false,
                compassEnabled: false,
                buildingsEnabled: false,
                indoorViewEnabled: false,
                trafficEnabled: false,
              ),
            ),
          ),

          // Center Pin (brand pulse)
          Positioned.fill(
            child: IgnorePointer(
              child: AnimatedBuilder(
                animation: Listenable.merge([_pinAnim, _pulseAnim]),
                builder: (_, __) {
                  final t = _pulseAnim.value;
                  final pulseSize = 26 + (t * 22);
                  final pulseOpacity = (1 - t).clamp(0.0, 1.0) * 0.18;

                  return Center(
                    child: Transform.translate(
                      offset: Offset(0, -_pinAnim.value - 26),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            width: pulseSize,
                            height: pulseSize,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: _brand.withOpacity(pulseOpacity),
                            ),
                          ),
                          const SizedBox(height: 7),
                          Container(
                            width: 22,
                            height: 7,
                            decoration: BoxDecoration(
                              color: Colors.black.withOpacity(0.22),
                              borderRadius: BorderRadius.circular(999),
                            ),
                          ),
                          const SizedBox(height: 7),
                          Image.asset(
                            "assets/icons/user_pin.png",
                            width: 58,
                            errorBuilder: (_, __, ___) => const Icon(
                              Icons.location_on,
                              color: _brand,
                              size: 54,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ),

          // Top search + title
          SafeArea(
            child: Column(
              children: [
                const SizedBox(height: 10),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  child: _topGlassBar(),
                ),
                const SizedBox(height: 10),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  child: _searchBox(),
                ),
                if (_showResults) _resultsBox(),
              ],
            ),
          ),

          // My location pill
          Positioned(
            right: 14,
            bottom: 265,
            child: _pillAction(
              icon: Icons.my_location,
              label: "موقعي",
              onTap: _goToMyLocation,
            ),
          ),

          // Bottom sheet (address + CTA)
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: SafeArea(
              top: false,
              child: _bottomGlassSheet(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _topGlassBar() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(18),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(.35),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: Colors.white10),
          ),
          child: Row(
            children: [
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(.30),
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white12),
                  ),
                  child: const Icon(Icons.arrow_back_ios_new,
                      color: Colors.white, size: 18),
                ),
              ),
              const SizedBox(width: 10),
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: _brand.withOpacity(.14),
                  shape: BoxShape.circle,
                  border: Border.all(color: _brand.withOpacity(.22)),
                ),
                child: const Icon(Icons.place_rounded, color: _brand, size: 20),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  "تحديد موقع الخدمة",
                  style: GoogleFonts.cairo(
                    color: Colors.white,
                    fontWeight: FontWeight.w900,
                    fontSize: 16.5,
                  ),
                  textDirection: TextDirection.rtl,
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(.25),
                  borderRadius: BorderRadius.circular(999),
                  border: Border.all(color: Colors.white12),
                ),
                child: Text(
                  widget.serviceType,
                  style: GoogleFonts.cairo(
                    color: Colors.white70,
                    fontWeight: FontWeight.w800,
                    fontSize: 12,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget _searchBox() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(18),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: _card.withOpacity(.78),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: Colors.white10),
          ),
          child: TextField(
            controller: _search,
            textDirection: TextDirection.rtl,
            textAlign: TextAlign.right,
            onChanged: _onSearchChanged,
            style: GoogleFonts.cairo(
              color: Colors.white,
              fontWeight: FontWeight.w800,
            ),
            cursorColor: _brand,
            decoration: InputDecoration(
              border: InputBorder.none,
              hintText: "ابحث عن مدينة أو شارع…",
              hintStyle: GoogleFonts.cairo(
                color: Colors.white54,
                fontWeight: FontWeight.w700,
              ),
              prefixIcon:
                  Icon(Icons.search, color: Colors.white.withOpacity(.70)),
              suffixIcon: _search.text.trim().isEmpty
                  ? null
                  : IconButton(
                      icon: Icon(Icons.close,
                          color: Colors.white.withOpacity(.75)),
                      onPressed: () {
                        setState(() {
                          _search.clear();
                          _results = [];
                          _showResults = false;
                        });
                      },
                    ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _resultsBox() {
    return Container(
      margin: const EdgeInsets.fromLTRB(14, 10, 14, 0),
      padding: const EdgeInsets.symmetric(vertical: 4),
      decoration: BoxDecoration(
        color: _card2.withOpacity(.94),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white10),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(.20),
            blurRadius: 18,
            offset: const Offset(0, 10),
          )
        ],
      ),
      constraints: const BoxConstraints(maxHeight: 280),
      child: ListView.separated(
        shrinkWrap: true,
        itemCount: _results.length,
        separatorBuilder: (_, __) =>
            Divider(color: Colors.white.withOpacity(.06), height: 1),
        itemBuilder: (_, i) {
          final item = _results[i];
          final desc = (item["description"] ?? "").toString();

          return ListTile(
            leading: Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: _brand.withOpacity(.12),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: _brand.withOpacity(.20)),
              ),
              child: const Icon(Icons.place, color: _brand, size: 18),
            ),
            title: Text(
              desc,
              textDirection: TextDirection.rtl,
              textAlign: TextAlign.right,
              style: GoogleFonts.cairo(
                  color: Colors.white,
                  fontWeight: FontWeight.w800,
                  fontSize: 13.5),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
            onTap: () => _onSelectPlace(item),
          );
        },
      ),
    );
  }

  Widget _pillAction({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.black.withOpacity(.35),
      elevation: 8,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, color: Colors.white, size: 18),
              const SizedBox(width: 8),
              Text(
                label,
                style: GoogleFonts.cairo(
                  color: Colors.white,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _bottomGlassSheet() {
    return ClipRRect(
      borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Container(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
          decoration: BoxDecoration(
            color: _card.withOpacity(.88),
            borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
            border: Border.all(color: Colors.white10),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 56,
                height: 5,
                decoration: BoxDecoration(
                  color: Colors.white24,
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              const SizedBox(height: 12),

              // Address
              Row(
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: _brand.withOpacity(.14),
                      shape: BoxShape.circle,
                      border: Border.all(color: _brand.withOpacity(.22)),
                    ),
                    child:
                        const Icon(Icons.location_on, color: _brand, size: 22),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          _currentAddress,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          textDirection: TextDirection.rtl,
                          textAlign: TextAlign.right,
                          style: GoogleFonts.cairo(
                            color: Colors.white,
                            fontWeight: FontWeight.w900,
                            fontSize: 13.8,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          "${_selected.latitude.toStringAsFixed(5)}, ${_selected.longitude.toStringAsFixed(5)}",
                          style: GoogleFonts.cairo(
                            color: Colors.white70,
                            fontWeight: FontWeight.w700,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 10),
                  if (_reverseLoading)
                    const SizedBox(
                      width: 22,
                      height: 22,
                      child: CircularProgressIndicator(
                        strokeWidth: 2.2,
                        color: _brand,
                      ),
                    )
                ],
              ),

              const SizedBox(height: 14),

              // Confirm CTA
              SizedBox(
                width: double.infinity,
                height: 56,
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: _brand.withOpacity(0.28),
                        blurRadius: 26,
                        offset: const Offset(0, 12),
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(16),
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        AnimatedOpacity(
                          opacity: _reverseLoading ? 0.45 : 1,
                          duration: const Duration(milliseconds: 180),
                          child: Container(
                              decoration:
                                  BoxDecoration(gradient: _ctaGradient)),
                        ),
                        Material(
                          color: Colors.transparent,
                          child: InkWell(
                            onTap: _reverseLoading ? null : _confirm,
                            child: Center(
                              child: Text(
                                "تأكيد الموقع",
                                style: GoogleFonts.cairo(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w900,
                                  color: Colors.black,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 10),

              // Hint
              Text(
                "اسحب الخريطة لتحديد مكانك بدقة",
                style: GoogleFonts.cairo(
                  color: Colors.white54,
                  fontWeight: FontWeight.w700,
                  fontSize: 12.5,
                ),
                textDirection: TextDirection.rtl,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
