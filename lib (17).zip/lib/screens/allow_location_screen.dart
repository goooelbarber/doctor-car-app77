// ignore_for_file: depend_on_referenced_packages, use_build_context_synchronously

import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import '../config/api_config.dart';
import 'searching_technician_screen.dart';

class CreateOrderScreen extends StatefulWidget {
  const CreateOrderScreen({super.key});

  @override
  State<CreateOrderScreen> createState() => _CreateOrderScreenState();
}

class _CreateOrderScreenState extends State<CreateOrderScreen> {
  // ======================
  // THEME
  // ======================
  static const Color _bg = Color(0xFF0B1220);
  static const Color _cardColor = Color(0xFF121B2E); // ✅ renamed
  static const Color _yellow = Color(0xFFFFC107);
  static const Color _danger = Color(0xFFFF4D4D);

  bool loading = false;
  bool estimating = false;

  String selectedService = "battery";

  // payment
  String paymentMethod = "cash"; // cash | card | wallet

  // location
  LatLng? pickedLocation; // manual pick
  Position? gpsPosition;

  // note / promo
  final TextEditingController notesCtrl = TextEditingController();
  final TextEditingController promoCtrl = TextEditingController();

  // estimate
  String currency = "EGP";
  double? estimatedFare;
  Map<String, dynamic> fareBreakdown = {};
  bool showBreakdown = false;

  // debounce for estimate
  Timer? _estimateDebounce;

  final Map<String, String> services = const {
    "battery": "خدمة البطارية",
    "tow": "خدمة السحب",
    "fuel": "توصيل وقود",
    "tire": "تبديل الإطارات",
  };

  // local fallback pricing
  final Map<String, double> _fallbackBase = const {
    "battery": 60,
    "tow": 120,
    "fuel": 70,
    "tire": 80,
  };

  void _snack(String msg, {bool danger = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: danger ? _danger : null,
        content: Text(msg, style: GoogleFonts.cairo()),
      ),
    );
  }

  Future<String> _getUserId() async {
    final prefs = await SharedPreferences.getInstance();
    final id = prefs.getString("userId");
    if (id == null || id.isEmpty) throw Exception("المستخدم غير مسجل");
    return id;
  }

  Future<Position> _getMyLocation() async {
    final serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) throw Exception("فعّل GPS أولًا");

    var perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) {
      perm = await Geolocator.requestPermission();
    }
    if (perm == LocationPermission.denied ||
        perm == LocationPermission.deniedForever) {
      throw Exception("تم رفض صلاحية الموقع");
    }

    return Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.high,
    );
  }

  LatLng? get _effectiveLocation {
    if (pickedLocation != null) return pickedLocation;
    if (gpsPosition != null) {
      return LatLng(gpsPosition!.latitude, gpsPosition!.longitude);
    }
    return null;
  }

  @override
  void initState() {
    super.initState();
    _initLocationAndEstimate();
  }

  Future<void> _initLocationAndEstimate() async {
    try {
      gpsPosition = await _getMyLocation();
      if (!mounted) return;
      setState(() {});
      await _refreshEstimate();
    } catch (e) {
      _snack(e.toString().replaceAll("Exception:", "").trim(), danger: true);
    }
  }

  Future<void> _refreshEstimate() async {
    final loc = _effectiveLocation;
    if (loc == null) return;

    setState(() => estimating = true);

    try {
      // لو عندك endpoint للتسعير:
      // GET /api/pricing/estimate?serviceType=...&lat=...&lng=...
      final uri = Uri.parse(
        "${ApiConfig.baseUrl}/api/pricing/estimate"
        "?serviceType=$selectedService&lat=${loc.latitude}&lng=${loc.longitude}",
      );

      final res = await http.get(uri).timeout(ApiConfig.requestTimeout);

      if (res.statusCode >= 200 &&
          res.statusCode < 300 &&
          res.body.isNotEmpty) {
        final decoded = jsonDecode(res.body);
        if (decoded is Map) {
          final m = Map<String, dynamic>.from(decoded);
          setState(() {
            currency = (m["currency"] ?? "EGP").toString();
            estimatedFare = (m["estimatedFare"] as num?)?.toDouble();
            final b = m["breakdown"];
            fareBreakdown = (b is Map) ? Map<String, dynamic>.from(b) : {};
          });
        } else {
          _applyLocalFallbackEstimate();
        }
      } else {
        _applyLocalFallbackEstimate();
      }
    } catch (_) {
      _applyLocalFallbackEstimate();
    } finally {
      if (mounted) setState(() => estimating = false);
    }
  }

  void _applyLocalFallbackEstimate() {
    final base = _fallbackBase[selectedService] ?? 60;
    final serviceFee = 5.0;
    final tax = (base + serviceFee) * 0.05;

    setState(() {
      currency = "EGP";
      estimatedFare = (base + serviceFee + tax);
      fareBreakdown = {
        "baseFee": base,
        "serviceFee": serviceFee,
        "tax": tax,
        "surgeMultiplier": 1.0,
        "discount": 0.0,
        "note": "تقدير مبدئي (Fallback)",
      };
    });
  }

  void _scheduleEstimate() {
    _estimateDebounce?.cancel();
    _estimateDebounce = Timer(const Duration(milliseconds: 350), () {
      _refreshEstimate();
    });
  }

  Future<void> _pickLocationOnMap() async {
    final loc = _effectiveLocation;
    if (loc == null) {
      _snack("لا يوجد موقع متاح حاليًا", danger: true);
      return;
    }

    final result = await showModalBottomSheet<LatLng>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _PickOnMapSheet(initial: loc),
    );

    if (result != null) {
      setState(() => pickedLocation = result);
      _scheduleEstimate();
    }
  }

  Future<void> _confirmAndCreateOrder() async {
    final loc = _effectiveLocation;
    if (loc == null) {
      _snack("حدد موقعك أولاً", danger: true);
      return;
    }

    final ok = await showModalBottomSheet<bool>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => _ConfirmOrderSheet(
        serviceName: services[selectedService]!,
        paymentMethod: paymentMethod,
        estimatedFare: estimatedFare,
        currency: currency,
        location: loc,
        notes: notesCtrl.text.trim(),
      ),
    );

    if (ok == true) {
      await createOrder();
    }
  }

  Future<void> createOrder() async {
    if (loading) return;

    final loc = _effectiveLocation;
    if (loc == null) {
      _snack("حدد موقعك أولاً", danger: true);
      return;
    }

    setState(() => loading = true);

    try {
      final userId = await _getUserId();

      final body = {
        "userId": userId,
        "serviceName": services[selectedService],
        "serviceType": selectedService,
        "location": {"lat": loc.latitude, "lng": loc.longitude},

        // Uber-like
        "paymentMethod": paymentMethod,
        "notes": notesCtrl.text.trim(),
        if (promoCtrl.text.trim().isNotEmpty)
          "promoCode": promoCtrl.text.trim(),

        if (estimatedFare != null)
          "clientEstimate": {
            "currency": currency,
            "estimatedFare": estimatedFare,
            "breakdown": fareBreakdown,
          },
      };

      final res = await http
          .post(
            Uri.parse(
                ApiConfig.createOrder), // ✅ ApiConfig.createOrder عندك String
            headers: ApiConfig.jsonHeaders(),
            body: jsonEncode(body),
          )
          .timeout(ApiConfig.requestTimeout);

      final decoded = res.body.isNotEmpty ? jsonDecode(res.body) : {};
      if (res.statusCode != 201 && res.statusCode != 200) {
        final msg = (decoded is Map ? decoded["message"] : null)?.toString();
        throw Exception(msg ?? "فشل إنشاء الطلب");
      }

      final data = decoded as Map<String, dynamic>;
      final order = (data["order"] ?? data) as Map<String, dynamic>;

      final orderId = (order["_id"] ?? order["orderId"])?.toString();
      if (orderId == null || orderId.isEmpty) {
        throw Exception("orderId غير موجود في response");
      }

      _snack("✅ تم إرسال الطلب، جاري البحث عن فني قريب...");

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => SearchingTechnicianScreen(
            userId: userId,
            serviceType: selectedService,
            lat: loc.latitude,
            lng: loc.longitude,
            orderId: orderId,
            fakeMode: false, selectedServices: [], address: '',
          ),
        ),
      );
    } catch (e) {
      _snack(e.toString().replaceAll("Exception:", "").trim(), danger: true);
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  // ======================
  // UI
  // ======================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _bg,
        elevation: 0,
        title: Text("طلب خدمة", style: GoogleFonts.cairo()),
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          _serviceSelector(),
          const SizedBox(height: 14),
          _locationCard(),
          const SizedBox(height: 14),
          _estimateCard(),
          const SizedBox(height: 14),
          _notesCard(),
          const SizedBox(height: 14),
          _paymentCard(),
          const SizedBox(height: 18),
          _submitButton(),
          const SizedBox(height: 10),
        ],
      ),
    );
  }

  // ✅ renamed
  Widget _buildCard({required Widget child}) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _cardColor.withOpacity(.90),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white10),
      ),
      child: child,
    );
  }

  Widget _serviceSelector() {
    return _buildCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "اختر نوع الخدمة",
            style: GoogleFonts.cairo(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 10),
          ...services.entries.map(
            (e) => RadioListTile<String>(
              value: e.key,
              groupValue: selectedService,
              onChanged: loading
                  ? null
                  : (v) {
                      setState(() => selectedService = v!);
                      _scheduleEstimate();
                    },
              title:
                  Text(e.value, style: GoogleFonts.cairo(color: Colors.white)),
              activeColor: _yellow,
              contentPadding: EdgeInsets.zero,
            ),
          ),
        ],
      ),
    );
  }

  Widget _locationCard() {
    final loc = _effectiveLocation;
    final text = loc == null
        ? "غير محدد"
        : "${loc.latitude.toStringAsFixed(5)}, ${loc.longitude.toStringAsFixed(5)}";

    return _buildCard(
      child: Row(
        children: [
          const Icon(Icons.my_location, color: _yellow),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "موقع الطلب",
                  style: GoogleFonts.cairo(
                    color: Colors.white,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  text,
                  style: GoogleFonts.cairo(color: Colors.white70, fontSize: 12),
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          OutlinedButton(
            onPressed: loading ? null : _pickLocationOnMap,
            style: OutlinedButton.styleFrom(
              side: const BorderSide(color: Colors.white24),
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
            ),
            child: Text("تحديد",
                style: GoogleFonts.cairo(fontWeight: FontWeight.w900)),
          ),
        ],
      ),
    );
  }

  Widget _estimateCard() {
    String fmt(double v) => v.toStringAsFixed(0);

    return _buildCard(
      child: Column(
        children: [
          Row(
            children: [
              const Icon(Icons.payments, color: _yellow),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  "السعر التقديري",
                  style: GoogleFonts.cairo(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
              if (estimating)
                const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              else
                Text(
                  estimatedFare == null
                      ? "--"
                      : "${fmt(estimatedFare!)} $currency",
                  style: GoogleFonts.cairo(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                  ),
                ),
            ],
          ),
          const SizedBox(height: 8),
          GestureDetector(
            onTap: () => setState(() => showBreakdown = !showBreakdown),
            child: Row(
              children: [
                Text(
                  showBreakdown ? "إخفاء التفاصيل" : "عرض تفاصيل السعر",
                  style: GoogleFonts.cairo(color: Colors.white70, fontSize: 13),
                ),
                const Spacer(),
                Icon(
                  showBreakdown ? Icons.expand_less : Icons.expand_more,
                  color: Colors.white70,
                ),
              ],
            ),
          ),
          if (showBreakdown) ...[
            const SizedBox(height: 10),
            ..._breakdownLines(),
          ],
        ],
      ),
    );
  }

  List<Widget> _breakdownLines() {
    String fmt(num? v) => (v ?? 0).toStringAsFixed(0);

    Widget line(String k, String v) => Padding(
          padding: const EdgeInsets.only(bottom: 6),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  k,
                  style: GoogleFonts.cairo(color: Colors.white70, fontSize: 13),
                ),
              ),
              Text(
                v,
                style: GoogleFonts.cairo(
                  color: Colors.white,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
        );

    final baseFee = (fareBreakdown["baseFee"] as num?) ?? 0;
    final serviceFee = (fareBreakdown["serviceFee"] as num?) ?? 0;
    final tax = (fareBreakdown["tax"] as num?) ?? 0;
    final surge = (fareBreakdown["surgeMultiplier"] as num?) ?? 1.0;
    final discount = (fareBreakdown["discount"] as num?) ?? 0;

    final note = fareBreakdown["note"]?.toString();

    final out = <Widget>[
      line("رسوم أساسية", "${fmt(baseFee)} $currency"),
      line("رسوم خدمة", "${fmt(serviceFee)} $currency"),
      line("ضريبة", "${fmt(tax)} $currency"),
      // ignore: unnecessary_cast
      if ((surge as num).toDouble() > 1.0)
        line("Surge", "x${surge.toStringAsFixed(1)}"),
      // ignore: unnecessary_cast
      if ((discount as num).toDouble() > 0)
        line("خصم", "-${fmt(discount)} $currency"),
    ];

    if (note != null && note.trim().isNotEmpty) {
      out.add(const SizedBox(height: 4));
      out.add(
        Text(
          note,
          style: GoogleFonts.cairo(color: Colors.white54, fontSize: 12),
        ),
      );
    }
    return out;
  }

  Widget _notesCard() {
    return _buildCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "ملاحظات للفني (اختياري)",
            style: GoogleFonts.cairo(
              color: Colors.white,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: notesCtrl,
            maxLines: 2,
            style: GoogleFonts.cairo(color: Colors.white),
            decoration: InputDecoration(
              hintText: "مثال: العربية مش بتدور / أنا واقف عند محطة ...",
              hintStyle: GoogleFonts.cairo(color: Colors.white38),
              filled: true,
              fillColor: Colors.white.withOpacity(.06),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: promoCtrl,
            style: GoogleFonts.cairo(color: Colors.white),
            decoration: InputDecoration(
              hintText: "Promo code (اختياري)",
              hintStyle: GoogleFonts.cairo(color: Colors.white38),
              filled: true,
              fillColor: Colors.white.withOpacity(.06),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: BorderSide.none,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _paymentCard() {
    Widget item(String key, String title, IconData icon) {
      final selected = paymentMethod == key;
      return Expanded(
        child: GestureDetector(
          onTap: loading ? null : () => setState(() => paymentMethod = key),
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
            decoration: BoxDecoration(
              color: selected
                  ? _yellow.withOpacity(.18)
                  : Colors.white.withOpacity(.05),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: selected ? _yellow.withOpacity(.55) : Colors.white10,
              ),
            ),
            child: Column(
              children: [
                Icon(
                  icon,
                  color: selected ? _yellow : Colors.white70,
                  size: 22,
                ),
                const SizedBox(height: 6),
                Text(
                  title,
                  style: GoogleFonts.cairo(
                    color: Colors.white,
                    fontWeight: FontWeight.w900,
                    fontSize: 13,
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return _buildCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "طريقة الدفع",
            style: GoogleFonts.cairo(
              color: Colors.white,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              item("cash", "كاش", Icons.money),
              const SizedBox(width: 10),
              item("card", "بطاقة", Icons.credit_card),
              const SizedBox(width: 10),
              item("wallet", "محفظة", Icons.account_balance_wallet),
            ],
          ),
        ],
      ),
    );
  }

  Widget _submitButton() {
    return SizedBox(
      width: double.infinity,
      height: 54,
      child: ElevatedButton(
        onPressed: loading ? null : _confirmAndCreateOrder,
        style: ElevatedButton.styleFrom(
          backgroundColor: _yellow,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
        child: loading
            ? const SizedBox(
                width: 22,
                height: 22,
                child: CircularProgressIndicator(
                  color: Colors.black,
                  strokeWidth: 2.5,
                ),
              )
            : Text(
                "طلب الفني الآن",
                style: GoogleFonts.cairo(
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                  color: Colors.black,
                ),
              ),
      ),
    );
  }

  @override
  void dispose() {
    _estimateDebounce?.cancel();
    notesCtrl.dispose();
    promoCtrl.dispose();
    super.dispose();
  }
}

// ============================================================
// Pick location on map sheet
// ============================================================
class _PickOnMapSheet extends StatefulWidget {
  final LatLng initial;
  const _PickOnMapSheet({required this.initial});

  @override
  State<_PickOnMapSheet> createState() => _PickOnMapSheetState();
}

class _PickOnMapSheetState extends State<_PickOnMapSheet> {
  late LatLng picked = widget.initial;
  GoogleMapController? c;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.78,
      decoration: const BoxDecoration(
        color: Color(0xFF0B1220),
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: Column(
        children: [
          const SizedBox(height: 10),
          Container(
            width: 56,
            height: 5,
            decoration: BoxDecoration(
              color: Colors.white24,
              borderRadius: BorderRadius.circular(10),
            ),
          ),
          const SizedBox(height: 10),
          Expanded(
            child: Stack(
              children: [
                GoogleMap(
                  initialCameraPosition:
                      CameraPosition(target: picked, zoom: 16),
                  onMapCreated: (cc) => c = cc,
                  onCameraMove: (pos) => picked = pos.target,
                  zoomControlsEnabled: false,
                  myLocationButtonEnabled: false,
                ),
                const Center(
                  child: Icon(Icons.place, color: Colors.amber, size: 42),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(14),
            child: SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                onPressed: () => Navigator.pop(context, picked),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.amber,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16)),
                ),
                child: Text("تأكيد الموقع",
                    style: GoogleFonts.cairo(fontWeight: FontWeight.w900)),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// Confirm order sheet
// ============================================================
class _ConfirmOrderSheet extends StatelessWidget {
  final String serviceName;
  final String paymentMethod;
  final double? estimatedFare;
  final String currency;
  final LatLng location;
  final String notes;

  const _ConfirmOrderSheet({
    required this.serviceName,
    required this.paymentMethod,
    required this.estimatedFare,
    required this.currency,
    required this.location,
    required this.notes,
  });

  String pmText() {
    if (paymentMethod == "card") return "بطاقة";
    if (paymentMethod == "wallet") return "محفظة";
    return "كاش";
  }

  @override
  Widget build(BuildContext context) {
    String fmt(double v) => v.toStringAsFixed(0);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: const BoxDecoration(
        color: Color(0xFF0B1220),
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 56,
              height: 5,
              decoration: BoxDecoration(
                color: Colors.white24,
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            const SizedBox(height: 14),
            Text(
              "تأكيد الطلب",
              style: GoogleFonts.cairo(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.w900,
              ),
            ),
            const SizedBox(height: 12),
            _row("الخدمة", serviceName),
            _row("الدفع", pmText()),
            _row(
              "السعر التقديري",
              estimatedFare == null ? "--" : "${fmt(estimatedFare!)} $currency",
            ),
            _row(
              "الموقع",
              "${location.latitude.toStringAsFixed(5)}, ${location.longitude.toStringAsFixed(5)}",
            ),
            if (notes.trim().isNotEmpty) _row("ملاحظات", notes),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Navigator.pop(context, false),
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: Colors.white24),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                    child: Text(
                      "رجوع",
                      style: GoogleFonts.cairo(fontWeight: FontWeight.w900),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => Navigator.pop(context, true),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.amber,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                    child: Text(
                      "تأكيد",
                      style: GoogleFonts.cairo(fontWeight: FontWeight.w900),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _row(String k, String v) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 92,
            child: Text(
              k,
              style: GoogleFonts.cairo(color: Colors.white70, fontSize: 13),
            ),
          ),
          Expanded(
            child: Text(
              v,
              style: GoogleFonts.cairo(
                color: Colors.white,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
