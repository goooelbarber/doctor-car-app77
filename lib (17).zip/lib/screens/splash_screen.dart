// PATH: lib/screens/splash_screen.dart
// ignore_for_file: use_build_context_synchronously

import 'dart:async';
import 'dart:math';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:package_info_plus/package_info_plus.dart';

import 'package:doctor_car_app/core/app_routes.dart';
import 'package:doctor_car_app/screens/role_selection_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  // ========= Assets =========
  static const String _logoAsset = "assets/images/loggo7.png";

  // ========= Timing =========
  static const Duration _minSplash = Duration(milliseconds: 3200);

  // ========= Brand Palette (✅ نفس درجة زر "اتصل") =========
  static const Color _bg0 = Color(0xFF060A10);
  static const Color _bg1 = Color(0xFF070E14);
  static const Color _bg2 = Color(0xFF0A1418);

  // Lime neon (زر الاتصال)
  static const Color _lime = Color(0xFFB8FF2C);
  static const Color _lime2 = Color(0xFF7CFF00);
  static const Color _limeDeep = Color(0xFF2D6B00);

  // ========= Animations =========
  late final AnimationController _intro;
  late final Animation<double> _fadeIn;
  late final Animation<double> _scaleIn;
  late final Animation<Offset> _slideIn;

  late final AnimationController _fx; // background loop + particles
  late final AnimationController _shine; // progress shine
  late final AnimationController _ambient; // subtle wobble

  // ========= Progress =========
  Timer? _pTimer;
  double _p = 0.05;
  double _stageTarget = 0.35;
  bool _workDone = false;
  bool _navigated = false;

  String _version = "v";

  @override
  void initState() {
    super.initState();
    HapticFeedback.lightImpact();

    _intro = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 950),
    )..forward();

    _fadeIn = CurvedAnimation(parent: _intro, curve: Curves.easeOutCubic);

    _scaleIn = Tween<double>(begin: 0.985, end: 1.0).animate(
      CurvedAnimation(parent: _intro, curve: Curves.easeOutExpo),
    );

    _slideIn =
        Tween<Offset>(begin: const Offset(0, 0.03), end: Offset.zero).animate(
      CurvedAnimation(parent: _intro, curve: Curves.easeOutCubic),
    );

    _fx =
        AnimationController(vsync: this, duration: const Duration(seconds: 10))
          ..repeat();

    _shine = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    )..repeat();

    _ambient = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 5200),
    )..repeat(reverse: true);

    _startProgress();
    _bootstrap();
  }

  void _startProgress() {
    _pTimer?.cancel();
    _pTimer = Timer.periodic(const Duration(milliseconds: 70), (_) {
      if (!mounted) return;

      final cap = _workDone ? 1.0 : 0.92;
      final target = min(_stageTarget, cap);

      setState(() {
        final diff = target - _p;
        if (diff <= 0) return;
        _p += max(0.0028, diff * 0.08);
        _p = _p.clamp(0.0, cap);
      });
    });
  }

  Future<void> _bootstrap() async {
    final minDelay = Future.delayed(_minSplash);
    final work = _initWork();

    await Future.wait([minDelay, work]);

    if (!mounted || _navigated) return;

    _workDone = true;
    _pTimer?.cancel();

    for (int i = 0; i < 18; i++) {
      if (!mounted) break;
      await Future.delayed(const Duration(milliseconds: 35));
      setState(() => _p = min(1.0, _p + 0.03));
    }

    if (!mounted) return;
    _navigated = true;

    Navigator.of(context).pushReplacement(
      AppRoutes.fadeScale(const RoleSelectionScreen()),
    );
  }

  Future<void> _initWork() async {
    _setStage(0.22);
    await _loadVersion();

    _setStage(0.52);
    await Future.delayed(const Duration(milliseconds: 480));

    _setStage(0.78);
    await Future.delayed(const Duration(milliseconds: 520));

    _setStage(0.92);
  }

  void _setStage(double v) {
    if (!mounted) return;
    setState(() => _stageTarget = v);
  }

  Future<void> _loadVersion() async {
    try {
      final info = await PackageInfo.fromPlatform();
      if (!mounted) return;
      setState(() => _version = "v${info.version}+${info.buildNumber}");
    } catch (_) {}
  }

  @override
  void dispose() {
    _pTimer?.cancel();
    _intro.dispose();
    _fx.dispose();
    _shine.dispose();
    _ambient.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final reduceMotion = MediaQuery.of(context).disableAnimations;
    final size = MediaQuery.of(context).size;
    final isWide = size.width > 520;
    final padTop = MediaQuery.of(context).padding.top;

    final logoBox = min(size.width * 0.60, isWide ? 270.0 : 240.0);
    final progressWidth =
        isWide ? min(520.0, size.width * 0.72) : min(360.0, size.width * 0.84);

    final amb = reduceMotion ? 0.0 : (_ambient.value - 0.5) * 2.0;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: Stack(
          children: [
            // ===== Background Gradient (animated) =====
            AnimatedBuilder(
              animation: _fx,
              builder: (_, __) {
                final t = _fx.value;
                final s1 = sin(t * 2 * pi) * 0.18;
                final s2 = cos(t * 2 * pi) * 0.18;

                return Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment(-1.0 + s1, -1.0 + s2),
                      end: Alignment(1.0 - s1, 1.0 - s2),
                      colors: const [
                        _bg0,
                        _bg1,
                        _bg2,
                      ],
                    ),
                  ),
                );
              },
            ),

            // ===== Pro Glow blobs (✅ أخضر) =====
            Positioned.fill(
              child: IgnorePointer(
                child: AnimatedBuilder(
                  animation: _fx,
                  builder: (_, __) => CustomPaint(
                    painter: _ProGlowPainter(_fx.value,
                        lime: _lime, lime2: _lime2, deep: _limeDeep),
                  ),
                ),
              ),
            ),

            // ===== Soft waves =====
            Positioned.fill(
              child: IgnorePointer(
                child: AnimatedBuilder(
                  animation: _fx,
                  builder: (_, __) =>
                      CustomPaint(painter: _SoftWavesPainter(_fx.value)),
                ),
              ),
            ),

            // ===== Particles / Stars =====
            Positioned.fill(
              child: IgnorePointer(
                child: AnimatedBuilder(
                  animation: _fx,
                  builder: (_, __) =>
                      CustomPaint(painter: _ParticlesPainter(_fx.value)),
                ),
              ),
            ),

            // ===== vignette =====
            Positioned.fill(
              child: IgnorePointer(
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: RadialGradient(
                      center: const Alignment(0, -0.2),
                      radius: 1.2,
                      colors: [
                        Colors.transparent,
                        Colors.black.withOpacity(0.52),
                      ],
                      stops: const [0.55, 1.0],
                    ),
                  ),
                ),
              ),
            ),

            // ===== Content =====
            SafeArea(
              child: Center(
                child: FadeTransition(
                  opacity: _fadeIn,
                  child: SlideTransition(
                    position: _slideIn,
                    child: Transform.translate(
                      offset: Offset(0, 3.0 * amb),
                      child: ScaleTransition(
                        scale: _scaleIn,
                        child: Column(
                          children: [
                            SizedBox(height: max(14, padTop * 0.2)),
                            const Spacer(),
                            _ProLogoFX(
                              asset: _logoAsset,
                              box: logoBox,
                              animate: !reduceMotion,
                              fx: _fx,
                              lime: _lime,
                              lime2: _lime2,
                            ),
                            const SizedBox(height: 18),
                            _ShimmerText(
                              "DoctorCar",
                              fontSize: isWide ? 38 : 33,
                              animate: !reduceMotion,
                              c1: _lime,
                              c2: _lime2,
                              c3: Colors.white.withOpacity(0.95),
                            ),
                            const SizedBox(height: 10),
                            Text(
                              "Smart Car Care & Diagnostics",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: isWide ? 13.5 : 13,
                                color: Colors.white.withOpacity(0.68),
                                fontWeight: FontWeight.w600,
                                letterSpacing: 0.2,
                              ),
                            ),
                            const Spacer(),
                            _PremiumProgressPro(
                              value: _p,
                              width: progressWidth,
                              shine: _shine,
                              animate: !reduceMotion,
                              c1: _lime,
                              c2: _lime2,
                            ),
                            const SizedBox(height: 12),
                            Text(
                              "جاري التحميل... ${(100 * _p).toInt()}%",
                              style: TextStyle(
                                color: Colors.white.withOpacity(0.78),
                                fontSize: 12,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            const SizedBox(height: 10),
                            Text(
                              _version,
                              style: TextStyle(
                                color: Colors.white.withOpacity(0.28),
                                fontSize: 11,
                              ),
                            ),
                            const SizedBox(height: 36),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// =====================
// PRO LOGO FX
// =====================
class _ProLogoFX extends StatefulWidget {
  const _ProLogoFX({
    required this.asset,
    required this.box,
    required this.animate,
    required this.fx,
    required this.lime,
    required this.lime2,
  });

  final String asset;
  final double box;
  final bool animate;
  final AnimationController fx;
  final Color lime;
  final Color lime2;

  @override
  State<_ProLogoFX> createState() => _ProLogoFXState();
}

class _ProLogoFXState extends State<_ProLogoFX> with TickerProviderStateMixin {
  late final AnimationController _pulse;
  late final AnimationController _float;
  late final AnimationController _orb;
  late final AnimationController _sheen;

  @override
  void initState() {
    super.initState();

    _pulse = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1800));
    _float = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 2400));
    _orb = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 2600));
    _sheen = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1800));

    if (widget.animate) {
      _pulse.repeat(reverse: true);
      _float.repeat(reverse: true);
      _orb.repeat();
      _sheen.repeat();
    }
  }

  @override
  void didUpdateWidget(covariant _ProLogoFX oldWidget) {
    super.didUpdateWidget(oldWidget);

    void startAll() {
      if (!_pulse.isAnimating) _pulse.repeat(reverse: true);
      if (!_float.isAnimating) _float.repeat(reverse: true);
      if (!_orb.isAnimating) _orb.repeat();
      if (!_sheen.isAnimating) _sheen.repeat();
    }

    void stopAll() {
      if (_pulse.isAnimating) _pulse.stop();
      if (_float.isAnimating) _float.stop();
      if (_orb.isAnimating) _orb.stop();
      if (_sheen.isAnimating) _sheen.stop();
    }

    widget.animate ? startAll() : stopAll();
  }

  @override
  void dispose() {
    _pulse.dispose();
    _float.dispose();
    _orb.dispose();
    _sheen.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final base = widget.box;
    final card = base * 0.84;

    return AnimatedBuilder(
      animation: Listenable.merge([_pulse, _float, _orb, _sheen, widget.fx]),
      builder: (_, __) {
        final p = widget.animate ? _pulse.value : 0.6;
        final f = widget.animate ? _float.value : 0.5;
        final o = widget.animate ? _orb.value : 0.3;
        final sh = widget.animate ? _sheen.value : 0.2;

        final glow = 0.20 + (p * 0.12);
        final scale = 1.0 + (p * 0.006);
        final dy = (f - 0.5) * 9.0 - 4;

        final ang = o * 2 * pi;
        final r = base * 0.40;
        final dot = Offset(cos(ang) * r, sin(ang) * r);

        return Transform.translate(
          offset: Offset(0, dy),
          child: Transform.scale(
            scale: scale,
            child: Stack(
              alignment: Alignment.center,
              children: [
                // Outer lime glow
                Container(
                  width: base * 1.18,
                  height: base * 1.18,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      colors: [
                        widget.lime.withOpacity(glow),
                        Colors.transparent,
                      ],
                    ),
                  ),
                ),

                // Secondary glow
                Container(
                  width: base * 1.02,
                  height: base * 1.02,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      colors: [
                        widget.lime2.withOpacity(0.08 + p * 0.06),
                        Colors.transparent,
                      ],
                    ),
                  ),
                ),

                // Orbital ring (lime)
                IgnorePointer(
                  child: CustomPaint(
                    size: Size(base, base),
                    painter: _OrbitRingPainter(
                      progress: o,
                      intensity: 0.50 + p * 0.25,
                      c1: widget.lime,
                      c2: widget.lime2,
                    ),
                  ),
                ),

                // Orbital dot
                Positioned(
                  left: (base / 2) + dot.dx - 5,
                  top: (base / 2) + dot.dy - 5,
                  child: Container(
                    width: 10,
                    height: 10,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white.withOpacity(0.78),
                      boxShadow: [
                        BoxShadow(
                          color: widget.lime.withOpacity(0.60),
                          blurRadius: 14,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                  ),
                ),

                // Glass card
                ClipRRect(
                  borderRadius: BorderRadius.circular(42),
                  clipBehavior: Clip.hardEdge,
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
                    child: Container(
                      width: card,
                      height: card,
                      padding: EdgeInsets.all(card * 0.08),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(42),
                        color: Colors.white.withOpacity(0.06),
                        border:
                            Border.all(color: Colors.white.withOpacity(0.18)),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.42),
                            blurRadius: 26,
                            offset: const Offset(0, 18),
                          ),
                        ],
                      ),
                      child: Stack(
                        children: [
                          Positioned.fill(
                            child: Opacity(
                              opacity: 0.80,
                              child: DecoratedBox(
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                    colors: [
                                      Colors.white.withOpacity(0.12),
                                      Colors.transparent,
                                      Colors.white.withOpacity(0.05),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned.fill(
                            child: IgnorePointer(
                              child: CustomPaint(
                                painter: _SheenPainter(progress: sh),
                              ),
                            ),
                          ),
                          Positioned.fill(
                            child: IgnorePointer(
                              child: CustomPaint(
                                painter: _LogoSparklesPainter(
                                  progress: widget.fx.value,
                                  accent: widget.lime,
                                ),
                              ),
                            ),
                          ),
                          Center(
                            child: FittedBox(
                              fit: BoxFit.contain,
                              child: Transform.scale(
                                scale: 1.22,
                                child: Image.asset(
                                  widget.asset,
                                  filterQuality: FilterQuality.high,
                                  errorBuilder: (_, __, ___) => Icon(
                                    Icons.car_repair,
                                    size: card * 0.48,
                                    color: Colors.white.withOpacity(0.92),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

// =====================
// Shimmer Text (lime)
// =====================
class _ShimmerText extends StatelessWidget {
  const _ShimmerText(
    this.text, {
    required this.fontSize,
    required this.animate,
    required this.c1,
    required this.c2,
    required this.c3,
  });

  final String text;
  final double fontSize;
  final bool animate;
  final Color c1;
  final Color c2;
  final Color c3;

  @override
  Widget build(BuildContext context) {
    final base = TextStyle(
      fontSize: fontSize,
      fontWeight: FontWeight.w900,
      letterSpacing: 0.6,
      color: Colors.white,
      height: 1.05,
    );

    if (!animate) {
      return ShaderMask(
        shaderCallback: (rect) => LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: [c1, c2, c3],
        ).createShader(rect),
        child: Text(text, style: base),
      );
    }

    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: const Duration(milliseconds: 1700),
      curve: Curves.easeInOut,
      builder: (context, v, _) {
        final a = -1.0 + (v * 2.0);
        return ShaderMask(
          shaderCallback: (rect) => LinearGradient(
            begin: Alignment(a, 0),
            end: Alignment(a + 1.2, 0),
            colors: [c1, c2, c3],
            stops: const [0.0, 0.55, 1.0],
          ).createShader(rect),
          child: Text(text, style: base),
        );
      },
    );
  }
}

// =====================
// Premium Progress (lime)
// =====================
class _PremiumProgressPro extends StatelessWidget {
  const _PremiumProgressPro({
    required this.value,
    required this.width,
    required this.shine,
    required this.animate,
    required this.c1,
    required this.c2,
  });

  final double value;
  final double width;
  final AnimationController shine;
  final bool animate;
  final Color c1;
  final Color c2;

  @override
  Widget build(BuildContext context) {
    final v = value.clamp(0.0, 1.0);

    return SizedBox(
      width: width,
      height: 14,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(999),
        child: Stack(
          children: [
            Positioned.fill(
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.08),
                    border: Border.all(color: Colors.white.withOpacity(0.10)),
                    borderRadius: BorderRadius.circular(999),
                  ),
                ),
              ),
            ),
            Align(
              alignment: Alignment.centerLeft,
              child: Container(
                width: max(6.0, width * v),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      c1.withOpacity(0.95),
                      c2.withOpacity(0.92),
                      Colors.white.withOpacity(0.70),
                    ],
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: c1.withOpacity(0.38),
                      blurRadius: 18,
                      offset: const Offset(0, 6),
                    ),
                  ],
                ),
              ),
            ),
            if (animate)
              AnimatedBuilder(
                animation: shine,
                builder: (_, __) {
                  final t = shine.value;
                  final left = (width * t) - (width * 0.25);
                  return Positioned(
                    left: left,
                    top: -8,
                    bottom: -8,
                    child: IgnorePointer(
                      child: Container(
                        width: width * 0.25,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Colors.white.withOpacity(0.0),
                              Colors.white.withOpacity(0.22),
                              Colors.white.withOpacity(0.0),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
          ],
        ),
      ),
    );
  }
}

// =====================
// Background Glow Painter (lime)
// =====================
class _ProGlowPainter extends CustomPainter {
  _ProGlowPainter(this.t,
      {required this.lime, required this.lime2, required this.deep});
  final double t;
  final Color lime;
  final Color lime2;
  final Color deep;

  @override
  void paint(Canvas canvas, Size size) {
    void drawBlob(Offset center, double radius, Color color, double opacity) {
      final paint = Paint()
        ..shader = RadialGradient(
          colors: [color.withOpacity(opacity), Colors.transparent],
        ).createShader(Rect.fromCircle(center: center, radius: radius));
      canvas.drawCircle(center, radius, paint);
    }

    final s = sin(t * 2 * pi);
    final c = cos(t * 2 * pi);

    drawBlob(
      Offset(size.width * (0.18 + 0.03 * s), size.height * (0.28 + 0.02 * c)),
      340,
      lime,
      0.20,
    );

    drawBlob(
      Offset(size.width * (0.84 + 0.02 * c), size.height * (0.34 + 0.02 * s)),
      320,
      lime2,
      0.12,
    );

    drawBlob(
      Offset(size.width * 0.50, size.height * (0.90 - 0.02 * s)),
      460,
      deep,
      0.10,
    );
  }

  @override
  bool shouldRepaint(covariant _ProGlowPainter oldDelegate) => true;
}

// =====================
// Soft waves painter
// =====================
class _SoftWavesPainter extends CustomPainter {
  _SoftWavesPainter(this.t);
  final double t;

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;

    void wave(double yBase, double amp, double thickness, double phase,
        double opacity) {
      final path = Path();
      final yy = h * yBase;

      path.moveTo(0, yy);
      for (double x = 0; x <= w; x += 18) {
        final v = sin((x / w) * 2 * pi + (t * 2 * pi) + phase) * amp;
        path.lineTo(x, yy + v);
      }

      final paint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = thickness
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 16)
        ..color = Colors.white.withOpacity(opacity);

      canvas.drawPath(path, paint);
    }

    wave(0.22, 10, 1.5, 0.0, 0.045);
    wave(0.44, 12, 1.7, 1.2, 0.038);
    wave(0.72, 14, 1.9, 2.1, 0.032);
  }

  @override
  bool shouldRepaint(covariant _SoftWavesPainter oldDelegate) => true;
}

// =====================
// Particles
// =====================
class _ParticlesPainter extends CustomPainter {
  _ParticlesPainter(this.t);
  final double t;

  static final List<_Particle> _particles = List.generate(44, (i) {
    final r = Random(i * 97 + 13);
    return _Particle(
      x: r.nextDouble(),
      y: r.nextDouble(),
      radius: 0.6 + r.nextDouble() * 1.8,
      speed: 0.04 + r.nextDouble() * 0.10,
      drift: (r.nextDouble() * 2 - 1) * 0.03,
      alpha: 0.10 + r.nextDouble() * 0.22,
    );
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.white;

    for (final p in _particles) {
      final yy = (p.y - (t * p.speed)) % 1.0;
      final xx = (p.x + sin((t * 2 * pi) + p.y * 6) * p.drift) % 1.0;

      final dx = xx * size.width;
      final dy = yy * size.height;

      final edgeFade = 1.0 - (dy / size.height - 0.5).abs() * 0.9;
      final a = (p.alpha * edgeFade).clamp(0.0, 0.28);

      paint.color = Colors.white.withOpacity(a);
      canvas.drawCircle(Offset(dx, dy), p.radius, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _ParticlesPainter oldDelegate) => true;
}

class _Particle {
  _Particle({
    required this.x,
    required this.y,
    required this.radius,
    required this.speed,
    required this.drift,
    required this.alpha,
  });

  final double x;
  final double y;
  final double radius;
  final double speed;
  final double drift;
  final double alpha;
}

// =====================
// Orbit ring painter (lime)
// =====================
class _OrbitRingPainter extends CustomPainter {
  _OrbitRingPainter({
    required this.progress,
    required this.intensity,
    required this.c1,
    required this.c2,
  });

  final double progress;
  final double intensity;
  final Color c1;
  final Color c2;

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width * 0.44;

    final basePaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2
      ..color = Colors.white.withOpacity(0.10 + intensity * 0.08);

    canvas.drawCircle(center, radius, basePaint);

    final arcPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.4
      ..strokeCap = StrokeCap.round
      ..shader = SweepGradient(
        startAngle: -pi / 3,
        endAngle: pi * 2,
        colors: [
          c1.withOpacity(0.0),
          c1.withOpacity(0.55),
          c2.withOpacity(0.40),
          c1.withOpacity(0.0),
        ],
        stops: const [0.0, 0.38, 0.55, 1.0],
        transform: GradientRotation(progress * 2 * pi),
      ).createShader(Rect.fromCircle(center: center, radius: radius));

    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      -pi / 2,
      pi * 1.15,
      false,
      arcPaint,
    );
  }

  @override
  bool shouldRepaint(covariant _OrbitRingPainter oldDelegate) => true;
}

// =====================
// Sheen painter
// =====================
class _SheenPainter extends CustomPainter {
  _SheenPainter({required this.progress});
  final double progress;

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;

    final x = -w + (w * 2.2 * progress);
    final rect = Rect.fromLTWH(x, -h * 0.2, w * 0.55, h * 1.4);

    final paint = Paint()
      ..blendMode = BlendMode.screen
      ..shader = LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          Colors.white.withOpacity(0.0),
          Colors.white.withOpacity(0.16),
          Colors.white.withOpacity(0.0),
        ],
        stops: const [0.0, 0.5, 1.0],
      ).createShader(rect);

    canvas.save();
    canvas.rotate(-0.18);
    canvas.drawRect(rect, paint);
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _SheenPainter oldDelegate) => true;
}

// =====================
// Sparkles painter (accent lime)
// =====================
class _LogoSparklesPainter extends CustomPainter {
  _LogoSparklesPainter({required this.progress, required this.accent});
  final double progress;
  final Color accent;

  static final List<_Spark> _sparks = List.generate(12, (i) {
    final r = Random(i * 31 + 7);
    return _Spark(
      x: r.nextDouble(),
      y: r.nextDouble(),
      phase: r.nextDouble(),
      size: 1.2 + r.nextDouble() * 2.2,
    );
  });

  @override
  void paint(Canvas canvas, Size size) {
    final t = progress;

    for (final s in _sparks) {
      final tt = (t + s.phase) % 1.0;
      final blink = (sin(tt * 2 * pi) * 0.5 + 0.5);
      final a = (0.05 + blink * 0.20).clamp(0.0, 0.22);

      final dx = size.width * s.x;
      final dy = size.height * s.y;

      final paint = Paint()
        ..color = Color.lerp(Colors.white, accent, 0.35)!.withOpacity(a)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6);

      canvas.drawCircle(Offset(dx, dy), s.size * (0.7 + blink * 0.6), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _LogoSparklesPainter oldDelegate) => true;
}

class _Spark {
  _Spark({
    required this.x,
    required this.y,
    required this.phase,
    required this.size,
  });

  final double x;
  final double y;
  final double phase;
  final double size;
}
