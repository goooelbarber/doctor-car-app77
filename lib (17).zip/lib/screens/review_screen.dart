// PATH: lib/screens/review_screen.dart
// ignore_for_file: depend_on_referenced_packages, use_build_context_synchronously

import 'dart:ui';
import 'package:doctor_car_app/screens/home_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

// ✅ لو هترجع للهوم مباشرة بدون Named Routes
// عدّل المسار ده حسب مشروعك

class ReviewScreen extends StatefulWidget {
  final String orderId;

  /// ✅ لو عندك Named Route للهوم (مثلاً: /home) خلّيها true
  /// ولو مش مستخدم Named Routes خلّيها false (الافتراضي)
  final bool useNamedHomeRoute;

  /// ✅ اسم الراوت للهوم لو useNamedHomeRoute = true
  final String homeRouteName;

  const ReviewScreen({
    super.key,
    required this.orderId,
    this.useNamedHomeRoute = false,
    this.homeRouteName = '/home',
  });

  @override
  State<ReviewScreen> createState() => _ReviewScreenState();
}

class _ReviewScreenState extends State<ReviewScreen>
    with TickerProviderStateMixin {
  // ================== THEME (DoctorCar Neon) ==================
  static const Color _bg = Color(0xff0B1220);
  static const Color _surface = Color(0xff0E1626);
  static const Color _surface2 = Color(0xff0C1322);

  // ✅ Brand (Neon Lime)
  static const Color _brand = Color(0xFFA8F12A);

  // Text
  static const Color _textMain = Color(0xffF9FAFB);
  static const Color _textSub = Color(0xffCBD5E1);
  // ignore: unused_field
  static const Color _textMute = Color(0xff94A3B8);

  // Status
  static const Color _yellow = Color(0xFFFFC107);
  static const Color _danger = Color(0xffEF4444);

  // ================== STATE ==================
  double overallRating = 0;
  double techRating = 0;
  double speedRating = 0;
  double priceRating = 0;

  bool isSending = false;

  final TextEditingController commentController = TextEditingController();

  final List<String> tags = const [
    "سريع",
    "محترف",
    "سعر مناسب",
    "تواصل ممتاز",
    "تأخير",
    "غير مرضي",
  ];

  final Set<String> selectedTags = {};

  // ✅ منع الضغط مرتين (إرسال متكرر)
  bool _submittedOnce = false;

  // ================== GRADIENTS / SHADOWS ==================
  Color get brand2 => Color.lerp(_brand, const Color(0xff0B1220), 0.22)!;
  Color get brand3 => Color.lerp(_brand, Colors.white, 0.18)!;

  LinearGradient get brandGradient => LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [brand3, _brand, brand2.withOpacity(.95)],
        stops: const [0.0, 0.48, 1.0],
      );

  LinearGradient get greenToWhiteGradient => LinearGradient(
        begin: Alignment.centerLeft,
        end: Alignment.centerRight,
        colors: [
          _brand.withOpacity(.95),
          Colors.white,
        ],
        stops: const [0.0, 1.0],
      );

  LinearGradient get glassGradient => LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          Colors.white.withOpacity(.08),
          Colors.white.withOpacity(.05),
          Colors.white.withOpacity(.03),
        ],
        stops: const [0.0, 0.55, 1.0],
      );

  List<BoxShadow> get glowNeon => [
        BoxShadow(
          color: _brand.withOpacity(.28),
          blurRadius: 28,
          spreadRadius: 1,
          offset: const Offset(0, 12),
        ),
        BoxShadow(
          color: brand3.withOpacity(.12),
          blurRadius: 50,
          spreadRadius: 2,
          offset: const Offset(0, 22),
        ),
      ];

  @override
  void dispose() {
    commentController.dispose();
    super.dispose();
  }

  // ================== SUBMIT ==================
  Future<void> submitReview() async {
    if (isSending || _submittedOnce) return;

    if (overallRating == 0) {
      _snack("من فضلك اختر التقييم العام");
      return;
    }

    _submittedOnce = true;
    HapticFeedback.mediumImpact();
    setState(() => isSending = true);

    // TODO: Call API here:
    // payload example:
    // {
    //  orderId: widget.orderId,
    //  overall: overallRating,
    //  tech: techRating,
    //  speed: speedRating,
    //  price: priceRating,
    //  tags: selectedTags.toList(),
    //  comment: commentController.text.trim(),
    // }

    // محاكاة طلب API
    await Future.delayed(const Duration(seconds: 2));

    if (!mounted) return;
    setState(() => isSending = false);

    _showSuccessSheet();
  }

  // ================= UI =================
  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: _bg,
        extendBodyBehindAppBar: true,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          iconTheme: const IconThemeData(color: _textMain),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(
                "تخطي",
                style: GoogleFonts.cairo(
                  color: _textSub,
                  fontWeight: FontWeight.w900,
                ),
              ),
            )
          ],
        ),
        body: Stack(
          children: [
            _backgroundGlow(),
            _content(),
            if (isSending) _loading(),
          ],
        ),
      ),
    );
  }

  // خلفية بتدرج + لمعة خفيفة
  Widget _backgroundGlow() {
    return Stack(
      children: [
        Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                _bg,
                Color.lerp(_bg, brand2, 0.10)!,
                const Color(0xff07101C),
              ],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
        ),
        Positioned(
          left: -60,
          top: -40,
          child: Container(
            width: 220,
            height: 220,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [
                  _brand.withOpacity(.18),
                  Colors.transparent,
                ],
              ),
            ),
          ),
        ),
        Positioned(
          right: -80,
          bottom: -60,
          child: Container(
            width: 260,
            height: 260,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [
                  _brand.withOpacity(.12),
                  Colors.transparent,
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _content() {
    final pad = MediaQuery.of(context).padding;
    return SafeArea(
      child: Center(
        child: ClipRRect(
          borderRadius: BorderRadius.circular(26),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
            child: Container(
              width: MediaQuery.of(context).size.width * 0.92,
              constraints: const BoxConstraints(maxWidth: 520),
              padding: EdgeInsets.fromLTRB(
                  16, 16, 16, 16 + (pad.bottom > 0 ? 2 : 0)),
              decoration: BoxDecoration(
                gradient: glassGradient,
                borderRadius: BorderRadius.circular(26),
                border: Border.all(color: Colors.white.withOpacity(.10)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(.35),
                    blurRadius: 28,
                    offset: const Offset(0, 14),
                  ),
                ],
              ),
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                child: Column(
                  children: [
                    _header(),
                    const SizedBox(height: 10),
                    _progressHint(),
                    const SizedBox(height: 14),
                    _ratingSection(
                      "التقييم العام",
                      (v) => setState(() => overallRating = v),
                      overallRating,
                      big: true,
                    ),
                    const SizedBox(height: 10),
                    _subRatings(),
                    const SizedBox(height: 12),
                    _tags(),
                    const SizedBox(height: 14),
                    _commentBox(),
                    const SizedBox(height: 16),
                    _submitButton(),
                    const SizedBox(height: 6),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _header() {
    return Row(
      children: [
        Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(
              colors: [
                _brand.withOpacity(.22),
                Colors.white.withOpacity(.10),
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            border: Border.all(color: _brand.withOpacity(.25)),
          ),
          child: const Icon(Icons.star_rounded, color: _yellow, size: 28),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "قيّم تجربتك",
                style: GoogleFonts.cairo(
                  color: _textMain,
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                "رقم الطلب: ${widget.orderId}",
                style: GoogleFonts.cairo(
                  color: _textSub,
                  fontSize: 12.5,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ✅ مؤشر بسيط يوضح التقدم
  Widget _progressHint() {
    final progress = _calcProgress();
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _surface2.withOpacity(.55),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(.08)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "اكتمال التقييم",
                  style: GoogleFonts.cairo(
                    color: _textMain,
                    fontWeight: FontWeight.w900,
                    fontSize: 13,
                  ),
                ),
                const SizedBox(height: 6),
                ClipRRect(
                  borderRadius: BorderRadius.circular(999),
                  child: LinearProgressIndicator(
                    value: progress,
                    minHeight: 8,
                    backgroundColor: Colors.white.withOpacity(.08),
                    valueColor: AlwaysStoppedAnimation<Color>(_brand),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _brand.withOpacity(.28)),
              color: _brand.withOpacity(.10),
            ),
            child: Text(
              "${(progress * 100).round()}%",
              style: GoogleFonts.cairo(
                color: _textMain,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
        ],
      ),
    );
  }

  double _calcProgress() {
    double p = 0;
    if (overallRating > 0) p += 0.50;
    if (techRating > 0) p += 0.15;
    if (speedRating > 0) p += 0.15;
    if (priceRating > 0) p += 0.10;
    if (commentController.text.trim().isNotEmpty || selectedTags.isNotEmpty)
      p += 0.10;
    return p.clamp(0.0, 1.0);
  }

  Widget _subRatings() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _surface.withOpacity(.72),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white.withOpacity(.08)),
      ),
      child: Column(
        children: [
          _ratingRow("احترافية الفني", (v) => setState(() => techRating = v),
              techRating),
          const SizedBox(height: 8),
          _ratingRow("سرعة الوصول", (v) => setState(() => speedRating = v),
              speedRating),
          const SizedBox(height: 8),
          _ratingRow(
              "السعر", (v) => setState(() => priceRating = v), priceRating),
        ],
      ),
    );
  }

  Widget _ratingRow(String title, Function(double) onRate, double value) {
    return Row(
      children: [
        Expanded(
          child: Text(
            title,
            style: GoogleFonts.cairo(
              color: _textSub,
              fontWeight: FontWeight.w900,
              fontSize: 13,
            ),
          ),
        ),
        _stars(value: value, size: 22, onTap: onRate),
      ],
    );
  }

  Widget _ratingSection(
    String title,
    Function(double) onRate,
    double value, {
    bool big = false,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: GoogleFonts.cairo(
            color: _textSub,
            fontSize: 13,
            fontWeight: FontWeight.w900,
          ),
        ),
        const SizedBox(height: 8),
        Center(
          child: _stars(
            value: value,
            size: big ? 44 : 28,
            onTap: (v) => setState(() => onRate(v)),
          ),
        ),
        if (big) ...[
          const SizedBox(height: 6),
          Center(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(999),
                border: Border.all(color: _brand.withOpacity(.30)),
                color: _brand.withOpacity(.10),
              ),
              child: Text(
                _ratingLabel(value),
                style: GoogleFonts.cairo(
                  color: _textMain,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
          ),
        ],
      ],
    );
  }

  Widget _stars({
    required double value,
    required double size,
    required Function(double) onTap,
  }) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(5, (i) {
        final filled = value >= (i + 1);

        return GestureDetector(
          onTap: () {
            HapticFeedback.selectionClick();
            onTap(i + 1.0);
          },
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 2),
            child: AnimatedScale(
              duration: const Duration(milliseconds: 130),
              scale: filled ? 1.08 : 1.0,
              child: Icon(
                Icons.star_rounded,
                size: size,
                color: filled ? _yellow : Colors.white24,
              ),
            ),
          ),
        );
      }),
    );
  }

  String _ratingLabel(double v) {
    if (v >= 5) return "ممتاز";
    if (v >= 4) return "جيد جدًا";
    if (v >= 3) return "جيد";
    if (v >= 2) return "مقبول";
    if (v >= 1) return "سيء";
    return "اختر تقييم";
  }

  Widget _tags() {
    return Align(
      alignment: Alignment.centerRight,
      child: Wrap(
        spacing: 10,
        runSpacing: 10,
        children: tags.map((t) {
          final active = selectedTags.contains(t);

          return InkWell(
            onTap: () {
              HapticFeedback.selectionClick();
              setState(() {
                active ? selectedTags.remove(t) : selectedTags.add(t);
              });
            },
            borderRadius: BorderRadius.circular(18),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 170),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                gradient: active ? greenToWhiteGradient : null,
                color: active ? null : Colors.white.withOpacity(.06),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(
                  color: active ? _brand.withOpacity(.55) : Colors.white12,
                ),
                boxShadow: active ? glowNeon : null,
              ),
              child: Text(
                t,
                style: GoogleFonts.cairo(
                  color: active ? Colors.black : _textSub,
                  fontWeight: FontWeight.w900,
                  fontSize: 12.5,
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _commentBox() {
    return TextField(
      controller: commentController,
      onChanged: (_) => setState(() {}),
      maxLines: 3,
      style: GoogleFonts.cairo(
        color: _textMain,
        fontWeight: FontWeight.w700,
      ),
      decoration: InputDecoration(
        hintText: "أضف تعليقًا (اختياري)",
        hintStyle: GoogleFonts.cairo(color: Colors.white38),
        filled: true,
        fillColor: Colors.white.withOpacity(.06),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: Colors.white12),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide(color: _brand.withOpacity(.85), width: 1.4),
        ),
      ),
    );
  }

  Widget _submitButton() {
    final disabled = isSending || overallRating == 0;

    return SizedBox(
      width: double.infinity,
      height: 56,
      child: AbsorbPointer(
        absorbing: disabled,
        child: InkWell(
          onTap: submitReview,
          borderRadius: BorderRadius.circular(18),
          child: Ink(
            decoration: BoxDecoration(
              gradient: disabled
                  ? LinearGradient(
                      colors: [
                        Colors.white.withOpacity(.12),
                        Colors.white.withOpacity(.08),
                      ],
                    )
                  : greenToWhiteGradient,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(
                color: disabled ? Colors.white12 : _brand.withOpacity(.28),
              ),
              boxShadow: disabled ? null : glowNeon,
            ),
            child: Center(
              child: Text(
                isSending ? "جاري الإرسال..." : "إرسال التقييم",
                style: GoogleFonts.cairo(
                  color: disabled ? Colors.white70 : Colors.black,
                  fontSize: 16.5,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _loading() {
    return Container(
      color: Colors.black.withOpacity(.45),
      child: Center(
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: _surface.withOpacity(.92),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: Colors.white.withOpacity(.10)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(color: _brand),
              const SizedBox(height: 12),
              Text(
                "جاري إرسال التقييم...",
                style: GoogleFonts.cairo(
                  color: _textMain,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                "من فضلك متقفلش الشاشة",
                style: GoogleFonts.cairo(
                  color: _textSub,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ================= HELPERS =================
  void _snack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: _danger.withOpacity(.92),
        content: Text(
          msg,
          textAlign: TextAlign.center,
          style: GoogleFonts.cairo(fontWeight: FontWeight.w900),
        ),
      ),
    );
  }

  /// ✅ رجوع للهوم (مباشرة)
  void _goHome() {
    if (!mounted) return;

    // اقفل الـ sheet لو مفتوح
    Navigator.of(context).pop();

    if (widget.useNamedHomeRoute) {
      // ✅ Named Route
      Navigator.of(context).pushNamedAndRemoveUntil(
        widget.homeRouteName,
        (route) => false,
      );
    } else {
      // ✅ Direct HomeScreen
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const HomeScreen()),
        (route) => false,
      );
    }
  }

  void _showSuccessSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isDismissible: false,
      enableDrag: false,
      builder: (_) {
        return SafeArea(
          top: false,
          child: Container(
            margin: const EdgeInsets.all(12),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: _surface.withOpacity(.96),
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: Colors.white.withOpacity(.10)),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(.35),
                  blurRadius: 24,
                  offset: const Offset(0, 14),
                )
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 56,
                  height: 5,
                  decoration: BoxDecoration(
                    color: Colors.white24,
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                const SizedBox(height: 14),
                Container(
                  width: 64,
                  height: 64,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      colors: [
                        _brand.withOpacity(.22),
                        Colors.white.withOpacity(.10),
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    border: Border.all(color: _brand.withOpacity(.25)),
                  ),
                  child:
                      const Icon(Icons.check_circle, color: _brand, size: 40),
                ),
                const SizedBox(height: 10),
                Text(
                  "شكرًا لتقييمك 🙏",
                  style: GoogleFonts.cairo(
                    color: _textMain,
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 6),
                Text(
                  "تم إرسال التقييم بنجاح",
                  style: GoogleFonts.cairo(
                    color: _textSub,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  height: 52,
                  child: InkWell(
                    // ✅ هنا التعديل الأساسي: يرجّع للهوم
                    onTap: _goHome,
                    borderRadius: BorderRadius.circular(18),
                    child: Ink(
                      decoration: BoxDecoration(
                        gradient: greenToWhiteGradient,
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(color: _brand.withOpacity(.28)),
                        boxShadow: glowNeon,
                      ),
                      child: Center(
                        child: Text(
                          "تم",
                          style: GoogleFonts.cairo(
                            color: Colors.black,
                            fontWeight: FontWeight.w900,
                            fontSize: 16,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
