// PATH: lib/screens/login_screen.dart
// ignore_for_file: use_build_context_synchronously

import 'dart:ui';
// ignore: unused_import
import 'dart:math' as math;

import 'package:flutter/foundation.dart'; // kIsWeb
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:local_auth/local_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:doctor_car_app/screens/driver/incoming_request_screen.dart';
import 'package:doctor_car_app/screens/home_screen.dart';
import 'package:doctor_car_app/services/api_service.dart';
import 'package:doctor_car_app/screens/role_selection_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen>
    with TickerProviderStateMixin {
  // =========================
  // 🎨 COLORS (MATCH DoctorCar UI)
  // =========================
  static const Color _bg0 = Color(0xFF0B0F10);
  static const Color _bg1 = Color(0xFF111718);
  static const Color _bg2 = Color(0xFF0A1010);

  // ignore: unused_field
  static const Color _card0 = Color(0xFF1A1F20);
  // ignore: unused_field
  static const Color _card1 = Color(0xFF202627);

  static const Color _lime = Color(0xFFB8FF2C);
  static const Color _lime2 = Color(0xFFB3FB2A);
  static const Color _onLime = Color(0xFF121A12);

  static const Color _mutedText = Color(0xFFB7C0BD);

  // =========================
  // Controllers
  // =========================
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  final LocalAuthentication _auth = LocalAuthentication();

  // =========================
  // Animations
  // =========================
  late final AnimationController _logoController;
  late final Animation<double> _logoScale;

  // =========================
  // State
  // =========================
  bool _obscureText = true;
  bool _isLoading = false;

  bool _rememberMe = true;
  bool _biometricEnabled = false;
  bool _deviceSupportsBiometric = false;

  String? _selectedRole; // rider|driver|technician...
  bool _roleChecked = false;

  // =========================
  // Pref keys
  // =========================
  static const String _kIsLoggedInKey = 'isLoggedIn';
  static const String _kTokenKey = 'token';
  static const String _kUserIdKey = 'userId';
  static const String _kUserEmailKey = 'userEmail';
  static const String _kUserNameKey = 'userName';
  static const String _kSelectedRoleKey = 'selectedRole';
  static const String _kBiometricKey = 'biometric';
  static const String _kForceLoginOnceKey = 'forceLoginOnce';

  static const String _kRememberedEmailKey = 'rememberedEmail';
  static const String _kRememberMeKey = 'rememberMe';

  // =========================
  // Google Web Client ID
  // =========================
  static const String kGoogleWebClientId =
      "261907163300-cngtqbjih04t2c5k66vfqd2tduqvt2oc.apps.googleusercontent.com";

  // =========================
  // Lifecycle
  // =========================
  @override
  void initState() {
    super.initState();

    _logoController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..forward();

    _logoScale = CurvedAnimation(
      parent: _logoController,
      curve: Curves.easeOutBack,
    );

    _bootstrap();
  }

  Future<void> _bootstrap() async {
    await _loadRoleOrRedirect();
    if (!mounted) return;

    await _loadRememberedEmail();

    final prefs = await SharedPreferences.getInstance();
    final forceLogin = prefs.getBool(_kForceLoginOnceKey) ?? false;

    if (forceLogin) {
      await prefs.setBool(_kForceLoginOnceKey, false); // one-time
    } else {
      await _autoRedirectIfAlreadyLoggedIn();
    }

    await _initBiometric();
  }

  @override
  void dispose() {
    _logoController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  // ======================================================
  // ROLE CHECK
  // ======================================================
  Future<void> _loadRoleOrRedirect() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      _selectedRole = prefs.getString(_kSelectedRoleKey);

      if (!mounted) return;

      if (_selectedRole == null || _selectedRole!.isEmpty) {
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const RoleSelectionScreen()),
          (route) => false,
        );
        return;
      }

      setState(() => _roleChecked = true);
    } catch (_) {
      if (mounted) setState(() => _roleChecked = true);
    }
  }

  Future<void> _changeRole() async {
    if (_isLoading) return;

    final prefs = await SharedPreferences.getInstance();

    await prefs.setBool(_kIsLoggedInKey, false);
    await prefs.remove(_kTokenKey);
    await prefs.remove(_kUserIdKey);
    await prefs.remove(_kUserEmailKey);
    await prefs.remove(_kUserNameKey);

    await prefs.remove(_kSelectedRoleKey);
    await prefs.remove(_kForceLoginOnceKey);

    if (!mounted) return;

    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const RoleSelectionScreen()),
      (route) => false,
    );
  }

  // ======================================================
  // AUTO REDIRECT
  // ======================================================
  Future<void> _autoRedirectIfAlreadyLoggedIn() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final isLoggedIn = prefs.getBool(_kIsLoggedInKey) ?? false;
      final token = prefs.getString(_kTokenKey) ?? "";
      final role = prefs.getString(_kSelectedRoleKey) ?? "";
      final userId = prefs.getString(_kUserIdKey) ?? "";

      if (!mounted) return;

      if (isLoggedIn &&
          token.isNotEmpty &&
          role.isNotEmpty &&
          userId.isNotEmpty) {
        await _goAfterLogin(role);
      }
    } catch (_) {}
  }

  // ======================================================
  // BIOMETRIC
  // ======================================================
  Future<void> _initBiometric() async {
    if (kIsWeb) return;

    try {
      final prefs = await SharedPreferences.getInstance();
      _biometricEnabled = prefs.getBool(_kBiometricKey) ?? false;

      final hasToken = (prefs.getString(_kTokenKey) ?? "").isNotEmpty;
      _deviceSupportsBiometric = await _auth.canCheckBiometrics;

      if (mounted) {
        setState(() {
          _biometricEnabled = _biometricEnabled && hasToken;
        });
      }
    } catch (_) {}
  }

  Future<void> _biometricLogin() async {
    if (kIsWeb || _isLoading) return;

    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString(_kTokenKey) ?? "";
    final role = prefs.getString(_kSelectedRoleKey) ?? "";

    if (token.isEmpty || role.isEmpty) {
      _showMessage("لا يوجد جلسة محفوظة للبصمة، سجل دخول مرة أولاً");
      return;
    }

    final success = await _auth.authenticate(
      localizedReason: 'سجل الدخول باستخدام Face ID / Fingerprint',
      options: const AuthenticationOptions(biometricOnly: true),
    );

    if (!success) return;

    if (!mounted) return;
    await _goAfterLogin(role);
  }

  // ======================================================
  // ✅ IMPORTANT: Role resolver
  // ======================================================
  String _resolveRoleToUse({
    required String selectedRole,
    dynamic serverUserObj,
  }) {
    final s = selectedRole.toLowerCase().trim();

    if (s == "driver" || s == "technician" || s == "mechanic") return "driver";
    if (s == "rider" || s == "user" || s == "client") return "rider";

    final fromServer =
        (serverUserObj is Map ? serverUserObj["role"]?.toString() : null) ?? "";
    final fs = fromServer.toLowerCase().trim();
    if (_isTechnicianRole(fs)) return "driver";
    return "rider";
  }

  // ======================================================
  // AUTH: EMAIL/PASSWORD
  // ======================================================
  Future<void> _login() async {
    if (_isLoading) return;

    FocusScope.of(context).unfocus();

    final email = _emailController.text.trim();
    final password = _passwordController.text.trim();

    if (!_isValidEmail(email)) {
      _showMessage("أدخل بريد إلكتروني صحيح");
      return;
    }

    if (password.length < 6) {
      _showMessage("كلمة المرور قصيرة");
      return;
    }

    setState(() => _isLoading = true);

    try {
      final prefs = await SharedPreferences.getInstance();
      final selectedRole = prefs.getString(_kSelectedRoleKey);

      if (selectedRole == null || selectedRole.isEmpty) {
        if (!mounted) return;
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const RoleSelectionScreen()),
          (route) => false,
        );
        return;
      }

      final res = await ApiService.login(email, password);

      if (res['token'] != null) {
        final token = (res['token'] ?? "").toString();

        final userObj = res['user'];
        final idFromUser =
            (userObj is Map ? (userObj['_id'] ?? userObj['id']) : null)
                ?.toString();
        final idFromRoot = (res['userId'] ?? res['id'] ?? "").toString();

        final finalId = (idFromUser != null && idFromUser.isNotEmpty)
            ? idFromUser
            : idFromRoot;

        final name =
            (userObj is Map ? (userObj['name'] ?? userObj['username']) : null)
                    ?.toString() ??
                "User";

        final roleToUse = _resolveRoleToUse(
          selectedRole: selectedRole,
          serverUserObj: userObj,
        );

        await prefs.setBool(_kIsLoggedInKey, true);
        await prefs.setString(_kTokenKey, token);
        await prefs.setString(_kUserIdKey, finalId);
        await prefs.setString(_kUserEmailKey, email);
        await prefs.setString(_kUserNameKey, name);
        await prefs.setString(_kSelectedRoleKey, roleToUse);

        await prefs.setBool(_kForceLoginOnceKey, false);

        if (!kIsWeb) {
          await prefs.setBool(_kBiometricKey, true);
        }

        await _saveRememberedEmail();

        if (!mounted) return;
        await _goAfterLogin(roleToUse);
      } else {
        _showMessage(res['message']?.toString() ?? "فشل تسجيل الدخول");
      }
    } catch (_) {
      _showMessage("تعذر الاتصال بالسيرفر");
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  // ======================================================
  // AUTH: GOOGLE
  // ======================================================
  Future<void> _loginWithGoogle() async {
    if (_isLoading) return;

    setState(() => _isLoading = true);

    try {
      final prefs = await SharedPreferences.getInstance();
      final selectedRole = prefs.getString(_kSelectedRoleKey);

      if (selectedRole == null || selectedRole.isEmpty) {
        if (!mounted) return;
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const RoleSelectionScreen()),
          (route) => false,
        );
        return;
      }

      final googleSignIn = GoogleSignIn(
        scopes: const ["email", "profile", "openid"],
        clientId: kIsWeb ? kGoogleWebClientId : null,
        serverClientId: !kIsWeb ? kGoogleWebClientId : null,
      );

      await googleSignIn.signOut();
      final account = await googleSignIn.signIn();
      if (account == null) return;

      final auth = await account.authentication;
      if (auth.idToken == null) {
        _showMessage("تعذر الحصول على Google Token");
        return;
      }

      final res =
          await ApiService.googleLogin(auth.idToken!, role: selectedRole);

      if (res['token'] != null) {
        final token = (res['token'] ?? "").toString();

        final userObj = res['user'];
        final idFromUser =
            (userObj is Map ? (userObj['_id'] ?? userObj['id']) : null)
                ?.toString();
        final idFromRoot = (res['userId'] ?? res['id'] ?? "").toString();

        final finalId = (idFromUser != null && idFromUser.isNotEmpty)
            ? idFromUser
            : idFromRoot;

        final name =
            (userObj is Map ? (userObj['name'] ?? userObj['username']) : null)
                    ?.toString() ??
                (account.displayName ?? "User");

        final email = (userObj is Map ? userObj['email'] : null)?.toString() ??
            account.email;

        final roleToUse = _resolveRoleToUse(
          selectedRole: selectedRole,
          serverUserObj: userObj,
        );

        await prefs.setBool(_kIsLoggedInKey, true);
        await prefs.setString(_kTokenKey, token);
        await prefs.setString(_kUserIdKey, finalId);
        await prefs.setString(_kUserNameKey, name);
        await prefs.setString(_kUserEmailKey, email);
        await prefs.setString(_kSelectedRoleKey, roleToUse);

        await prefs.setBool(_kForceLoginOnceKey, false);

        if (!kIsWeb) {
          await prefs.setBool(_kBiometricKey, true);
        }

        if (!mounted) return;
        await _goAfterLogin(roleToUse);
      } else {
        _showMessage(res['message']?.toString() ?? "Google login failed");
      }
    } catch (_) {
      _showMessage("Google login failed");
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  // ======================================================
  // 🚀 NAVIGATION
  // ======================================================
  Future<void> _goAfterLogin(String role) async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString(_kTokenKey) ?? "";
    final userId = prefs.getString(_kUserIdKey) ?? "";

    if (!mounted) return;

    final Widget next = _isTechnicianRole(role)
        ? IncomingRequestScreen(
            technicianToken: token,
            technicianId: userId,
          )
        : const HomeScreen();

    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => next),
      (route) => false,
    );
  }

  // ======================================================
  // HELPERS
  // ======================================================
  bool _isTechnicianRole(String role) {
    final r = role.toLowerCase().trim();
    return r == "driver" ||
        r == "technician" ||
        r == "mechanic" ||
        r == "service_provider";
  }

  String _roleLabel(String? role) {
    final r = (role ?? "").toLowerCase();
    if (_isTechnicianRole(r)) return "فني";
    return "راكب";
  }

  bool _isValidEmail(String email) =>
      RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(email);

  void _showMessage(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg, textAlign: TextAlign.center)),
    );
  }

  Future<void> _loadRememberedEmail() async {
    final prefs = await SharedPreferences.getInstance();
    _emailController.text = prefs.getString(_kRememberedEmailKey) ?? "";
    _rememberMe = prefs.getBool(_kRememberMeKey) ?? true;
    if (mounted) setState(() {});
  }

  Future<void> _saveRememberedEmail() async {
    final prefs = await SharedPreferences.getInstance();
    if (_rememberMe) {
      await prefs.setString(_kRememberedEmailKey, _emailController.text.trim());
    } else {
      await prefs.remove(_kRememberedEmailKey);
    }
    await prefs.setBool(_kRememberMeKey, _rememberMe);
  }

  double _passwordStrength() {
    final p = _passwordController.text;
    if (p.isEmpty) return 0;
    if (p.length >= 12) return 1;
    if (p.length >= 8) return 0.7;
    if (p.length >= 6) return 0.5;
    return 0.25;
  }

  String _strengthLabel() {
    final v = _passwordStrength();
    if (v >= 1) return "قوية جدًا";
    if (v >= 0.7) return "قوية";
    if (v >= 0.5) return "متوسطة";
    if (v > 0) return "ضعيفة";
    return "";
  }

  // ======================================================
  // UI
  // ======================================================
  @override
  Widget build(BuildContext context) {
    if (!_roleChecked) {
      return const Scaffold(
        backgroundColor: _bg0,
        body: Center(child: CircularProgressIndicator(color: _lime)),
      );
    }

    return Scaffold(
      body: Stack(
        children: [
          _backgroundLikeScreenshot(), // ✅ نفس الخلفية بجد
          SafeArea(
            child: Align(
              alignment: Alignment.center,
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 520),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: _glassCard(),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ✅ Background قريب جدًا من الصورة: مناطق خضراء مائلة + تظليل + لمعة لايم
  Widget _backgroundLikeScreenshot() {
    return Stack(
      children: [
        // Base gradient dark
        const Positioned.fill(
          child: DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [_bg0, _bg1, _bg2],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),
        ),

        // Big diagonal green area (left)
        Positioned(
          left: -120,
          top: -80,
          child: Transform.rotate(
            angle: -0.18,
            child: Container(
              width: 260,
              height: 520,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(180),
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    const Color(0xFF2E3D16).withOpacity(.85),
                    const Color(0xFF1B2610).withOpacity(.35),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
        ),

        // Big diagonal green area (bottom-right)
        Positioned(
          right: -150,
          bottom: -160,
          child: Transform.rotate(
            angle: -0.25,
            child: Container(
              width: 420,
              height: 420,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(260),
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    const Color(0xFF2B3A14).withOpacity(.65),
                    const Color(0xFF1A2410).withOpacity(.25),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
        ),

        // Glow painter (lime highlights) + subtle pattern
        Positioned.fill(
          child: CustomPaint(
            painter: _DoctorCarBackgroundPainter(),
          ),
        ),

        // Vignette (edges darker)
        Positioned.fill(
          child: DecoratedBox(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: const Alignment(0, -0.2),
                radius: 1.1,
                colors: [
                  Colors.transparent,
                  Colors.black.withOpacity(.45),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _glassCard() {
    final roleLabel = _roleLabel(_selectedRole);

    return ClipRRect(
      borderRadius: BorderRadius.circular(28),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(.10),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: Colors.white.withOpacity(.18)),
            boxShadow: [
              BoxShadow(
                blurRadius: 30,
                color: Colors.black.withOpacity(.30),
                offset: const Offset(0, 18),
              ),
            ],
          ),
          child: SingleChildScrollView(
            child: Column(
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(.08),
                        borderRadius: BorderRadius.circular(999),
                        border:
                            Border.all(color: Colors.white.withOpacity(.16)),
                      ),
                      child: Text(
                        "الدور: $roleLabel",
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                    const Spacer(),
                    TextButton(
                      onPressed: _isLoading ? null : _changeRole,
                      child: const Text(
                        "تغيير الدور",
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),

                // ✅ الدائرة (زي ستايل الصورة) + لمعة خفيفة + حلقات
                ScaleTransition(
                  scale: _logoScale,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      // outer ring
                      Container(
                        width: 104,
                        height: 104,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.white.withOpacity(.06),
                          border:
                              Border.all(color: Colors.white.withOpacity(.12)),
                        ),
                      ),
                      // lime ring glow
                      Container(
                        width: 98,
                        height: 98,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              blurRadius: 36,
                              color: _lime.withOpacity(.28),
                              spreadRadius: 2,
                            ),
                          ],
                        ),
                      ),
                      // main circle
                      Container(
                        width: 92,
                        height: 92,
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(
                            colors: [_lime, _lime2],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                        ),
                        child: const Icon(
                          Icons.directions_car_filled,
                          color: _onLime,
                          size: 46,
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 18),
                const Text(
                  "تسجيل الدخول",
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 6),
                const Text(
                  "أكمل رحلتك بأمان — دخول سريع واحترافي",
                  style: TextStyle(color: Colors.white70),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 22),

                _field(_emailController, Icons.email, "البريد الإلكتروني"),
                const SizedBox(height: 14),
                _passwordField(),
                const SizedBox(height: 10),

                Row(
                  children: [
                    Expanded(
                      child: LinearProgressIndicator(
                        value: _passwordStrength(),
                        minHeight: 6,
                        borderRadius: BorderRadius.circular(20),
                        backgroundColor: Colors.white24,
                        color: _lime,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Text(
                      _strengthLabel(),
                      style: const TextStyle(
                        color: Colors.white70,
                        fontSize: 12,
                      ),
                    )
                  ],
                ),

                const SizedBox(height: 10),
                Row(
                  children: [
                    Checkbox(
                      value: _rememberMe,
                      activeColor: _lime,
                      onChanged: _isLoading
                          ? null
                          : (v) => setState(() => _rememberMe = v ?? true),
                    ),
                    const Text("تذكرني", style: TextStyle(color: Colors.white)),
                    const Spacer(),
                    TextButton(
                      onPressed: _isLoading
                          ? null
                          : () =>
                              Navigator.pushNamed(context, '/forgot-password'),
                      child: const Text(
                        "نسيت كلمة المرور؟",
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ],
                ),

                if (!kIsWeb && _deviceSupportsBiometric && _biometricEnabled)
                  Align(
                    alignment: Alignment.centerRight,
                    child: TextButton.icon(
                      onPressed: _isLoading ? null : _biometricLogin,
                      icon: const Icon(Icons.fingerprint, color: Colors.white),
                      label: const Text(
                        "دخول بالبصمة",
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ),

                const SizedBox(height: 6),
                SizedBox(
                  width: double.infinity,
                  height: 54,
                  child: ElevatedButton(
                    onPressed: _isLoading ? null : _login,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _lime,
                      foregroundColor: _onLime,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18),
                      ),
                      elevation: 0,
                    ),
                    child: _isLoading
                        ? const SizedBox(
                            width: 22,
                            height: 22,
                            child: CircularProgressIndicator(
                              strokeWidth: 2.5,
                              color: _onLime,
                            ),
                          )
                        : const Text(
                            "تسجيل الدخول",
                            style: TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                  ),
                ),

                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                        child: Divider(color: Colors.white.withOpacity(.25))),
                    const Padding(
                      padding: EdgeInsets.symmetric(horizontal: 10),
                      child:
                          Text("أو", style: TextStyle(color: Colors.white70)),
                    ),
                    Expanded(
                        child: Divider(color: Colors.white.withOpacity(.25))),
                  ],
                ),

                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  height: 54,
                  child: OutlinedButton.icon(
                    onPressed: _isLoading ? null : _loginWithGoogle,
                    icon: const Icon(FontAwesomeIcons.google, size: 18),
                    label: const Text(
                      "تسجيل بواسطة Google",
                      style:
                          TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
                    ),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.white,
                      side: BorderSide(color: Colors.white.withOpacity(.30)),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18),
                      ),
                      backgroundColor: Colors.white.withOpacity(.06),
                    ),
                  ),
                ),

                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _social(FontAwesomeIcons.facebookF),
                    const SizedBox(width: 12),
                    _social(FontAwesomeIcons.apple),
                    const SizedBox(width: 12),
                    _social(FontAwesomeIcons.twitter),
                  ],
                ),

                const SizedBox(height: 10),
                Text(
                  "بالاستمرار أنت توافق على الشروط وسياسة الخصوصية",
                  style: TextStyle(
                    color: _mutedText.withOpacity(.75),
                    fontSize: 12,
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ======================================================
  // Widgets
  // ======================================================
  Widget _field(TextEditingController c, IconData i, String hint) {
    return TextField(
      controller: c,
      keyboardType: TextInputType.emailAddress,
      textAlign: TextAlign.right,
      style: const TextStyle(color: Colors.white),
      decoration: _input(i, hint),
    );
  }

  Widget _passwordField() => TextField(
        controller: _passwordController,
        obscureText: _obscureText,
        style: const TextStyle(color: Colors.white),
        textAlign: TextAlign.right,
        onChanged: (_) => setState(() {}),
        decoration: _input(Icons.lock, "كلمة المرور").copyWith(
          suffixIcon: IconButton(
            icon: Icon(
              _obscureText ? Icons.visibility_off : Icons.visibility,
              color: Colors.white,
            ),
            onPressed: () => setState(() => _obscureText = !_obscureText),
          ),
        ),
      );

  InputDecoration _input(IconData icon, String hint) => InputDecoration(
        filled: true,
        fillColor: Colors.white.withOpacity(.10),
        prefixIcon: Icon(icon, color: Colors.white),
        hintText: hint,
        hintStyle: const TextStyle(color: Colors.white70),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 16),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: BorderSide(color: Colors.white.withOpacity(.16)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: const BorderSide(color: _lime, width: 1.3),
        ),
      );

  Widget _social(IconData icon) => InkWell(
        onTap: () => _showMessage("سيتم تفعيلها قريبًا"),
        borderRadius: BorderRadius.circular(999),
        child: Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.white.withOpacity(.08),
            border: Border.all(color: Colors.white.withOpacity(.22)),
          ),
          child: Icon(icon, color: Colors.white, size: 18),
        ),
      );
}

// ======================================================
// ✅ Painter يعمل الخلفية زي الصورة: لمعات + دوائر + خطوط خفيفة
// ======================================================
class _DoctorCarBackgroundPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    // Soft lime glows
    final glow = Paint()
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 70);

    glow.color = const Color(0xFFB8FF2C).withOpacity(.10);
    canvas.drawCircle(Offset(size.width * .18, size.height * .22), 170, glow);

    glow.color = const Color(0xFF6F962F).withOpacity(.10);
    canvas.drawCircle(Offset(size.width * .86, size.height * .28), 210, glow);

    glow.color = const Color(0xFF2D6B00).withOpacity(.08);
    canvas.drawCircle(Offset(size.width * .72, size.height * .86), 260, glow);

    // Subtle diagonal lines (texture)
    final linePaint = Paint()
      ..color = Colors.white.withOpacity(.035)
      ..strokeWidth = 1;

    final spacing = 18.0;
    for (double x = -size.height; x < size.width + size.height; x += spacing) {
      canvas.drawLine(
        Offset(x, 0),
        Offset(x + size.height, size.height),
        linePaint,
      );
    }

    // Dots (very subtle)
    final dotPaint = Paint()..color = Colors.white.withOpacity(.03);
    const double r = 1.2;
    for (int i = 0; i < 55; i++) {
      final dx = (size.width * 0.08) + (i * 11.0) % (size.width * 0.84);
      final dy = (size.height * 0.12) + ((i * 19.0) % (size.height * 0.76));
      canvas.drawCircle(Offset(dx, dy), r, dotPaint);
    }

    // A very soft top highlight (like glossy header)
    final rect = Rect.fromLTWH(0, 0, size.width, size.height * .28);
    final topGrad = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          Color(0x66FFFFFF),
          Color(0x00FFFFFF),
        ],
      ).createShader(rect);
    canvas.drawRect(rect, topGrad);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
