// PATH: lib/services/socket_service.dart
// ignore_for_file: unused_import

import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;

import '../config/api_config.dart';

enum SocketRole { user, technician }

typedef _ConnCb = void Function(bool connected);

class SocketService {
  // ===============================
  // 🧠 Singleton
  // ===============================
  static final SocketService _instance = SocketService._internal();
  factory SocketService() => _instance;
  SocketService._internal();

  IO.Socket? _socket;

  SocketRole? _role;
  String? _userId;
  String? _technicianId;
  String? _token;

  /// ✅ خليها true وقت التجارب
  bool debugLogs = true;

  bool get isConnected => _socket?.connected ?? false;

  // ✅ Queue: أي emit قبل الاتصال يتخزن ويتبعت أول ما نتصل
  final List<_PendingEmit> _pending = [];

  // ✅ Rooms cache for reconnect
  final Set<String> _joinedOrderRooms = <String>{};

  // ✅ throttle tech location emit
  DateTime _lastTechLocationEmit = DateTime.fromMillisecondsSinceEpoch(0);

  // ✅ listeners registry (multiple callbacks per event)
  final Map<String, Map<int, Function>> _listeners = {};
  int _listenerAutoId = 0;

  // ✅ connection listeners (multiple)
  final Map<int, _ConnCb> _connectionListeners = {};
  bool _connectionHooked = false;

  // ===============================
  // 🔌 Init
  // ===============================

  /// استخدمها في تطبيق المستخدم
  void initUser({required String userId}) {
    _role = SocketRole.user;
    _userId = userId;
    _technicianId = null;
    _token = null;
    _connect();
  }

  /// استخدمها في تطبيق الفني
  void initTechnician({required String technicianId, String? token}) {
    _role = SocketRole.technician;
    _technicianId = technicianId;
    _userId = null;
    _token = token;
    _connect();
  }

  // ===============================
  // CONNECT
  // ===============================
  void _connect() {
    // لو socket موجود بالفعل
    if (_socket != null) {
      if (!_socket!.connected) {
        _socket!.connect();
      } else {
        _emitPresence();
        _flushPending();
        _rejoinCachedRooms();
      }
      _hookConnectionEventsOnce();
      return;
    }

    final url = ApiConfig.socketUrl; // لازم ييجي من ApiConfig
    _log("🌐 socketUrl = $url");

    final opts = IO.OptionBuilder()
        // ✅ أهم حاجة: websocket أولاً (Cloudflare أحسن مع websocket)
        .setTransports(['websocket', 'polling'])
        .disableAutoConnect()
        .enableReconnection()
        .setReconnectionAttempts(999999)
        .setReconnectionDelay(700)
        .setTimeout(20000)
        .enableForceNew()
        .build();

    // Auth للفني
    if (_token != null && _token!.isNotEmpty) {
      opts['auth'] = {'token': _token};
    }

    _socket = IO.io(url, opts);

    _socket!.onConnect((_) {
      _log("✅ Socket connected: ${_socket!.id}");
      _emitPresence();
      _flushPending();
      _rejoinCachedRooms();
      _notifyConn(true);
    });

    _socket!.onReconnect((attempt) {
      _log("🟢 Socket reconnected (attempt=$attempt)");
      _emitPresence();
      _flushPending();
      _rejoinCachedRooms();
      _notifyConn(true);
    });

    _socket!.onDisconnect((_) {
      _log("🔴 Socket disconnected");
      _notifyConn(false);
    });

    _socket!.onConnectError((e) {
      _log("❌ Socket connect error: $e");
      _notifyConn(false);
    });

    _socket!.onError((e) {
      _log("❌ Socket error: $e");
      _notifyConn(false);
    });

    _hookConnectionEventsOnce();
    _socket!.connect();
  }

  void _hookConnectionEventsOnce() {
    if (_connectionHooked) return;
    _connectionHooked = true;
  }

  void _notifyConn(bool connected) {
    for (final cb in _connectionListeners.values) {
      try {
        cb(connected);
      } catch (e) {
        _log("⚠️ Connection listener error: $e");
      }
    }
  }

  void _emitPresence() {
    if (_socket == null || !_socket!.connected) return;

    if (_role == SocketRole.user && _userId != null) {
      _socket!.emit("user:online", {"userId": _userId});
      _log("👤 user:online emitted ($_userId)");
    }

    if (_role == SocketRole.technician && _technicianId != null) {
      _socket!.emit("technician:online", {"technicianId": _technicianId});
      _log("🛠️ technician:online emitted ($_technicianId)");
    }
  }

  // ===============================
  // ✅ Emit safe + Queue
  // ===============================
  void safeEmit(String event, dynamic data) {
    if (_socket == null) {
      _pending.add(_PendingEmit(event, data));
      _log("🕒 queued emit($event) socket=null");
      _connect();
      return;
    }

    if (!_socket!.connected) {
      _pending.add(_PendingEmit(event, data));
      _log("🕒 queued emit($event) not connected");
      _socket!.connect();
      return;
    }

    _socket!.emit(event, data);
  }

  /// ✅ emit with ack
  Future<T?> emitWithAck<T>(
    String event,
    dynamic data, {
    Duration timeout = const Duration(seconds: 6),
  }) async {
    final s = _socket;
    if (s == null || !s.connected) {
      safeEmit(event, data);
      return null;
    }

    final completer = Completer<T?>();
    Timer? t;

    t = Timer(timeout, () {
      if (!completer.isCompleted) completer.complete(null);
    });

    try {
      s.emitWithAck(event, data, ack: (res) {
        t?.cancel();
        if (!completer.isCompleted) {
          completer.complete(res as T?);
        }
      });
    } catch (_) {
      s.emit(event, data);
      t.cancel();
      if (!completer.isCompleted) completer.complete(null);
    }

    return completer.future;
  }

  void _flushPending() {
    if (_socket == null || !_socket!.connected) return;
    if (_pending.isEmpty) return;

    final copy = List<_PendingEmit>.from(_pending);
    _pending.clear();

    for (final p in copy) {
      _socket!.emit(p.event, p.data);
    }

    _log("✅ flushed pending emits: ${copy.length}");
  }

  // ===============================
  // 🔄 Connection status (Multi listeners)
  // ===============================
  int onConnectionChanged(_ConnCb cb) {
    final id = ++_listenerAutoId;
    _connectionListeners[id] = cb;
    cb(isConnected);
    return id;
  }

  void removeConnectionListener(int token) {
    _connectionListeners.remove(token);
  }

  // ===============================
  // ✅ Generic event subscription (multi listeners)
  // ===============================
  int onEvent(String event, void Function(dynamic data) cb) {
    final s = _socket;
    final id = ++_listenerAutoId;

    _listeners.putIfAbsent(event, () => {});
    _listeners[event]![id] = cb;

    if (s != null && _listeners[event]!.length == 1) {
      s.on(event, (data) {
        final map = _listeners[event];
        if (map == null) return;
        for (final fn in map.values) {
          try {
            fn(data);
          } catch (e) {
            _log("⚠️ listener($event) error: $e");
          }
        }
      });
    }

    return id;
  }

  void offEventByToken(String event, int token) {
    final map = _listeners[event];
    if (map == null) return;
    map.remove(token);
    if (map.isEmpty) {
      _listeners.remove(event);
    }
  }

  int onceEvent(String event, void Function(dynamic data) cb) {
    int token = 0;
    token = onEvent(event, (data) {
      cb(data);
      offEventByToken(event, token);
    });
    return token;
  }

  // ===============================
  // 🧹 تنظيف listeners (اختياري)
  // ===============================
  void clearSupportListeners() {
    _socket?.off("supportMessage:new");
    _socket?.off("supportMessage:ack");
    _socket?.off("supportChat:typing");
    _socket?.off("supportChat:read");
  }

  void clearOrderListeners() {
    _socket?.off("order:new");
    _socket?.off("order:accepted");
    _socket?.off("order:accept:failed");
    _socket?.off("orderStatusUpdated");
    _socket?.off("order:timeout");
    _socket?.off("order:canceled");
    _socket?.off("order:failed");
    _socket?.off("technicianLocationUpdate");

    _socket?.off("technician:online:ok");
    _socket?.off("joinOrderRoom:ok");
    _socket?.off("joinOrderRoom:error");
    _socket?.off("leaveOrderRoom:ok");
    _socket?.off("leaveOrderRoom:error");

    _socket?.off("order:match:status");
  }

  // ===============================
  // 📦 Orders (Technician)
  // ===============================
  void onNewOrder(void Function(Map<String, dynamic> order) cb) {
    _socket?.off("order:new");
    _socket?.on("order:new", (data) {
      if (data == null) return;
      if (data is Map) cb(Map<String, dynamic>.from(data));
    });
  }

  void acceptOrder(String orderId) {
    if (_technicianId == null) return;
    safeEmit("order:accept", {
      "orderId": orderId,
      "technicianId": _technicianId,
    });
  }

  void rejectOrder(String orderId) {
    if (_technicianId == null) return;
    safeEmit("order:reject", {
      "orderId": orderId,
      "technicianId": _technicianId,
    });
  }

  /// ✅ السيرفر مستني String
  void joinOrderRoom(String orderId) {
    if (orderId.trim().isEmpty) return;
    _joinedOrderRooms.add(orderId);
    safeEmit("joinOrderRoom", orderId);
  }

  void leaveOrderRoom(String orderId) {
    _joinedOrderRooms.remove(orderId);
    safeEmit("leaveOrderRoom", orderId);
  }

  // ✅ Cancel order (User side)
  void cancelOrder(String orderId) {
    safeEmit("order:cancel", {
      "orderId": orderId,
      if (_userId != null) "userId": _userId,
      "by": _role?.name ?? "unknown",
    });

    _log("🛑 cancelOrder emitted for $orderId");
  }

  void onOrderAccepted(void Function(Map<String, dynamic>) cb) {
    _socket?.off("order:accepted");
    _socket?.on("order:accepted", (data) {
      if (data == null) return;
      if (data is Map) cb(Map<String, dynamic>.from(data));
    });
  }

  void onOrderAcceptFailed(void Function(Map<String, dynamic>) cb) {
    _socket?.off("order:accept:failed");
    _socket?.on("order:accept:failed", (data) {
      if (data == null) return;
      if (data is Map) cb(Map<String, dynamic>.from(data));
    });
  }

  void onTechnicianOnlineOk(void Function(Map<String, dynamic>) cb) {
    _socket?.off("technician:online:ok");
    _socket?.on("technician:online:ok", (data) {
      if (data == null) return;
      if (data is Map) cb(Map<String, dynamic>.from(data));
    });
  }

  void onOrderStatusUpdated(
    void Function(String status, Map<String, dynamic> data) cb,
  ) {
    _socket?.off("orderStatusUpdated");
    _socket?.on("orderStatusUpdated", (data) {
      if (data == null) return;

      if (data is String) {
        cb(data, const {});
        return;
      }

      if (data is Map) {
        final m = Map<String, dynamic>.from(data);
        final status = (m["status"] ?? "").toString();
        cb(status, m);
        return;
      }

      _log("⚠️ orderStatusUpdated unknown payload: $data");
    });
  }

  void onTechnicianLocation(void Function(double lat, double lng) cb) {
    _socket?.off("technicianLocationUpdate");
    _socket?.on("technicianLocationUpdate", (data) {
      if (data == null || data is! Map) return;

      final m = Map<String, dynamic>.from(data);
      final loc = m["location"];
      if (loc is! Map) return;

      final lm = Map<String, dynamic>.from(loc);
      final lat = (lm["lat"] as num?)?.toDouble();
      final lng = (lm["lng"] as num?)?.toDouble();
      if (lat == null || lng == null) return;

      cb(lat, lng);
    });
  }

  // ===============================
  // ✅ Matching
  // ===============================
  void requestBestMatch({
    required String orderId,
    required double lat,
    required double lng,
    required String serviceType,
    required List<String> selectedServices,
  }) {
    safeEmit("order:match:best", {
      "orderId": orderId,
      "userId": _userId,
      "serviceType": serviceType,
      "selectedServices": selectedServices,
      "location": {"lat": lat, "lng": lng},
      "ts": DateTime.now().toIso8601String(),
    });
  }

  void onMatchStatus(void Function(Map<String, dynamic> data) cb) {
    _socket?.off("order:match:status");
    _socket?.on("order:match:status", (data) {
      if (data == null) return;
      if (data is Map) cb(Map<String, dynamic>.from(data));
    });
  }

  // ===============================
  // 📍 Technician live location
  // ===============================
  void emitTechnicianLocation({
    required double lat,
    required double lng,
    String? orderId,
    Duration throttle = const Duration(milliseconds: 800),
    String eventName = "technician:location:update",
  }) {
    if (_role != SocketRole.technician) return;

    final now = DateTime.now();
    if (now.difference(_lastTechLocationEmit) < throttle) return;
    _lastTechLocationEmit = now;

    safeEmit(eventName, {
      "technicianId": _technicianId,
      if (orderId != null) "orderId": orderId,
      "location": {"lat": lat, "lng": lng},
      "ts": now.toIso8601String(),
    });
  }

  // ===============================
  // 💬 Support Chat
  // ===============================
  void joinSupportChat(String chatId) {
    safeEmit("joinSupportChat", {"chatId": chatId});
  }

  void leaveSupportChat(String chatId) {
    safeEmit("leaveSupportChat", {"chatId": chatId});
  }

  void sendSupportMessage({
    required String chatId,
    required String text,
    required String senderType,
    String? senderId,
    String? clientTempId,
  }) {
    safeEmit("supportMessage:send", {
      "chatId": chatId,
      "text": text,
      "senderType": senderType,
      if (senderId != null) "senderId": senderId,
      if (clientTempId != null) "clientTempId": clientTempId,
    });
  }

  void onSupportMessage(void Function(Map<String, dynamic>) cb) {
    _socket?.off("supportMessage:new");
    _socket?.on("supportMessage:new", (data) {
      if (data == null) return;
      if (data is Map) cb(Map<String, dynamic>.from(data));
    });
  }

  void onSupportAck(void Function(Map<String, dynamic>) cb) {
    _socket?.off("supportMessage:ack");
    _socket?.on("supportMessage:ack", (data) {
      if (data == null) return;
      if (data is Map) cb(Map<String, dynamic>.from(data));
    });
  }

  void emitSupportTyping({
    required String chatId,
    required bool typing,
    required String senderType,
  }) {
    safeEmit("supportChat:typing", {
      "chatId": chatId,
      "typing": typing,
      "senderType": senderType,
    });
  }

  void onSupportTyping(void Function(Map<String, dynamic>) cb) {
    _socket?.off("supportChat:typing");
    _socket?.on("supportChat:typing", (data) {
      if (data == null) return;
      if (data is Map) cb(Map<String, dynamic>.from(data));
    });
  }

  void emitSupportRead({
    required String chatId,
    required String readerType,
  }) {
    safeEmit("supportChat:read", {"chatId": chatId, "readerType": readerType});
  }

  // ===============================
  // ✅ Rejoin rooms after reconnect
  // ===============================
  void _rejoinCachedRooms() {
    if (_socket == null || !_socket!.connected) return;
    if (_joinedOrderRooms.isEmpty) return;

    for (final orderId in _joinedOrderRooms) {
      _socket!.emit("joinOrderRoom", orderId);
    }

    _log("🔁 rejoined order rooms: ${_joinedOrderRooms.length}");
  }

  // ===============================
  // 🔌 Disconnect / Dispose
  // ===============================
  void disconnect() {
    try {
      _socket?.clearListeners();
      _socket?.disconnect();
      _socket?.dispose();
    } catch (_) {}

    _socket = null;
    _role = null;
    _userId = null;
    _technicianId = null;
    _token = null;

    _pending.clear();
    _joinedOrderRooms.clear();

    _listeners.clear();
    _connectionListeners.clear();
    _connectionHooked = false;
  }

  void dispose() => disconnect();

  void _log(String msg) {
    if (!debugLogs) return;
    if (kDebugMode) debugPrint(msg);
  }
}

class _PendingEmit {
  final String event;
  final dynamic data;
  _PendingEmit(this.event, this.data);
}
