// ignore: unused_import
import 'package:flutter/foundation.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

class ApiConfig {
  ApiConfig._();

  // ======================================================
  // 🌍 ENV HELPERS
  // ======================================================

  static String _clean(String url) {
    if (url.endsWith("/")) {
      return url.substring(0, url.length - 1);
    }
    return url;
  }

  static String? _getEnv(String key) {
    final value = dotenv.env[key];
    if (value == null) return null;
    final trimmed = value.trim();
    return trimmed.isEmpty ? null : trimmed;
  }

  static bool get isProduction =>
      (_getEnv("NODE_ENV") ?? "").toLowerCase() == "production";

  // ======================================================
  // 🌐 BACKEND BASE URL
  // ======================================================

  /// يدعم:
  /// API_BASE_URL
  /// BASE_URL
  static String get baseUrl {
    final fromEnv = _getEnv("API_BASE_URL") ?? _getEnv("BASE_URL");

    if (fromEnv != null) {
      return _clean(fromEnv);
    }

    // fallback local network
    const local = "http://192.168.1.12:5555";
    return local;
  }

  /// كل REST endpoints تبدأ من هنا
  static String get apiBase => "$baseUrl/api";

  /// Socket ممكن يبقى مختلف لو حابب
  static String get socketUrl {
    final socketOverride = _getEnv("SOCKET_URL");
    if (socketOverride != null) {
      return _clean(socketOverride);
    }
    return baseUrl;
  }

  static const Duration requestTimeout = Duration(seconds: 20);

  static Map<String, String> jsonHeaders({String? token}) => {
        "Content-Type": "application/json",
        "Accept": "application/json",
        if (token != null && token.isNotEmpty) "Authorization": "Bearer $token",
      };

  // ======================================================
  // 🔐 AUTH
  // ======================================================

  static String get userLogin => "$apiBase/users/login";
  static String get technicianLogin => "$apiBase/technicians/login";

  // ======================================================
  // 🚕 ORDERS
  // ======================================================

  static String get orders => "$apiBase/orders";
  static String get createOrder => "$apiBase/orders";
  static String orderById(String id) => "$apiBase/orders/$id";
  static String cancelOrder(String id) => "$apiBase/orders/$id/cancel";

  // ======================================================
  // 👨‍🔧 TECHNICIANS
  // ======================================================

  static String get technicians => "$apiBase/technicians";

  // ======================================================
  // 🏪 CENTERS
  // ======================================================

  static String get centers => "$apiBase/centers";

  static String nearbyCenters({
    required double lat,
    required double lng,
    int limit = 20,
    int maxDistanceMeters = 50000,
    String? governorate,
    String? city,
  }) {
    final l = limit.clamp(1, 50);
    final md = maxDistanceMeters.clamp(1000, 200000);

    final qp = <String, String>{
      "lat": lat.toString(),
      "lng": lng.toString(),
      "limit": l.toString(),
      "maxDistance": md.toString(),
    };

    if (governorate != null && governorate.trim().isNotEmpty) {
      qp["governorate"] = governorate.trim();
    }
    if (city != null && city.trim().isNotEmpty) {
      qp["city"] = city.trim();
    }

    return Uri.parse("$apiBase/centers/nearby")
        .replace(queryParameters: qp)
        .toString();
  }

  // ======================================================
  // 💬 SUPPORT CHAT
  // ======================================================

  static String get support => "$apiBase/support";
  static String get supportChats => "$apiBase/support/chats";
  static String supportMessages(String chatId) =>
      "$apiBase/support/chats/$chatId/messages";

  // ======================================================
  // 💳 PAYMENTS
  // ======================================================

  static String get payments => "$apiBase/payments";

  // ======================================================
  // ⭐ FEEDBACK
  // ======================================================

  static String get feedback => "$apiBase/feedback";

  // ======================================================
  // 🗺️ MAPS VIA BACKEND
  // ======================================================

  static String mapsAutocomplete(String input, {String lang = "ar"}) {
    final qp = {"input": input.trim(), "lang": lang};
    return Uri.parse("$apiBase/maps/autocomplete")
        .replace(queryParameters: qp)
        .toString();
  }

  static String mapsPlaceDetails(String placeId, {String lang = "ar"}) {
    final qp = {"placeId": placeId.trim(), "lang": lang};
    return Uri.parse("$apiBase/maps/place-details")
        .replace(queryParameters: qp)
        .toString();
  }

  static String mapsReverseGeocode({
    required double lat,
    required double lng,
    String lang = "ar",
  }) {
    final qp = {"lat": "$lat", "lng": "$lng", "lang": lang};
    return Uri.parse("$apiBase/maps/reverse-geocode")
        .replace(queryParameters: qp)
        .toString();
  }

  static String mapsDirections({
    required double fromLat,
    required double fromLng,
    required double toLat,
    required double toLng,
  }) {
    final qp = {
      "fromLat": "$fromLat",
      "fromLng": "$fromLng",
      "toLat": "$toLat",
      "toLng": "$toLng",
    };

    return Uri.parse("$apiBase/maps/directions")
        .replace(queryParameters: qp)
        .toString();
  }
}
