import 'package:doctor_car_app/screens/orders/orders_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart'; // kIsWeb
import 'package:easy_localization/easy_localization.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

import 'package:provider/provider.dart';

import 'package:doctor_car_app/screens/splash_screen.dart';
import 'package:doctor_car_app/screens/login_screen.dart';
import 'package:doctor_car_app/screens/home_screen.dart';
import 'package:doctor_car_app/screens/road_services_screen.dart';
import 'package:doctor_car_app/screens/SignUp_Screen.dart';
import 'package:doctor_car_app/screens/vehicles/vehicle_screen.dart';
import 'package:doctor_car_app/screens/smart_accident_screen.dart';
import 'package:doctor_car_app/screens/settings_screen.dart';
import 'package:doctor_car_app/screens/auth/forgot_password_screen.dart';
import 'package:doctor_car_app/screens/role_selection_screen.dart';

// ✅ الفني (المسار النهائي الوحيد)
import 'package:doctor_car_app/screens/driver/incoming_request_screen.dart';

// ✅ Conditional import (Web vs Non-web)
import 'web/google_maps_loader_stub.dart'
    if (dart.library.html) 'web/google_maps_loader_web.dart';

/// ✅ Orders Store
import 'package:doctor_car_app/services/orders/orders_store.dart';

const String kGoogleMapsApiKey = "AIzaSyD9BGSScE-DU9nbdFgIbJV4fbNspNdPg_M";

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await EasyLocalization.ensureInitialized();

  // ✅ Load .env
  try {
    await dotenv.load(fileName: ".env");
  } catch (e) {
    debugPrint("⚠️ dotenv load failed: $e");
  }

  // ✅ Google Maps JS for Web
  if (kIsWeb) {
    await loadGoogleMapsJS(kGoogleMapsApiKey);
  }

  // ✅ IMPORTANT: init OrdersStore BEFORE runApp
  final ordersStore = OrdersStore();
  await ordersStore.init(); // ✅ هنا الفرق الأساسي

  runApp(
    EasyLocalization(
      supportedLocales: const [Locale('ar'), Locale('en')],
      path: 'assets/translations',
      fallbackLocale: const Locale('ar'),
      saveLocale: true,
      child: MultiProvider(
        providers: [
          // ✅ provide the READY store (not creating new one)
          ChangeNotifierProvider<OrdersStore>.value(value: ordersStore),
        ],
        child: const DoctorCarApp(),
      ),
    ),
  );
}

class DoctorCarApp extends StatelessWidget {
  const DoctorCarApp({super.key});

  static const Color brandPrimary = Color(0xFF1F4BA5);

  ThemeData _buildLightTheme() {
    final base = ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: brandPrimary),
    );

    return base.copyWith(
      textTheme: GoogleFonts.cairoTextTheme(base.textTheme),
      scaffoldBackgroundColor: const Color(0xffF5F6FA),
      appBarTheme: AppBarTheme(
        elevation: 0,
        centerTitle: true,
        backgroundColor: Colors.transparent,
        titleTextStyle: GoogleFonts.cairo(
          fontSize: 18,
          fontWeight: FontWeight.w800,
          color: const Color(0xff111827),
        ),
        iconTheme: const IconThemeData(color: Color(0xff111827)),
      ),
    );
  }

  ThemeData _buildDarkTheme() {
    final base = ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      colorScheme: ColorScheme.fromSeed(
        seedColor: brandPrimary,
        brightness: Brightness.dark,
      ),
    );

    return base.copyWith(
      textTheme: GoogleFonts.cairoTextTheme(base.textTheme),
      scaffoldBackgroundColor: const Color(0xff0E1320),
      appBarTheme: AppBarTheme(
        elevation: 0,
        centerTitle: true,
        backgroundColor: Colors.transparent,
        titleTextStyle: GoogleFonts.cairo(
          fontSize: 18,
          fontWeight: FontWeight.w800,
          color: Colors.white,
        ),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Doctor Car',
      theme: _buildLightTheme(),
      darkTheme: _buildDarkTheme(),
      themeMode: ThemeMode.system,

      // Localization
      localizationsDelegates: context.localizationDelegates,
      supportedLocales: context.supportedLocales,
      locale: context.locale,

      home: const SplashScreen(),

      routes: {
        '/login': (_) => const LoginScreen(),
        '/home': (_) => const HomeScreen(),
        '/road': (_) => const RoadServicesScreen(),
        '/signup': (_) => const SignUpScreen(),
        '/vehicle': (_) => const VehiclesScreen(),
        '/smart-accident': (_) => const SmartAccidentScreen(),
        '/settings': (_) => const SettingsScreen(),
        '/forgot-password': (_) => const ForgotPasswordScreen(),
        '/role': (_) => const RoleSelectionScreen(),
        '/orders': (_) => const OrdersScreen(),
      },

      onGenerateRoute: (settings) {
        if (settings.name == '/driver-home') {
          final args = settings.arguments as Map<String, dynamic>?;

          final token = (args?['token'] ?? '').toString();
          final id = (args?['id'] ?? '').toString();

          return MaterialPageRoute(
            builder: (_) => IncomingRequestScreen(
              technicianToken: token,
              technicianId: id,
            ),
          );
        }
        return null;
      },
    );
  }
}
