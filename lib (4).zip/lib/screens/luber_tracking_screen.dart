// ignore_for_file: depend_on_referenced_packages, use_build_context_synchronously

import 'dart:ui';
import 'package:doctor_car_app/screens/payment/paymob_checkout_screen.dart';
import 'package:doctor_car_app/screens/feedback_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import '../config/api_config.dart';
import '../services/paymob_service.dart';

class UberTrackingScreen extends StatefulWidget {
  final String orderId;
  final String userId;
  final String serviceType;
  final List<String> selectedServices;

  const UberTrackingScreen({
    super.key,
    required this.orderId,
    required this.userId,
    required this.serviceType,
    required this.selectedServices,
  });

  @override
  State<UberTrackingScreen> createState() => _UberTrackingScreenState();
}

class _UberTrackingScreenState extends State<UberTrackingScreen>
    with TickerProviderStateMixin {
  final MapController _map = MapController();
  IO.Socket? socket;

  LatLng userLocation = const LatLng(31.416, 31.813);
  LatLng? driverLocation;

  String orderStatus = "pending";

  String driverName = "محمد إبراهيم";
  String driverCar = "هيونداي النترا";
  String driverPlate = "ط ن د 3214";
  double driverRating = 4.9;
  int eta = 8;

  bool paying = false;

  late AnimationController sheetCtrl;

  @override
  void initState() {
    super.initState();

    sheetCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    )..forward();

    _connectSocket();
  }

  // ================= SOCKET =================
  void _connectSocket() {
    socket = IO.io(
      ApiConfig.baseUrl,
      {
        "transports": ["websocket"],
        "autoConnect": true,
      },
    );

    socket!.onConnect((_) {
      socket!.emit("joinOrderRoom", widget.orderId);
    });

    socket!.on("driverLocationUpdate", (data) {
      setState(() {
        driverLocation = LatLng(
          (data["lat"] as num).toDouble(),
          (data["lng"] as num).toDouble(),
        );
      });
    });

    socket!.on("orderStatusUpdated", (data) async {
      orderStatus = data["status"];

      if (orderStatus == "assigned") {
        driverName = data["driver"]["name"];
        driverCar = data["driver"]["carModel"];
        driverPlate = data["driver"]["plate"];
        eta = data["driver"]["eta"];
      }

      if (orderStatus == "completed") {
        await Future.delayed(const Duration(seconds: 1));
        selectPaymentMethod(); // فتح الدفع تلقائيًا
      }

      setState(() {});
    });
  }

  // ================= CALL =================
  Future<void> callDriver() async {
    final Uri uri = Uri(scheme: "tel", path: "01275649151");
    await launchUrl(uri);
  }

  // ================= WHATSAPP =================
  Future<void> whatsappDriver() async {
    final Uri uri = Uri.parse("https://wa.me/201275649151");
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  // ========================= PAYMENT OPTIONS SHEET =========================
  Future<void> selectPaymentMethod() async {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.black87,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
      ),
      builder: (_) {
        return Padding(
          padding: const EdgeInsets.all(22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 55,
                height: 5,
                decoration: BoxDecoration(
                  color: Colors.grey.shade500,
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                "اختر طريقة الدفع",
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                    color: Colors.white),
              ),
              const SizedBox(height: 25),
              paymentOption(
                title: "💳 فيزا / ماستركارد",
                subtitle: "الدفع باستخدام البطاقة البنكية",
                method: "card",
              ),
              paymentOption(
                title: "📱 محافظ موبايل (Orange Cash)",
                subtitle: "Vodafone – Orange – Etisalat Wallet",
                method: "wallet",
              ),
              paymentOption(
                title: "🏧 فوري",
                subtitle: "الدفع عبر أقرب ماكينة فوري",
                method: "kiosk",
              ),
              const SizedBox(height: 10),
            ],
          ),
        );
      },
    );
  }

  Widget paymentOption({
    required String title,
    required String subtitle,
    required String method,
  }) {
    return GestureDetector(
      onTap: () {
        Navigator.pop(context);
        openPayment(method: method);
      },
      child: Container(
        padding: const EdgeInsets.all(16),
        margin: const EdgeInsets.only(bottom: 14),
        decoration: BoxDecoration(
          color: Colors.white12,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.white24),
        ),
        child: Row(
          children: [
            const Icon(Icons.payments, size: 32, color: Colors.amber),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 16)),
                Text(subtitle,
                    style:
                        TextStyle(color: Colors.grey.shade300, fontSize: 13)),
              ],
            )
          ],
        ),
      ),
    );
  }

  // ================= PAYMENT =================
  Future<void> openPayment({String method = "card"}) async {
    if (paying) return;
    setState(() => paying = true);

    try {
      const amount = 150;

      // 1) إنشاء Order
      final order = await PaymobService.createOrder(amount);
      if (order == null || order["success"] != true) {
        setState(() => paying = false);
        return;
      }

      final paymobOrderId = order["orderId"];

      // 2) الحصول على Payment Key
      final key = await PaymobService.getPaymentKey(
        amount: amount,
        orderId: paymobOrderId,
        method: method,
      );

      if (key == null || key["success"] != true) {
        setState(() => paying = false);
        return;
      }

      final iframeUrl = key["iframe"];

      // 3) الانتقال لصفحة الدفع
      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => PaymobCheckoutScreen(
            iframeUrl: iframeUrl,
            orderId: widget.orderId,
            amount: amount,
          ),
        ),
      );

      // 4) تقييم العميل بعد الدفع
      openRating();
    } catch (e) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text("خطأ أثناء الدفع: $e")));
    }

    setState(() => paying = false);
  }

  void openRating() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => FeedbackScreen(
          orderId: widget.orderId,
          userId: widget.userId,
        ),
      ),
    );
  }

  // ================= STATUS TEXT =================
  String statusText() {
    switch (orderStatus) {
      case "assigned":
        return "🚗 السائق في الطريق — يصل خلال $eta دقيقة";
      case "in_progress":
        return "🔧 جاري تنفيذ خدمتك الآن";
      case "completed":
        return "✔ الخدمة انتهت — سيتم تحويلك للدفع";
      default:
        return "⌛ جاري البحث عن أقرب فني…";
    }
  }

  // ================= UI =================
  @override
  Widget build(BuildContext context) {
    final markers = <Marker>[
      Marker(
        point: userLocation,
        child:
            const Icon(Icons.person_pin_circle, color: Colors.blue, size: 45),
      ),
    ];

    if (driverLocation != null) {
      markers.add(
        Marker(
          point: driverLocation!,
          child: const Icon(Icons.local_taxi, color: Colors.amber, size: 40),
        ),
      );
    }

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          FlutterMap(
            mapController: _map,
            options: MapOptions(
              initialCenter: userLocation,
              initialZoom: 14,
            ),
            children: [
              TileLayer(
                urlTemplate: "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
              ),
              MarkerLayer(markers: markers),
            ],
          ),
          buildUberSheet(),
        ],
      ),
    );
  }

  // ================= UBER SHEET =================
  Widget buildUberSheet() {
    return Align(
      alignment: Alignment.bottomCenter,
      child: FadeTransition(
        opacity: sheetCtrl,
        child: SlideTransition(
          position: Tween(begin: const Offset(0, 1), end: Offset.zero).animate(
            CurvedAnimation(parent: sheetCtrl, curve: Curves.easeOutExpo),
          ),
          child: Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.85),
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(28)),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 60,
                  height: 5,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade600,
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.white12,
                      ),
                      child: const Icon(Icons.local_taxi,
                          size: 30, color: Colors.amber),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        statusText(),
                        style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.white),
                      ),
                    )
                  ],
                ),
                const SizedBox(height: 20),
                driverInfoUI(),
                const SizedBox(height: 22),
                Row(
                  children: [
                    Expanded(child: actionBtn("اتصال", Icons.call, callDriver)),
                    const SizedBox(width: 14),
                    Expanded(child: whatsappBtn()),
                  ],
                ),
                const SizedBox(height: 22),
                ElevatedButton(
                  onPressed: () => selectPaymentMethod(),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.redAccent,
                    minimumSize: const Size(double.infinity, 56),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14)),
                  ),
                  child: const Text(
                    "إنهاء الخدمة (الدفع)",
                    style: TextStyle(fontSize: 18, color: Colors.white),
                  ),
                ),
                const SizedBox(height: 14),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget driverInfoUI() {
    return Row(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: Image.asset(
            "assets/images/driver.png",
            width: 70,
            height: 70,
            fit: BoxFit.cover,
          ),
        ),
        const SizedBox(width: 14),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(driverName,
                style: const TextStyle(
                    fontSize: 18,
                    color: Colors.white,
                    fontWeight: FontWeight.bold)),
            Text(driverCar,
                style: TextStyle(fontSize: 15, color: Colors.grey.shade400)),
            Text(driverPlate,
                style: TextStyle(fontSize: 14, color: Colors.grey.shade500)),
            Row(
              children: [
                Icon(Icons.star, color: Colors.amber.shade400, size: 18),
                Text(" ${driverRating.toStringAsFixed(1)}",
                    style: const TextStyle(color: Colors.white)),
              ],
            )
          ],
        )
      ],
    );
  }

  Widget actionBtn(String title, IconData icon, VoidCallback onTap) {
    return ElevatedButton.icon(
      onPressed: onTap,
      icon: Icon(icon, color: Colors.black),
      label: Text(title,
          style: const TextStyle(color: Colors.black, fontSize: 16)),
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.amber,
        minimumSize: const Size(double.infinity, 54),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
    );
  }

  Widget whatsappBtn() {
    return ElevatedButton.icon(
      onPressed: whatsappDriver,
      icon: const FaIcon(FontAwesomeIcons.whatsapp, color: Colors.white),
      label: const Text("واتساب",
          style: TextStyle(color: Colors.white, fontSize: 16)),
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.green.shade600,
        minimumSize: const Size(double.infinity, 54),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
    );
  }
}
