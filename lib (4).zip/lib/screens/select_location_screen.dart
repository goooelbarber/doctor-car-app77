// ignore: unused_import
import 'package:doctor_car_app/screens/luber_tracking_screen.dart';

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

class SelectLocationScreen extends StatefulWidget {
  final String serviceType;
  final String userId;
  final List<String> selectedServices;

  const SelectLocationScreen({
    super.key,
    required this.serviceType,
    required this.userId,
    required this.selectedServices,
  });

  @override
  State<SelectLocationScreen> createState() => _SelectLocationScreenState();
}

class _SelectLocationScreenState extends State<SelectLocationScreen> {
  final MapController map = MapController();
  LatLng selectedLocation = const LatLng(31.4175, 31.8153); // موقع ثابت للـ Web

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
        title: const Text("تحديد الموقع"),
        centerTitle: true,
      ),
      body: Stack(
        children: [
          /// MAP
          FlutterMap(
            mapController: map,
            options: MapOptions(
              initialCenter: selectedLocation,
              initialZoom: 15,
              onTap: (tapPos, point) {
                setState(() => selectedLocation = point);
              },
            ),
            children: [
              TileLayer(
                urlTemplate: "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
              ),
              MarkerLayer(
                markers: [
                  Marker(
                    point: selectedLocation,
                    child: const Icon(Icons.location_pin,
                        color: Colors.red, size: 45),
                  ),
                ],
              )
            ],
          ),

          Positioned(
            bottom: 20,
            left: 20,
            right: 20,
            child: ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => UberTrackingScreen(
                      orderId: "ORDER_${DateTime.now().millisecondsSinceEpoch}",
                      userId: widget.userId,
                      serviceType: widget.serviceType,
                      selectedServices: widget.selectedServices,
                    ),
                  ),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.amber,
                foregroundColor: Colors.black,
                padding: const EdgeInsets.symmetric(vertical: 18),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
              ),
              child: const Text(
                "تأكيد الموقع",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
            ),
          )
        ],
      ),
    );
  }
}
