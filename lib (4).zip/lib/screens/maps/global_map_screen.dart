import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;

class GlobalMapScreen extends StatefulWidget {
  const GlobalMapScreen({super.key});

  @override
  State<GlobalMapScreen> createState() => _GlobalMapScreenState();
}

class _GlobalMapScreenState extends State<GlobalMapScreen> {
  final MapController _mapController = MapController();
  LatLng _center = const LatLng(26.8206, 30.8025); // 🇪🇬 مصر مبدئيًا
  LatLng? _userLocation;
  final TextEditingController _searchController = TextEditingController();
  bool _loadingLocation = false;

  @override
  void initState() {
    super.initState();
    _getCurrentLocation();
  }

  /// 📍 جلب موقع المستخدم الحالي
  Future<void> _getCurrentLocation() async {
    setState(() => _loadingLocation = true);

    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        await Geolocator.openLocationSettings();
        return;
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.deniedForever) return;

      final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );

      setState(() {
        _userLocation = LatLng(pos.latitude, pos.longitude);
        _center = _userLocation!;
        _loadingLocation = false;
      });

      _mapController.move(_center, 12);
    } catch (e) {
      debugPrint("⚠️ Error getting location: $e");
      setState(() => _loadingLocation = false);
    }
  }

  /// 🔍 البحث عن مكان باستخدام OpenStreetMap (Nominatim API)
  Future<void> _searchPlace(String query) async {
    if (query.isEmpty) return;
    try {
      final url =
          "https://nominatim.openstreetmap.org/search?q=$query&format=json&limit=1";
      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data.isNotEmpty) {
          final lat = double.parse(data[0]['lat']);
          final lon = double.parse(data[0]['lon']);
          final newLocation = LatLng(lat, lon);

          setState(() {
            _center = newLocation;
          });

          _mapController.move(newLocation, 13);
        } else {
          // ignore: use_build_context_synchronously
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text("لم يتم العثور على المكان المطلوب"),
            backgroundColor: Colors.redAccent,
          ));
        }
      }
    } catch (e) {
      debugPrint("❌ Error searching: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("الخريطة العالمية 🌍"),
        backgroundColor: Colors.blue.shade800,
        actions: [
          IconButton(
            icon: const Icon(Icons.my_location),
            onPressed: _getCurrentLocation,
          ),
        ],
      ),
      body: Stack(
        children: [
          FlutterMap(
            mapController: _mapController,
            options: MapOptions(
              initialCenter: _center,
              initialZoom: 6,
            ),
            children: [
              TileLayer(
                urlTemplate:
                    "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
                subdomains: const ['a', 'b', 'c'],
                userAgentPackageName: 'com.example.doctor_car',
              ),
              MarkerLayer(
                markers: [
                  if (_userLocation != null)
                    Marker(
                      point: _userLocation!,
                      child: const Icon(Icons.location_on,
                          color: Colors.red, size: 35),
                    ),
                ],
              ),
            ],
          ),

          // 🔍 مربع البحث العلوي
          Positioned(
            top: 15,
            left: 15,
            right: 15,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(30),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.15),
                    blurRadius: 8,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: TextField(
                controller: _searchController,
                textAlign: TextAlign.right,
                decoration: InputDecoration(
                  hintText: "ابحث عن دولة أو مدينة...",
                  border: InputBorder.none,
                  suffixIcon: IconButton(
                    icon: const Icon(Icons.search, color: Colors.blueAccent),
                    onPressed: () =>
                        _searchPlace(_searchController.text.trim()),
                  ),
                ),
                onSubmitted: (value) => _searchPlace(value.trim()),
              ),
            ),
          ),

          // ⏳ مؤشر التحميل عند البحث أو تحديد الموقع
          if (_loadingLocation)
            const Center(
              child: CircularProgressIndicator(color: Colors.blue),
            ),
        ],
      ),
    );
  }
}
