import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:http/http.dart' as http;
import 'package:geolocator/geolocator.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;

class TechnicianMapScreen extends StatefulWidget {
  const TechnicianMapScreen({super.key});

  @override
  State<TechnicianMapScreen> createState() => _TechnicianMapScreenState();
}

class _TechnicianMapScreenState extends State<TechnicianMapScreen> {
  final MapController _mapController = MapController();
  LatLng _center = LatLng(30.0444, 31.2357); // 🇪🇬 القاهرة افتراضيًا
  LatLng? _userLocation;
  final TextEditingController _searchController = TextEditingController();
  bool _loading = false;
  List<dynamic> _technicians = [];

  IO.Socket? _socket;
  Map<String, LatLng> _technicianPositions = {}; // 🗺️ لحفظ مواقع الفنيين

  @override
  void initState() {
    super.initState();
    _initMap();
    _connectSocket();
  }

  @override
  void dispose() {
    _socket?.dispose();
    super.dispose();
  }

  /// 📡 الاتصال بـ Socket.IO
  void _connectSocket() {
    _socket = IO.io(
      "http://10.0.2.2:5000", // 🔹 غيّرها لـ IP جهازك إنك على موبايل حقيقي
      IO.OptionBuilder().setTransports(['websocket']).build(),
    );

    _socket!.onConnect((_) {
      debugPrint("✅ متصل بالسيرفر عبر Socket.IO");
    });

    _socket!.on("locationUpdate", (data) {
      // 📍 تحديث موقع الفني على الخريطة
      if (data["id"] != null && data["lat"] != null && data["lng"] != null) {
        setState(() {
          _technicianPositions[data["id"]] =
              LatLng(data["lat"].toDouble(), data["lng"].toDouble());
        });
      }
    });

    _socket!.onDisconnect((_) {
      debugPrint("❌ تم قطع الاتصال بـ Socket.IO");
    });
  }

  /// 🧭 تهيئة الخريطة والموقع
  Future<void> _initMap() async {
    await _getUserLocation();
    await _getTechnicians();
  }

  /// 📍 تحديد موقع المستخدم الحالي
  Future<void> _getUserLocation() async {
    setState(() => _loading = true);

    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        await Geolocator.openLocationSettings();
        return;
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }

      if (permission == LocationPermission.deniedForever) return;

      final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );

      setState(() {
        _userLocation = LatLng(pos.latitude, pos.longitude);
        _center = _userLocation!;
      });

      _mapController.move(_center, 13);
    } catch (e) {
      debugPrint("❌ Error getting location: $e");
    }

    setState(() => _loading = false);
  }

  /// 🌍 جلب الفنيين من السيرفر
  Future<void> _getTechnicians() async {
    try {
      const String apiUrl = "http://10.0.2.2:5000/api/technicians";
      final response = await http.get(Uri.parse(apiUrl));

      if (response.statusCode == 200) {
        final List<dynamic> data = jsonDecode(response.body);
        setState(() {
          _technicians = data;
        });
      } else {
        debugPrint("⚠️ فشل جلب الفنيين: ${response.statusCode}");
      }
    } catch (e) {
      debugPrint("❌ خطأ أثناء تحميل الفنيين: $e");
    }
  }

  /// 🔍 البحث عن مكان
  Future<void> _searchPlace(String query) async {
    if (query.isEmpty) return;
    setState(() => _loading = true);

    try {
      final url =
          "https://nominatim.openstreetmap.org/search?q=$query&format=json&limit=1";
      final res = await http.get(Uri.parse(url));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data.isNotEmpty) {
          final lat = double.parse(data[0]['lat']);
          final lon = double.parse(data[0]['lon']);
          final newLoc = LatLng(lat, lon);
          setState(() {
            _center = newLoc;
          });
          _mapController.move(newLoc, 13);
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text("لم يتم العثور على المكان المطلوب"),
              backgroundColor: Colors.redAccent,
            ),
          );
        }
      }
    } catch (e) {
      debugPrint("⚠️ Search error: $e");
    }

    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("تتبع الفنيين مباشرة 🔧"),
        backgroundColor: Colors.blue.shade800,
        actions: [
          IconButton(
            icon: const Icon(Icons.my_location),
            onPressed: _getUserLocation,
          ),
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _getTechnicians,
          ),
        ],
      ),
      body: Stack(
        children: [
          FlutterMap(
            mapController: _mapController,
            options: MapOptions(
              initialCenter: _center,
              initialZoom: 7,
              minZoom: 3,
              maxZoom: 18,
            ),
            children: [
              TileLayer(
                urlTemplate:
                    "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
                subdomains: const ['a', 'b', 'c'],
              ),

              // 🟢 موقع المستخدم
              if (_userLocation != null)
                MarkerLayer(
                  markers: [
                    Marker(
                      point: _userLocation!,
                      child: const Icon(Icons.person_pin_circle,
                          color: Colors.green, size: 40),
                    ),
                  ],
                ),

              // 🟠 الفنيين الثابتين من السيرفر
              MarkerLayer(
                markers: _technicians.map((tech) {
                  return Marker(
                    point: LatLng(tech['lat'], tech['lng']),
                    width: 50,
                    height: 50,
                    child: const Icon(Icons.build_circle,
                        color: Colors.orange, size: 35),
                  );
                }).toList(),
              ),

              // 🔵 الفنيين المتحركين (تحديث مباشر من Socket)
              MarkerLayer(
                markers: _technicianPositions.entries.map((entry) {
                  return Marker(
                    point: entry.value,
                    width: 50,
                    height: 50,
                    child: const Icon(Icons.directions_car,
                        color: Colors.blue, size: 35),
                  );
                }).toList(),
              ),
            ],
          ),

          // 🔍 البحث عن مكان
          Positioned(
            top: 15,
            left: 15,
            right: 15,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(30),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.15),
                    blurRadius: 8,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: TextField(
                controller: _searchController,
                textAlign: TextAlign.right,
                decoration: InputDecoration(
                  hintText: "ابحث عن مكان...",
                  border: InputBorder.none,
                  suffixIcon: IconButton(
                    icon: const Icon(Icons.search, color: Colors.blueAccent),
                    onPressed: () =>
                        _searchPlace(_searchController.text.trim()),
                  ),
                ),
                onSubmitted: (value) => _searchPlace(value.trim()),
              ),
            ),
          ),

          if (_loading)
            const Center(
              child: CircularProgressIndicator(color: Colors.blue),
            ),
        ],
      ),
    );
  }
}
