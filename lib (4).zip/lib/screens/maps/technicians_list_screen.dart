import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:http/http.dart' as http;
import 'package:geolocator/geolocator.dart';
import 'package:doctor_car_app/services/api_service.dart';

class TechniciansListScreen extends StatefulWidget {
  final List<String> selectedServices;
  const TechniciansListScreen(
      {super.key, required this.selectedServices, required technicians});

  @override
  State<TechniciansListScreen> createState() => _TechniciansListScreenState();
}

class _TechniciansListScreenState extends State<TechniciansListScreen> {
  bool isLoading = true;
  List technicians = [];
  double userLat = 30.0444;
  double userLng = 31.2357;

  final MapController _mapController = MapController();

  @override
  void initState() {
    super.initState();
    _getLocation();
    _fetchTechnicians();
  }

  Future<void> _getLocation() async {
    try {
      final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );
      setState(() {
        userLat = pos.latitude;
        userLng = pos.longitude;
      });
    } catch (_) {}
  }

  Future<void> _fetchTechnicians() async {
    try {
      List allTechs = [];
      for (final s in widget.selectedServices) {
        final res = await http
            .get(Uri.parse('${ApiService.baseUrl}/technicians?service=$s'));
        if (res.statusCode == 200) {
          allTechs.addAll(jsonDecode(res.body));
        }
      }
      setState(() {
        technicians = allTechs;
        isLoading = false;
      });
    } catch (_) {
      setState(() => isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final markers = [
      Marker(
        point: LatLng(userLat, userLng),
        width: 50,
        height: 50,
        child:
            const Icon(Icons.person_pin_circle, color: Colors.blue, size: 45),
      ),
      ...technicians.map((t) {
        return Marker(
          point: LatLng(
            (t['lat'] ?? userLat).toDouble(),
            (t['lng'] ?? userLng).toDouble(),
          ),
          width: 40,
          height: 40,
          child: const Icon(Icons.engineering,
              color: Colors.orangeAccent, size: 36),
        );
      }).toList()
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('الفنيين المتاحين'),
        backgroundColor: Colors.blue.shade800,
        foregroundColor: Colors.white,
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                SizedBox(
                  height: 300,
                  child: FlutterMap(
                    mapController: _mapController,
                    options: MapOptions(
                      initialCenter: LatLng(userLat, userLng),
                      initialZoom: 12.5,
                    ),
                    children: [
                      TileLayer(
                        urlTemplate:
                            'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
                        subdomains: const ['a', 'b', 'c'],
                      ),
                      MarkerLayer(markers: markers),
                    ],
                  ),
                ),
                Expanded(
                  child: ListView.builder(
                    padding: const EdgeInsets.all(10),
                    itemCount: technicians.length,
                    itemBuilder: (context, i) {
                      final t = technicians[i];
                      return Card(
                        child: ListTile(
                          leading: const Icon(Icons.engineering,
                              color: Colors.orange),
                          title: Text(t['name'] ?? 'فني'),
                          subtitle: Text(
                              'الخدمة: ${t['serviceType'] ?? 'غير محدد'}\nالتقييم: ⭐ ${t['rating'] ?? 4.5}'),
                          trailing: ElevatedButton(
                            onPressed: () {},
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.blue.shade700,
                            ),
                            child: const Text('اختيار'),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
    );
  }
}
