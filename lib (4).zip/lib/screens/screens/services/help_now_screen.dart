import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
// ignore: unused_import
import 'package:geolocator/geolocator.dart';

class HelpNowScreen extends StatelessWidget {
  const HelpNowScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100, // خلفية فاتحة
      appBar: AppBar(
        title: const Text(
          'طلب مساعدة الآن',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 1,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),

      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            // ✅ خريطة فعلية من OpenStreetMap
            SizedBox(
              height: 250,
              child: FlutterMap(
                options: const MapOptions(
                  initialCenter: LatLng(30.0444, 31.2357), // القاهرة كمثال
                  initialZoom: 13,
                ),
                children: [
                  TileLayer(
                    urlTemplate:
                        "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
                    subdomains: const ['a', 'b', 'c'],
                  ),
                  const MarkerLayer(
                    markers: [
                      Marker(
                        point: LatLng(30.0444, 31.2357),
                        width: 60,
                        height: 60,
                        child: Icon(
                          Icons.location_on,
                          color: Colors.red,
                          size: 40,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 10),

            // قائمة الخدمات (كما في الصورة)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10.0),
              child: Column(
                children: [
                  _buildServiceTile(
                    context,
                    title: 'فحص الأعطال الذكي',
                    subtitle: 'تحليل العطل واقتراح السبب تلقائياً.',
                    icon: Icons.search,
                    color: Colors.blue.shade800,
                    onTap: () =>
                        _showServiceMessage(context, 'فحص الأعطال الذكي'),
                  ),
                  _buildServiceTile(
                    context,
                    title: 'خدمة مساعدة الطريق السريعة',
                    subtitle: 'طلب فوري لميكانيكي أو ونش بناءً على موقعك.',
                    icon: Icons.handyman,
                    color: Colors.orange,
                    onTap: () => _showServiceMessage(
                        context, 'خدمة مساعدة الطريق السريعة'),
                  ),
                  _buildServiceTile(
                    context,
                    title: 'فني متنقل',
                    subtitle: 'فني يصل لموقعك مباشرة ويتتبعه على الخريطة.',
                    icon: Icons.directions_bike,
                    color: Colors.purple,
                    onTap: () => _showServiceMessage(context, 'فني متنقل'),
                  ),
                  _buildServiceTile(
                    context,
                    title: 'تزويد الوقود الطارئ',
                    subtitle: 'تحديد نوع وكمية الوقود المطلوبة.',
                    icon: Icons.local_gas_station,
                    color: Colors.lightBlue,
                    onTap: () =>
                        _showServiceMessage(context, 'تزويد الوقود الطارئ'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),

      // الزر السفلي (طلب الخدمة الآن)
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(20.0),
        child: ElevatedButton(
          onPressed: () {
            _showServiceMessage(context, 'طلب الخدمة الآن بشكل نهائي');
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.orange.shade700,
            foregroundColor: Colors.white,
            minimumSize: const Size(double.infinity, 55),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
            elevation: 5,
          ),
          child: const Text(
            'طلب الخدمة الآن',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
        ),
      ),
    );
  }

  // 🔹 دالة بناء بطاقة الخدمة
  Widget _buildServiceTile(
    BuildContext context, {
    required String title,
    required String subtitle,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Card(
      elevation: 3,
      margin: const EdgeInsets.symmetric(vertical: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(10),
        child: Padding(
          padding: const EdgeInsets.all(15.0),
          child: Row(
            textDirection: TextDirection.rtl,
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(icon, color: color, size: 30),
              ),
              const SizedBox(width: 15),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                          fontSize: 16, fontWeight: FontWeight.bold),
                      textAlign: TextAlign.right,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style:
                          TextStyle(fontSize: 13, color: Colors.grey.shade600),
                      textAlign: TextAlign.right,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              Icon(Icons.arrow_back_ios, size: 18, color: Colors.grey.shade400),
            ],
          ),
        ),
      ),
    );
  }

  // 🔹 دالة لعرض رسالة مؤقتة
  void _showServiceMessage(BuildContext context, String serviceName) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('تم النقر على خدمة: $serviceName')),
    );
  }
}
