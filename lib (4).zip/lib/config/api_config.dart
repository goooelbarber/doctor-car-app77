class ApiConfig {
  static const String baseUrl = "http://192.168.1.10:5000"; // ← الـ IP الصحيح
  static String socket = baseUrl;

  static String get orders => "$baseUrl/api/orders";
  static String get technicians => "$baseUrl/api/technicians";
  static String get feedback => "$baseUrl/api/feedback";
  static String get payments => "$baseUrl/api/payments";
}
