import 'dart:io';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:image_picker/image_picker.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:doctor_car_app/screens/vehicles/vehicle_screen.dart';

class AccountSettingsScreen extends StatefulWidget {
  const AccountSettingsScreen({super.key});

  @override
  State<AccountSettingsScreen> createState() => _AccountSettingsScreenState();
}

class _AccountSettingsScreenState extends State<AccountSettingsScreen> {
  bool _notificationsEnabled = true;
  String _language = 'ar';
  String _userName = 'مستخدم التطبيق';
  bool _isDarkMode = false;
  File? _profileImage;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  // 🧠 تحميل الإعدادات
  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _notificationsEnabled = prefs.getBool('notificationsEnabled') ?? true;
      _language = prefs.getString('language') ?? 'ar';
      _userName = prefs.getString('userName') ?? 'مستخدم التطبيق';
      _isDarkMode = prefs.getBool('darkMode') ?? false;
    });
  }

  // 💾 حفظ الإعدادات
  Future<void> _saveSettings() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('notificationsEnabled', _notificationsEnabled);
    await prefs.setString('language', _language);
    await prefs.setString('userName', _userName);
    await prefs.setBool('darkMode', _isDarkMode);
  }

  // 🌐 تغيير اللغة
  Future<void> _changeLanguage(String lang) async {
    setState(() => _language = lang);
    await _saveSettings();
    if (!mounted) return;
    await context.setLocale(Locale(lang));
  }

  // 🌙 تبديل الوضع الليلي
  void _toggleDarkMode(bool value) {
    setState(() => _isDarkMode = value);
    _saveSettings();
  }

  // 🖼️ اختيار صورة الملف الشخصي
  Future<void> _pickProfileImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null && mounted) {
      setState(() => _profileImage = File(pickedFile.path));
    }
  }

  // 📞 التواصل مع الدعم الفني
  Future<void> _contactSupport(String method) async {
    final whatsapp = Uri.parse("https://wa.me/201275649151");
    final email = Uri.parse("mailto:support@doctorcar.com?subject=Support");
    final phone = Uri.parse("tel:+201275649151");

    final Uri url = (method == 'whatsapp')
        ? whatsapp
        : (method == 'email')
            ? email
            : phone;

    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
    } else {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('تعذر فتح التطبيق')));
    }
  }

  // ✏️ تعديل الاسم
  Future<void> _editName() async {
    final controller = TextEditingController(text: _userName);
    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('تعديل الاسم'),
        content: TextField(
          controller: controller,
          textAlign: TextAlign.right,
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('إلغاء')),
          ElevatedButton(
            onPressed: () {
              setState(() => _userName = controller.text);
              _saveSettings();
              Navigator.pop(context);
            },
            child: const Text('حفظ'),
          ),
        ],
      ),
    );
  }

  // ❌ حذف الحساب
  // ignore: unused_element
  void _showDeleteDialog() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("تأكيد حذف الحساب"),
        content: const Text("هل تريد حذف الحساب؟"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("إلغاء"),
          ),
          TextButton(
            onPressed: () async {
              final prefs = await SharedPreferences.getInstance();
              await prefs.clear();
              if (!mounted) return;
              Navigator.of(context)
                  .pushNamedAndRemoveUntil('/login', (_) => false);
            },
            child: const Text("حذف"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = _isDarkMode;
    final bgColor = isDark ? const Color(0xFF121212) : const Color(0xFFF7F8FA);
    final textColor = isDark ? Colors.white : Colors.black;

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        title: Text('my_account'.tr()),
        centerTitle: true,
        backgroundColor: Colors.blue.shade700,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // 🖼️ الصورة والاسم
          Column(
            children: [
              Stack(
                alignment: Alignment.bottomRight,
                children: [
                  CircleAvatar(
                    radius: 55,
                    backgroundColor: Colors.blue.shade100,
                    backgroundImage: _profileImage != null
                        ? FileImage(_profileImage!)
                        : null,
                    child: _profileImage == null
                        ? const Icon(Icons.person, size: 60)
                        : null,
                  ),
                  GestureDetector(
                    onTap: _pickProfileImage,
                    child: CircleAvatar(
                      radius: 16,
                      backgroundColor: Colors.blue,
                      child: const Icon(Icons.camera_alt,
                          color: Colors.white, size: 18),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Text(_userName,
                  style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: textColor)),
              TextButton(
                  onPressed: _editName, child: const Text('edit_name').tr()),
            ],
          ),

          const Divider(height: 40),

          Text('account_settings'.tr(),
              style: TextStyle(
                  fontSize: 20, fontWeight: FontWeight.bold, color: textColor),
              textAlign: TextAlign.center),
          const SizedBox(height: 20),

          // 🌐 اللغة
          _buildCard(
            icon: Icons.language,
            color: Colors.blue,
            title: 'change_language'.tr(),
            subtitle: _language == 'ar' ? 'العربية' : 'English',
            trailing: DropdownButton<String>(
              value: _language,
              underline: const SizedBox(),
              items: const [
                DropdownMenuItem(value: 'ar', child: Text('العربية')),
                DropdownMenuItem(value: 'en', child: Text('English')),
              ],
              onChanged: (v) {
                if (v != null) _changeLanguage(v);
              },
            ),
          ),

          // 🔔 الإشعارات
          _buildSwitchCard(
            icon: Icons.notifications,
            color: Colors.orange,
            title: 'notifications'.tr(),
            value: _notificationsEnabled,
            onChanged: (val) {
              setState(() => _notificationsEnabled = val);
              _saveSettings();
            },
          ),

          // 🌙 الوضع الليلي
          _buildSwitchCard(
            icon: Icons.nightlight_round,
            color: Colors.purple,
            title: 'dark_mode'.tr(),
            value: _isDarkMode,
            onChanged: _toggleDarkMode,
          ),

          // 🚗 إدارة المركبات
          _buildCard(
            icon: Icons.car_rental,
            color: Colors.blue,
            title: 'manage_vehicles'.tr(),
            subtitle: 'manage_vehicles_sub'.tr(),
            onTap: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const VehiclesScreen())),
          ),

          // 💳 طرق الدفع
          _buildCard(
            icon: Icons.credit_card,
            color: Colors.orange,
            title: 'payment_methods'.tr(),
            subtitle: 'payment_methods_sub'.tr(),
          ),

          const Divider(),

          // 📞 *** قسم التواصل مع الدعم الفني (المطلوب إضافته) ***
          const SizedBox(height: 15),
          Text("contact_support".tr(),
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center),
          const SizedBox(height: 15),

          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildSupportButton(
                  FontAwesomeIcons.whatsapp,
                  'support_whatsapp'.tr(),
                  Colors.green,
                  () => _contactSupport('whatsapp')),
              _buildSupportButton(Icons.email, 'support_email'.tr(),
                  Colors.blue, () => _contactSupport('email')),
              _buildSupportButton(Icons.phone, 'support_call'.tr(),
                  Colors.orange, () => _contactSupport('call')),
            ],
          ),

          const SizedBox(height: 25),

          // 🚪 تسجيل الخروج
          ElevatedButton.icon(
            onPressed: () async {
              final prefs = await SharedPreferences.getInstance();
              await prefs.clear();
              if (!mounted) return;
              Navigator.of(context)
                  .pushNamedAndRemoveUntil('/login', (route) => false);
            },
            icon: const Icon(Icons.logout),
            label: Text('logout'.tr()),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              minimumSize: const Size(double.infinity, 50),
            ),
          ),
        ],
      ),
    );
  }

  // Widgets
  Widget _buildCard({
    required IconData icon,
    required Color color,
    required String title,
    String? subtitle,
    Widget? trailing,
    VoidCallback? onTap,
  }) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: ListTile(
        leading: Icon(icon, color: color),
        title: Text(title),
        subtitle: subtitle != null ? Text(subtitle) : null,
        trailing: trailing ??
            const Icon(Icons.arrow_forward_ios, size: 18, color: Colors.grey),
        onTap: onTap,
      ),
    );
  }

  Widget _buildSwitchCard({
    required IconData icon,
    required Color color,
    required String title,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: SwitchListTile(
        secondary: Icon(icon, color: color),
        title: Text(title),
        value: value,
        onChanged: onChanged,
      ),
    );
  }

  Widget _buildSupportButton(
      IconData icon, String label, Color color, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        width: 90,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color),
        ),
        child: Column(
          children: [
            Icon(icon, color: color, size: 30),
            const SizedBox(height: 6),
            Text(label,
                style: TextStyle(
                    color: color, fontWeight: FontWeight.bold, fontSize: 12)),
          ],
        ),
      ),
    );
  }
}
