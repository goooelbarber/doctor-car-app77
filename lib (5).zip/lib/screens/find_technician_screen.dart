import 'dart:convert';
// ignore: unused_import
import 'package:doctor_car_app/screens/luber_tracking_screen.dart';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import '../config/api_config.dart';
// ignore: unused_import

class FindTechnicianScreen extends StatefulWidget {
  final String serviceType;
  final double lat;
  final double lng;

  const FindTechnicianScreen({
    super.key,
    required this.serviceType,
    required this.lat,
    required this.lng,
    required String userId,
  });

  @override
  State<FindTechnicianScreen> createState() => _FindTechnicianScreenState();
}

class _FindTechnicianScreenState extends State<FindTechnicianScreen> {
  bool searching = true;
  String message = "جاري البحث عن أقرب فني...";

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 800), _createOrder);
  }

  /// 🧠 إنشاء الطلب والتعيين التلقائي للفني
  Future<void> _createOrder() async {
    final url = Uri.parse(ApiConfig.orders);

    final body = {
      "userId": "68fe4505493ae17aa81d605b", // ID ثابت للتجربة
      "serviceType": widget.serviceType,
      "location": {"lat": widget.lat, "lng": widget.lng}
    };

    try {
      final res = await http.post(
        url,
        headers: {"Content-Type": "application/json"},
        body: json.encode(body),
      );

      final data = json.decode(res.body);

      if (res.statusCode == 201 && data["success"] == true) {
        final order = data["order"];
        final String orderId = order["_id"];
        final bool assigned = order["status"] == "assigned";

        setState(() {
          searching = false;
          message = assigned
              ? "تم تعيين أقرب فني وهو الآن في الطريق إليك"
              : "تم تسجيل الطلب — نبحث عن فني متاح";
        });

        await Future.delayed(const Duration(milliseconds: 800));

        Navigator.pushReplacement(
          // ignore: use_build_context_synchronously
          context,
          MaterialPageRoute(
            builder: (_) => UberTrackingScreen(
              orderId: orderId,
              selectedServices: [widget.serviceType],
              userId: "68fe4505493ae17aa81d605b",
              serviceType: widget.serviceType,
            ),
          ),
        );
      } else {
        setState(() {
          searching = false;
          message = "تعذر إنشاء الطلب. حاول مرة أخرى.";
        });
      }
    } catch (e) {
      setState(() {
        searching = false;
        message = "❌ تعذر الاتصال بالسيرفر";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            searching
                ? const CircularProgressIndicator(
                    color: Colors.blueAccent,
                    strokeWidth: 4,
                  )
                : const Icon(Icons.check_circle, color: Colors.green, size: 60),
            const SizedBox(height: 20),
            Text(
              message,
              textAlign: TextAlign.center,
              style: GoogleFonts.cairo(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
            const SizedBox(height: 25),
            if (!searching)
              ElevatedButton(
                onPressed: () => Navigator.pop(context),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blueGrey.shade700,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 25, vertical: 12),
                ),
                child: Text(
                  "رجوع",
                  style: GoogleFonts.cairo(
                    fontSize: 16,
                    color: Colors.white,
                  ),
                ),
              )
          ],
        ),
      ),
    );
  }
}
