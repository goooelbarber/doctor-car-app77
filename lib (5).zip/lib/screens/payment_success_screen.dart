import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'feedback_screen.dart';

class PaymentSuccessScreen extends StatelessWidget {
  final String orderId;
  final String userId;
  final String? technicianName;

  const PaymentSuccessScreen({
    super.key,
    required this.orderId,
    required this.userId,
    this.technicianName,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(30.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.check_circle_outline,
                  color: Colors.green, size: 100),
              const SizedBox(height: 20),
              Text(
                "تم الدفع بنجاح ✅",
                style: GoogleFonts.cairo(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.green,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                "شكرًا لاستخدامك Doctor Car!\nنتمنى لك تجربة مريحة وآمنة 🚗💨",
                textAlign: TextAlign.center,
                style: GoogleFonts.cairo(fontSize: 16),
              ),
              const SizedBox(height: 30),
              ElevatedButton.icon(
                onPressed: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (_) => FeedbackScreen(
                        orderId: orderId,
                        userId: userId,
                        technicianName: technicianName,
                      ),
                    ),
                  );
                },
                icon: const Icon(Icons.star_rate_rounded, color: Colors.white),
                label: Text(
                  "قيّم تجربتك",
                  style: GoogleFonts.cairo(fontSize: 16, color: Colors.white),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blueAccent,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 40, vertical: 12),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
              ),
              const SizedBox(height: 10),
              TextButton(
                onPressed: () =>
                    Navigator.popUntil(context, (route) => route.isFirst),
                child: const Text("تخطي لاحقًا"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
