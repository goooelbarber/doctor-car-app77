import 'dart:async';
import 'dart:convert';
// ignore: unused_import
import 'package:doctor_car_app/screens/luber_tracking_screen.dart';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;

import '../config/api_config.dart';

class SearchingTechnicianScreen extends StatefulWidget {
  final String orderId;
  final String userId;
  final String serviceType;
  final List<String> selectedServices;

  const SearchingTechnicianScreen({
    super.key,
    required this.orderId,
    required this.userId,
    required this.serviceType,
    required this.selectedServices,
  });

  @override
  State<SearchingTechnicianScreen> createState() =>
      _SearchingTechnicianScreenState();
}

class _SearchingTechnicianScreenState extends State<SearchingTechnicianScreen> {
  Timer? _timer;
  // ignore: unused_field
  bool _assigned = false;

  @override
  void initState() {
    super.initState();
    _startPolling();
  }

  // =====================================================
  // 🟦 استعلام كل 3 ثواني عن حالة الطلب حتى يتعيّن فني
  // =====================================================
  void _startPolling() {
    _timer = Timer.periodic(const Duration(seconds: 3), (_) {
      _checkOrderStatus();
    });
  }

  Future<void> _checkOrderStatus() async {
    final url = Uri.parse("${ApiConfig.orders}/${widget.orderId}");

    try {
      final res = await http.get(url);
      final data = jsonDecode(res.body);

      if (data["success"] == true) {
        final status = data["order"]["status"];

        if (status == "assigned") {
          _assigned = true;
          _timer?.cancel();

          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (_) => UberTrackingScreen(
                orderId: widget.orderId,
                userId: widget.userId,
                serviceType: widget.serviceType,
                selectedServices: widget.selectedServices,
              ),
            ),
          );
        }
      }
    } catch (_) {}
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  // =====================================================
  // 🟦 UI — شاشة انتظار اختيار الفني
  // =====================================================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F6FA),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset("assets/images/searching.gif", height: 170),
              const SizedBox(height: 30),
              Text(
                "جاري البحث عن أقرب فني...",
                style: GoogleFonts.cairo(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                "نبحث الآن في منطقتك لتحديد أقرب فني متاح لتنفيذ طلبك.",
                textAlign: TextAlign.center,
                style: GoogleFonts.cairo(fontSize: 16),
              ),
              const SizedBox(height: 40),
              const CircularProgressIndicator(
                color: Colors.redAccent,
                strokeWidth: 3,
              )
            ],
          ),
        ),
      ),
    );
  }
}
