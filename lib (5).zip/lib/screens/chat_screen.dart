import 'package:flutter/material.dart';
// ignore: library_prefixes
import 'package:socket_io_client/socket_io_client.dart' as IO;
import '../config/api_config.dart';

class ChatScreen extends StatefulWidget {
  final String orderId;
  final String userId;
  final String technicianId;

  const ChatScreen({
    super.key,
    required this.orderId,
    required this.userId,
    required this.technicianId,
  });

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  IO.Socket? socket;
  List<Map<String, dynamic>> messages = [];
  final TextEditingController _msgController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    _connectSocket();
  }

  void _connectSocket() {
    socket = IO.io(ApiConfig.socket, {
      "transports": ["websocket"],
      "autoConnect": true,
    });

    socket!.onConnect((_) {
      socket!.emit("joinChatRoom", widget.orderId);
    });

    socket!.on("receiveMessage", (data) {
      setState(() {
        messages.add(
            {"from": data["from"], "text": data["text"], "time": data["time"]});
      });
      _scrollDown();
    });
  }

  void _sendMessage() {
    if (_msgController.text.trim().isEmpty) return;

    final text = _msgController.text.trim();

    socket!.emit("sendMessage", {
      "roomId": widget.orderId,
      "from": widget.userId,
      "to": widget.technicianId,
      "text": text,
      "time": DateTime.now().toString(),
    });

    setState(() {
      messages.add({
        "from": widget.userId,
        "text": text,
        "time": DateTime.now().toString(),
      });
    });

    _msgController.clear();
    _scrollDown();
  }

  void _scrollDown() {
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_scrollController.hasClients) {
        _scrollController.jumpTo(_scrollController.position.maxScrollExtent);
      }
    });
  }

  bool _isMe(String id) => id == widget.userId;

  @override
  void dispose() {
    socket?.disconnect();
    socket?.destroy();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffF6F7F9),
      appBar: AppBar(
        backgroundColor: Colors.blue.shade800,
        title: const Row(
          children: [
            CircleAvatar(
              backgroundColor: Colors.white,
              child: Icon(Icons.person, color: Colors.blue),
            ),
            SizedBox(width: 10),
            Text("الفني", style: TextStyle(color: Colors.white)),
          ],
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              itemCount: messages.length,
              padding: const EdgeInsets.all(12),
              itemBuilder: (_, i) {
                final msg = messages[i];
                final isMe = _isMe(msg["from"]);

                return Align(
                  alignment:
                      isMe ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 10),
                    constraints: const BoxConstraints(maxWidth: 260),
                    decoration: BoxDecoration(
                      color: isMe ? Colors.blue : Colors.grey.shade300,
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Text(
                      msg["text"],
                      style: TextStyle(
                        color: isMe ? Colors.white : Colors.black87,
                        fontSize: 15,
                      ),
                    ),
                  ),
                );
              },
            ),
          ),

          /// ====== مربع كتابة الرسالة ======
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            decoration: const BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                    blurRadius: 5, color: Colors.black12, offset: Offset(0, -3))
              ],
            ),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _msgController,
                    decoration: InputDecoration(
                      hintText: "اكتب رسالة...",
                      filled: true,
                      fillColor: Colors.grey.shade200,
                      contentPadding:
                          const EdgeInsets.symmetric(horizontal: 14),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(25),
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                CircleAvatar(
                  backgroundColor: Colors.blue.shade800,
                  child: IconButton(
                    icon: const Icon(Icons.send, color: Colors.white),
                    onPressed: _sendMessage,
                  ),
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}
