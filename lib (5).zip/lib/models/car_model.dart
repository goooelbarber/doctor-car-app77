// 📁 lib/models/car_model.dart

class CarModel {
  final String id;
  final String brand;
  final String model;
  final int year;
  final String plateNumber;
  final String vin;
  final int mileage;
  final String? imageUrl;

  CarModel({
    required this.id,
    required this.brand,
    required this.model,
    required this.year,
    required this.plateNumber,
    required this.vin,
    required this.mileage,
    this.imageUrl,
  });

  factory CarModel.fromJson(Map<String, dynamic> json) => CarModel(
        id: json["_id"],
        brand: json["brand"],
        model: json["model"],
        year: json["year"],
        plateNumber: json["plateNumber"] ?? "",
        vin: json["vin"] ?? "",
        mileage: json["mileage"] ?? 0,
        imageUrl: json["imageUrl"],
      );

  get lastOilChange => null;

  get nextOilChange => null;

  get lastService => null;

  Map<String, dynamic> toJson() => {
        "brand": brand,
        "model": model,
        "year": year,
        "plateNumber": plateNumber,
        "vin": vin,
        "mileage": mileage,
        "imageUrl": imageUrl,
      };
}
