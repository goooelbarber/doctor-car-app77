class ApiConfig {
  static const String baseUrl = "http://192.168.1.10:5000";

  // 🔥 API KEY لخدمات خرائط Google
  static const String googleMapsApiKey =
      "AIzaSyD9BGSScE-DU9nbdFgIbJV4fbNspNdPg_M&libraries";

  // 🌍 Google Autocomplete API
  static String autocomplete(String text) =>
      "https://maps.googleapis.com/maps/api/place/autocomplete/json?input=$text&key=$googleMapsApiKey&language=ar";

  // 📌 Google Place Details API
  static String placeDetails(String placeId) =>
      "https://maps.googleapis.com/maps/api/place/details/json?place_id=$placeId&key=$googleMapsApiKey&language=ar";

  // APIs داخل السيرفر
  static String get orders => "$baseUrl/api/orders";
  static String get technicians => "$baseUrl/api/technicians";
  static String get feedback => "$baseUrl/api/feedback";
  static String get payments => "$baseUrl/api/payments";

  static get socket => null;

  static snapToRoad(double latitude, double longitude) {}
}
