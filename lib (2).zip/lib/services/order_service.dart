import 'dart:convert';
import 'package:http/http.dart' as http;

class OrderService {
  final String baseUrl = "http://192.168.1.10:5001/api/orders";

  Future<Map<String, dynamic>> createOrder({
    required String userId,
    required String serviceType,
    required double lat,
    required double lng,
  }) async {
    final body = {
      "userId": userId,
      "serviceType": serviceType,
      "location": {"lat": lat, "lng": lng}
    };

    final response = await http.post(
      Uri.parse(baseUrl),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode(body),
    );

    return jsonDecode(response.body);
  }
}
