import 'dart:convert';
import 'package:http/http.dart' as http;

class PaymobService {
  static const String base = "http://YOUR_SERVER_IP:5001/api/paymob/pay";

  static Future<String?> createPayment({
    required int amount,
    required String name,
    required String phone,
    String email = "test@test.com",
  }) async {
    final response = await http.post(
      Uri.parse(base),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({
        "amount": amount,
        "customer": {
          "name": name,
          "phone": phone,
          "email": email,
        }
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return data["iframe_url"];
    }
    return null;
  }
}
