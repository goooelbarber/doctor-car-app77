import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

class ApiService {
  // 🌍 تحديد عنوان السيرفر تلقائيًا حسب نوع التشغيل
  static String get baseUrl {
    const int port = 5001; // المنفذ الذي يعمل عليه السيرفر
    const String localIP =
        "192.168.1.11"; // ⚠️ غيّره لو الـ Network في السيرفر بيظهر IP مختلف

    if (kIsWeb) {
      // ✅ Flutter Web على المتصفح (Chrome/Edge)
      return "http://localhost:$port/api";
    } else if (defaultTargetPlatform == TargetPlatform.android) {
      // 📱 Android emulator أو جهاز فعلي
      return kDebugMode
          ? "http://10.0.2.2:$port/api" // Emulator
          : "http://$localIP:$port/api"; // جهاز أندرويد حقيقي على الشبكة
    } else if (defaultTargetPlatform == TargetPlatform.iOS) {
      // 📱 iOS simulator أو جهاز فعلي
      return "http://$localIP:$port/api";
    } else {
      // 💻 باقي الأنظمة (Windows/macOS/Linux)
      return "http://localhost:$port/api";
    }
  }

  // =====================================================================
  // 🔌 اختبار الاتصال بالسيرفر
  // =====================================================================
  static Future<void> checkConnection() async {
    try {
      final url = Uri.parse("$baseUrl/");
      final res = await http.get(url);
      if (res.statusCode == 200) {
        debugPrint("✅ السيرفر متصل ويعمل: ${res.body}");
      } else {
        debugPrint("⚠️ السيرفر رد بكود: ${res.statusCode}");
      }
    } catch (e) {
      debugPrint("❌ لا يمكن الاتصال بالسيرفر: $e");
    }
  }

  // =====================================================================
  // 👤 المستخدم (تسجيل الدخول / إنشاء حساب)
  // =====================================================================

  /// تسجيل الدخول
  static Future<Map<String, dynamic>> login(
      String email, String password) async {
    try {
      final url = Uri.parse("$baseUrl/users/login");
      final res = await http.post(
        url,
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "email": email.trim(),
          "password": password.trim(),
        }),
      );

      if (res.statusCode == 200 || res.statusCode == 201) {
        return jsonDecode(res.body);
      } else {
        debugPrint("❌ فشل تسجيل الدخول: ${res.body}");
        return {
          "error": true,
          "message": "فشل تسجيل الدخول: ${res.statusCode}"
        };
      }
    } catch (e) {
      debugPrint("⚠️ خطأ أثناء تسجيل الدخول: $e");
      return {"error": true, "message": "تعذر الاتصال بالسيرفر"};
    }
  }

  /// إنشاء حساب جديد
  static Future<Map<String, dynamic>> register(
      String name, String email, String password, String role) async {
    try {
      final url = Uri.parse("$baseUrl/users/register");
      final res = await http.post(
        url,
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "name": name.trim(),
          "email": email.trim(),
          "password": password.trim(),
          "role": role.trim(),
        }),
      );

      if (res.statusCode == 200 || res.statusCode == 201) {
        return jsonDecode(res.body);
      } else {
        debugPrint("❌ فشل إنشاء الحساب: ${res.body}");
        return {
          "error": true,
          "message": "فشل إنشاء الحساب: ${res.statusCode}"
        };
      }
    } catch (e) {
      debugPrint("⚠️ خطأ أثناء التسجيل: $e");
      return {"error": true, "message": "تعذر الاتصال بالسيرفر"};
    }
  }

  // =====================================================================
  // 🚗 إدارة السيارات
  // =====================================================================

  /// عرض جميع سيارات المستخدم
  static Future<List<dynamic>> getVehicles(String token) async {
    try {
      // ✅ المسار الصحيح حسب vehicleRoutes.js
      final url = Uri.parse("$baseUrl/vehicles/my-vehicles");
      final res = await http.get(url, headers: {
        "Authorization": "Bearer $token",
        "Content-Type": "application/json",
      });

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data is List) return data;
        if (data["vehicles"] != null) return data["vehicles"];
        return [];
      } else {
        debugPrint("❌ فشل في جلب السيارات: ${res.body}");
        return [];
      }
    } catch (e) {
      debugPrint("⚠️ خطأ أثناء جلب السيارات: $e");
      return [];
    }
  }

  /// إضافة سيارة جديدة
  static Future<Map<String, dynamic>> addVehicle(
    String token, {
    required String brand,
    required String model,
    required String fuel,
    required String condition,
    required String plateNumber,
    required String year,
    required String color,
    required String chassisNumber,
  }) async {
    try {
      final url = Uri.parse("$baseUrl/vehicles");
      final res = await http.post(
        url,
        headers: {
          "Authorization": "Bearer $token",
          "Content-Type": "application/json",
        },
        body: jsonEncode({
          "brand": brand.trim(),
          "model": model.trim(),
          "fuel": fuel.trim(),
          "condition": condition.trim(),
          "plateNumber": plateNumber.trim(),
          "year": year.trim(),
          "color": color.trim(),
          "chassisNumber": chassisNumber.trim(),
        }),
      );

      if (res.statusCode == 200 || res.statusCode == 201) {
        return jsonDecode(res.body);
      } else {
        debugPrint("❌ فشل إضافة السيارة: ${res.body}");
        return {"error": true, "message": "فشل إضافة السيارة"};
      }
    } catch (e) {
      debugPrint("⚠️ خطأ أثناء الإرسال: $e");
      return {"error": true, "message": "تعذر الاتصال بالسيرفر"};
    }
  }

  /// تحديث بيانات السيارة
  static Future<Map<String, dynamic>> updateVehicle(
    String token, {
    required String vehicleId,
    String? brand,
    String? model,
    String? fuel,
    String? condition,
    String? plateNumber,
    String? year,
    String? color,
    String? chassisNumber,
  }) async {
    try {
      final url = Uri.parse("$baseUrl/vehicles/$vehicleId");
      final res = await http.put(
        url,
        headers: {
          "Authorization": "Bearer $token",
          "Content-Type": "application/json",
        },
        body: jsonEncode({
          if (brand != null) "brand": brand,
          if (model != null) "model": model,
          if (fuel != null) "fuel": fuel,
          if (condition != null) "condition": condition,
          if (plateNumber != null) "plateNumber": plateNumber,
          if (year != null) "year": year,
          if (color != null) "color": color,
          if (chassisNumber != null) "chassisNumber": chassisNumber,
        }),
      );

      if (res.statusCode == 200) {
        return jsonDecode(res.body);
      } else {
        debugPrint("❌ فشل تعديل السيارة: ${res.body}");
        return {"error": true, "message": "فشل تعديل السيارة"};
      }
    } catch (e) {
      debugPrint("⚠️ خطأ أثناء التعديل: $e");
      return {"error": true, "message": "تعذر الاتصال بالسيرفر"};
    }
  }

  /// حذف السيارة
  static Future<Map<String, dynamic>> deleteVehicle(
      String token, String id) async {
    try {
      final url = Uri.parse("$baseUrl/vehicles/$id");
      final res = await http.delete(
        url,
        headers: {
          "Authorization": "Bearer $token",
          "Content-Type": "application/json",
        },
      );

      if (res.statusCode == 200 || res.statusCode == 204) {
        debugPrint("✅ تم حذف السيارة بنجاح");
        return {"success": true, "message": "تم حذف السيارة بنجاح"};
      } else {
        debugPrint("❌ فشل حذف السيارة: ${res.body}");
        return {"error": true, "message": "فشل حذف السيارة: ${res.statusCode}"};
      }
    } catch (e) {
      debugPrint("⚠️ خطأ أثناء حذف السيارة: $e");
      return {"error": true, "message": "تعذر الاتصال بالسيرفر"};
    }
  }

  // =====================================================================
  // 🧰 الفنيين (Technicians)
  // =====================================================================

  /// جلب الفنيين القريبين من موقع المستخدم
  static Future<List<dynamic>> getTechnicians(
      String token, String service, double lat, double lng) async {
    try {
      final url =
          Uri.parse("$baseUrl/technicians?service=$service&lat=$lat&lng=$lng");
      final res = await http.get(url, headers: {
        "Authorization": "Bearer $token",
        "Content-Type": "application/json",
      });

      if (res.statusCode == 200) {
        return jsonDecode(res.body);
      } else {
        debugPrint("❌ فشل جلب الفنيين: ${res.body}");
        return [];
      }
    } catch (e) {
      debugPrint("⚠️ خطأ أثناء جلب الفنيين: $e");
      return [];
    }
  }

  /// إرسال طلب فني محدد
  static Future<Map<String, dynamic>> sendRequest(
      String token, String technicianId, double lat, double lng) async {
    try {
      final url = Uri.parse("$baseUrl/requests");
      final res = await http.post(
        url,
        headers: {
          "Authorization": "Bearer $token",
          "Content-Type": "application/json",
        },
        body: jsonEncode({
          "technicianId": technicianId,
          "userLocation": {"lat": lat, "lng": lng}
        }),
      );

      if (res.statusCode == 200 || res.statusCode == 201) {
        return jsonDecode(res.body);
      } else {
        debugPrint("❌ فشل إرسال الطلب: ${res.body}");
        return {"error": true, "message": "فشل إرسال الطلب"};
      }
    } catch (e) {
      debugPrint("⚠️ خطأ أثناء إرسال الطلب: $e");
      return {"error": true, "message": "تعذر الاتصال بالسيرفر"};
    }
  }

  /// تتبع موقع الفني
  static Future<Map<String, dynamic>> trackTechnician(
      String token, String technicianId) async {
    try {
      final url = Uri.parse("$baseUrl/technicians/$technicianId/location");
      final res = await http.get(url, headers: {
        "Authorization": "Bearer $token",
        "Content-Type": "application/json",
      });

      if (res.statusCode == 200) {
        return jsonDecode(res.body);
      } else {
        debugPrint("❌ فشل تتبع الفني: ${res.body}");
        return {"error": true, "message": "فشل تتبع الفني"};
      }
    } catch (e) {
      debugPrint("⚠️ خطأ أثناء تتبع الفني: $e");
      return {"error": true, "message": "تعذر الاتصال بالسيرفر"};
    }
  }
}
