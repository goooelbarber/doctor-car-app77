import 'package:doctor_car_app/screens/smart_accident_screen.dart';
import 'package:doctor_car_app/screens/vehicles/vehicle_screen.dart';
import 'package:flutter/material.dart';
import 'package:doctor_car_app/screens/splash_screen.dart';
import 'package:doctor_car_app/screens/login_screen.dart';
import 'package:doctor_car_app/screens/SignUp_Screen.dart';
import 'package:doctor_car_app/screens/road_services_screen.dart';
import 'package:doctor_car_app/screens/home_screen.dart';
import 'package:easy_localization/easy_localization.dart'; // ✅ لإدارة اللغات

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // ✅ تهيئة مكتبة الترجمة
  await EasyLocalization.ensureInitialized();

  runApp(
    EasyLocalization(
      supportedLocales: const [Locale('ar'), Locale('en')],
      path: 'assets/translations', // مكان ملفات الترجمة
      fallbackLocale: const Locale('ar'),
      saveLocale: true, // يحفظ اللغة المختارة
      child: const DoctorCarApp(),
    ),
  );
}

class DoctorCarApp extends StatelessWidget {
  const DoctorCarApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Doctor Car',
      theme: ThemeData(
        primaryColor: const Color(0xFF0D47A1),
        fontFamily: 'Cairo',
      ),

      // ✅ دعم الترجمة
      localizationsDelegates: context.localizationDelegates,
      supportedLocales: context.supportedLocales,
      locale: context.locale,

      // ✅ صفحة البداية
      home: const SplashScreen(),

      // ✅ تعريف المسارات
      routes: {
        '/login': (context) => const LoginScreen(),
        '/home': (context) => const HomeScreen(),
        '/road': (context) => const RoadServicesScreen(),
        '/signup': (context) => const SignUpScreen(),
        '/vehicle': (context) => const VehiclesScreen(),
        "/smart-accident": (context) => const SmartAccidentScreen(),
      },
    );
  }
}
