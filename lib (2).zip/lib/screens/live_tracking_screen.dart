// ignore_for_file: unused_import
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
// ignore: library_prefixes
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'package:url_launcher/url_launcher.dart'; // ✅ اتصال + واتساب
import 'package:font_awesome_flutter/font_awesome_flutter.dart'; // ✅ أيقونة واتساب
import '../config/api_config.dart';

class LiveTrackingScreen extends StatefulWidget {
  final String orderId;
  final List<String> selectedServices;

  const LiveTrackingScreen({
    super.key,
    required this.orderId,
    required this.selectedServices,
    required String userId,
    required String serviceType,
  });

  @override
  State<LiveTrackingScreen> createState() => _LiveTrackingScreenState();
}

class _LiveTrackingScreenState extends State<LiveTrackingScreen> {
  final MapController _mapController = MapController();
  IO.Socket? socket;

  // مواقع
  LatLng userLocation = const LatLng(31.416, 31.813);
  LatLng? technicianLocation;

  // حالة الطلب
  String orderStatus = "⏳ جاري إرسال الطلب...";
  // ignore: unused_field
  String? _lastStatus;
  DateTime _lastToastAt = DateTime.fromMillisecondsSinceEpoch(0);

  // ☎️ بيانات التواصل مع الفني
  static const String _techPhoneLocal = "01275649151"; // محلي
  static const String _techPhoneIntl = "201275649151"; // دولي بدون +

  // الخدمات لعرضها
  final Map<String, Map<String, String>> _servicesData = const {
    'tow': {'name': 'خدمة ونش', 'img': 'assets/images/tow_truck.png'},
    'battery': {'name': 'خدمة بطارية', 'img': 'assets/images/battery.png'},
    'fuel': {'name': 'خدمة بنزين', 'img': 'assets/images/fuel.png'},
    'tire': {'name': 'خدمة الكاوتش', 'img': 'assets/images/tire.png'},
    'ride': {'name': 'سيارة ركاب', 'img': 'assets/images/car.png'},
  };

  @override
  void initState() {
    super.initState();
    _connectSocket();
  }

  // ===== Socket.IO =====
  void _connectSocket() {
    socket = IO.io(ApiConfig.socket, {
      "transports": ["websocket"],
      "autoConnect": true,
    });

    socket!.onConnect((_) {
      _notify("تم الاتصال", "✅ تم الاتصال بالتتبع المباشر");
      socket!.emit("joinOrderRoom", widget.orderId);
    });

    // 📡 تحديث موقع الفني
    socket!.on("technicianLocationUpdate", (data) {
      final loc =
          (data is Map && data["location"] != null) ? data["location"] : data;
      if (loc is Map && loc["lat"] != null && loc["lng"] != null) {
        final newPos = LatLng(
          (loc["lat"] as num).toDouble(),
          (loc["lng"] as num).toDouble(),
        );
        final wasNull = technicianLocation == null;

        setState(() => technicianLocation = newPos);
        _mapController.move(newPos, 14);

        if (wasNull) {
          _notify("الفني تحرّك", "🚗 الفني في الطريق إليك الآن");
        }
      }
    });

    // 🔄 تحديث حالة الطلب
    socket!.on("orderStatusUpdated", (data) {
      final newStatus = (data is Map && data["status"] != null)
          ? data["status"].toString()
          : orderStatus;

      if (newStatus != orderStatus) {
        setState(() => orderStatus = newStatus);
        _notify("حالة الطلب", _statusMessage(newStatus));
        _lastStatus = newStatus;
      }
    });

    socket!.onDisconnect((_) {
      _notify("انقطاع الاتصال", "🔴 تم فصل الاتصال بالتتبع");
    });
  }

  String _statusMessage(String status) {
    final s = status.trim().toLowerCase();
    if (s.contains("assigned") || s.contains("الفني") || s.contains("طريق")) {
      return "🚗 الفني في الطريق";
    } else if (s.contains("in_progress") ||
        s.contains("جار") ||
        s.contains("تنفيذ")) {
      return "🛠️ جاري تنفيذ الخدمة";
    } else if (s.contains("completed") || s.contains("تم")) {
      return "✅ تم إكمال الطلب، شكرًا لك!";
    } else if (s.contains("cancel") || s.contains("ملغي")) {
      return "⚠️ تم إلغاء الطلب";
    }
    return status;
  }

  void _notify(String title, String message) {
    if (!mounted) return;
    final now = DateTime.now();
    if (now.difference(_lastToastAt).inMilliseconds < 1500) return;
    _lastToastAt = now;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(12),
        backgroundColor: Colors.blueGrey.shade900,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        content: Row(
          children: [
            const Icon(Icons.notifications_active, color: Colors.amber),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, color: Colors.white)),
                  const SizedBox(height: 2),
                  Text(message, style: const TextStyle(color: Colors.white70)),
                ],
              ),
            ),
          ],
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  // ✅ نافذة تأكيد الاتصال الهاتفي
  Future<void> _confirmAndCall() async {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text("📞 اتصال بالفني",
            style: TextStyle(fontWeight: FontWeight.bold)),
        content: const Text(
          "هل ترغب في الاتصال الآن بالفني $_techPhoneLocal؟",
          textAlign: TextAlign.center,
        ),
        actionsAlignment: MainAxisAlignment.spaceEvenly,
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child:
                const Text("إلغاء", style: TextStyle(color: Colors.redAccent)),
          ),
          ElevatedButton.icon(
            onPressed: () async {
              Navigator.pop(ctx);
              final Uri callUri = Uri(scheme: 'tel', path: _techPhoneLocal);
              if (await canLaunchUrl(callUri)) {
                await launchUrl(callUri);
              } else {
                _notify("خطأ", "تعذر فتح تطبيق الاتصال");
              }
            },
            icon: const Icon(Icons.call, color: Colors.white),
            label: const Text("اتصال"),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.green,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
            ),
          ),
        ],
      ),
    );
  }

  // ✅ زر واتساب (wa.me) برسالة جاهزة
  Future<void> _openWhatsApp() async {
    final msg =
        "مرحبًا، أنا عميل لطلب رقم ${widget.orderId}. أحتاج متابعة/تأكيد الخدمة. شكرًا لكم.";
    final Uri waUri = Uri.parse(
      "https://wa.me/$_techPhoneIntl?text=${Uri.encodeComponent(msg)}",
    );

    if (await canLaunchUrl(waUri)) {
      await launchUrl(waUri, mode: LaunchMode.externalApplication);
    } else {
      _notify("واتساب", "تعذر فتح واتساب على هذا الجهاز");
    }
  }

  @override
  void dispose() {
    socket?.disconnect();
    socket?.destroy();
    super.dispose();
  }

  // === عناصر واجهة صغيرة ===
  Widget _serviceCard(String title, String assetPath) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.grey.shade300),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 6,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      padding: const EdgeInsets.all(10),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: Image.asset(assetPath,
                width: 48, height: 48, fit: BoxFit.cover),
          ),
          const SizedBox(height: 6),
          Text(
            title,
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 13,
              color: Colors.black87,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildServiceGrid() {
    final chosen = widget.selectedServices;
    return GridView.count(
      crossAxisCount: 3,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      mainAxisSpacing: 10,
      crossAxisSpacing: 10,
      children: chosen.map((key) {
        final data = _servicesData[key];
        if (data == null) return const SizedBox();
        return _serviceCard(data['name']!, data['img']!);
      }).toList(),
    );
  }

  @override
  Widget build(BuildContext context) {
    final markers = <Marker>[
      Marker(
        point: userLocation,
        child: const Icon(Icons.person_pin_circle,
            color: Colors.blueAccent, size: 40),
      ),
      if (technicianLocation != null)
        Marker(
          point: technicianLocation!,
          child:
              const Icon(Icons.location_pin, color: Colors.redAccent, size: 45),
        ),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text("تتبع الفني 🚗"),
        backgroundColor: Colors.blue.shade800,
        centerTitle: true,
      ),
      backgroundColor: const Color(0xFFF4F6FA),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // 🗺️ الخريطة
            SizedBox(
              height: MediaQuery.of(context).size.height * 0.45,
              child: FlutterMap(
                mapController: _mapController,
                options: MapOptions(
                  initialCenter: userLocation,
                  initialZoom: 13.5,
                ),
                children: [
                  TileLayer(
                    urlTemplate:
                        'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                    userAgentPackageName: 'doctor_car_app',
                  ),
                  MarkerLayer(markers: markers),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // 🧰 الخدمات المطلوبة
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Align(
                alignment: Alignment.centerRight,
                child: Text(
                  "🧰 الخدمات المطلوبة:",
                  style: TextStyle(
                    color: Colors.blue.shade900,
                    fontWeight: FontWeight.bold,
                    fontSize: 17,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: _buildServiceGrid(),
            ),
            const SizedBox(height: 24),

            // 📦 حالة الطلب + الاتصال + واتساب
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(18),
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(24),
                  topRight: Radius.circular(24),
                ),
              ),
              child: Column(
                children: [
                  const Text(
                    "📦 حالة الطلب",
                    style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    orderStatus,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Colors.blueAccent,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 14),

                  // أزرار التواصل
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: _confirmAndCall,
                          icon: const Icon(Icons.call, color: Colors.white),
                          label: const Text("اتصال بالفني"),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.orange,
                            foregroundColor: Colors.white,
                            minimumSize: const Size(double.infinity, 48),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: _openWhatsApp,
                          icon: const FaIcon(FontAwesomeIcons.whatsapp,
                              color: Colors.white),
                          label: const Text("واتساب"),
                          style: ElevatedButton.styleFrom(
                            backgroundColor:
                                const Color(0xFF25D366), // WhatsApp green
                            foregroundColor: Colors.white,
                            minimumSize: const Size(double.infinity, 48),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
