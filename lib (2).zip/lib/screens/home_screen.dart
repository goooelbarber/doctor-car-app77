// ===============================
//       HOME SCREEN — MERGED FINAL + Supplementary
// ===============================

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'package:doctor_car_app/screens/live_tracking_screen.dart';
import 'package:doctor_car_app/screens/account_settings_screen.dart';
import 'package:doctor_car_app/screens/smart_accident_screen.dart';
import 'package:doctor_car_app/screens/road_services_selection_screen.dart';
import 'package:doctor_car_app/screens/previous_services_screen.dart';
import 'package:doctor_car_app/screens/supplementary_services_screen.dart'; // ← إضافة مهمة

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  bool _isDarkMode = false;
  final int _selectedIndex = 0;
  bool _isDrawerOpen = false;

  late AnimationController _controller;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;
  late Animation<Offset> _drawerSlide;

  final Color _lightPrimary = const Color(0xFF1565C0);
  final Color _lightAccent = const Color(0xFFFFA000);
  final Color _darkBg = const Color(0xFF0E1420);

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    _fadeAnimation = CurvedAnimation(
      parent: _controller,
      curve: Curves.easeIn,
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.2),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));

    _drawerSlide = Tween<Offset>(
      begin: const Offset(-1.2, 0),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic));

    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _toggleTheme() {
    setState(() => _isDarkMode = !_isDarkMode);
  }

  void _toggleDrawer() {
    setState(() => _isDrawerOpen = !_isDrawerOpen);
  }

  // ================================
  // 🔥 إعادة إرسال طلب قديم
  // ================================
  void _repeatOrder(Map<String, dynamic> order) async {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text("🔁 جاري إعادة إرسال طلب: ${order['serviceName']}"),
        backgroundColor: Colors.orange,
        duration: const Duration(seconds: 2),
      ),
    );

    await Future.delayed(const Duration(seconds: 1));

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => LiveTrackingScreen(
          userId: "68fe4505493ae17aa81d605b",
          serviceType: order["serviceType"],
          selectedServices: const [],
          orderId: '',
        ),
      ),
    );
  }

  void _openTracking(String serviceType) async {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text("🚗 جاري إرسال طلبك..."),
        backgroundColor: Colors.blueAccent,
        duration: Duration(seconds: 2),
      ),
    );

    await Future.delayed(const Duration(seconds: 1));

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => LiveTrackingScreen(
          userId: "68fe4505493ae17aa81d605b",
          serviceType: serviceType,
          selectedServices: const [],
          orderId: '',
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bool isDark = _isDarkMode;

    final Color bgColor = isDark ? _darkBg : Colors.white;
    final Color textColor = isDark ? Colors.white : Colors.black87;
    final Color primaryColor = isDark ? Colors.blueAccent : _lightPrimary;
    final Color accentColor = isDark ? Colors.orangeAccent : _lightAccent;

    return Scaffold(
      backgroundColor: bgColor,
      body: Stack(
        children: [
          // ============================
          //          DRAWER
          // ============================
          SlideTransition(
            position: _drawerSlide,
            child: AnimatedOpacity(
              opacity: _isDrawerOpen ? 1 : 0,
              duration: const Duration(milliseconds: 400),
              child:
                  _buildDrawer(context, textColor, accentColor, primaryColor),
            ),
          ),

          // ============================
          //        MAIN CONTENT
          // ============================
          AnimatedContainer(
            duration: const Duration(milliseconds: 400),
            transform: Matrix4.translationValues(
              _isDrawerOpen ? 230 : 0,
              _isDrawerOpen ? 60 : 0,
              0,
            )..scale(_isDrawerOpen ? 0.88 : 1.0),
            curve: Curves.easeInOutCubic,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(_isDrawerOpen ? 25 : 0),
              boxShadow: _isDrawerOpen
                  ? [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.3),
                        blurRadius: 20,
                        offset: const Offset(0, 10),
                      )
                    ]
                  : [],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(_isDrawerOpen ? 25 : 0),
              child: Scaffold(
                backgroundColor: bgColor,

                // ============================
                //            APP BAR
                // ============================
                appBar: AppBar(
                  backgroundColor: bgColor,
                  elevation: 4,
                  centerTitle: true,
                  leading: IconButton(
                    icon: Icon(
                      _isDrawerOpen ? Icons.close : Icons.menu,
                      color: accentColor,
                      size: 30,
                    ),
                    onPressed: _toggleDrawer,
                  ),
                  actions: [
                    IconButton(
                      onPressed: _toggleTheme,
                      icon: Icon(
                        isDark ? Icons.light_mode : Icons.dark_mode,
                        color: accentColor,
                      ),
                    ),
                  ],
                  title: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(5),
                        decoration: BoxDecoration(
                          color: Colors.redAccent.withOpacity(0.1),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.directions_car,
                          color: Colors.redAccent,
                          size: 26,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        "Doctor Car",
                        style: GoogleFonts.cairo(
                          color: primaryColor,
                          fontWeight: FontWeight.bold,
                          fontSize: 22,
                        ),
                      ),
                    ],
                  ),
                ),

                // ============================
                //           BODY
                // ============================
                body: FadeTransition(
                  opacity: _fadeAnimation,
                  child: SlideTransition(
                    position: _slideAnimation,
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        children: [
                          Text(
                            "مركز التشخيص والخدمات الذكية",
                            style: GoogleFonts.cairo(
                              color: textColor,
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 20),

                          // ============================
                          //      BIG CARD
                          // ============================
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  accentColor.withOpacity(0.8),
                                  accentColor
                                ],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: [
                                BoxShadow(
                                  color: accentColor.withOpacity(0.5),
                                  offset: const Offset(4, 4),
                                  blurRadius: 12,
                                ),
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.3),
                                  offset: const Offset(-3, -3),
                                  blurRadius: 10,
                                ),
                              ],
                            ),
                            child: Row(
                              children: [
                                // خدمات الطريق
                                Expanded(
                                  child: GestureDetector(
                                    onTap: () {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (_) =>
                                              const RoadServicesSelectionScreen(),
                                        ),
                                      );
                                    },
                                    child: Container(
                                      height: 120,
                                      decoration: BoxDecoration(
                                        color: Colors.orangeAccent
                                            .withOpacity(0.2),
                                        borderRadius: BorderRadius.circular(15),
                                      ),
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          const Icon(Icons.alt_route,
                                              color: Colors.white, size: 45),
                                          const SizedBox(height: 6),
                                          Text(
                                            "خدمات الطريق",
                                            style: GoogleFonts.cairo(
                                              color: Colors.white,
                                              fontWeight: FontWeight.bold,
                                              fontSize: 18,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),

                                const SizedBox(width: 8),

                                // الطوارئ
                                Expanded(
                                  child: GestureDetector(
                                    onTap: () => _openTracking("طوارئ الطريق"),
                                    child: Container(
                                      height: 120,
                                      decoration: BoxDecoration(
                                        color:
                                            Colors.redAccent.withOpacity(0.25),
                                        borderRadius: BorderRadius.circular(15),
                                      ),
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          const Icon(Icons.emergency,
                                              color: Colors.white, size: 45),
                                          const SizedBox(height: 6),
                                          Text(
                                            "الطوارئ",
                                            style: GoogleFonts.cairo(
                                              color: Colors.white,
                                              fontWeight: FontWeight.bold,
                                              fontSize: 18,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),

                          const SizedBox(height: 30),

                          Text(
                            "🚀 اكتشف خدمات المساعدة والتشخيص المتقدمة!",
                            style: GoogleFonts.cairo(
                              color: accentColor,
                              fontSize: 15,
                              fontWeight: FontWeight.bold,
                            ),
                          ),

                          const SizedBox(height: 30),

                          // ============================
                          //       QUICK ACTIONS
                          // ============================
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              // ⭐ Auto Accident
                              GestureDetector(
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (_) =>
                                            const SmartAccidentScreen()),
                                  );
                                },
                                child: _build3DIcon(
                                  icon: Icons.car_crash,
                                  label: "Auto Accident",
                                  color: Colors.red.shade400,
                                  textColor: textColor,
                                ),
                              ),

                              // الخدمات الإضافية Supplementary
                              GestureDetector(
                                onTap: () async {
                                  final result = await Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) =>
                                          const SupplementaryServicesScreen(),
                                    ),
                                  );

                                  if (result != null) {
                                    _openTracking(result["type"]);
                                  }
                                },
                                child: _build3DIcon(
                                  icon: Icons.more_horiz,
                                  label: "More",
                                  color: Colors.purple,
                                  textColor: textColor,
                                ),
                              ),

                              _build3DIcon(
                                icon: Icons.call,
                                label: "Call",
                                color: const Color(0xFF60A5FA),
                                textColor: textColor,
                              ),

                              // 🔥 افتح الخدمات السابقة
                              GestureDetector(
                                onTap: () async {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) =>
                                          const PreviousServicesScreen(),
                                    ),
                                  ).then((order) {
                                    if (order != null) {
                                      _repeatOrder(order);
                                    }
                                  });
                                },
                                child: _build3DIcon(
                                  icon: Icons.history,
                                  label: "Previous",
                                  color: Colors.orange,
                                  textColor: textColor,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),

                // ============================
                //     Bottom Navigation
                // ============================
                bottomNavigationBar: BottomAppBar(
                  color: isDark ? Colors.grey.shade900 : Colors.white,
                  notchMargin: 10,
                  shape: const CircularNotchedRectangle(),
                  child: SizedBox(
                    height: 70,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _buildBottomIcon(
                          icon: Icons.person,
                          label: "حسابي",
                          selected: _selectedIndex == 1,
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => const AccountSettingsScreen(),
                              ),
                            );
                          },
                          color: accentColor,
                        ),
                        const SizedBox(width: 40),
                        _buildBottomIcon(
                          icon: Icons.home,
                          label: "الرئيسية",
                          selected: _selectedIndex == 0,
                          onTap: () {},
                          color: accentColor,
                        ),
                      ],
                    ),
                  ),
                ),

                floatingActionButton: FloatingActionButton(
                  backgroundColor: primaryColor,
                  onPressed: () => _openTracking("تواصل فوري"),
                  shape: const CircleBorder(),
                  child: const Icon(Icons.chat_bubble_outline, size: 28),
                ),
                floatingActionButtonLocation:
                    FloatingActionButtonLocation.centerDocked,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // =========================================
  //               DRAWER
  // =========================================
  Widget _buildDrawer(
      BuildContext context, Color textColor, Color accentColor, Color primary) {
    return Container(
      width: 250,
      decoration: const BoxDecoration(
        color: Color(0xFF1E293B),
        borderRadius: BorderRadius.only(
          topRight: Radius.circular(25),
          bottomRight: Radius.circular(25),
        ),
      ),
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          DrawerHeader(
            decoration: BoxDecoration(color: primary),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.directions_car, size: 60, color: Colors.white),
                const SizedBox(height: 10),
                Text(
                  "Doctor Car",
                  style: GoogleFonts.cairo(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                  ),
                ),
              ],
            ),
          ),
          _buildDrawerItem(Icons.info_outline, "من نحن", accentColor),
          _buildDrawerItem(
              Icons.contact_mail_rounded, "تواصل معنا", accentColor),
          _buildDrawerItem(Icons.settings, "الإعدادات", accentColor),
          ListTile(
            leading: Icon(Icons.more_horiz, color: accentColor),
            title: Text(
              "الخدمات الإضافية",
              style: GoogleFonts.cairo(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 15,
              ),
            ),
            onTap: () async {
              Navigator.pop(context);
              final result = await Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const SupplementaryServicesScreen(),
                ),
              );
              if (result != null) {
                _openTracking(result["type"]);
              }
            },
          ),
          ListTile(
            leading: Icon(Icons.history, color: accentColor),
            title: Text(
              "سجل الخدمات السابقة",
              style: GoogleFonts.cairo(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 15,
              ),
            ),
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const PreviousServicesScreen(),
                ),
              ).then((order) {
                if (order != null) {
                  _repeatOrder(order);
                }
              });
            },
          ),
        ],
      ),
    );
  }

  ListTile _buildDrawerItem(IconData icon, String title, Color color) {
    return ListTile(
      leading: Icon(icon, color: color),
      title: Text(
        title,
        style: GoogleFonts.cairo(
          color: Colors.white,
          fontWeight: FontWeight.bold,
          fontSize: 15,
        ),
      ),
      onTap: () => Navigator.pop(context),
    );
  }

  // =========================================
  //               3D ICON
  // =========================================
  Widget _build3DIcon({
    required IconData icon,
    required String label,
    required Color color,
    required Color textColor,
  }) {
    return Column(
      children: [
        Container(
          width: 80,
          height: 80,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                color.withOpacity(0.6),
                color.withOpacity(0.9),
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(25),
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.5),
                offset: const Offset(4, 4),
                blurRadius: 12,
              ),
              BoxShadow(
                color: Colors.black.withOpacity(0.4),
                offset: const Offset(-4, -4),
                blurRadius: 10,
              ),
            ],
          ),
          child: Icon(icon, color: Colors.white, size: 40),
        ),
        const SizedBox(height: 10),
        Text(
          label,
          style: GoogleFonts.cairo(
            color: textColor,
            fontWeight: FontWeight.bold,
            fontSize: 15,
          ),
        ),
      ],
    );
  }

  // =========================================
  //               BOTTOM NAV ICON
  // =========================================
  Widget _buildBottomIcon({
    required IconData icon,
    required String label,
    required bool selected,
    required VoidCallback onTap,
    required Color color,
  }) {
    return InkWell(
      onTap: onTap,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 26, color: selected ? color : Colors.grey.shade600),
          const SizedBox(height: 4),
          Text(
            label,
            style: GoogleFonts.cairo(
              fontSize: 13,
              color: selected ? color : Colors.grey.shade600,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}
