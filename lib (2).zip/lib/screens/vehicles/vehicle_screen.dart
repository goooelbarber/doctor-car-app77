import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:doctor_car_app/services/api_service.dart';
import 'add_vehicle_screen.dart';

class VehiclesScreen extends StatefulWidget {
  const VehiclesScreen({super.key});

  @override
  State<VehiclesScreen> createState() => _VehiclesScreenState();
}

class _VehiclesScreenState extends State<VehiclesScreen> {
  List<dynamic> vehicles = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchVehicles();
  }

  Future<void> _fetchVehicles() async {
    setState(() => _isLoading = true);

    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('token');

    if (token == null) {
      setState(() {
        _isLoading = false;
        vehicles = [];
      });
      return;
    }

    final res = await ApiService.getVehicles(token);

    setState(() {
      _isLoading = false;
      vehicles = res;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F8FB),
      appBar: AppBar(
        backgroundColor: Colors.blue.shade800,
        elevation: 0,
        centerTitle: true,
        title: const Text(
          "إدارة المركبات",
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : vehicles.isEmpty
              ? _buildEmptyState(context)
              : _buildVehiclesList(),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          final added = await Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const AddVehicleScreen()),
          );
          if (added == true) _fetchVehicles();
        },
        backgroundColor: Colors.blue.shade700,
        icon: const Icon(Icons.add),
        label: const Text("إضافة سيارة"),
      ),
    );
  }

  /// 🧩 شاشة فارغة عند عدم وجود سيارات
  Widget _buildEmptyState(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: Image.network(
                'https://cdn.pixabay.com/photo/2017/02/27/16/55/auto-2109441_1280.jpg',
                height: 180,
                width: 260,
                fit: BoxFit.cover,
              ),
            ),
            const SizedBox(height: 30),
            const Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(FontAwesomeIcons.car, color: Colors.redAccent, size: 18),
                SizedBox(width: 8),
                Text(
                  "لا توجد سيارات حتى الآن",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            const Text(
              "لم تقم بإضافة أي سيارات بعد.\nأضف سيارتك الأولى للبدء الآن 🚘",
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 14, height: 1.5, color: Colors.grey),
            ),
            const SizedBox(height: 25),
            ElevatedButton.icon(
              onPressed: () async {
                final added = await Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const AddVehicleScreen()),
                );
                if (added == true) _fetchVehicles();
              },
              icon: const Icon(Icons.add_circle_outline, color: Colors.white),
              label: const Text(
                "إنشاء سيارة جديدة",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green.shade600,
                foregroundColor: Colors.white,
                padding:
                    const EdgeInsets.symmetric(horizontal: 30, vertical: 14),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
                elevation: 5,
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// 🚗 عرض قائمة السيارات بعد الربط
  Widget _buildVehiclesList() {
    return RefreshIndicator(
      onRefresh: _fetchVehicles,
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: vehicles.length,
        itemBuilder: (context, index) {
          final v = vehicles[index];
          final condition = v["condition"] ?? "غير محدد";
          final color = _getConditionColor(condition);

          return Container(
            margin: const EdgeInsets.symmetric(vertical: 10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.08),
                  blurRadius: 8,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Row(
              children: [
                Container(
                  width: 6,
                  height: 140,
                  decoration: BoxDecoration(
                    color: color,
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(16),
                      bottomLeft: Radius.circular(16),
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              v["brand"] ?? "غير معروف",
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const Icon(FontAwesomeIcons.car,
                                color: Colors.blue),
                          ],
                        ),
                        const SizedBox(height: 8),
                        _infoRow("الموديل", v["model"]),
                        _infoRow("اللون", v["color"]),
                        _infoRow("رقم اللوحة", v["plateNumber"]),
                        const SizedBox(height: 10),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              condition,
                              style: TextStyle(
                                color: color,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Row(
                              children: [
                                IconButton(
                                  onPressed: () {
                                    // تعديل المركبة لاحقاً
                                  },
                                  icon: const Icon(
                                    FontAwesomeIcons.penToSquare,
                                    color: Colors.orange,
                                  ),
                                ),
                                IconButton(
                                  onPressed: () {
                                    _deleteVehicle(v["_id"]);
                                  },
                                  icon: const Icon(
                                    FontAwesomeIcons.trash,
                                    color: Colors.redAccent,
                                  ),
                                ),
                              ],
                            )
                          ],
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _infoRow(String label, dynamic value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(value?.toString() ?? "-", style: const TextStyle(fontSize: 15)),
          Text(label,
              style: const TextStyle(
                  color: Colors.grey, fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }

  Color _getConditionColor(String condition) {
    switch (condition) {
      case "ممتازة":
        return Colors.green.shade600;
      case "جيدة جدًا":
        return Colors.orange.shade600;
      case "تحتاج صيانة":
        return Colors.red.shade600;
      default:
        return Colors.grey;
    }
  }

  Future<void> _deleteVehicle(String? id) async {
    if (id == null) return;

    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('token');

    if (token == null) return;

    final confirm = await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("تأكيد الحذف"),
        content: const Text("هل أنت متأكد من حذف هذه السيارة؟"),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text("إلغاء")),
          TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text("نعم، حذف")),
        ],
      ),
    );

    if (confirm != true) return;

    final res = await ApiService.deleteVehicle(token, id);
    if (res["error"] == true) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(res["message"]),
        backgroundColor: Colors.redAccent,
      ));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text("🚗 تم حذف السيارة بنجاح"),
        backgroundColor: Colors.green,
      ));
      _fetchVehicles();
    }
  }
}
