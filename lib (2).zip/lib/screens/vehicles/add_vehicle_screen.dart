import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:doctor_car_app/services/api_service.dart';

class AddVehicleScreen extends StatefulWidget {
  const AddVehicleScreen({super.key});

  @override
  State<AddVehicleScreen> createState() => _AddVehicleScreenState();
}

class _AddVehicleScreenState extends State<AddVehicleScreen> {
  final _formKey = GlobalKey<FormState>();
  bool _isLoading = false;

  final yearCtrl = TextEditingController();
  final plateCtrl = TextEditingController();
  final chassisCtrl = TextEditingController();

  String? selectedBrand,
      selectedModel,
      selectedFuel,
      selectedCondition,
      selectedColor;

  final Map<String, List<String>> carBrands = {
    "Toyota": ["Corolla", "Camry", "Yaris", "RAV4"],
    "Hyundai": ["Elantra", "Sonata", "Tucson", "Accent"],
    "Kia": ["Sportage", "Cerato", "Rio"],
    "BMW": ["X3", "X5", "3 Series"],
    "Mercedes": ["C-Class", "E-Class", "GLA"],
    "Nissan": ["Sunny", "Altima", "Patrol"],
    "Chevrolet": ["Cruze", "Malibu", "Spark"],
    "Ford": ["Focus", "Explorer", "Mustang"],
  };

  final fuelTypes = ["بنزين", "ديزل", "هايبرد", "كهرباء"];
  final conditions = ["ممتازة", "جيدة جدًا", "جيدة", "تحتاج صيانة"];
  final colors = ["أبيض", "أسود", "رمادي", "فضي", "أزرق", "أحمر", "ذهبي"];

  Future<void> _saveVehicle() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isLoading = true);

    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('token');

    if (token == null) {
      // ignore: use_build_context_synchronously
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text("⚠️ يجب تسجيل الدخول أولًا"),
        backgroundColor: Colors.redAccent,
      ));
      setState(() => _isLoading = false);
      return;
    }

    final res = await ApiService.addVehicle(
      token,
      brand: selectedBrand!,
      model: selectedModel!,
      fuel: selectedFuel!,
      condition: selectedCondition!,
      plateNumber: plateCtrl.text.trim(),
      year: yearCtrl.text.trim(),
      color: selectedColor!,
      chassisNumber: chassisCtrl.text.trim(),
    );

    setState(() => _isLoading = false);

    if (res["error"] == true) {
      // ignore: use_build_context_synchronously
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(res["message"]),
        backgroundColor: Colors.redAccent,
      ));
    } else {
      // ignore: use_build_context_synchronously
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text("✅ تم إضافة السيارة بنجاح"),
        backgroundColor: Colors.green,
      ));
      // ignore: use_build_context_synchronously
      Navigator.pop(context, true);
    }
  }

  InputDecoration _inputDecoration({required IconData icon, String? hint}) {
    return InputDecoration(
      hintText: hint,
      prefixIcon: Icon(icon, color: Colors.blue.shade800),
      filled: true,
      fillColor: const Color(0xFFF8FAFF),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(15),
        borderSide: BorderSide(color: Colors.blue.shade100),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(15),
        borderSide: BorderSide(color: Colors.blue.shade100),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(15),
        borderSide: BorderSide(color: Colors.blue.shade400, width: 1.5),
      ),
    );
  }

  Widget _dropdown(String label, String? value, List<String> items,
      IconData icon, void Function(String?) onChanged) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Text(label,
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
        const SizedBox(height: 6),
        DropdownButtonFormField<String>(
          value: value,
          icon: const Icon(Icons.keyboard_arrow_down_rounded),
          decoration: _inputDecoration(icon: icon),
          dropdownColor: Colors.white,
          items: items
              .map((e) => DropdownMenuItem(value: e, child: Text(e)))
              .toList(),
          onChanged: onChanged,
          validator: (v) => v == null ? "الرجاء الاختيار" : null,
        ),
        const SizedBox(height: 14),
      ],
    );
  }

  Widget _textField(
      TextEditingController controller, String label, IconData icon,
      {TextInputType type = TextInputType.text}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Text(label,
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
        const SizedBox(height: 6),
        TextFormField(
          controller: controller,
          textAlign: TextAlign.right,
          keyboardType: type,
          decoration: _inputDecoration(icon: icon, hint: label),
          validator: (v) => v == null || v.isEmpty ? "هذا الحقل مطلوب" : null,
        ),
        const SizedBox(height: 14),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF3F6FC),
      appBar: AppBar(
        backgroundColor: Colors.blue.shade800,
        title: const Text("إضافة سيارة جديدة 🚗",
            style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
        elevation: 2,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                    color: Colors.black.withOpacity(0.07),
                    blurRadius: 8,
                    offset: const Offset(0, 4))
              ],
            ),
            child: Column(
              children: [
                _dropdown("الماركة", selectedBrand, carBrands.keys.toList(),
                    FontAwesomeIcons.car, (val) {
                  setState(() {
                    selectedBrand = val;
                    selectedModel = null;
                  });
                }),
                if (selectedBrand != null)
                  _dropdown(
                      "الموديل",
                      selectedModel,
                      carBrands[selectedBrand] ?? [],
                      FontAwesomeIcons.gear, (val) {
                    setState(() => selectedModel = val);
                  }),
                _dropdown("نوع الوقود", selectedFuel, fuelTypes,
                    FontAwesomeIcons.gasPump, (val) {
                  setState(() => selectedFuel = val);
                }),
                _dropdown("حالة السيارة", selectedCondition, conditions,
                    FontAwesomeIcons.screwdriverWrench, (val) {
                  setState(() => selectedCondition = val);
                }),
                _dropdown(
                    "اللون", selectedColor, colors, FontAwesomeIcons.palette,
                    (val) {
                  setState(() => selectedColor = val);
                }),
                _textField(yearCtrl, "سنة الصنع", FontAwesomeIcons.calendarDays,
                    type: TextInputType.number),
                _textField(plateCtrl, "رقم اللوحة", FontAwesomeIcons.idCard),
                _textField(chassisCtrl, "رقم الهيكل (الشاصي)",
                    FontAwesomeIcons.hashtag),
                const SizedBox(height: 20),
                ElevatedButton.icon(
                  onPressed: _isLoading ? null : _saveVehicle,
                  icon: const Icon(FontAwesomeIcons.floppyDisk, size: 18),
                  label: Text(
                    _isLoading ? "جارٍ الحفظ..." : "إضافة السيارة الجديدة",
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green.shade600,
                    foregroundColor: Colors.white,
                    minimumSize: const Size(double.infinity, 55),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
