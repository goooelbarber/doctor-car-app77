import 'package:flutter/material.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;

class ChatScreen extends StatefulWidget {
  final String orderId;

  const ChatScreen({super.key, required this.orderId});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  late IO.Socket socket;
  final TextEditingController msgCtrl = TextEditingController();
  List<Map<String, String>> messages = [];

  @override
  void initState() {
    super.initState();

    socket = IO.io("http://192.168.1.10:5001",
        IO.OptionBuilder().setTransports(["websocket"]).build());

    socket.onConnect((_) {
      socket.emit("joinOrderRoom", widget.orderId);
    });

    socket.on("chatMessage", (data) {
      setState(() {
        messages.add({"from": data["from"], "msg": data["msg"]});
      });
    });
  }

  void sendMessage() {
    socket.emit("chatMessage", {
      "orderId": widget.orderId,
      "from": "user",
      "msg": msgCtrl.text,
    });
    msgCtrl.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("محادثة الفني")),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              children: messages
                  .map((m) => ListTile(
                        title: Text(m["msg"]!),
                        subtitle: Text(m["from"]!),
                      ))
                  .toList(),
            ),
          ),
          Row(
            children: [
              Expanded(
                child: TextField(controller: msgCtrl),
              ),
              IconButton(
                icon: const Icon(Icons.send),
                onPressed: sendMessage,
              )
            ],
          )
        ],
      ),
    );
  }
}
