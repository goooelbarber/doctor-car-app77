import 'dart:async';
import 'package:doctor_car_app/services/api_service.dart';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';
import 'package:shared_preferences/shared_preferences.dart';

class FindTechnicianScreen extends StatefulWidget {
  const FindTechnicianScreen({super.key});

  @override
  State<FindTechnicianScreen> createState() => _FindTechnicianScreenState();
}

class _FindTechnicianScreenState extends State<FindTechnicianScreen> {
  final MapController _mapController = MapController();
  final List<Map<String, dynamic>> services = [
    {"name": "ونش", "icon": Icons.local_shipping, "value": "tow"},
    {"name": "بطارية", "icon": Icons.battery_charging_full, "value": "battery"},
    {"name": "كاوتش", "icon": Icons.tire_repair, "value": "tire"},
    {"name": "وقود", "icon": Icons.local_gas_station, "value": "fuel"},
    {"name": "صيانة عامة", "icon": Icons.build, "value": "mechanic"},
  ];

  String? selectedService;
  bool _loading = false;
  Position? _currentPosition;
  List<dynamic> technicians = [];

  @override
  void initState() {
    super.initState();
    _determinePosition();
  }

  Future<void> _determinePosition() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      // ignore: use_build_context_synchronously
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("يرجى تفعيل GPS")),
      );
      return;
    }

    LocationPermission permission = await Geolocator.requestPermission();
    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) {
      // ignore: use_build_context_synchronously
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("تم رفض إذن تحديد الموقع")),
      );
      return;
    }

    final pos = await Geolocator.getCurrentPosition();
    setState(() => _currentPosition = pos);
  }

  Future<void> _fetchTechnicians() async {
    if (selectedService == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("يرجى اختيار نوع الخدمة")),
      );
      return;
    }

    if (_currentPosition == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("جارٍ تحديد موقعك...")),
      );
      return;
    }

    setState(() => _loading = true);

    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('token');
    final res = await ApiService.getTechnicians(
      token!,
      selectedService!,
      _currentPosition!.latitude,
      _currentPosition!.longitude,
    );

    setState(() {
      _loading = false;
      technicians = res;
    });
  }

  void _showTechnicianDetails(dynamic tech) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(18))),
      builder: (_) {
        return Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                tech["name"] ?? "فني مجهول",
                style:
                    const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
              ),
              const SizedBox(height: 6),
              Text("الخدمة: ${tech["serviceType"] ?? "-"}"),
              Text("التقييم: ${tech["rating"] ?? "غير متوفر"}⭐"),
              Text(
                  "المسافة: ${tech["distance"]?.toStringAsFixed(1) ?? "?"} كم"),
              const SizedBox(height: 16),
              ElevatedButton.icon(
                onPressed: () {
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text("تم إرسال طلب إلى ${tech["name"]} 🚗"),
                      backgroundColor: Colors.green.shade600,
                    ),
                  );
                },
                icon: const Icon(Icons.check_circle_outline),
                label: const Text("اختيار هذا الفني"),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green.shade700,
                  minimumSize: const Size(double.infinity, 45),
                ),
              )
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF6F8FA),
      appBar: AppBar(
        backgroundColor: Colors.blue.shade800,
        centerTitle: true,
        title: const Text("🔍 ابحث عن فني"),
      ),
      body: Column(
        children: [
          _buildServiceSelector(),
          Expanded(
            child: _currentPosition == null
                ? const Center(child: Text("جارٍ تحديد موقعك..."))
                : Stack(
                    children: [
                      FlutterMap(
                        mapController: _mapController,
                        options: MapOptions(
                          initialCenter: LatLng(
                            _currentPosition!.latitude,
                            _currentPosition!.longitude,
                          ),
                          initialZoom: 14.5,
                          interactionOptions: const InteractionOptions(
                              flags: InteractiveFlag.all),
                        ),
                        children: [
                          TileLayer(
                            urlTemplate:
                                'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
                            subdomains: const ['a', 'b', 'c'],
                            userAgentPackageName: 'doctor_car_app',
                          ),
                          MarkerLayer(
                            markers: [
                              // موقع المستخدم
                              Marker(
                                point: LatLng(_currentPosition!.latitude,
                                    _currentPosition!.longitude),
                                width: 50,
                                height: 50,
                                child: const Icon(Icons.my_location,
                                    color: Colors.blue, size: 32),
                              ),
                              // الفنيين
                              ...technicians.map((tech) {
                                return Marker(
                                  point: LatLng(
                                    tech["location"]["lat"],
                                    tech["location"]["lng"],
                                  ),
                                  width: 55,
                                  height: 55,
                                  child: GestureDetector(
                                    onTap: () => _showTechnicianDetails(tech),
                                    child: const Icon(
                                      Icons.location_on,
                                      color: Colors.redAccent,
                                      size: 40,
                                    ),
                                  ),
                                );
                                // ignore: unnecessary_to_list_in_spreads
                              }).toList(),
                            ],
                          ),
                        ],
                      ),
                      if (_loading)
                        const Center(
                          child: CircularProgressIndicator(
                            color: Colors.blue,
                          ),
                        ),
                    ],
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildServiceSelector() {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.all(10),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: services.map((s) {
            final isSelected = selectedService == s["value"];
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 6),
              child: ChoiceChip(
                label: Row(
                  children: [
                    Icon(s["icon"],
                        color:
                            isSelected ? Colors.white : Colors.blue.shade700),
                    const SizedBox(width: 6),
                    Text(
                      s["name"],
                      style: TextStyle(
                        color: isSelected ? Colors.white : Colors.blue.shade800,
                      ),
                    ),
                  ],
                ),
                selected: isSelected,
                selectedColor: Colors.blue.shade700,
                backgroundColor: Colors.grey.shade100,
                onSelected: (_) {
                  setState(() {
                    selectedService = s["value"];
                  });
                  _fetchTechnicians();
                },
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}
