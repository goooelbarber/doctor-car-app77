import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import '../config/api_config.dart';

class FeedbackScreen extends StatefulWidget {
  final String orderId;
  final String userId; // لو حابب ترسله
  final String? technicianName; // اختياري للعرض

  const FeedbackScreen({
    super.key,
    required this.orderId,
    required this.userId,
    this.technicianName,
  });

  @override
  State<FeedbackScreen> createState() => _FeedbackScreenState();
}

class _FeedbackScreenState extends State<FeedbackScreen> {
  double _rating = 5.0;
  final TextEditingController _commentCtrl = TextEditingController();
  bool _submitting = false;

  Future<void> _submitFeedback() async {
    if (_submitting) return;
    setState(() => _submitting = true);

    try {
      final res = await http.post(
        Uri.parse(ApiConfig.feedback),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "orderId": widget.orderId,
          "userId": widget.userId,
          "rating": _rating,
          "comment": _commentCtrl.text.trim(),
        }),
      );

      final data = jsonDecode(res.body);
      if (res.statusCode == 201 || data["success"] == true) {
        if (!mounted) return;
        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            title: const Text("شكراً لك!"),
            content: const Text("تم إرسال التقييم بنجاح ✅"),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context); // close dialog
                  Navigator.popUntil(
                      context, (route) => route.isFirst); // رجوع للرئيسية
                },
                child: const Text("تم"),
              ),
            ],
          ),
        );
      } else {
        _showError(data["message"] ?? "تعذر إرسال التقييم");
      }
    } catch (e) {
      _showError("حدث خطأ أثناء الإرسال");
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  void _showError(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("❌ $msg")),
    );
  }

  @override
  Widget build(BuildContext context) {
    const primary = Colors.blueAccent;
    // ignore: unused_local_variable
    const accent = Colors.orangeAccent;

    return Scaffold(
      appBar: AppBar(
        title: const Text("تقييم الخدمة ⭐"),
        backgroundColor: primary,
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: ListView(
          children: [
            if (widget.technicianName != null)
              Center(
                child: Text(
                  "الفني: ${widget.technicianName}",
                  style: GoogleFonts.cairo(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: primary,
                  ),
                ),
              ),
            const SizedBox(height: 20),
            Center(
              child: RatingBar.builder(
                initialRating: _rating,
                minRating: 1,
                allowHalfRating: true,
                itemCount: 5,
                itemSize: 40,
                itemBuilder: (context, _) =>
                    const Icon(Icons.star, color: Colors.amber),
                onRatingUpdate: (value) => setState(() => _rating = value),
              ),
            ),
            const SizedBox(height: 25),
            Text(
              "اكتب تعليقك (اختياري)",
              style:
                  GoogleFonts.cairo(fontSize: 16, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _commentCtrl,
              maxLines: 5,
              decoration: InputDecoration(
                hintText: "شاركنا رأيك لتحسين خدمتنا...",
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
            const SizedBox(height: 30),
            SizedBox(
              height: 52,
              child: ElevatedButton.icon(
                onPressed: _submitting ? null : _submitFeedback,
                icon: _submitting
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(
                            strokeWidth: 2, color: Colors.white))
                    : const Icon(Icons.send, color: Colors.white),
                label: Text(
                  _submitting ? "جاري الإرسال..." : "إرسال التقييم",
                  style: GoogleFonts.cairo(
                      fontSize: 18, fontWeight: FontWeight.bold),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: primary,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                ),
              ),
            ),
            const SizedBox(height: 10),
            Text(
              "طلب رقم: ${widget.orderId}",
              textAlign: TextAlign.center,
              style: GoogleFonts.cairo(color: Colors.grey[600]),
            ),
          ],
        ),
      ),
    );
  }
}
