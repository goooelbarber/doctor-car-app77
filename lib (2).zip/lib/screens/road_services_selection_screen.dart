import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'live_tracking_screen.dart';

class RoadServicesSelectionScreen extends StatefulWidget {
  const RoadServicesSelectionScreen({super.key});

  @override
  State<RoadServicesSelectionScreen> createState() =>
      _RoadServicesSelectionScreenState();
}

class _RoadServicesSelectionScreenState
    extends State<RoadServicesSelectionScreen> with TickerProviderStateMixin {
  final Set<String> _selected = {};
  bool _showMap = false;
  LatLng _userPosition = const LatLng(31.4175, 31.8153); // دمياط كمثال

  late AnimationController _controller;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  final List<Map<String, dynamic>> services = [
    {
      "key": "tow",
      "title": "خدمة ونش 🚚",
      "image": "assets/images/tow_truck.png",
    },
    {
      "key": "battery",
      "title": "خدمة بطارية 🔋",
      "image": "assets/images/battery.png",
    },
    {
      "key": "fuel",
      "title": "خدمة بنزين ⛽",
      "image": "assets/images/fuel.png",
    },
    {
      "key": "tire",
      "title": "خدمة الكاوتش 🛞",
      "image": "assets/images/tire.png",
    },
    {
      "key": "ride",
      "title": "سيارة ركاب 🚗",
      "image": "assets/images/car.png",
    },
  ];

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );

    _fadeAnimation = CurvedAnimation(
      parent: _controller,
      curve: Curves.easeIn,
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.15),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOut),
    );

    _controller.forward();
  }

  void _confirmOrder() {
    if (_selected.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("يرجى اختيار خدمة أولاً"),
          backgroundColor: Colors.redAccent,
        ),
      );
      return;
    }

    setState(() {
      _showMap = true;
    });

    // بعد ثانيتين ينتقل إلى تتبع الفني
    Timer(const Duration(seconds: 2), () {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => LiveTrackingScreen(
            userId: "68fe4505493ae17aa81d605b",
            serviceType: _selected.join(", "),
            selectedServices: _selected.toList(),
            orderId: '',
          ),
        ),
      );
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  // تصميم كارت الخدمة
  Widget _buildServiceCard(Map<String, dynamic> service, bool selected) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      curve: Curves.easeOut,
      decoration: BoxDecoration(
        color: selected ? const Color(0xFFDFFFE0) : Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: selected ? Colors.green : Colors.grey.shade300,
          width: selected ? 2 : 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () {
          setState(() {
            if (selected) {
              _selected.remove(service["key"]);
            } else {
              _selected.add(service["key"]);
            }
          });
        },
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(service["image"], width: 65, height: 65),
            const SizedBox(height: 8),
            Text(
              service["title"],
              textAlign: TextAlign.center,
              style: GoogleFonts.cairo(
                fontWeight: FontWeight.bold,
                color: selected ? Colors.green.shade800 : Colors.black87,
                fontSize: 15,
              ),
            ),
            const SizedBox(height: 6),
            Icon(
              selected ? Icons.check_circle : Icons.circle_outlined,
              color: selected ? Colors.green : Colors.grey.shade400,
              size: 22,
            ),
          ],
        ),
      ),
    );
  }

  // خريطة صغيرة تظهر بعد الطلب
  Widget _buildMiniMap() {
    return AnimatedOpacity(
      duration: const Duration(milliseconds: 600),
      opacity: _showMap ? 1 : 0,
      child: Container(
        margin: const EdgeInsets.only(top: 20),
        height: 200,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
              color: Colors.green.withOpacity(0.25),
              blurRadius: 10,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: FlutterMap(
            options: MapOptions(
              initialCenter: _userPosition,
              initialZoom: 13.5,
            ),
            children: [
              TileLayer(
                urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                userAgentPackageName: 'doctor_car_app',
              ),
              MarkerLayer(markers: [
                Marker(
                  point: _userPosition,
                  width: 45,
                  height: 45,
                  child: const Icon(
                    Icons.location_pin,
                    color: Colors.redAccent,
                    size: 38,
                  ),
                ),
              ]),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7FBF7),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 2,
        title: Text(
          "خدمات الطريق 🚘",
          style: GoogleFonts.cairo(
            color: Colors.black87,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded,
              color: Colors.black87),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: FadeTransition(
        opacity: _fadeAnimation,
        child: SlideTransition(
          position: _slideAnimation,
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            child: Column(
              children: [
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.08),
                        blurRadius: 10,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      Text(
                        "اختر نوع الخدمة المطلوبة",
                        style: GoogleFonts.cairo(
                          fontWeight: FontWeight.bold,
                          color: Colors.black87,
                          fontSize: 17,
                        ),
                      ),
                      const SizedBox(height: 12),
                      GridView.builder(
                        itemCount: services.length,
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        gridDelegate:
                            const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          crossAxisSpacing: 12,
                          mainAxisSpacing: 12,
                          childAspectRatio: 1.0,
                        ),
                        itemBuilder: (context, index) {
                          final service = services[index];
                          final selected = _selected.contains(service["key"]);
                          return _buildServiceCard(service, selected);
                        },
                      ),
                      const SizedBox(height: 16),
                      SizedBox(
                        width: double.infinity,
                        height: 56,
                        child: ElevatedButton(
                          onPressed: _confirmOrder,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.green.shade600,
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14),
                            ),
                            elevation: 5,
                            shadowColor: Colors.greenAccent.withOpacity(0.3),
                          ),
                          child: Text(
                            "طلب الخدمة",
                            style: GoogleFonts.cairo(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                if (_showMap) _buildMiniMap(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
