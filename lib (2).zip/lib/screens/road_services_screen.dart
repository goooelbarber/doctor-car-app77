import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import '../config/api_config.dart';
import 'live_tracking_screen.dart';

class RoadServicesScreen extends StatefulWidget {
  const RoadServicesScreen({super.key});

  @override
  State<RoadServicesScreen> createState() => _RoadServicesScreenState();
}

class _RoadServicesScreenState extends State<RoadServicesScreen> {
  final MapController _mapController = MapController();
  LatLng? _userPosition;
  bool _loading = true;

  String? _selectedService;
  List<dynamic> _technicians = [];

  final Map<String, Map<String, String>> _services = {
    "tow": {"name": "خدمة ونش", "img": "assets/images/tow_truck.png"},
    "battery": {"name": "خدمة بطارية", "img": "assets/images/battery.png"},
    "fuel": {"name": "خدمة بنزين", "img": "assets/images/fuel.png"},
    "tire": {"name": "خدمة الكاوتش", "img": "assets/images/tire.png"},
    "ride": {"name": "سيارة ركاب", "img": "assets/images/car.png"},
  };

  @override
  void initState() {
    super.initState();
    _determinePosition();
  }

  /// 🧭 تحديد موقع المستخدم الحالي
  Future<void> _determinePosition() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      setState(() => _loading = false);
      return;
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }

    if (permission == LocationPermission.deniedForever ||
        permission == LocationPermission.denied) {
      setState(() => _loading = false);
      return;
    }

    final pos = await Geolocator.getCurrentPosition();
    setState(() {
      _userPosition = LatLng(pos.latitude, pos.longitude);
      _loading = false;
    });
  }

  /// 🔍 جلب الفنيين حسب نوع الخدمة
  Future<void> _fetchTechnicians(String serviceType) async {
    setState(() {
      _selectedService = serviceType;
      _technicians = [];
    });

    try {
      final url = Uri.parse(
          "${ApiConfig.baseUrl}/api/technicians?service=$serviceType");
      final res = await http.get(url);

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        setState(() => _technicians = data);
      }
    } catch (e) {
      debugPrint("❌ خطأ في جلب الفنيين: $e");
    }
  }

  /// 📍 إنشاء العلامات على الخريطة
  List<Marker> _buildMarkers() {
    final markers = <Marker>[];

    if (_userPosition != null) {
      markers.add(
        Marker(
          point: _userPosition!,
          width: 45,
          height: 45,
          child: const Icon(Icons.person_pin_circle,
              color: Colors.blueAccent, size: 40),
        ),
      );
    }

    for (var tech in _technicians) {
      if (tech["location"] != null && tech["location"]["coordinates"] != null) {
        final coords = tech["location"]["coordinates"];
        if (coords.length == 2) {
          markers.add(
            Marker(
              point: LatLng(coords[1], coords[0]),
              width: 45,
              height: 45,
              child: const Icon(Icons.location_on,
                  color: Colors.redAccent, size: 36),
            ),
          );
        }
      }
    }

    return markers;
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      backgroundColor: const Color(0xFFF4F6FA),
      appBar: AppBar(
        title: const Text("خدمات الطريق 🚗",
            style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
        backgroundColor: Colors.blue.shade800,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(height: 12),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: GridView.count(
                crossAxisCount: 3,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                children: _services.entries.map((entry) {
                  final key = entry.key;
                  final data = entry.value;
                  final isSelected = _selectedService == key;
                  return GestureDetector(
                    onTap: () => _fetchTechnicians(key),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 250),
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: isSelected ? Colors.blue.shade50 : Colors.white,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color:
                              isSelected ? Colors.blue : Colors.grey.shade300,
                          width: 2,
                        ),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Image.asset(data["img"]!, width: 50, height: 50),
                          const SizedBox(height: 8),
                          Text(
                            data["name"]!,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: isSelected
                                  ? Colors.blue.shade800
                                  : Colors.black87,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
            const SizedBox(height: 12),
            if (_selectedService != null)
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: ElevatedButton.icon(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => LiveTrackingScreen(
                          orderId:
                              "ORDER_${DateTime.now().millisecondsSinceEpoch}",
                          selectedServices: [_selectedService!],
                          userId: '',
                          serviceType: '',
                        ),
                      ),
                    );
                  },
                  icon: const Icon(Icons.directions_car),
                  label: const Text("طلب الخدمة الآن"),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.orange,
                    foregroundColor: Colors.white,
                    minimumSize: const Size(double.infinity, 50),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                ),
              ),
            const SizedBox(height: 8),
            if (_userPosition != null)
              SizedBox(
                height: 400,
                child: FlutterMap(
                  mapController: _mapController,
                  options: MapOptions(
                    initialCenter: _userPosition!,
                    initialZoom: 13.0,
                  ),
                  children: [
                    TileLayer(
                      urlTemplate:
                          'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                      userAgentPackageName: 'doctor_car_app',
                    ),
                    MarkerLayer(markers: _buildMarkers()),
                  ],
                ),
              )
            else
              const Padding(
                padding: EdgeInsets.all(20),
                child: Text(
                  "تعذر تحديد موقعك الحالي، يرجى تفعيل GPS 🔄",
                  style: TextStyle(color: Colors.redAccent),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
