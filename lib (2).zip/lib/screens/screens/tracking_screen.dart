import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:socket_io_client/socket_io_client.dart' as IO;

class LiveTrackingScreen extends StatefulWidget {
  final String userId;
  final String serviceType;

  const LiveTrackingScreen({
    super.key,
    required this.userId,
    required this.serviceType,
  });

  @override
  State<LiveTrackingScreen> createState() => _LiveTrackingScreenState();
}

class _LiveTrackingScreenState extends State<LiveTrackingScreen> {
  GoogleMapController? _mapController;
  IO.Socket? socket;
  Marker? technicianMarker;
  Marker? userMarker;
  LatLng? userPosition;
  LatLng? technicianPosition;

  bool isOrderCreated = false;
  String? orderId;
  String orderStatus = "جارٍ إنشاء الطلب...";

  @override
  void initState() {
    super.initState();
    _initUserLocation();
  }

  // 📍 الحصول على موقع المستخدم الحالي
  Future<void> _initUserLocation() async {
    final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);

    setState(() {
      userPosition = LatLng(pos.latitude, pos.longitude);
      userMarker = Marker(
        markerId: const MarkerId("user"),
        position: userPosition!,
        infoWindow: const InfoWindow(title: "موقعك"),
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueAzure),
      );
    });

    await _createOrder();
  }

  // 📦 إرسال الطلب للسيرفر
  Future<void> _createOrder() async {
    final url = Uri.parse(
        "http://10.0.2.2:5000/api/orders"); // غيّر IP إذا كنت على جهاز حقيقي
    final response = await http.post(
      url,
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({
        "userId": widget.userId,
        "serviceType": widget.serviceType,
        "location": {
          "lat": userPosition!.latitude,
          "lng": userPosition!.longitude,
          "address": "موقع العميل"
        }
      }),
    );

    final data = jsonDecode(response.body);
    print("📩 استجابة السيرفر: $data");

    if (data["success"]) {
      setState(() {
        isOrderCreated = true;
        orderId = data["order"]["_id"];
        orderStatus = data["order"]["status"];
      });
      _initSocket();
    } else {
      setState(() => orderStatus = "فشل إنشاء الطلب");
    }
  }

  // ⚙️ الاتصال بـ Socket.IO
  void _initSocket() {
    socket = IO.io("http://10.0.2.2:5000", <String, dynamic>{
      "transports": ["websocket"],
      "autoConnect": true,
    });

    socket!.onConnect((_) {
      print("✅ متصل بـ Socket.IO");
      socket!.emit("joinOrderRoom", orderId);
    });

    // 📍 تحديث موقع الفني لايف
    socket!.on("technicianLocationUpdate", (data) {
      print("📡 موقع الفني الجديد: $data");
      if (data is Map && data["location"] != null) {
        final loc = data["location"];
        setState(() {
          technicianPosition = LatLng(loc["lat"], loc["lng"]);
          technicianMarker = Marker(
            markerId: const MarkerId("technician"),
            position: technicianPosition!,
            infoWindow: const InfoWindow(title: "الفني"),
            icon: BitmapDescriptor.defaultMarkerWithHue(
                BitmapDescriptor.hueOrange),
          );
        });

        if (_mapController != null) {
          _mapController!
              .animateCamera(CameraUpdate.newLatLng(technicianPosition!));
        }
      }
    });

    // 🔄 تحديث حالة الطلب
    socket!.on("orderStatusUpdated", (data) {
      setState(() => orderStatus = data["status"]);
      print("📦 حالة الطلب: $data");
    });

    socket!.onDisconnect((_) => print("🔴 تم قطع الاتصال بـ Socket.IO"));
  }

  @override
  void dispose() {
    socket?.disconnect();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final markers = <Marker>{};
    if (userMarker != null) markers.add(userMarker!);
    if (technicianMarker != null) markers.add(technicianMarker!);

    return Scaffold(
      appBar: AppBar(
        title: const Text("تتبع الفني 🚗"),
        backgroundColor: Colors.blueAccent,
      ),
      body: userPosition == null
          ? const Center(child: CircularProgressIndicator())
          : Stack(
              children: [
                GoogleMap(
                  initialCameraPosition:
                      CameraPosition(target: userPosition!, zoom: 14),
                  markers: markers,
                  onMapCreated: (controller) => _mapController = controller,
                ),
                Positioned(
                  bottom: 20,
                  left: 20,
                  right: 20,
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(15),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.2),
                          blurRadius: 6,
                        )
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          "📦 حالة الطلب:",
                          style: const TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 16),
                        ),
                        Text(
                          orderStatus,
                          style: const TextStyle(
                              color: Colors.blueAccent, fontSize: 18),
                        ),
                        const SizedBox(height: 10),
                        ElevatedButton.icon(
                          icon: const Icon(Icons.call),
                          label: const Text("اتصال بالفني"),
                          onPressed: () {},
                        )
                      ],
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}
