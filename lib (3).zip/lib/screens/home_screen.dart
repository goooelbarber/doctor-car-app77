// ignore_for_file: depend_on_referenced_packages

import 'dart:convert';
import 'dart:ui';
import 'package:doctor_car_app/screens/about_screen.dart';
import 'package:doctor_car_app/screens/contact_screen.dart';
import 'package:doctor_car_app/screens/road_services_screen.dart';
// ignore: unused_import
import 'package:doctor_car_app/screens/luber_tracking_screen.dart';

// ignore: unused_import
import 'package:doctor_car_app/screens/select_location_screen.dart'
    show SelectLocationScreen;
import 'package:doctor_car_app/screens/settings_screen.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;

// شاشات التطبيق
import 'package:doctor_car_app/screens/account_settings_screen.dart';
import 'package:doctor_car_app/screens/smart_accident_screen.dart';
// ignore: unused_import
import 'package:doctor_car_app/screens/road_services_selection_screen.dart';
import 'package:doctor_car_app/screens/previous_services_screen.dart';
import 'package:doctor_car_app/screens/supplementary_services_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  // ====================================================
  // 🔥 AI SEARCH SYSTEM
  // ====================================================

  final TextEditingController _searchController = TextEditingController();

  /// 🔥 ضع مفتاح OpenAI هنا
  final String openAIApiKey =
      "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";

  bool isProcessingAI = false;

  // AI ENGINE — يحلل المشكلة ويرجع خدمة واحدة
  Future<String?> aiDiagnose(String problem) async {
    try {
      setState(() => isProcessingAI = true);

      final response = await http.post(
        Uri.parse("https://api.openai.com/v1/chat/completions"),
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer $openAIApiKey",
        },
        body: jsonEncode({
          "model": "gpt-3.5-turbo",
          "messages": [
            {
              "role": "system",
              "content":
                  "You are an automotive AI. Reply with ONLY ONE WORD from this list:\n"
                      "Battery, Tire, Fuel, Road, Emergency, Accident, Towing, Oil, Engine, Sensors, Brakes, Cooling, Transmission, Others."
            },
            {"role": "user", "content": problem}
          ]
        }),
      );

      if (response.statusCode != 200) {
        debugPrint("AI ERROR: ${response.body}");
        return null;
      }

      final data = jsonDecode(response.body);
      String result = data["choices"][0]["message"]["content"].trim();

      debugPrint("AI RAW RESULT = $result");
      return result;
    } catch (e) {
      debugPrint("AI EXCEPTION: $e");
      return null;
    } finally {
      setState(() => isProcessingAI = false);
    }
  }

  // تشغيل عند الضغط على السيرش
  void handleSearch() async {
    String query = _searchController.text.trim();
    if (query.isEmpty) return;

    FocusScope.of(context).unfocus();

    String? result = await aiDiagnose(query);

    if (result == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("AI Error — Try Again")),
      );
      return;
    }

    // خريطة تحويل النتائج
    final Map<String, String> map = {
      "Battery": "Battery",
      "Tire": "Tire",
      "Fuel": "Fuel",
      "Road": "Road Services",
      "Emergency": "Emergency",
      "Accident": "Accident",
      "Towing": "Towing",
      "Oil": "Oil",
      "Engine": "Engine",
      "Sensors": "Sensors",
      "Brakes": "Brakes",
      "Cooling": "Cooling",
      "Transmission": "Transmission",
      "Others": "Road Services",
    };

    String? finalService = map[result];

    debugPrint("FINAL SERVICE = $finalService");

    if (finalService == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Unknown Service Returned: $result")),
      );
      return;
    }

    openTracking(finalService);
  }

  // فتح صفحة التتبع
  void openTracking(String serviceType) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => UberTrackingScreen(
          userId: "68fe4505493ae17aa81d605b",
          serviceType: serviceType,
          selectedServices: const [],
          orderId: "",
        ),
      ),
    );
  }

  // ====================================================
  // 🔥 ANIMATIONS + UI SETTINGS
  // ====================================================

  late AnimationController waveCtrl;
  late AnimationController pulseCtrl;

  bool isArabic = true;
  bool darkMode = true;
  bool drawerOpen = false;

  String t(String ar, String en) => isArabic ? ar : en;

  Color get textColor =>
      darkMode ? Colors.white : const Color.fromARGB(255, 5, 43, 94);

  Color get bgColor =>
      darkMode ? const Color.fromARGB(255, 3, 55, 79) : Colors.white;

  @override
  void initState() {
    super.initState();

    waveCtrl =
        AnimationController(vsync: this, duration: const Duration(seconds: 3))
          ..repeat(reverse: true);

    pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
      lowerBound: 0.90,
      upperBound: 1.18,
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    waveCtrl.dispose();
    pulseCtrl.dispose();
    super.dispose();
  }

  // ====================================================
  // 🔥 DRAWER
  // ====================================================
  Widget drawerWidget(double w, BuildContext context) {
    return Container(
      width: w * 0.60,
      color: const Color(0xFF0B1120),
      padding: const EdgeInsets.only(top: 85, left: 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.directions_car, color: Colors.white, size: 55),
          const SizedBox(height: 18),
          Text(
            "Doctor Car",
            style: GoogleFonts.cairo(
              color: Colors.white,
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 35),

          /// ----------------------------
          /// ACTIVE & CLICKABLE MENU ITEMS
          /// ----------------------------

          drawerItem(
            icon: Icons.info,
            label: t("من نحن", "About Us"),
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const AboutScreen()),
              );
            },
          ),

          drawerItem(
            icon: Icons.phone,
            label: t("تواصل معنا", "Contact Us"),
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const ContactScreen()),
              );
            },
          ),

          drawerItem(
            icon: Icons.settings,
            label: t("الإعدادات", "Settings"),
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const SettingsScreen()),
              );
            },
          ),

          drawerItem(
            icon: Icons.history,
            label: t("السجل", "Previous Services"),
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => const PreviousServicesScreen()),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget drawerItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 14),
        child: Row(
          children: [
            Icon(icon, color: Colors.amber, size: 26),
            const SizedBox(width: 10),
            Text(
              label,
              style: GoogleFonts.cairo(color: Colors.white, fontSize: 18),
            ),
          ],
        ),
      ),
    );
  }

  // ====================================================
  // 🔥 SEARCH BOX
  // ====================================================

  Widget searchBox(double w) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: w * 0.06),
      child: Container(
        height: 55,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          border: Border.all(color: Colors.amber, width: 2),
          color: const Color.fromARGB(255, 93, 148, 196).withOpacity(0.25),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Row(
          children: [
            GestureDetector(
              onTap: handleSearch,
              child: const Icon(Icons.search, color: Colors.amber),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: TextField(
                controller: _searchController,
                onSubmitted: (_) => handleSearch(),
                style: GoogleFonts.cairo(color: textColor, fontSize: 17),
                decoration: InputDecoration(
                  border: InputBorder.none,
                  hintText: t("اكتب مشكلتك هنا...", "Describe your problem..."),
                  hintStyle:
                      GoogleFonts.cairo(color: textColor.withOpacity(0.5)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ====================================================
  // 🔥 FROSTED CARD
  // ====================================================

  Widget frostedCard(String title, IconData icon, VoidCallback onTap) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(22),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: GestureDetector(
          onTap: onTap,
          child: Container(
            height: 145,
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.25),
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: Colors.amber, width: 2),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, color: Colors.amber, size: 42),
                const SizedBox(height: 12),
                Text(title,
                    style: GoogleFonts.cairo(
                        color: textColor,
                        fontSize: 26,
                        fontWeight: FontWeight.bold)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ====================================================
  // 🔥 QUICK BUTTON
  // ====================================================

  Widget quickBtn(IconData icon, String label, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            width: 65,
            height: 65,
            decoration: BoxDecoration(
              color: Colors.amber,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: Colors.amber.withOpacity(0.35),
                  blurRadius: 25,
                  spreadRadius: 4,
                )
              ],
            ),
            child: Icon(icon, size: 30, color: Colors.black),
          ),
          const SizedBox(height: 0),
          Text(label, style: GoogleFonts.cairo(color: textColor, fontSize: 18)),
        ],
      ),
    );
  }

  // ====================================================
  // 🔥 PAGE CONTENT
  // ====================================================

  Widget content(double w) {
    return Scaffold(
      backgroundColor: const Color.fromARGB(0, 201, 187, 190),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.only(bottom: 200),
          child: Column(
            children: [
              const SizedBox(height: 12),

              // TOP BAR
              Padding(
                padding: EdgeInsets.symmetric(horizontal: w * 0.06),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    GestureDetector(
                        onTap: () => setState(() => drawerOpen = !drawerOpen),
                        child: const Icon(Icons.menu,
                            color: Colors.amber, size: 32)),
                    Row(
                      children: [
                        const Icon(Icons.directions_car,
                            color: Colors.amber, size: 30),
                        const SizedBox(width: 6),
                        Text("Doctor Car",
                            style: GoogleFonts.cairo(
                                color: textColor,
                                fontSize: 24,
                                fontWeight: FontWeight.bold)),
                      ],
                    ),
                    Row(
                      children: [
                        IconButton(
                          onPressed: () => setState(() => isArabic = !isArabic),
                          icon: const Icon(Icons.language,
                              color: Colors.amber, size: 28),
                        ),
                        IconButton(
                          onPressed: () => setState(() => darkMode = !darkMode),
                          icon: Icon(
                              darkMode ? Icons.light_mode : Icons.dark_mode,
                              color: Colors.amber,
                              size: 28),
                        ),
                      ],
                    )
                  ],
                ),
              ),

              const SizedBox(height: 20),

              // TITLE
              Text(
                t("التشخيص والخدمات الذكية", "Diagnostics & Smart Services"),
                style: GoogleFonts.cairo(
                    color: textColor,
                    fontSize: 22,
                    fontWeight: FontWeight.bold),
              ),

              const SizedBox(height: 22),

              // SEARCH
              searchBox(w),

              const SizedBox(height: 55),

              // BIG BUTTONS
              Padding(
                padding: EdgeInsets.symmetric(horizontal: w * 0.06),
                child: Row(
                  children: [
                    Expanded(
                      child: frostedCard(
                        t("خدمات الطريق", "Road Services"),
                        Icons.alt_route,
                        () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => const RoadServicesScreen(),
                            ),
                          );
                        },
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: frostedCard(
                        t("الطوارئ", "Emergency"),
                        Icons.emergency,
                        () => openTracking("Emergency"),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 28),

              Text(
                t("المساعدة والتشخيص المتقدمة",
                    "Advanced Assistance & Diagnosis"),
                style: GoogleFonts.cairo(
                    color: textColor,
                    fontWeight: FontWeight.bold,
                    fontSize: 20),
              ),

              const SizedBox(height: 22),

              // QUICK BUTTONS
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  quickBtn(Icons.history, t("السابقة", "Previous"), () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => const PreviousServicesScreen()));
                  }),
                  quickBtn(Icons.handyman, t("الدعم", "Support"), () {}),
                  quickBtn(Icons.more_horiz, t("المزيد", "More"), () async {
                    final r = await Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => const SupplementaryServicesScreen()),
                    );
                    if (r != null) openTracking(r["type"]);
                  }),
                  quickBtn(Icons.car_crash, t("حادث", "Accident"), () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => const SmartAccidentScreen()));
                  }),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ====================================================
  // 🔥 PAGE + BOTTOM NAV
  // ====================================================

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;

    return Directionality(
      textDirection: isArabic ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        backgroundColor: bgColor,
        body: Stack(
          children: [
            Positioned.fill(
                child: CustomPaint(painter: TopWavePainter(darkMode))),

            // Drawer
            AnimatedPositioned(
              duration: const Duration(milliseconds: 250),
              left: drawerOpen ? 0 : -w * 0.60,
              top: 0,
              bottom: 0,
              child: drawerWidget(w, context),
            ),

            // Main content animation
            AnimatedScale(
              scale: drawerOpen ? 0.88 : 1,
              duration: const Duration(milliseconds: 300),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                transform: Matrix4.translationValues(
                  drawerOpen ? w * 0.45 : 0,
                  drawerOpen ? h * 0.02 : 0,
                  0,
                ),
                child: content(w),
              ),
            ),
          ],
        ),

        // Bottom Bar
        bottomNavigationBar: SizedBox(
          height: 175,
          child: Stack(
            alignment: Alignment.center,
            clipBehavior: Clip.none,
            children: [
              Positioned.fill(
                child: AnimatedBuilder(
                  animation: waveCtrl,
                  builder: (_, __) =>
                      CustomPaint(painter: BottomWavePainter(waveCtrl.value)),
                ),
              ),
              Positioned(
                top: 20,
                child: ScaleTransition(
                  scale: pulseCtrl,
                  child: Container(
                    width: 95,
                    height: 95,
                    decoration: BoxDecoration(
                      color: Colors.amber,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                            color: Colors.amber.withOpacity(0.5),
                            blurRadius: 55,
                            spreadRadius: 10)
                      ],
                    ),
                    child:
                        const Icon(Icons.call, color: Colors.black, size: 40),
                  ),
                ),
              ),
              Positioned(
                top: 120,
                child: Text(
                  t("اتصال سريع", "Quick Call"),
                  style: GoogleFonts.cairo(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 18),
                ),
              ),
              Positioned(
                bottom: 25,
                left: 35,
                child: bottomNavBtn(Icons.person, t("حسابي", "Account"), () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const AccountSettingsScreen()),
                  );
                }),
              ),
              Positioned(
                bottom: 25,
                right: 35,
                child: bottomNavBtn(Icons.home, t("الرئيسية", "Home"), () {}),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget bottomNavBtn(IconData icon, String label, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              color: const Color.fromARGB(255, 47, 173, 223).withOpacity(0.25),
              shape: BoxShape.circle,
              border: Border.all(color: Colors.amber, width: 2),
              boxShadow: [
                BoxShadow(color: Colors.amber.withOpacity(0.25), blurRadius: 20)
              ],
            ),
            child: Icon(icon, color: Colors.amber, size: 30),
          ),
          const SizedBox(height: 6),
          Text(
            label,
            style: GoogleFonts.cairo(color: Colors.white, fontSize: 15),
          ),
        ],
      ),
    );
  }
}

// ====================================================
// 🔥 PAINTERS
// ====================================================

class TopWavePainter extends CustomPainter {
  final bool dark;
  TopWavePainter(this.dark);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..shader = LinearGradient(
        colors: dark
            ? [
                const Color.fromARGB(255, 56, 122, 149),
                const Color.fromARGB(255, 18, 95, 163)
              ]
            : [Colors.white, Colors.grey.shade300],
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));

    final path = Path();
    path.moveTo(0, size.height * 0.35);
    path.quadraticBezierTo(size.width * 0.30, size.height * 0.48,
        size.width * 0.55, size.height * 0.40);
    path.quadraticBezierTo(
        size.width * 0.90, size.height * 0.30, size.width, size.height * 0.45);
    path.lineTo(size.width, 0);
    path.lineTo(0, 0);

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(_) => true;
}

class BottomWavePainter extends CustomPainter {
  final double t;
  BottomWavePainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    double shift = 25 * t;

    final paint = Paint()
      ..shader = const LinearGradient(
        colors: [
          Colors.black,
          Colors.black,
          Color.fromARGB(40, 255, 191, 0),
        ],
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
      ).createShader(const Rect.fromLTWH(0, 0, 0, 0));

    Path path = Path();

    path.moveTo(0, 45 + shift);
    path.quadraticBezierTo(
        size.width * 0.25, 5 + shift, size.width * 0.50, 35 + shift);
    path.quadraticBezierTo(
        size.width * 0.85, 75 + shift, size.width, 40 + shift);

    path.lineTo(size.width, size.height);
    path.lineTo(0, size.height);
    path.close();

    final glow = Paint()
      ..color = Colors.amber.withOpacity(0.15)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 45);

    canvas.drawCircle(Offset(size.width / 2, 45 + shift), 140, glow);

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(_) => true;
}
