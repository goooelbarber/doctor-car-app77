import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool darkMode = true;
  bool notifications = true;
  bool gps = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0B1120),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: false,

        /// 🔙 زر رجوع شغال 100%
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),

        title: Text(
          "Settings",
          style: GoogleFonts.cairo(
            fontSize: 24,
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          children: [
            settingItem(
              icon: Icons.dark_mode,
              title: "Dark Mode",
              value: darkMode,
              onChange: (v) => setState(() => darkMode = v),
            ),
            settingItem(
              icon: Icons.notifications_active,
              title: "Notifications",
              value: notifications,
              onChange: (v) => setState(() => notifications = v),
            ),
            settingItem(
              icon: Icons.location_on,
              title: "GPS Services",
              value: gps,
              onChange: (v) => setState(() => gps = v),
            ),
          ],
        ),
      ),
    );
  }

  /// 🔧 عنصر الإعداد الواحد
  Widget settingItem({
    required IconData icon,
    required String title,
    required bool value,
    required Function(bool) onChange,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 18),
      decoration: BoxDecoration(
        color: const Color(0xFF1B2436),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white12),
      ),
      child: Row(
        children: [
          Icon(icon, size: 28, color: Colors.amber),
          const SizedBox(width: 15),
          Expanded(
            child: Text(
              title,
              style: GoogleFonts.cairo(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          Switch(
            value: value,
            activeColor: Colors.amber,
            onChanged: onChange,
          ),
        ],
      ),
    );
  }
}
